#!/bin/bash
echo "Installing Redis";
echo "Redis home folder for now is $REDISHOME_DIR";

DB_DIR=$REDISHOME_DIR/databases;
echo "Create the DB directory $DB_DIR";
mkdir -m 0570 -p -v -Z $DB_DIR;
chown $DEF_USER:root $DB_DIR -R;

cd $INSTALL_TEMP_DIR;
echo "Download Redis to the temp directory $INSTALL_TEMP_DIR";
wget http://download.redis.io/redis-stable.tar.gz;
tar xzf redis-stable.tar.gz;

echo "Copy Redis to the Redis home directory $REDISHOME_DIR";
cp -r $INSTALL_TEMP_DIR/redis-stable/* $REDISHOME_DIR/;
chown $DEF_USER:root $REDISHOME_DIR -R;
chmod -R 2770 $REDISHOME_DIR;

echo "Exec make and make test commands from $REDISHOME_DIR";
cd $REDISHOME_DIR;
make;
make test;
pause;

cd $INSTALL_TEMP_DIR;
#replace the REDISHOME_DIR into the config files
echo "Replace ENV variables into the Redis configuration files";
sed -i "s|$\REDISHOME_DIR|$REDISHOME_DIR|g" $INSTALL_TEMP_DIR/redis/conf/*.*;

#copy Redis and Sentinel configuration files
echo "Copy the Redis configuration files from $INSTALL_TEMP_DIR/redis/ to the Redis home folder";
cp -ar $INSTALL_TEMP_DIR/redis/* $REDISHOME_DIR/;
chown $DEF_USER:root $REDISHOME_DIR -R;
chmod -R 0570 $REDISHOME_DIR;
chmod 2770 $REDISHOME_DIR/conf/sentinel*.*; #sentinel can write to config files

echo "Copy the the Redis configuration for MONIT tool to /etc/monit/conf.d/redis.monit";
rm -rf /var/lib/monit/events;
rm -rf /etc/monit/conf.d/*redis*.*;
cp -ar $REDISHOME_DIR/conf/redis.monit /etc/monit/conf.d/;
chown root:root /etc/monit/conf.d/redis.monit;
chmod 2750 /etc/monit/conf.d/redis.monit;

pause;

echo "Run the Redis on vps startup to $REDISHOME_DIR/startup_redis_sh";
chown $DEF_USER:root $REDISHOME_DIR/startup_redis_sh;
chmod 2570 $REDISHOME_DIR/startup_redis_sh;
sudo crontab -l | { cat; echo "@reboot $REDISHOME_DIR/startup_redis_sh"; } | sudo crontab -;

echo "Redis was installed";