#!/bin/bash
echo -n "Stop(y) or start(n)? "
read answer
if echo "$answer" | grep -iq "^y" ;then
    	echo "stop";	
	sudo iptables-save > $HOME/iptablesrules.txt;
	sudo iptables -X;
	sudo iptables -F;
	sudo iptables -t nat -F;
	sudo iptables -t nat -X;
	sudo iptables -t mangle -F;
	sudo iptables -t mangle -X;
	sudo iptables -P INPUT ACCEPT;
	sudo iptables -P FORWARD ACCEPT;
	sudo iptables -P OUTPUT ACCEPT;
else
    echo "start";
	sudo iptables-restore < $HOME/iptablesrules.txt;
fi