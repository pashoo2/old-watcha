#!/bin/bash
#http://0pointer.de/blog/projects/resources.html

apt-get install unzip;

echo "Add user for HTTP SERVER";
adduser $HTTP_SERVER_USER;
adduser $HTTP_SERVER_USER $DEF_USER;

echo "Installing the NVM";
apt-get install python-software-properties;
apt-get install build-essential libssl-dev;

NVM_INSTALL=$INSTALL_TEMP_DIR/install_nvm.sh;
echo '' > $NVM_INSTALL;
chmod +x $NVM_INSTALL;
wget -O $NVM_INSTALL https://raw.githubusercontent.com/creationix/nvm/v0.32.1/install.sh;
sed -i "s|$\HOME|$HOME_DIR|g" $NVM_INSTALL;
bash $NVM_INSTALL;
export NVM_DIR="$HOME_DIR/.nvm";
[ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh";
echo "Installing the latest stable Node JS";
nvm install --lts;
nvm use --lts;
NODE_EXEC_PATH=$(which node); #define the nodejs executable path
echo "Node exec path = $NODE_EXEC_PATH";

if ! [[ -v NODE_EXEC_PATH ]] || [[ -z $NODE_EXEC_PATH ]]; then
	echo "Please enter the path to the node bin:";
	read NODE_EXEC_PATH;
else

chown -R $DEF_USER:$DEF_USER $NVM_DIR;
pause;

sed -i "s|$\NODE_EXEC_PATH|$NODE_EXEC_PATH|g" $INSTALL_TEMP_DIR/nodejs/*.*;
sed -i "s|$\DEF_USER|$DEF_USER|g" $INSTALL_TEMP_DIR/nodejs/*.*;
sed -i "s|$\NODESCRIPTHOME_DIR|$NODESCRIPTHOME_DIR|g" $INSTALL_TEMP_DIR/nodejs/*.*;
sed -i "s|$\HTTP_SERVER_USER|$HTTP_SERVER_USER|g" $INSTALL_TEMP_DIR/nodejs/*.*;

mkdir -p $NODESCRIPTHOME_DIR/server/ $NODESCRIPTHOME_DIR/server/cert/; 
cp $INSTALL_TEMP_DIR/nodejs/scripts/gserver.zip $NODESCRIPTHOME_DIR/;
unzip $NODESCRIPTHOME_DIR/gserver.zip -d $NODESCRIPTHOME_DIR/;
rm $NODESCRIPTHOME_DIR/gserver.zip;
#set permissions and owner for a node files
chown -R $DEF_USER:$DEF_USER $NODESCRIPTHOME_DIR;
chmod 710 $NODESCRIPTHOME_DIR/ -R;

cp -ar $INSTALL_TEMP_DIR/nodejs/cert/*.* $NODESCRIPTHOME_DIR/server/cert/;

chown -R $DEF_USER:$DEF_USER $NODESCRIPTHOME_DIR/server;
#only the default user have all permissions for the server directory
chmod 710 $NODESCRIPTHOME_DIR/server/ -R;
chmod 750 $NODESCRIPTHOME_DIR/server/settings/ -R;
chmod 750 $NODESCRIPTHOME_DIR/server/node_modules/ -R;
chmod 750 $NODESCRIPTHOME_DIR/server/sh/startWebServer.js;

mkdir -p $NODESCRIPTHOME_DIR/client;
chown -R $DEF_USER:$DEF_USER $NODESCRIPTHOME_DIR/client;
#only the default user have all permissions for the server directory, nodeuser can execute and read files, but can't write anything here
chmod 750 $NODESCRIPTHOME_DIR/client/ -R;

#create directory for http server logs
HTTP_SERVER_LOGS_DIR=$NODESCRIPTHOME_DIR/client/logs/;
echo "Directory for HTTP SERVER logs is $HTTP_SERVER_LOGS_DIR";
mkdir -p $HTTP_SERVER_LOGS_DIR;
chown -R $HTTP_SERVER_USER:$DEF_USER $HTTP_SERVER_LOGS_DIR/;
chmod 770 $HTTP_SERVER_LOGS_DIR/ -R;

echo "install gServer as a service";
cp $INSTALL_TEMP_DIR/nodejs/gserverapp.service /lib/systemd/system/;
systemctl enable gserverapp.service;
systemctl start gserverapp.service;

echo "install HTTP SERVER as a service";
cp $INSTALL_TEMP_DIR/nodejs/ghttpserver.service /lib/systemd/system/;
systemctl enable ghttpserver.service;
systemctl start ghttpserver.service;

echo 'Installing AppArmor.';
apt-get -y install apparmor apparmor-profiles apparmor-utils;

echo '
	Autoconfigure nodejs profile in AppArmor:
	When all nodejs modules will be installed and the application was deployed do this:
	1)type under the non-root user: which node
	2)cd /etc/apparmor.d/
	3)aa-autodep "type here the result from 1)";
	for automatically compilaion the nodejs rules
	Then: 
	1) make the application full test
	2)When all the available tests will be done use: "aa-complain nginx"
	3)Approve all rules by: "aa-logprof"
	4) edit profile by "nano /etc/apparmor.d/usr.sbin.nginx"
	after the nodejs actions will be approved';