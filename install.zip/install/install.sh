#!/bin/bash

#https://certsimple.com/blog/deploy-node-on-linux

pause(){
 read -n1 -rsp $'Press any key to continue or Ctrl+C to exit...\n';
}

export ETH_INTERFACE=ens3; 
export DEF_SSHPORT=6754;
export DEF_USER=user;
export HOME_DIR=/home/$DEF_USER;
export WS_PORT=8888;
export HTTP_SERVER_USER=nodeuser; #user for hhtp server
export INSTALLATION_DIR=$(dirname "${BASH_SOURCE[0]}");

echo "Add the new user $DEF_USER and the gorup $DEF_USER";
adduser $DEF_USER;
groupadd $DEF_USER;
usermod -aG sudo $DEF_USER;
usermod -aG $DEF_USER $DEF_USER;
chown $DEF_USER:$DEF_USER $HOME_DIR;

echo "Set the default folder $HOME_DIR for the user $DEF_USER"; 
usermod -d $HOME_DIR $DEF_USER;
dpkg-statoverride --update --add root $DEF_USER 4750 /bin/su;

echo "Set the user as thew owner for installation directory";
chown -R $DEF_USER:$DEF_USER $INSTALLATION_DIR;

echo "Export variables DEF_USER, DEF_SSHPORT, HOME_DIR, SCRIPT_PATH, NVMHOME_DIR, NODESCRIPTHOME_DIR, REDISHOME_DIR, INSTALL_TEMP_DIR";
echo "Variables that will be available after the system start is DEF_USER, HOME_DIR, REDISHOME_DIR, NVMHOME_DIR";

echo "Creating the default folders";

USER_BIN_PATH=$HOME_DIR/bin;
if [[ ! -d $USER_BIN_PATH ]]; then
	mkdir -m 0770 -p -v -Z $USER_BIN_PATH;
	echo "Create USER_BIN_PATH=$USER_BIN_PATH with the permissions for the current user";
fi
chown -R $DEF_USER:$DEF_USER $USER_BIN_PATH;
echo "Home path for the user scripts is $USER_BIN_PATH";

export NVMHOME_DIR=$USER_BIN_PATH/nvm/;
if [ ! -d $NVMHOME_DIR ]; then
	mkdir -m 0750 -p -v -Z $NVMHOME_DIR;
	echo "Create NVMHOME_DIR=$NVMHOME_DIR with the permissions for the current user";
fi
chown -R $DEF_USER:root $NVMHOME_DIR;
echo "Home path for NVM is $NVMHOME_DIR";

export NODESCRIPTHOME_DIR=$USER_BIN_PATH/gnodescript;
if [[ ! -d $NODESCRIPTHOME_DIR ]]; then
	mkdir -m 0750 -p -v -Z $NODESCRIPTHOME_DIR;
	echo "Create REDISHOME_DIR=$REDISHOME_DIR with the permissions for the current user";
fi
chown -R $DEF_USER:root $NODESCRIPTHOME_DIR;
echo "Home path for NodeJS scripts is $NODESCRIPTHOME_DIR";

export REDISHOME_DIR=$USER_BIN_PATH/gredis;
if [ ! -d $REDISHOME_DIR ]; then
	mkdir -m 0770 -p -v -Z $REDISHOME_DIR;
	echo "Create REDISHOME_DIR=$REDISHOME_DIR with the permissions for the current user";
fi
chown -R $DEF_USER:root $NODESCRIPTHOME_DIR;
echo "Home path for Redis is $REDISHOME_DIR";

export INSTALL_TEMP_DIR=$HOME_DIR/tmp/installscript;
if [ ! -d $INSTALL_TEMP_DIR ]; then
	mkdir -m 0770 -p -v -Z $INSTALL_TEMP_DIR;
	echo "Create temporary installation folder $INSTALL_TEMP_DIR";
	echo "Create INSTALL_TEMP_DIR=$INSTALL_TEMP_DIR with the permissions for the current user";
fi
chown -R $DEF_USER:$DEF_USER $INSTALL_TEMP_DIR;
chmod -R 0750 $INSTALL_TEMP_DIR;

#copy all from this folder to the destination folder
echo "Copy all installation files to the temporary installation folder $INSTALL_TEMP_DIR";
cp -avr $INSTALLATION_DIR/* $INSTALL_TEMP_DIR/;

echo "Do you whant to configure only the iptables(Y)?";
read xx;
if [[ "$xx" = "Y" ]]; then
	iptables -F;
	. $INSTALL_TEMP_DIR/settingup_iptables.sh;
	rm -rf $INSTALL_TEMP_DIR;
	exit;
fi;

echo "Do you whant to install nvm, nodejs and all the scripts(Y)?";
read x;
if [[ "$x" = "Y" ]]; then
	#install nodejs
	echo "temporary disable iptables rules";
	iptables -F;
	. $INSTALL_TEMP_DIR/nvm_install.sh;
	echo "Installation of NodeJS was competed. Remove the temporary folder";
	rm -rf $INSTALL_TEMP_DIR;
	exit;
fi;

apt-get update;
apt-get upgrade;

apt-get install -y gcc;
apt-get install -y build-essential;
apt-get install -y make;

pause;

# add the export variables to the init
echo "Add the export variables to /etc/environment DEF_USER,REDISHOME_DIR,NODESCRIPTHOME_DIR";
echo -e "\nDEF_USER=$DEF_USER\nREDISHOME_DIR=$REDISHOME_DIR\nNODESCRIPTHOME_DIR=$NODESCRIPTHOME_DIR" >> /etc/environment;

# # set to use the UTC timezone on the server
echo "Set UTC timezone as the default on the server";
rm /etc/localtime;
ln -s /usr/share/zoneinfo/UTC /etc/localtime;

pause;

echo "Make the swipe file /swapfile with the size of 16Gb";
dd if=/dev/zero of=/swapfile bs=1G count=16;
chmod 600 /swapfile;
ls -lh /swapfile;
mkswap /swapfile;
swapon /swapfile;
swapon -s;

pause;

echo "Install cron";
apt-get install cron;
service cron start;

echo "Secure shared memory";
echo -e "\ntmpfs /run/shm tmpfs defaults,noexec,nosuid 0 0" >> /etc/fstab;

echo "Prevent IP Spoofing";
echo -e "\norder bind,hosts" >> /etc/host.conf;
echo -e "nospoof on" >> /etc/host.conf;

pause;

echo "setting up /etc/sysctl.conf and disable ipv6 by a settings from the sysctl.conf";
cat $INSTALL_TEMP_DIR/sysctl.conf >> /etc/sysctl.conf;
sysctl -p; #relod the conf

echo "install prelink and configure /etc/cron.daily/prelink";
apt-get -y install prelink;
sed -i 's/PRELINKING=unknown/PRELINKING=YES/g' /etc/cron.daily/prelink;
/etc/cron.daily/prelink;
echo "install preload";
apt-get -y install preload;
	
echo "Mount the additional drive";
( mkdir -p /mnt/vdb | (
 mkfs.ext4 /dev/vdb;
	mount /dev/vdb /mnt/vdb;
	echo -e "\n/dev/vdb /mnt/vdb ext4 defaults 0 1">>/etc/fstab; ) ) || echo "There is no available additional drives in /dev/vdb";

echo "Install and setting up the backup system";
apt-get -y install rsync;
mkdir /mnt/vdb/backup;
chown $DEF_USER:root /mnt/vdb/backup;
chmod 0470 /mnt/vdb/backup;

#install monit to monitoring for redis and nodejs processes
apt-get install monit;
echo "Monit was installed, logs are available in /var/log/monit.log";
monit stop all;

#install Redis

. $INSTALL_TEMP_DIR/redis_install.sh;
	
echo "Add an hourly cronjobs";
cp $INSTALL_TEMP_DIR/cronjob_hourly /etc/cron.hourly;
chown root:root /etc/cron.hourly/cronjob_hourly;
chmod 0750 /etc/cron.hourly/cronjob_hourly;

echo "install fail2ban";
apt-get install fail2ban;
sed -i "s|$\DEF_SSHPORT|$DEF_SSHPORT|g" $INSTALL_TEMP_DIR/jail.local;
cp $INSTALL_TEMP_DIR/jail.local /etc/fail2ban/jail.local;
chown root:root /etc/fail2ban/jail.local;
chmod 700 /etc/fail2ban/jail.local;
service fail2ban restart;

pause;

echo "Configuring ssh!";
echo "Change the port for ssh and the default user.";
sed -i "s|$\DEF_SSHPORT|$DEF_SSHPORT|g" $INSTALL_TEMP_DIR/sshd_config;
sed -i "s|$\DEF_USER|$DEF_USER|g" $INSTALL_TEMP_DIR/sshd_config;
echo "The port is $DEF_SSHPORT, the user is $DEF_USER";
cp $INSTALL_TEMP_DIR/sshd_config /etc/ssh/sshd_config;
chown root:root /etc/ssh/sshd_config;
chmod 750 /etc/ssh/sshd_config;

pause;

echo "Install nmap if you wish";
echo "Install rkhunter and chkrootkit";
echo "Append IPV6_DISABLE=1 to the GRUB_CMDLINE_LINUX variable in /etc/default/grub. Run update-grub and reboot.";


#reboot;

#echo "Install webmin";
##add-apt-repository "deb http://webmin.mirror.somersettechsolutions.co.uk/repository sarge contrib";
##add-apt-repository "deb http://download.webmin.com/download/repository sarge contrib";
##apt-get update;
##wget -q http://www.webmin.com/jcameron-key.asc -O- | apt-key add -;
##apt-get update;
##apt-get install webmin;
##sed -i 's/port=10000/port=7658/g' /etc/webmin/miniserv.conf;
##echo "Webmin was installed on the default port 7658 (or 10000)";

###found open ports
###apt-get -y install nmap;
###echo "List of an open ports:";
###nmap -v -sT localhost;
###echo "SYN scanning:";
###nmap -v -sS localhost;

### apt-get -y install rkhunter chkrootkit;
### chkrootkit;
### rkhunter --update;
###rkhunter --propupd;
### rkhunter --check;

#pause;

##service ssh restart;
##systemctl reload sshd;

#echo "Copy the startup scripts";
#mv $INSTALL_TEMP_DIR/project.init /etc/init/project_init;
#chmod 755 /etc/init/project_init;
#crontab -l | { cat; echo "@reboot /etc/init/project_init"; } | crontab -;