#!/bin/bash

OAUTH_SERVERS="www.googleapis.com googleapis.com apis.live.net login.live.com apis.live.net graph.microsoft.com login.microsoftonline.com graph.facebook.com";

apt-get install -y iptables-persistent;

IPT=/sbin/iptables;

if [[ -v ETH_INTERFACE ]] || [[ -z $ETH_INTERFACE ]]; then
	export ETH_INTERFACE=ens3;
fi

if [[ -v DEF_SSHPORT ]] || [[ -z $DEF_SSHPORT ]]; then
	export DEF_SSHPORT=7111;
fi

echo "The network interface is $ETH_INTERFACE.";
echo "The SSH port is $DEF_SSHPORT.";

#remove all the previous
$IPT -F;

# We don't break the established connections
# iptables -A INPUT -m state --state RELATED,ESTABLISHED -j ACCEPT;
# iptables -A OUTPUT -m state --state RELATED,ESTABLISHED -j ACCEPT;
# echo "Established connections allowed";

# Authorizes the incoming and outgoing traffic on the loopback network interface (IP : 127.0.0.1)
$IPT -A INPUT  -i lo -j ACCEPT;
$IPT -A OUTPUT -o lo -j ACCEPT;
echo "Loopback traffic allowed";

#
# Allow outgoing pings
$IPT -A OUTPUT -o $ETH_INTERFACE -p icmp -j ACCEPT;

#DNS
$IPT -A OUTPUT -o $ETH_INTERFACE -p udp --dport 53 -j ACCEPT;
$IPT -A INPUT  -i $ETH_INTERFACE -p udp -d watchasn.com --sport 53 -j ACCEPT;


#
# Allow TCP connections on tcp port 80, 8080, 443, $DEF_SSHPORT
#
$IPT -A INPUT -i $ETH_INTERFACE -p tcp --sport 80 -d watchasn.com --dport 80 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT;
$IPT -A OUTPUT -o $ETH_INTERFACE -p tcp --sport 80 --dport 80 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT;
$IPT -A INPUT -i $ETH_INTERFACE -p tcp --sport 1024:65535 -d watchasn.com --dport 8080 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT;
$IPT -A OUTPUT -o $ETH_INTERFACE -p tcp --sport 8080 --dport 1024:65535 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT;
$IPT -A INPUT -i $ETH_INTERFACE -p tcp --sport 443 -d watchasn.com --dport 443 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT;
$IPT -A OUTPUT -o $ETH_INTERFACE -p tcp --sport 443 --dport 443 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT;

#for a websocket connections
echo "Enable $WS_PORT for a web socket connections";
$IPT -A INPUT -i $ETH_INTERFACE -p tcp --dport $WS_PORT -j ACCEPT;
$IPT -A OUTPUT -o $ETH_INTERFACE -p tcp --sport $WS_PORT -j ACCEPT;


#webmin
#$IPT -A INPUT -p tcp  --dport  7658 -m state --state NEW,ESTABLISHED -j ACCEPT;
#$IPT -A OUTPUT -p tcp --sport  7658 -m state --state ESTABLISHED -j ACCEPT;

#ssh
$IPT -A INPUT -i $ETH_INTERFACE -p tcp --dport $DEF_SSHPORT -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT;
$IPT -A OUTPUT -o $ETH_INTERFACE -p tcp --sport $DEF_SSHPORT -m conntrack --ctstate ESTABLISHED -j ACCEPT;

#ftp backup
#echo "ftp allowed for your ip = 144.217.6.83/32 and ftp ftpback-bhs1-98.ip-198-100-151.net";
#$IPT -A INPUT  -d 144.217.6.83/32 -s ftpback-bhs1-98.ip-198-100-151.net -p tcp -m tcp --sport 21 -m conntrack --ctstate ESTABLISHED -j ACCEPT 
#$IPT -A INPUT  -d 144.217.6.83/32 -s ftpback-bhs1-98.ip-198-100-151.net -p tcp -m tcp --sport 20 --dport 1024: -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT 
#$IPT -A INPUT  -d 144.217.6.83/32 -s ftpback-bhs1-98.ip-198-100-151.net -p tcp -m tcp --sport 1024: --dport 1024: -m conntrack --ctstate ESTABLISHED -j ACCEPT 
#$IPT -A OUTPUT -s 144.217.6.83/32 -d ftpback-bhs1-98.ip-198-100-151.net -p tcp -m tcp --dport 21 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
#$IPT -A OUTPUT -s 144.217.6.83/32 -d ftpback-bhs1-98.ip-198-100-151.net -p tcp -m tcp --dport 20 -m conntrack --ctstate ESTABLISHED -j ACCEPT 
#$IPT -A OUTPUT -s 144.217.6.83/32 -d ftpback-bhs1-98.ip-198-100-151.net -p tcp -m tcp --sport 1024:65535 --dport 1024:65535 -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

#REROUTE from 80 to 8080
$IPT -t nat -I PREROUTING -i $ETH_INTERFACE -p tcp --dport 80 -j REDIRECT --to-ports 8080;

########################
########ANTI DDOS########
########################

#reject traffic to localhost that does not originate from lo0
#$IPT -t filter -A INPUT ! -i lo -s 127.0.0.0/8 -j LOG --log-prefix -j LOG_DROP1;

echo "rule 1";
### 1: Drop invalid packets ###
$IPT -t mangle -A PREROUTING -m conntrack --ctstate INVALID -j DROP;

echo "rule 2";
### 2: Drop TCP packets that are new and are not SYN ###
$IPT -t mangle -A PREROUTING -p tcp ! --syn -m conntrack --ctstate NEW -j DROP;

echo "rule 3";
### 3: Drop SYN packets with suspicious MSS value ###
$IPT -t mangle -A PREROUTING -p tcp -m conntrack --ctstate NEW -m tcpmss ! --mss 536:65535 -j DROP;

echo "rule 4";
### 4: Block packets with bogus TCP flags ###
$IPT -t mangle -A PREROUTING -p tcp --tcp-flags FIN,SYN,RST,PSH,ACK,URG NONE -j DROP;
$IPT -t mangle -A PREROUTING -p tcp --tcp-flags FIN,SYN FIN,SYN -j DROP;
$IPT -t mangle -A PREROUTING -p tcp --tcp-flags SYN,RST SYN,RST -j DROP;
$IPT -t mangle -A PREROUTING -p tcp --tcp-flags SYN,FIN SYN,FIN -j DROP;
$IPT -t mangle -A PREROUTING -p tcp --tcp-flags FIN,RST FIN,RST -j DROP;
$IPT -t mangle -A PREROUTING -p tcp --tcp-flags FIN,ACK FIN -j DROP;
$IPT -t mangle -A PREROUTING -p tcp --tcp-flags ACK,URG URG -j DROP;
$IPT -t mangle -A PREROUTING -p tcp --tcp-flags ACK,FIN FIN -j DROP;
$IPT -t mangle -A PREROUTING -p tcp --tcp-flags ACK,PSH PSH -j DROP;
$IPT -t mangle -A PREROUTING -p tcp --tcp-flags ALL ALL -j DROP;
$IPT -t mangle -A PREROUTING -p tcp --tcp-flags ALL NONE -j DROP;
$IPT -t mangle -A PREROUTING -p tcp --tcp-flags ALL FIN,PSH,URG -j DROP;
$IPT -t mangle -A PREROUTING -p tcp --tcp-flags ALL SYN,FIN,PSH,URG -j DROP;
$IPT -t mangle -A PREROUTING -p tcp --tcp-flags ALL SYN,RST,ACK,FIN,URG -j DROP;

echo "rule 5";
### 5: Block spoofed packets ###
$IPT -t mangle -A PREROUTING -s 224.0.0.0/3 -j DROP;
$IPT -t mangle -A PREROUTING -s 169.254.0.0/16 -j DROP;
$IPT -t mangle -A PREROUTING -s 172.16.0.0/12 -j DROP;
$IPT -t mangle -A PREROUTING -s 192.0.2.0/24 -j DROP;
$IPT -t mangle -A PREROUTING -s 192.168.0.0/16 -j DROP;
$IPT -t mangle -A PREROUTING -s 10.0.0.0/8 -j DROP;
$IPT -t mangle -A PREROUTING -s 0.0.0.0/8 -j DROP;
$IPT -t mangle -A PREROUTING -s 240.0.0.0/5 -j DROP;
$IPT -t mangle -A PREROUTING -s 127.0.0.0/8 ! -i lo -j DROP;

echo "rule 6";
### 6: Drop ICMP (you usually don't need this protocol) ###
$IPT -t mangle -A PREROUTING -p icmp -j DROP;

echo "rule 7";
### 7: Drop fragments in all chains ###
$IPT -t mangle -A PREROUTING -f -j DROP;

echo "rule 8";
### 8: Limit connections per source IP ###
$IPT -A INPUT -p tcp -m connlimit --connlimit-above 111 -j REJECT --reject-with tcp-reset;

echo "rule 9";
### 9: Limit RST packets ###
$IPT -A INPUT -p tcp --tcp-flags RST RST -m limit --limit 2/s --limit-burst 2 -j ACCEPT;
$IPT -A INPUT -p tcp --tcp-flags RST RST -j DROP;

echo "rule 10";
### 10: Limit new TCP connections per second per source IP ###
$IPT -A INPUT -p tcp -m conntrack --ctstate NEW -m limit --limit 60/s --limit-burst 20 -j ACCEPT;
$IPT -A INPUT -p tcp -m conntrack --ctstate NEW -j DROP;

echo "rule 11";
### 11: Use SYNPROXY on all ports (disables connection limiting rule) ###
#$IPT -t raw -A PREROUTING -p tcp -m tcp --syn -j CT --notrack;
#$IPT -A INPUT -p tcp -m tcp -m conntrack --ctstate INVALID,UNTRACKED -j SYNPROXY --sack-perm --timestamp --wscale 7 --mss 1460;
#$IPT -A INPUT -m conntrack --ctstate INVALID -j DROP;

echo "rule ssh brute-force protection";
### SSH brute-force protection ###
$IPT -A INPUT -p tcp --dport $DEF_SSHPORT -m conntrack --ctstate NEW -m recent --set;
$IPT -A INPUT -p tcp --dport $DEF_SSHPORT -m conntrack --ctstate NEW -m recent --update --seconds 60 --hitcount 10 -j DROP;

echo "rule ssh protection against port scanning";
### Protection against port scanning ###
$IPT -N port-scanning;
$IPT -A port-scanning -p tcp --tcp-flags SYN,ACK,FIN,RST RST -m limit --limit 1/s --limit-burst 2 -j RETURN;
$IPT -A port-scanning -j DROP;

#echo "reject traffic to localhost that does not originate from lo";
#reject traffic to localhost that does not originate from lo
$IPT -A INPUT ! -i lo -s 127.0.0.0/8 -j DROP;

#OAUTH
for ip in $OAUTH_SERVERS
do
	echo "Allow connection to '$ip' on port 21"
	$IPT -A OUTPUT -o $ETH_INTERFACE -p tcp -d "$ip" --dport 21  -m state --state NEW,ESTABLISHED -j ACCEPT;
	$IPT -A INPUT  -i $ETH_INTERFACE -p tcp -s "$ip" --sport 21  -m state --state ESTABLISHED     -j ACCEPT;

	echo "Allow connection to '$ip' on port 80"
	$IPT -A OUTPUT -o $ETH_INTERFACE -p tcp -d "$ip" --dport 80  -m state --state NEW,ESTABLISHED -j ACCEPT;
	$IPT -A INPUT -i $ETH_INTERFACE  -p tcp -s "$ip" --sport 80  -m state --state ESTABLISHED     -j ACCEPT;

	echo "Allow connection to '$ip' on port 443"
	$IPT -A OUTPUT -o $ETH_INTERFACE -p tcp -d "$ip" --dport 443 -m state --state NEW,ESTABLISHED -j ACCEPT;
	$IPT -A INPUT -i $ETH_INTERFACE  -p tcp -s "$ip" --sport 443 -m state --state ESTABLISHED     -j ACCEPT;
done

######################
# Default Policy DROP#
###################v##

#with logging
$IPT -N LOGGING;
$IPT -A INPUT -j LOGGING;
$IPT -A OUTPUT -j LOGGING;
$IPT -A FORWARD -j LOGGING;
$IPT -A LOGGING -m limit --limit 2/min -j LOG --log-prefix "IPTables-Dropped" --log-level 4;
$IPT -A LOGGING -j DROP;

#without logging
#$IPT -A INPUT -j DROP;
#$IPT -A OUTPUT -j DROP
#$IPT -A FORWARD -j DROP;


rm /etc/iptables/rules.v4;
iptables-save > /etc/iptables/rules.v4;