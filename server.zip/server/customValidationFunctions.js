var common = require("./common.js");
var dbGeo = require("./dbGeo.js");
var hashes = require("./hashes.js");
var messages = require("./messagesHandlers.js");

var Promise = require("bluebird");

//functions from libraries
var calculateNearestLHFByLocationHashOrLHF = hashes.calculateNearestLHFByLocationHashOrLHF;
var isLocationHashByFingerprint = hashes.decodeAndCheckLHFByFingerprint;
var getLocationsByLS = dbGeo.getLocationsByLS;
var isArray = common.isArray;
var toInt = common.strToInt;
var hasProperty = common.hasProperty;
var stopLocationHandling = messages.messagesMakers.stopLocationHandling;
var encodeLocationHashByCoords = hashes.encodeLocationHashByCoords;

/*
    calculate a location hash by a given longitude and lattitude
    and put it into the object property calcLocationHash
    if the object has a property called 'locationHash', then check if the location was changed and put the property "_flLocationChanged"
*/
function calculateLocationHashByCoords(objectWithLngLat) {
    if ( hasProperty(objectWithLngLat, "lng") === false
        || hasProperty(objectWithLngLat, "lat") === false) {
            return new Error("Lng or Lat property is absent in the object");
    }
    if ( hasProperty(objectWithLngLat, "locationHash") === true ) {
        var calcLocationHash = encodeLocationHashByCoords(objectWithLngLat.lng, objectWithLngLat.lat);
        objectWithLngLat.calcLocationHash = calcLocationHash;
        if ( objectWithLngLat.locationHash !== calcLocationHash ) { //location was changed
            objectWithLngLat["_flLocationChanged"] = true; //set the corresponding flag
        } else { //was not been changed
            objectWithLngLat["_flLocationChanged"] = false;
        }
        objectWithLngLat.calcLocationHash = calcLocationHash;
    } else {
        objectWithLngLat.calcLocationHash = encodeLocationHashByCoords(objectWithLngLat.lng, objectWithLngLat.lat);
    }

    return true;
}


////////////////////////////////////////////


//when got all locations maintained by the local server
checkILSNearestLocation.afterGotLocationsByLS = function(res){
    if ( res == null 
        || res.length === 0 ) {
            throw new Error("There is no locations that are maintained by the ils"); 
    } else {
        this._customVariables["maintainedLocations"] = res; //put all a maintained locations to the custom variable
        return checkILSNearestLocation(this.nearestLocations, this._customVariables); //and call the vSchemaFunc_checkILSNearestLocation once again
    }
};

/*
    check if location is nearest to the maintained by the ils location
    nearestLocations - may be an one or a several locations(Array) 
*/
function checkILSNearestLocation(nearestLocations, _customVariables) {
    var maintainedLocations = _customVariables["maintainedLocations"];
    if (maintainedLocations == null) { //if there is no custom variable, that contains a locations, that are maintained by the ls
        var lsID = _customVariables["userID"];
        if (lsID == null) {
            throw new Error("There is no the property, that is called 'userID' into the custom variables");
        }
        //get all the maintained locations by an id of the ls from the db
        return getLocationsByLS(lsID, true) //use the fast method to get maintained locations
                .bind({
                    _customVariables : _customVariables,
                    nearestLocations : nearestLocations
                })
                .then(checkILSNearestLocation.afterGotLocationsByLS);
    }
    if ( nearestLocations == null ) { //the nearest locations from the incoming message
        throw new Error("The property 'nearestLocations' is empty");
    }
    if ( typeof(maintainedLocations) === "number" ) { //only the one location is maintained by the ls
        maintainedLocations = [maintainedLocations];  //put it into the array  
    } else 
    if ( isArray(maintainedLocations) !== true 
        || maintainedLocations.length === 0 ) {
            throw new Error("The property 'maintainedLocations' is empty or not an array");
    }
    
    var i, len;
    var flNumber = typeof(nearestLocations) === "number";
    if ( flNumber === true
        || nearestLocations.length === 1 ) { //if necessary to check only the one given nearest location
        
            var nearestLocation;
            if ( flNumber === false ) {
                nearestLocation = nearestLocations[0];
                if ( typeof(nearestLocation) !== "number" ) {
                    throw new Error("Nearest location has a wrong format " + nearestLocation);    
                }
            } else {
                nearestLocation = nearestLocations;    
            }
            
            var nearestLocationsToLocation = calculateNearestLHFByLocationHashOrLHF(nearestLocation); //calculate all the nearest locations to the incoming nearest location
            if ( isArray(nearestLocationsToLocation) === true ) {
                for( i =0, len = maintainedLocations.length; i < len; i++ ) {
                    if ( nearestLocationsToLocation.indexOf(maintainedLocations[i]) !== -1 ) {
                        return true; //if one of the maintained location is the nearest    
                    }    
                }
            }
            
            throw new Error("The location " + nearestLocation + " is not the nearest location to the maintained locations ");
    
    } else { //if given an array with the nearest locatons
        
        if ( nearestLocations.length > ( maintainedLocations.length * 8 ) ) { //each of maintained locations has an eight the nearest locations
            throw new Error("Too much the nearest locations");
        }
        
        var lngParts = []; //longitude parts of a maintained locations
        var indLngParts = 0;
        var latParts = []; //lattitude parts of a maintained locations
        var indLatParts = 0;
        
        var arrPartsOfLocation;
        for( i =0, len = maintainedLocations.length; i < len; i++ ) {
            arrPartsOfLocation = hashes.returnLocationHashPartsInServerFormat(maintainedLocations[i]); //arrPartsOfLocation = [lngSquareNumber, latSquareNumber]
            
            lngParts[++indLngParts] = arrPartsOfLocation[0]; //all the nearest numbers of longitude squares
            lngParts[++indLngParts] = arrPartsOfLocation[0]-1;
            lngParts[++indLngParts] = arrPartsOfLocation[0]+1;
            
            latParts[++indLatParts] = arrPartsOfLocation[1]; //all the nearest numbers of lattitude squares
            latParts[++indLatParts] = arrPartsOfLocation[1]-1;
            latParts[++indLatParts] = arrPartsOfLocation[1]+1;
        }
        
        var flArray = isArray(nearestLocations);
        var _nearestLocations = (flArray === true) ? nearestLocations : Object.keys(nearestLocations);
        var numOfNearestLocations =_nearestLocations.length;
        
        var flCheckRandom;
        var percentage;
        if ( numOfNearestLocations > 8 ) { //choose the percentage of incoming locations for checking depending on the number of the incoming nearest locations
            flCheckRandom = true;
            percentage = 8 / numOfNearestLocations; //the base number of locations for checking is ten. Locations will be chosen randomly with an accuracy that to choose only 8 locations for checkout
        }
        
        var countRemoved = 0;
        for ( i =0; i < numOfNearestLocations; i++ ) {
            var _nearestLocationHash = _nearestLocations[i];
            if ( flCheckRandom === true  //if check only a random locations
                && Math.random() > percentage ) { //and do not necessary to check (check only for 40% of the incoming nearest locations)
                    if ( hashes.ifLocationHashIsLHF(_nearestLocationHash) === true ) { //check it fast
                        continue;
                    } else {
                        throw new Error("Nearest location has a wrong format " + nearestLocation);    
                    }
            } else {
                arrPartsOfLocation = hashes.returnLocationHashPartsInServerFormat(_nearestLocationHash); //arrPartsOfLocation = [lngSquareNumber, latSquareNumber]
                if ( arrPartsOfLocation === false //wrong format
                    || lngParts.indexOf(arrPartsOfLocation[0]) === -1 //try to find the parts into the list of the parts, that are the nearest to the maintained
                    || lngParts.indexOf(arrPartsOfLocation[1]) === -1 ) {
                        //if the requested location is not the nearest location to the maintained location
                        countRemoved++; //delete the location hash from the given list of the nearest locations
                        if ( flArray === true ) {
                            _nearestLocations.splice(i,1);
                        } else {
                            delete nearestLocations[_nearestLocationHash];
                        }
                }
            }
        }
        if ( countRemoved === numOfNearestLocations ) { //all locations were removed from the given list and are not valid
            throw new Error("All the requested locations are not the nearest to the locations that are maintained by the ils: " + maintainedLocations);
        }
        if ( numOfNearestLocations > 8
            && (countRemoved / numOfNearestLocations) > 0.49 ) {
                 throw new Error("There are too many requested locations are not the nearest to the locations that are maintained by the ils: " + maintainedLocations);        
        }
    }
    return true;
}


/////////////////////////////////////////////

/*
    check the location, that if the location is maintained by the ils
    put the maintainedLocation to the _customVariables["maintainedLocations"]
    send the message to stop the locations handling if they are not maintined
    _customVariables["userID"] must contain the current user ID
*/
function checkILSMaintainedLocation(maintainedLocations, _customVariables) {
    if ( _customVariables == null ) {
        throw new Error("The property '_customVariables' is empty");
    }
    var lsID = _customVariables["userID"];
    if (lsID == null) {
        throw new Error("There is no the property, that is called 'userID' into the custom variables");
    }
    if ( _customVariables["maintainedLocations"] === undefined ) { //if the variable is not already defined
        if ( isArray(maintainedLocations) === false ) { //if the maintained locations argument is not defined, try to define them from other sources 
            if ( typeof(maintainedLocations) === "number" ) { //the only a one location
                maintainedLocations = [maintainedLocations];
            } else if ( typeof(maintainedLocations) === "object" ) { //if it is an object where the properties is a locations hashes
                maintainedLocations = Object.keys(maintainedLocations);
                for ( var i = 0, len = maintainedLocations.length; i < len; i++ ) { //validate locations format
                    var maintainedLocationHash = maintainedLocations[i];
                    if ( isLocationHashByFingerprint(maintainedLocationHash) === false ) { //check the format of location hash, if lattitude hash is bigger then the maximum
                        throw new Error("maintainedLocation has a wrong format " + maintainedLocationHash);
                    }
                }    
            } else { //can't to define maintained locations
                throw new Error("List with a maintained locations is empty or has an unknown format");    
            }
        }
    
        return getLocationsByLS(lsID, true)
                .bind({ maintainedLocations : maintainedLocations,
                        lsID : lsID,
                        _customVariables : _customVariables })
                .then(checkILSMaintainedLocation.afterGetLocationsByLS);    
    } else { //if the valid  maintained locations are defined by the _customVariables["maintainedLocations"]
        return checkILSMaintainedLocation.afterGetLocationsByLS(
                    _customVariables["maintainedLocations"], //list with the valid maintained locations
                    {   maintainedLocations : maintainedLocations,
                        lsID : lsID,
                        _customVariables : _customVariables }
                );    
    }
}

//whan got all locations by a local server
checkILSMaintainedLocation.afterGetLocationsByLS = function(validMaintainedLocations, context) {
    
    if ( context === undefined ) { //if the argument is not defined
        context = this;  //get from the real context  
    }
    
    var maintainedLocations = context.maintainedLocations;
    var countNotValidLocations = 0; //a number of locations that are given, but not maintained by the local server
    
    if ( isArray(validMaintainedLocations) === true
        && validMaintainedLocations.length > 0 ) {
            if ( maintainedLocations.length === 1
                && validMaintainedLocations.indexOf(maintainedLocations[0]) === -1) { //if only the one location was given, but it is not maintained by the local server
                    stopLocationHandling(context.lsID, maintainedLocations); //send a message to the ls to stop handling the location by it
                    countNotValidLocations++;    
            }    
    } else {
        stopLocationHandling(context.lsID, maintainedLocations); //send a message to the ls to stop handling the location by it
        throw new Error("Locations are not maintained by the ls");    
    }
    
    if ( countNotValidLocations === maintainedLocations.length ) { //if all the given locations are not valid maintained locations
        throw new Error("Locations are not maintained by the ls");    
    } else {
        context._customVariables["maintainedLocations"] = validMaintainedLocations;
        return true;
    }
};

//////////////////////////////////////////////////////////////////////////////////////////

function returnResult(){
    return this.returnIfSuccess;    
}

function validate_chooseAnotherLS_fromILS(objToValidate, returnIfSuccess, userID) {
    var promisesToDo = [];
    var _customVariables = {userID : userID};
    promisesToDo[0] = checkILSMaintainedLocation(objToValidate.locations.maintainedLocations, _customVariables); //check if a locations are maintained by the ils
    promisesToDo[1] = checkILSNearestLocation(objToValidate.locations.nearestLocations, _customVariables); //check if a locations are nearest to the maintained locations
    return Promise
            .all(promisesToDo)
            .bind({returnIfSuccess : returnIfSuccess})
            .then(returnResult);
}

function validate_getLocalServerID_fromILS(objToValidate, returnIfSuccess, userID) {
    return checkILSMaintainedLocation(objToValidate.locations.maintainedLocations, {userID : userID})
            .bind({returnIfSuccess : returnIfSuccess})
            .then(returnResult);
}

module.exports = {
    chooseAnotherLS_fromELS  : calculateLocationHashByCoords, //call the function for the body of a message
    getLocalServerID_fromELS : calculateLocationHashByCoords, //call the function for the body of a message
    chooseAnotherLS_fromILS  : validate_chooseAnotherLS_fromILS,
    getLocalServerID_fromILS : validate_getLocalServerID_fromILS
};


//check if the properties of an object is a locations hashes
// function propertiesIsLocations(toReturn, value, upwardsObj, schema, callback) {
//     if ( typeof(value) !== "object" ) {
//           throw new Error("The value is not an object");
//     }
//     var _keys = Object.keys(value); //check all object's properties
//     var len = _keys.length;
//     if ( len === 0 ) { //if a keys are absent into the given object
//         throw new Error("The object is empty");    
//     } else {
//         for ( var i = 0; i < len; i++ ) {
//             if ( isLocationHashByFingerprint(_keys[i]) === false  ) { //if the object proprty is not a location hash
//                 throw new Error("Object's property is not a location hash");
//             }
//         }
//         return toReturn;
//     }
// }

// //check if the properties of an object is an IDs of the users
// function propertiesIsUsersID(toReturn, value, upwardsObj, schema, callback){
//      if ( typeof(value) !== "object" ) {
//           throw new Error("The value is not an object");
//     }
//     var _keys = Object.keys(value); //check all object's properties
//     var len = _keys.length;
//     if ( len === 0 ) { //if a keys are absent into the given object
//         throw new Error("The object is empty");    
//     } else {
//         for( var i =0; i < len; i++ ) {
//             var usrID = toInt(_keys[i]);
//             if ( usrID < 0
//                  || usrID > 9999999
//                  || usrID % 1 !== 0) { //if not an integer
//                     throw new Error("Object's property for userID is not an integer or out of range");
//             }    
//         }
//     }
//     return toReturn;
// }
