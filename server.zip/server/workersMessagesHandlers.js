var ChildProcess = require("child_process");
var fork = ChildProcess.fork.bind(ChildProcess);
var util = require("util");
var EventEmitter = require("events").EventEmitter;
var common = require("./common.js");
var path = require("path");
var appSettings = require("./settings/settings.js");
var handlerMassagesFromAClientPath = "handleMassageFromAClient.js";

//start a workers for handling messages from a clients
function MessagesHandlers(){
    this.workers = []; //list with all the started workers
    this.numOfWorkers = 0; //a number of the started workers
    this.indWorkingWorker = 0; //index of the worker, that make the current job
    
    this.flUseWorkers = appSettings.useWorkers; //start without a workers
    
    this.start();
}
util.inherits(MessagesHandlers, EventEmitter);

/*
    emitted events:
        disconnectUser(userID, reason) - disconnect the user because of the reasen      
        sendMessageToUser(userID, message) - send a message to the user
*/

//settings for this module
MessagesHandlers.prototype.settings = {
    workersToStart : appSettings.workersToStart,
    numCPUs : require('os').cpus().length
};

/*
    send a message from a user for handling to an idle worker
    message - JSON string or a plain object with the message description
*/
MessagesHandlers.prototype.handleMessage = function(message, userID) {
    var msg;
    if ( this.flUseWorkers === true ) { //started without the workers
        msg = common.getFStr(userID, 9) + typeof(message) === "string" ? JSON.stringify(message) : message; //form the message
        this.idleWorker().send(common.getFStr(userID, 9) + (typeof(message) !== "string" ? JSON.stringify(message) : message)); //get an idle worker and send the client message to it
    } else { //Workers
        msg = typeof(message) === "string" ? ( common.getFStr(userID, 9) + message ) : message; //form the message
        this.messagesHandler.handleMessage(msg); //send the message to the worker
    }
};

//fork a workers for the module
MessagesHandlers.prototype.start = function() {
    if ( this.flUseWorkers === true ) {
        var listWorkers = this.workers;
        var numWorkers  = this.settings.workersToStart;
        if ( numWorkers > this.settings.numCPUs ) { //if wanted to start more workers than CPUs available
            console.log("System has only " + this.settings.numCPUs + " CPUs" ); //show warning message
        }
        
        //start worker in a number of numWorkers
        for ( var i = 0; i < numWorkers; i++ ) {
            listWorkers[i] = this.startWorker(); //start a new worker
        }
    } else {
        var messagesHandler = this.messagesHandler = require(path.resolve(__dirname, handlerMassagesFromAClientPath)); 
        var _self = this;
        messagesHandler.on("message", this.onWorkerMessage.bind({main : _self}));
    }
};

//stop all workers
MessagesHandlers.prototype.stop = function(){
   var listWorkers = this.workers; //list with all started workers
   var keys = Object.keys(listWorkers); //get an indexes of workers into the list
   for ( var i = 0, len = keys.length; i < len; i++ ) {
        this.closeWorker(listWorkers[keys[i]]); //close the worker from the list
    } 
};

//start a worker
MessagesHandlers.prototype.startWorker = function(){
    var _execArgv = [], env = {}, worker;
    // if ( process.env.DEBUG !== undefined
    //     || this.settings.DEBUG === true ) {
    //         env.DEBUG = "*";
    //         _execArgv = ["--nolazy", "--debug=" + (15460 + this.numOfWorkers) ];  //debug with the increasing number of the debbugger port
    // }
    worker = ChildProcess.fork(
        path.resolve(__dirname, "./handleMassageFromAClient.js"),
        {execArgv : _execArgv}
    ); 
    this.setListenersWorker(worker); //set the listeners for the worker events
    this.numOfWorkers++; //increase the number of the started workers
    return worker;
};

//close the worker
function closeWorker_err(){ //the function will be called if an error while closing a worker
    this.kill('SIGINT');    
}
function closeWorker_removeListeners(){ //remove listeners for a closed worker
    this.removeAllListeners();
}
MessagesHandlers.prototype.closeWorker = function(worker){
    this.removeListeners(worker); //remove all listeners from the listened events
    worker.kill('SIGINT'); //kill the process
    this.numOfWorkers--; //decrease the number of the working workers
    worker.on("error", closeWorker_err);
    worker.on("exit" , closeWorker_removeListeners);
};

//use round-robin for chosing a worker for the next task
MessagesHandlers.prototype.idleWorker = function(){
    var worker = this.workers[this.indWorkingWorker]; //return the chosen worker
    if ( worker != null
        && worker.connected === true ) {
            if ( (++this.indWorkingWorker) === this.numOfWorkers ) { //if we reached the last worker, then use the first
              this.indWorkingWorker = 0;
            }
            return worker;        
    } else {
        this.idleWorker();    
    }
};

//on message from a worker
MessagesHandlers.prototype.onWorkerMessage = function(message){
    
    //this.main = MessagesHandlers. It was bound before
    
    if ( this.flUseWorkers === true
        && this.worker.connected === false ) { //if the worker is not connected
            this.main.closeWorker(this.worker); //close the worker if it is not connected witht the main thread   
    } else if ( typeof(message) === "string" ) {
        if ( message.charAt(0) === "d" ) { //if it is necessary to disconnect the user
           //prefix "d" - is the first character
           //get the user id - characters from 1 to 9
           //the reason - characters before 9
           this.main.emit("disconnectUser", parseInt(message.substr(1,9), 10), message.substr(10)); 
        } else { //if it is necessary to send message for a user
           //get the user id - the first 9 characters 
           //the stringified message -before the first 9 characters
           this.main.emit("sendMessageToUser", parseInt(message.substr(0,9), 10), message.substr(9)); //emit the event to send the message to the user
        }  
    }
    
};

//on error
MessagesHandlers.prototype.onWorkerError = function(err){
    if (  this.worker.connected === false ) { //if not connected
         this.main.closeWorker( this.worker);    
    } else { //show the error to the user
        console.log(err);
    }
};

//when a worker closed, killed, disconnected
MessagesHandlers.prototype.onWorkerClosed = function(){
    
    //get from the context
    var worker = this.worker;
    var main = this.main;
    
    var listWorkers = main.workers; //list with all started workers    
    var ind = listWorkers.indexOf(worker); //find index of this worker into the list
    
    if ( ind !== -1 ) { //if has not been closed already
        main.closeWorker(worker); //kill the worker process
        listWorkers[ind] = main.startWorker(); //start a new worker intead of the closed
    }
};

//set listeners for worker events
MessagesHandlers.prototype.setListenersWorker = function(worker){
    
    //bind this object to all event listeners
    var objCOntext = {
        worker : worker, //this worker and the main object
        main : this //MessagesHandlers object
    };
    
    //bound functions
    var func_onWorkerError = this.onWorkerError.bind(objCOntext);
    var func_onWorkerClosed = this.onWorkerClosed.bind(objCOntext);
    var func_onWorkerMessage = this.onWorkerMessage.bind(objCOntext);
    
    /*
        Error emitted when:
        The process could not be spawned, or
        The process could not be killed, or
        Sending a message to the child process failed for whatever reason.
    */
    worker.on("error", func_onWorkerError);
    worker.on("close", func_onWorkerClosed); //stdio streams of a child process have all terminated
    worker.on("disconnect", func_onWorkerClosed); //it is no longer possible to send messages
    worker.on("exit", func_onWorkerClosed); //event is emitted after the child process ends.
    
    worker.on("message", func_onWorkerMessage);
    
};

//remove listeners from worker
MessagesHandlers.prototype.removeListenersWorker = function(worker){
    worker.removeAllListeners("error");
    worker.removeAllListeners("close");
    worker.removeAllListeners("disconnect");
    worker.removeAllListeners("exit");    
    worker.removeAllListeners("message");
};

module.exports = MessagesHandlers;




