var dbGeo = require("../dbGeo.js");

var Redis = require('ioredis'),
    hashes = require("../hashes.js"),
    commongeo = require("../commonGeoFunctions.js");
var dbMesaging = require("../dbMessaging.js");    
var getTimestamp = require("../getTimestamp.js");
var Promise = require("bluebird");
var Readline = require("readline");
var resolvePathMy = require("resolvePathMy");
var settings = require(resolvePathMy(__dirname, "settings/settings.js"));
var common = require("../common.js");

var rl = Readline.createInterface({ input: process.stdin, output: process.stdout });
var settingsRedis = settings.redisDB;
var redisNodesSettings = settingsRedis.redisNodes;
var optionsIORedis = settingsRedis.optionsIORedis;
var connectionsToRedisNodes = []; //array with connections to each redis node
var waitingPromises = [];
for( var i = 0, len = redisNodesSettings.length; i < len; i++ ) { //connect to each redis node
    var redisNode = connectionsToRedisNodes[i] = new Redis(redisNodesSettings[i].port, redisNodesSettings[i].host, optionsIORedis);
    if ( optionsIORedis.lazyConnect === true ) {
        waitingPromises[waitingPromises.length] = redisNode.connect();
    } else {
        start();
    }
}

if ( optionsIORedis.lazyConnect === true ) {
    Promise.all(waitingPromises) //whiting when connected to all redis nodes
        .then(function(){
            return dbGeo.start
                .then(function(e){
                    if ( e instanceof Error ) {
                        throw e;
                    }
                    console.log("Connected with all redis nodes");
                    start();
                });
        })
        .catch(function(e){ //can't connect to the redis node
            console.log(e.stack);
            console.log("Can't to connect with a redis node");
        });
} else {
    start();
}

function removeLocalServerForLocation() {
    rl.question("Type the location hash (default = '12248482462000'): ", function(locationHash) {
        locationHash = locationHash || 12248482462000;
        if ( locationHash ) {
            dbGeo.delLocalServerID(locationHash)
            .then(function(res){
                if ( res === true ) {
                    console.log("Done");
                } else {
                    console.log("Not done");
                }
                start();
            })
            .catch(function(e){
                console.log("Error:");    
                console.log(e);
                start();
            });
        }
    });
}

function showLocationsForLS(){
    rl.question("Type the local server ID: ", function(lsID) {
        if ( lsID ) {
            dbGeo.getLocationsByLS(lsID)
            .then(function(listLocations){
                if( Array.isArray(listLocations) === true && listLocations.length > 0 ) {
                    console.log("Locations:");
                    for( var i in listLocations ) {
                        console.log(listLocations[i]);    
                    }    
                } else {
                    console.log("Locations are absent");    
                }
                start();
            })
            .catch(function(e){
                console.log("Error:");    
                console.log(e);
                start();
            });
        }
    });    
}

function showLSForLocationHash(){
    rl.question("Type the location hash: ", function(locationHash) {
        if ( locationHash ) {
            dbGeo.getLocalServerID(locationHash)
            .then(function(userID){
                if ( userID ) {
                    console.log(userID);
                } else { //local servers are absent
                    console.log("Local servers for the location are absent");
                }
                start();
            })
            .catch(function(e){
                console.log("Error:");    
                console.log(e);
                start();
            });
        }
    });    
}

function showAllWaitingPongResponces(){
    //redisConnection.redisClient
    //.then(function (_redisClient) {
    //    return _redisClient.ZRANGE("_g_pongResponse", 0, 2000000)
    //    .then(function(result){
    //        if ( result != null ) {
    //            for( var i in result ) {
    //                console.log(result[i]);
    //            }
    //        } else {
    //            console.log("Responces are absent");
    //        }
    //        start();
    //    })
    //    .catch(function(e){
    //        console.log("Error:");
    //        console.log(e);
    //        start();
    //    });
    //});
}

function showAllCheckNewLocalServers(){
    //redisConnection.redisClient
    //.then(function (_redisClient) {
    //    return _redisClient.ZRANGE("_g_checkingNewLS", 0, 2000000)
    //    .then(function(result){
    //        if ( result != null ) {
    //            for( var i in result ) {
    //                console.log(result[i]);
    //            }
    //        } else {
    //            console.log("Responces are absent");
    //        }
    //        start();
    //    })
    //    .catch(function(e){
    //        console.log("Error:");
    //        console.log(e);
    //        start();
    //    });
    //});
}

//if flReturnLocations = true, then only return the locations in the result and do not exec start
function showAllLocations(flReturnLocations) {
    var promisesToDo = [];
    for ( var ind in connectionsToRedisNodes ) {
        promisesToDo[promisesToDo.length] = connectionsToRedisNodes[ind].keys("*"); //get all the keys that are stored on this redis instance
    }

    return Promise.all(promisesToDo)
        .then(function(results){ //got all the keys from each of the redis nodes
            if ( Array.isArray(results) === false ) {
                throw new Error("The result is wrong");
            }

            var locationsHashes = []; //get ls id for each location
            for( var i = 0, len = results.length; i < len; i++ ) { //for each key
                var keys = results[i];
                if ( Array.isArray(keys) === true
                    && keys.length > 0) { //if the keys are not empty
                        for( var ii = 0, len2 = keys.length; ii < len2; ii++ ) { //get ls id for each key = location hash
                            var key = parseInt(keys[ii], 10);
                            if ( isNaN(key) === false
                                && hashes.isLocationHashIsLHF(key) === true ) { //if the key is a location hash
                                    locationsHashes[locationsHashes.length] = key; //get ID of the local server for this location
                            }
                        }
                }
            }

            if ( (flReturnLocations === false || flReturnLocations == null)
                && locationsHashes.length > 0 ) {
                    return dbGeo.getLocalServerID(locationsHashes, true, true)
                        .then(function(results){
                            for( var ind in results ) {
                                var res = results[ind];
                                console.log("Location hash : " + res.locationHash + ", id of the local server: " + res.localServerID + ", timestamp: " + res.timestamp);
                            }
                        });
            } else if ( locationsHashes.length === 0 ) {
                console.log("Locations are absent");
                return null;
            } else {
                return locationsHashes; //if it is needed to return only the list with the locations    
            }
        })
        .then(function(results){
            if ( flReturnLocations === false 
                || flReturnLocations == null ) {
                    console.log("--------SHOW ALL LOCATIONS----------------");
                    console.log("Operation was completed");
                    start();
            } else {
              return results;  
            }
        })
        .catch(function(e){
            console.log("--------SHOW ALL LOCATIONS----------------");
            console.log(e.stack);
            console.log("An error has occured");
            start();
        });
}

//add the task for checking local server
function addTaskCheckNewLS() {
    //var localServerID, locationHash;
    //rl.question("Type the local server ID ( default value = '12222' ): ", function(lsID) {
    //    if ( !lsID ) {
    //        //default =
    //        localServerID = '12222';
    //    } else {
    //        localServerID = lsID;
    //    }
    //    rl.question("Type the location hash ( default value = '102963527946' ): ", function(locHash) {
    //        if ( !locHash ) {
    //            //default =
    //            locationHash = '102963527946';
    //        } else {
    //            locationHash = locHash;
    //        }
    //        dbMesaging.addWaitingPongResponse(localServerID, locationHash)
    //        .then(function(num){
    //            if ( num > 0 ) {
    //                console.log("Done.");
    //            } else {
    //                console.log("Was not done.");
    //            }
    //            start();
    //        })
    //        .catch(function(e){
    //            console.log("Error:");
    //            console.log(e);
    //            start();
    //        });
    //    });
    //});
}

//add the waiting pong task
function addTaskWaitingPong() {
    //var localServerID, locationHash;
    //rl.question("Type the local server ID ( default value = '12222' ): ", function(lsID) {
    //    if ( !lsID ) {
    //        //default =
    //        localServerID = '12222';
    //    } else {
    //        localServerID = lsID;
    //    }
    //    rl.question("Type the location hash ( default value = '102963527946' ): ", function(locHash) {
    //        if ( !locHash ) {
    //            //default =
    //            locationHash = '102963527946';
    //        } else {
    //            locationHash = locHash;
    //        }
    //        dbMesaging.addWaitingPongResponse(localServerID, locationHash)
    //        .then(function(num){
    //            if ( num > 0 ) {
    //                console.log("Done.");
    //            } else {
    //                console.log("Was not done.");
    //            }
    //            start();
    //        })
    //        .catch(function(e){
    //            console.log("Error:");
    //            console.log(e);
    //            start();
    //        });
    //    });
    //});
}

//set the local server as the handler for a location
function setLocalServerForLocation() {
    var localServerID, locationHash;
    rl.question("Type the local server ID ( default value = '12222' ): ", function(lsID) {
        
        if ( !lsID ) {
            //default = 
            localServerID = '12222';
        } else {
            localServerID = lsID;            
        }
        var defaultLocationHash = hashes.encodeLocationHashByCoords(20.1233,-0.12334);
        rl.question("Type the location hash ( default value = '" + defaultLocationHash + "' ): ", function(locHash) {
            if ( !locHash ) {
                //default = 
                locationHash = defaultLocationHash;
            } else {
                locationHash = locHash;            
            }
            dbGeo.setLocalServerID(Number(locationHash), localServerID)
            .then(function(res){
                if ( res instanceof Error ) {
                    throw res;
                } else {
                    if ( res === true ) {
                        console.log("Done!");    
                    } else {
                        console.log("Not done!");    
                    }
                    start();
                }
            })
            .catch(function(e){
                console.log("Error:");    
                console.log(e);
                start();
            });
        });
    });    
}

function CleanAllCheckNewLocalServers(flWithoutStart){
    //return redisConnection.redisClient
    //.then(function (_redisClient) {
    //    return _redisClient.ZREMRANGEBYSCORE("_g_checkingNewLS", 0, 200000000000000000);
    //})
    //.then(function(removedNum){
    //    console.log("--------DELETE ALL CHECK NEW LS----------------");
    //    if ( removedNum > 0 ) {
    //        console.log("Removed : " + removedNum);
    //    } else {
    //        console.log("Nothing to remove");
    //    }
    //    start(flWithoutStart);
    //})
    //.catch(function(e){
    //    console.log("--------DELETE ALL CHECK NEW LS----------------");
    //    console.log("Error:");
    //    console.log(e);
    //    start(flWithoutStart);
    //});
}

function CleanAllWaitingPong(flWithoutStart){
    //return redisConnection.redisClient
    //.then(function (_redisClient) {
    //    return _redisClient.ZREMRANGEBYSCORE("_g_pongResponse", 0, 200000000000000000);
    //})
    //.then(function(removedNum){
    //    console.log("--------DELETE ALL WAITING PONGS----------------");
    //    if ( removedNum > 0 ) {
    //        console.log("Removed : " + removedNum);
    //    } else {
    //        console.log("Nothing to remove");
    //    }
    //    start(flWithoutStart);
    //})
    //.catch(function(e){
    //    console.log("--------DELETE ALL WAITING PONGS----------------");
    //    console.log("Error:");
    //    console.log(e);
    //    start(flWithoutStart);
    //});
}

function deleteAllLocalServersAndLocations(flWithoutStart){
    return showAllLocations(true)
    .then(
        function(res){
            if ( Array.isArray(res) === true ) {
                var promisesToExecute = [];
                var locations = [];
                for( var i in res ) {
                    var locationHash = res[i];
                    locations.push(locationHash);
                    promisesToExecute.push(dbGeo.delLocalServerID(locationHash));    
                }
                return Promise.all(promisesToExecute)
                .then(function(res){
                    for( var i in res ) {
                       console.log("--------DELETE ALL LOCATIONS----------------");
                        if ( res[i] !== true ) {
                            console.log("Location was not removed: " + locations[i]);  
                        } else {
                            console.log("Location was removed: " + locations[i]);    
                        }
                    }
                    start(flWithoutStart);
                });
            } else {
                console.log("--------DELETE ALL LOCATIONS----------------");
                console.log("Locations are absent");
                start(flWithoutStart);    
            }
        }   
    )
    .catch(function(e){
        console.log("--------DELETE ALL LOCATIONS----------------");
        console.log("Error:");    
        console.log(e);
        start(flWithoutStart);
    });
}

function cleanAll(){
    var promisesToDo = [];
    for ( var ind in connectionsToRedisNodes ) {
        promisesToDo[promisesToDo.length] = connectionsToRedisNodes[ind].flushall(); //get all the keys that are stored on this redis instance
    }

    return Promise.all(promisesToDo)
    .then(function(){
        console.log("--------CLEAN All----------------");
        console.log("Operation was completed");
        start();
    });
}

function deleteLocationFromHandlingListOfLocalServer() {

    var localServerID, locationHash;
    rl.question("Type the local server ID ( default value = '12222' ): ", function(lsID) {
        if ( !lsID ) {
            //default = 
            localServerID = '12222';
        } else {
            localServerID = lsID;            
        }
        var defaultLocationHash = hashes.encodeLocationHashByCoords(20.1233,-0.12334);
        rl.question("Type the location hash ( default value = '" + defaultLocationHash + "' ): ", function(locHash) {
            if ( !locHash ) {
                //default = 
                locationHash = defaultLocationHash;
            } else {
                locationHash = locHash;            
            }
            
            dbGeo.removeLocationForLS(localServerID, locationHash)
                .then(function(result){
                    if ( result === false
                        && ( result instanceof Error === false ) ) {
                            console.log("Something goes wrong");    
                    } else {
                        console.log("all done"); 
                    }
                    
                    start();
                });
            
        });
    });
    
}

function setTTLForAllLocationsByLS(){
    
    rl.question("Type the local server ID ( default value = '12222' ): ", function(lsID) {
        return dbGeo.setExpireForAllLocationsByLS(lsID == "" ? 12222 : lsID)                
            .then(function(res){
                if ( res === false
                    || res instanceof Error ) {
                        console.log("The ttl was not set!");
                        if ( res instanceof Error ) {
                            console.log(res.message);    
                            console.log(res.stack);
                        }
                } else {
                    console.log("Done!");    
                }
                
                start();
            });
    });
    
}

//if location hash is given, then do not ask to type it and process the given location
function getRemainingTTlForLocation(locationHash) {
    
    var flUseStart = !locationHash; //if the location hash was not given, then use the start function, otherwise do not do that
    function _start() { //start
        if ( flUseStart === true ) { 
            start();    
        }
    }
    
    function showForLocation(locationHash) {
        
        if ( !locationHash ) {
            locationHash = 11609001347190;    
        }
        
        var currTimestamp = getTimestamp();
        return dbGeo.getLocalServerID(locationHash, true)
                .then(function(result){
                    if ( result === false ) {
                        console.log("The ls for the location " + locationHash + " is absent");
                        _start();
                    } else {
                        var lsID = result.localServerID;
                        var timetamp = result.timestamp;
                        console.log("When the ls was set for the location  " + locationHash + " : " + timetamp);
                        
                        var redisClient = dbGeo.redisClient;
                        return redisClient.start.then(function(){
                            return redisClient.ttl(locationHash)
                                    .then(function(ttl){
                                        if ( typeof(ttl) === "number" ) {
                                            console.log("Remaining ttl for the location  " + locationHash + " : " + ttl);
                                        }
                                    })
                                    .then(function(){
                                        return redisClient.ttl(hashes.getKeyOfUserIDForDb(lsID))
                                                .then(function(ttl){
                                                    if ( typeof(ttl) === "number" ) {
                                                        console.log("Remaining ttl for the local server list location " + locationHash + " : " + ttl);
                                                    }
                                                });
                                    })
                                    .then(function(){
                                        return dbGeo.getLocationsByLS(lsID, true, true, true)
                                            .then(function(res){
                                                if ( typeof(res) === "object"
                                                    && res !== null
                                                    && typeof(res[locationHash]) === "number" ) {
                                                        console.log("Remaining ttl for location from the list location  " + locationHash + " : " + (res[locationHash] + settings.dbGeoModule.ttlLocalServer - currTimestamp));    
                                                } 
                                                _start();
                                            });
                                    });
                        })
                        .catch(function(err){
                            console.log(err);
                            _start();
                        });
                    }    
                });
    }
    
    if ( !locationHash ) {
        rl.question("Type the location hash ( default value = '11609001347190' ): ", showForLocation);
    } else {
        return showForLocation(locationHash);    
    }
    
}

//ttl for all the locations, that are handled by the ls
function getRemainingTTlForLS() {
    rl.question("Type the id of the local server ( default value = '12222' ): ", function(lsID) {
        
        if ( !lsID ) {
            lsID = 12222;    
        }
        
        return dbGeo.getLocationsByLS(lsID, true)
                .then(function(res){
                    if ( Array.isArray(res) === true ) {
                        var len = res.length;
                        if ( len > 0 ) {
                            for(  var i =0; i < len; i++ ) { //for each location
                                var locationHash = res[i];
                                var promisesToDO = []; //list with a promises
                                if ( typeof(locationHash) === "number"
                                    && locationHash !== 0 ) { //if the location is not empty process it
                                        promisesToDO[promisesToDO.length] = getRemainingTTlForLocation(locationHash);
                                }
                                
                            }
                            
                            return Promise.all(promisesToDO).then(start, start);
                        } else {
                            console.log("Locations are absent");
                            start();    
                        }
                    } 
                });
        
    });
}

//get nearest locations for location
function calcAllNearestLocations() {
    rl.question("Type the location hash: ", function(locationHash) {
        
        if ( !locationHash ) {
            console.log("Empty location hash");
            return;    
        }  
        
        var nearestLocations = hashes.calculateNearestLHFByLocationHashOrLHF(locationHash);
        return dbGeo
                .getLocalServerID(nearestLocations, true, true)
                .then(function(results){
                    if ( results.length === 0 ) {
                        console.log(nearestLocations);    
                    } else {
                        for( var i = 0, len = results.length; i < len; i++ ) {
                            var resForLocation = results[i];
                            var strRes = "Nearest location hash : " + resForLocation.locationHash;
                            if ( common.isEmptyLSID(resForLocation.localServerID) === false ) { //if the ls is exists for the location
                                strRes = strRes + " handled by the local server " + resForLocation.localServerID + " timestamp " + resForLocation.timestamp;    
                            }
                            console.log(strRes);    
                        }
                    }
                    start();
                });        
    });
}

function calcLocationHashByCoords() {
    rl.question("Type the lattitude: ", function(lat) {
        rl.question("Type the longitude: ", function(lng) {
            var lh = hashes.encodeLocationHashByCoords(lng, lat);
            if ( typeof(lh) === "number"
                || typeof(lh) === "string" ) {
                    console.log("Locations hash is " + lh);        
            } else {
                console.log("Can't calculate the location hash");
            }
            start();
        });
    });
}

function start(flWithoutStart) {

    if ( flWithoutStart !== true ) {
        console.log("------------------------------------------");
        console.log("What you want to do: ");
        console.log("0. Exit");
        console.log("1. Remove the local server for the location");
        console.log("2. Show all locations, that are handled by the local server");
        console.log("3. Show all the 'waiting pong responces'");
        console.log("4. Show a local server for the location");
        console.log("5. Show all the 'check new local servers'");
        console.log("6. Show all locations and local servers and timestamps");
        console.log("7. Add task 'checking new ls'");
        console.log("8. Add task 'waiting pong'");
        console.log("9. Set the local server for the location");
        console.log("10. Clean all tasks 'check new local servers'");
        console.log("11. Clean all tasks 'waiting pong'");
        console.log("12. Delete all local servers for all locations");
        console.log("13. Clean all");
        console.log("14. Remove location from the list of the local server");
        console.log("15. Set time to live for all locations by the ls"); 
        console.log("16. Get the remaining ttl of the ls for the location");  
        console.log("17. Get the remaining ttl for the ls and all the locations");
        console.log("18. Calculate the nearest locations to the location");
        console.log("19. Calculate the location hash by a coordinates");
        
        rl.question("\nYour choice:", onData);
    }
}

function onData(data){
    
    var answer = data.trim();

    switch(answer) {
        case "0" : //exit
            process.exit();
            return;
        case "1" :
            removeLocalServerForLocation();
            break;
        case "2" : //show the list of  a locations that are maintained by the ls
            showLocationsForLS();
            break;
        case "3" : //show the list of  a locations that are maintained by the ls
            showAllWaitingPongResponces();
            break;
        case "4" : //show the list of  a locations that are maintained by the ls
            showLSForLocationHash();
            break;
        case "5" : //show the list of  a locations that are maintained by the ls
            showAllCheckNewLocalServers();
            break;
        case "6" : //show the list of  a locations that are maintained by the ls
            showAllLocations();
            break;
        case "7" : //show the list of  a locations that are maintained by the ls
            addTaskCheckNewLS();
            break;
        case "8" : //show the list of  a locations that are maintained by the ls
            addTaskWaitingPong();
            break;
        case "9" : //show the list of  a locations that are maintained by the ls
            setLocalServerForLocation();
            break;
        case "10": //show the list of  a locations that are maintained by the ls
            CleanAllCheckNewLocalServers();
            break;
        case "11": //show the list of  a locations that are maintained by the ls
            CleanAllWaitingPong();
            break;
        case "12": //show the list of  a locations that are maintained by the ls
            deleteAllLocalServersAndLocations();
            break;
        case "13": //show the list of  a locations that are maintained by the ls
            cleanAll();
            break;
        case "14": //show the list of  a locations that are maintained by the ls
            deleteLocationFromHandlingListOfLocalServer();
            break;
        case "15": //show the list of  a locations that are maintained by the ls
            setTTLForAllLocationsByLS();
            break;
        case "16": //show the list of  a locations that are maintained by the ls
            getRemainingTTlForLocation();
            break;
        case "17": //show the list of  a locations that are maintained by the ls
            getRemainingTTlForLS();
            break;
        case "18":  //calculate the nearest locations for the location  
            calcAllNearestLocations();
            break;
         case "19":    
            calcLocationHashByCoords();
            break;
        default  :
            console.log("Unknown command");
            start();
            return;
    }
}