"use strict";

var path = require("path"),
    Promise = require("bluebird"),
    PipeCommander = require("myPipeCommander"),
    appSettings = require(path.resolve(__dirname,"settings/settings.js")),
    Redis = require('ioredis'),
    EventEmitter = require("events"),
    util = require("util");
    
var log = require("./logger.js").loggerMsg(__filename);

var settingsRedis = appSettings.redisDB;
var settingsRedisPubSubServers = settingsRedis.redisNodesForPubSub; //host and port of redis nodes for pub sub
var optionsPipelineCommander = {
    redisNodesSettings : settingsRedis.redisNodesForPubSub, //options for pub sub instances of redis db
    ioRedisOptions : settingsRedis.optionsIORedis, //specified by the ioredis library    
    options : settingsRedis.optionsPipelineCommander //especially for the PipelineCommander library
}; 

//indGServer = index of the gServer, which subscribes and publish with another servers
function CommunicationServer(indGServer){

    if ( Array.isArray(optionsPipelineCommander.redisNodesSettings) === false
        || optionsPipelineCommander.redisNodesSettings.length === 0 ) { //if there is no redis instances for messaging between the gServers
            this.started = false;
    } else {
        this.indGServer = indGServer;
        this.log = log;
        this.channelName = "ch:" + indGServer;
        var pipeCommander = new PipeCommander(optionsPipelineCommander); //for sending messages to another nodes
        this.redisClientForPublishing = pipeCommander
        this.indexRedisNode = pipeCommander.nodeByKey(this.channelName); //get the right number of the redis node to which messages will be sent for from another gServers for this gServer
        this.redisClientForSubscribing = new Redis(settingsRedisPubSubServers[this.indexRedisNode]); //connect to the redis node, that will be broadcast a messages for this server
        this.redisClientForSubscribing.subscribe(this.channelName, this.onSubscribe.bind(this)); //subscribe to the messages form another nodes
        this.redisClientForSubscribing.on("message", this.onMessage.bind(this)); //on messages form another nodes
    }
}
util.inherits(CommunicationServer, EventEmitter);

//when subscribed to the messaging channel for the gServer
CommunicationServer.prototype.onSubscribe = function (err, count) {
    if ( err != null 
        || count !== 1 ) { //if an eeror has occurred while subscribing
            log(err);
            this.redisClientForSubscribing.subscribe("ch:" + this.indGServer, this.onSubscribe.bind(this));
    } else {
        
    }
};

//on message from a channel
CommunicationServer.prototype.onMessage = function (channel, message) {
    if ( channel === this.channelName ) {
        var resMessage;
        try {
            resMessage = JSON.parse(message); //convert the message to an object
        } catch(e) {
            this.log(e); 
            return;
        }
        if ( resMessage != null ) {
            this.emit("message", resMessage);
        }
    }
};

//on message from a channel. indGServer = index of a gserver where this message will be sent
CommunicationServer.prototype.sendMessage = function (indGServer, message) {
    var channelNameForGServer = "ch:" + indGServer;
    if ( typeof(message) === "object"
        && message != null) { //necessary to stringify the object before publish it
            this.redisClientForPublishing.publish(channelNameForGServer, JSON.stringify(message));
    } else if ( typeof(message) === "string" ) { //if a string
        this.redisClientForPublishing.publish(channelNameForGServer, message);
    }
};

module.exports = CommunicationServer;