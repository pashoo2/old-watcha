var resolvePath = require("resolvePathMy");
var settings = require(resolvePath(__dirname, "settings/settings.js"));
var messagesSettings = settings.messagesSettings,
	empty_user_id = messagesSettings.empty_user_id; //the value of the empty user id

function isEmptyObject(obj) {
    if ( typeof(obj) != "object" ) {
        return !obj;
    }
    for (var key in obj) {
        return false;
    }
    return true;
};

function strToInt(str) {
    return typeof(str) === "number" ? str : parseInt(str,10);
};

/*
    check if integer. If a string the error will be shown and trying to convert to a number
    If not a number throw error
*/
function checkInteger(val) {
    if ( typeof(val) !== "number"
         || val === 0 ) {
            if ( isNaN(val) === false ) { //try to conver string to number
                val = strToInt(val);    
            } else { //if the conversion was failed
                return NaN;        
            }
    }
    return val;
}

function numToStr(num) {
    return typeof(num) === "string" ? num : num+'';
}

//get string with the length as fillNum and zero filled prefix
function getFStr(int, fillNum) {
    return ("000000000" + int).substr(-fillNum);
}

function hasProperty(obj, propName) {
    return (obj[propName] != null);
}

//return an index of the removed element or -1 if an element was not found
function deleteFromArray(array, value){
  var numFound = array.indexOf(value);
  if ( numFound !== -1 ) {
    array.splice(numFound, 1);    
  }
  return numFound;
}

function mergeUnique(arrayDest, arrayContributor) {
    var lenDest = arrayDest.length;
    var lenContributor = arrayContributor.length;
    if ( typeof(lenDest) !== "number"
        || typeof(lenContributor) !== "number" ) {
            console.log("Common.mergeUnique: ERROR. One of the arguments is not an array");
            return [];        
    }
    var i = 0;
    while( i < lenContributor ) {
        var el = arrayContributor[i];
        if ( arrayDest.indexOf(el) === -1 ) {
            arrayDest[lenDest] = arrayContributor[i];    
            lenDest++;
        }
        i++;    
    }  
}

//check if the variable is an array
function isArray(_variable){
    return typeof(_variable) === "object"
        && _variable !== null
        && _variable.constructor === Array;
}

//return a full copy of a value
function getCopyOfVal(value){
    var toReturn;
    if ( typeof(value) === "object" ) { //an object or array
        if ( isArray(value) === true ) { //it is an array
            toReturn = [];    
        } else { //it is an object
            toReturn = {};
        }
        var _keys = Object.keys(value);
        for ( var i =0, len = _keys.length; i < len; i++ ) { //if an object, it will be not a deep copy of the object, because it is too long
            var _key = _keys[i];
            toReturn[_key] = value[_key];   
        }
    } else if ( typeof(value) !== "function" ) { //a primitive
        toReturn = value;  
    }
    return toReturn;
}

function extend(origin) {
  
  if ( arguments.length > 1 ) {
      
      for( var i = 1, len = arguments.length; i < len; i++ ) {
          var add = arguments[i];
          // Don't do anything if add isn't an object
          if (!add || typeof add !== 'object') return origin;
        
          var keys = Object.keys(add);
          var ii = keys.length;
          while (ii--) {
                if ( origin[keys[ii]] == null ) { //if a key with this name is absent in the origin object
                    origin[keys[ii]] = add[keys[ii]];
                }
          }
      }
  }
  return origin;    
}

//call the given method of an object context[methodName] or function func with the argument, that are defined by the array = _arguments
//or may be call as function, _arguments, then the given function will be called with the given arguments
function callFunctionWithArguments(context, methodName, _arguments) { //or function, _arguments
    if ( _arguments !== undefined ) { //if a method call with the given arguments
        if ( typeof(context[methodName]) === "function" ) {  
            if ( _arguments.length == null ) {
                return (context[methodName])(_arguments);    
            } else {
                switch( _arguments.length ) {
                    case 0:
                        return (context[methodName])();
                    case 1:
                        return (context[methodName])(_arguments[0]);
                    case 2:
                        return (context[methodName])(_arguments[0],_arguments[1]);
                    case 3:
                        return (context[methodName])(_arguments[0],_arguments[1],_arguments[2]);
                    case 4:
                        return (context[methodName])(_arguments[0],_arguments[1],_arguments[2],_arguments[3]);
                    case 5:
                        return (context[methodName])(_arguments[0],_arguments[1],_arguments[2],_arguments[3],_arguments[4]);
                    case 6:
                        return (context[methodName])(_arguments[0],_arguments[1],_arguments[2],_arguments[3],_arguments[4],_arguments[5]);
                    case 7:
                        return (context[methodName])(_arguments[0],_arguments[1],_arguments[2],_arguments[3],_arguments[4],_arguments[5],_arguments[6]);
                    case 8:
                        return (context[methodName])(_arguments[0],_arguments[1],_arguments[2],_arguments[3],_arguments[4],_arguments[5],_arguments[6],_arguments[7]);
                    case 9:
                        return (context[methodName])(_arguments[0],_arguments[1],_arguments[2],_arguments[3],_arguments[4],_arguments[5],_arguments[6],_arguments[7],_arguments[8]);
                    default: 
                        return (context[methodName]).apply(context, _arguments);
                }
            }
        }
    } else if ( methodName !== undefined ) { //if a function call with the given arguments
        var func = context;
        _arguments = methodName;
        if ( typeof(func) === "function" ) {  
            switch( _arguments.length ) {
                case 1:
                    return func(_arguments[0]);
                case 2:
                   return func(_arguments[0],_arguments[1]);
                case 3:
                    return func(_arguments[0],_arguments[1],_arguments[2]);
                case 4:
                    return func(_arguments[0],_arguments[1],_arguments[2],_arguments[3]);
                case 5:
                    return func(_arguments[0],_arguments[1],_arguments[2],_arguments[3],_arguments[4]);
                case 6:
                    return func(_arguments[0],_arguments[1],_arguments[2],_arguments[3],_arguments[4],_arguments[5]);
                case 7:
                    return func(_arguments[0],_arguments[1],_arguments[2],_arguments[3],_arguments[4],_arguments[5],_arguments[6]);
                case 8:
                    return func(_arguments[0],_arguments[1],_arguments[2],_arguments[3],_arguments[4],_arguments[5],_arguments[6],_arguments[7]);
                case 9:
                    return func(_arguments[0],_arguments[1],_arguments[2],_arguments[3],_arguments[4],_arguments[5],_arguments[6],_arguments[7],_arguments[8]);
                default: //more than 9
                    return func.apply(this, _arguments);
            }
        }
    }
}

/*
    return an array from the given arguments object
    make it from Arguments or if only one argument is defined and it is an Array, then this function will handle this Array
*/
function makeArrayFromArguments() {
    var ret;
    var _arguments = (arguments.length === 1 && isArray(arguments[0])) ? arguments[0] : arguments;
    switch( _arguments.length ) {
        case 1:
            ret = [_arguments[0]];
        case 2:
            ret = [_arguments[0],_arguments[1]];
        case 3:
            ret = [_arguments[0],_arguments[1],_arguments[2]];
        case 4:
            ret = [_arguments[0],_arguments[1],_arguments[2],_arguments[3]];
        case 5:
            ret = [_arguments[0],_arguments[1],_arguments[2],_arguments[3],_arguments[4]];
        case 6:
            ret = [_arguments[0],_arguments[1],_arguments[2],_arguments[3],_arguments[4],_arguments[5]];
        case 7:
            ret = [_arguments[0],_arguments[1],_arguments[2],_arguments[3],_arguments[4],_arguments[5],_arguments[6]];
        case 8:
            ret = [_arguments[0],_arguments[1],_arguments[2],_arguments[3],_arguments[4],_arguments[5],_arguments[6],_arguments[7]];
        case 9:
            ret = [_arguments[0],_arguments[1],_arguments[2],_arguments[3],_arguments[4],_arguments[5],_arguments[6],_arguments[7],_arguments[8]];
        default:  //more than 9
            ret = Array.prototype.slice.call(_arguments);
    }
    return ret;
}

//return false
function returnFalse(e){
    return false;    
}

//return false if the given user id is empty
function isEmptyLSID(lsID){
    return typeof(lsID) !== "number"
            || lsID === empty_user_id;    
}

//rerturn true if the string only with alphanumeric
function isAlphaNumeric(str) {
  var code, i, len;

  for (i = 0, len = str.length; i < len; i++) {
    code = str.charCodeAt(i);
    if (!(code > 47 && code < 58) && // numeric (0-9)
        !(code > 64 && code < 91) && // upper alpha (A-Z)
        !(code > 96 && code < 123)) { // lower alpha (a-z)
            return false;
    }
  }
  return true;
};

module.exports = {
    isEmptyObject : isEmptyObject,
    strToInt : strToInt,
    checkInteger : checkInteger,
    numToStr : numToStr,
    getFStr  : getFStr,
    hasProperty : hasProperty,
    deleteFromArray : deleteFromArray,
    mergeUnique : mergeUnique,
    isArray : isArray,
    getCopyOfVal : getCopyOfVal,
    extend : extend,
    callFunctionWithArguments : callFunctionWithArguments,
    makeArrayFromArguments : makeArrayFromArguments,
    returnFalse : returnFalse,
    resolvedPromiseTrue  : Promise.resolve(true), //Promise, resolved with true
    resolvedPromiseFalse : Promise.resolve(false), //Promise, resolved with false
    isEmptyLSID : isEmptyLSID,
    isAlphaNumeric : isAlphaNumeric
};