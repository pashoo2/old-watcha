var common = require("./common.js");

//return a hash tag to define redis cluster slot for the location hash
function getHashTagByLocationHash(locationHash) {
   return locationHash % 100; //the last two numbers is a hash tag
}

//add hash tag to a key to define a redis cluster node where is this key is located
function addHashTagToKey(key, hashTag) {
    return key + "{" + hashTag + "}";    
}

module.exports = {
    getHashTagByLocationHash : getHashTagByLocationHash,
    addHashTagToKey : addHashTagToKey
};