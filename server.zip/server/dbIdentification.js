"use strict";

var path = require("path"),
    getTimestamp = require("./getTimestamp.js"),
    Promise = require("bluebird"),
    commonlib = require("./common.js"),
    PipeCommander = require("myPipeCommander");
    
var log = require("./logger.js").loggerMsg(__filename);

//start redis client with automatically pipelining and distribution
var appSettings = require(path.resolve(__dirname,"settings/settings.js"));
var settingsRedis = appSettings.redisDB;
var optionsPipelineCommander = {
    redisNodesSettings : settingsRedis.redisNodesForIdentification, //host and port of a redis nodes
    ioRedisOptions : settingsRedis.optionsIORedis, //specified by the ioredis library    
    options : settingsRedis.optionsPipelineCommander //especially for the PipelineCommander library
};
var redisClient = new PipeCommander(optionsPipelineCommander); //use as redisClient.commandName.then(afterResult)

var keyDelimetr = "//"; //delimiter for the user id from a prefix
//make the list with prefixes for social networks according to global settings
var prefixesForSocialNetworks = {};
var integrationSettings = appSettings.integration;
var socialNames = Object.keys(integrationSettings);
for( var i= 0, len = socialNames.length; i < len; i++ ) {
    var snName = socialNames[i]; //social network name
    var dbKeyPrefix = integrationSettings[snName].dbKeyPrefix;
    if ( typeof(dbKeyPrefix) === "string" ) { //if the prefix is defined
        prefixesForSocialNetworks[snName] = dbKeyPrefix + keyDelimetr; //prefix with delimetr
    } else {
        log("DB key prefix for the social network" + snName + " is not defined");    
    }
}

/*
    return user ID in this application, depending on id in the social network and id of the user in this social network
*/
var isAlphaNumeric = commonlib.isAlphaNumeric;
function getInnerUserID(idSocialNetwork, prefix) {
    if ( typeof(idSocialNetwork) !== "string"
        || idSocialNetwork.length === 0
        || isAlphaNumeric(idSocialNetwork) === false ) {
            return Promise.reject(new Error("Wrong user ID in the social network used for identification"));        
    } else {
        if ( typeof(prefix) === "string" ) { //if the prefix is defined for the social network
            var dbKey = prefix + "//" + idSocialNetwork;
            return redisClient
                    .get(dbKey) //get the inner id for the user
                    .then(function(res){
                        if ( typeof(res) === "string" ) { //if the inner user id is exists
                            return parseInt(res, 10); //return integer user id in the app    
                        } else { //if the id for the user is not exists
                            return redisClient
                                .incr("current//id") //increment the current available id
                                .then(function(innerID){ //set this id for the key
                                    return redisClient
                                            .set(dbKey, innerID)
                                            .then(function(res){
                                                if ( res === "OK" ) { //if the inner id was set for the user
                                                    return parseInt(innerID, 10);  
                                                }
                                            });
                                });
                        }    
                    });
        } else {
            return Promise.reject(new Error("Unknown social network used for identification"));
        }
    }
}

module.exports = {
    getInnerUserID : getInnerUserID
};