var getTimestamp = require("./getTimestamp.js");

var commonF = require("./common.js");
var _toInt = commonF.strToInt;
var _toStr = commonF.numToStr;


var subtrahendForTimestampHash = 1431075799;
var dividerForTimestampHash = 60;
var prefixForKeyUserID = 6; //for a location hashes as a keys for the redis Db the first(prefix) numeric symbol must be equal from 1 to 4. There is no location hashes, that may starts with a symbol of "9"

//count a digits into an integer nyumber and pow 10 into the degree of the resuted number
function multiplierCountDigits(integer) {
    return Math.pow( 10, ( Math.floor(Math.log10(integer)) + 1 ) );   
}

//get a hash by the user ID for saving it into the db as a key
function getKeyOfUserIDForDb(userID) {
    return prefixForKeyUserID * multiplierCountDigits(userID) + userID;
}

//get the user ID by the key (given by getKeyOfUserIDForDb)  from the db
function getUserIDFromDbKey(hashUserID) {
   return _toInt(_toStr(hashUserID).substr(1)); 
}

//get hash value by the local server ID and it's location
function getHashOfLocalServer(localServerID, locationHash) {
    var m1 = multiplierCountDigits(localServerID);
    return prefixForKeyUserID * m1 * multiplierCountDigits(locationHash) + locationHash * m1 + localServerID;
}

//return localServerID and it's location hash
//{ localServerID, locationHash }
function parseHashOfLocalServer(lsHash) {
    lsHash = _toStr(lsHash);
    var locationHash  = lsHash.substr(0, maxDigits); //a fixed-length location hash is going first
    var localServerID = lsHash.substr(maxDigits);
    return {
        localServerID : _toInt(localServerID),
        locationHash  : _toInt(locationHash)
    };
}

//get a hash of the current timestamp, with the precision of one minute
//addToCurrentTimestamp - will be added to the current timestamp
function getTimestampHash(timestamp, addToCurrentTimestamp) {
    return Math.ceil(( ( (timestamp === undefined ? getTimestamp() : timestamp) + (addToCurrentTimestamp === undefined ? 0 : addToCurrentTimestamp) ) - subtrahendForTimestampHash)  /dividerForTimestampHash);
}

//return a timestamp by the hash of a timestamp, with the precision of one minute
function getTimestampByHash(timestampHash){
    return _toInt(timestampHash) * dividerForTimestampHash + subtrahendForTimestampHash;   
}
//return hash user ID + timestamp
function getHashUserIDWithTimestamp(userID){
    var timestampHash = getTimestampHash(); //it is necesssary to make a 7 digits number from the timestamp hash
    return _toInt(userID) * 10000000 + timestampHash; //10000000 - multiplier to get 7-digits timestampHash   
}
//return {userID, timestamp} by a hash of userID + timestamp
function getTimestampAndUserIDByHash(hashUserIDWithTimestamp) {
   var _hash = _toStr(hashUserIDWithTimestamp);
   var timestamp = getTimestampByHash(_hash.substr(-7)); //the last 7 symbols
   var userID = _hash.substr(0, _hash.length-7); //without the last 7 symbols
   return {
       timestamp : _toInt(timestamp),
       userID    : _toInt(userID)
   };
}

/*
    return one string for all this values
    prefix - the first one symbol
    an another symbols are a hash of a localServerID with a location hash
*/
function getHashLocalServerLocation(localServerID, locationHash, prefix) {
    var hash = getHashOfLocalServer(localServerID, locationHash);
    return _toInt(prefix || 9) * multiplierCountDigits(hash) + hash;
}

//return an object with the following properties
//{ 
//  prefix
//  localServerID
//  locationHash 
//}
function getPrefixLocalServerLocationByHash(_hash) {
   _hash = _toStr(_hash);
   var prefix  = _hash.substr(0,1);
   var localServerWithLocation = parseHashOfLocalServer(_hash.substr(1));
   return {
       prefix : prefix,
       localServerID :  localServerWithLocation.localServerID, 
       locationHash  :  localServerWithLocation.locationHash
   };
}

var commonGeoF = require("./commonGeoFunctions.js");
var locationHashParts = commonGeoF.locationHashParts;
var locationHashToSquaresNumbers = commonGeoF.locationHashToSquaresNumbers;
var calculateNearestLocationsBySquaresNumbers = commonGeoF.calculateNearestLocationsBySquaresNumbers;
var getCoordsSignsByPrefix = commonGeoF.getCoordsSignsByPrefix;
const geoSettings = commonGeoF.moduleSettings;
const maxDigitsQuadrantLngPart = geoSettings.maxDigitsQuadrantLng; //means max digits in the longitude part of a hash
const maxDigitsQuadrantLngAsMultiplier = geoSettings.maxDigitsQuadrantLngAsMultiplier; //10 in power of max digits in the longitude part of a hash
const maxDigitsQuadrantLatPart = geoSettings.maxDigitsQuadrantLat; //means max digits in the longitude part of a hash
const maxDigitsQuadrantLatAsMultiplier = geoSettings.maxDigitsQuadrantLatAsMultiplier; //10 in power of max digits in the latitude part of a hash
const maxDigits = geoSettings.maxDigits; //the maximum number of a digits of a location hash in the server format

const maxLatPart = geoSettings.maxNumberQuadrantLat; //the maximum value of the longitude part of a locations hahes
const maxLngPart = geoSettings.maxNumberQuadrantLng; //the maximum value of the lattitude part of a locations hahes

function fingerprint32(s) { //java object.hashCode
    var hash,
        strlen = s.length,
        i,
        c;
    if ( strlen === 0 ) {
        return hash;
    }
    for ( i = 0, hash = 0; i < strlen; i++ ) {
        hash = ((hash << 5) - hash) + s.charCodeAt(i);
        hash &= hash; // Convert to 32bit integer
    }
    return hash;
}

const key2 = parseInt("0b1011100111000000", 2);
const key3 = "sksdj";
const rightShiftNumDigitsKey2 = key2.toString(2).length - 10;
const maxLengthFingerprint = 3;
const prefixMultiplier = geoSettings.prefixMultiplier;

const maxDigitsLHF = maxDigits + maxLengthFingerprint; //the maximum length of lhf string = max digits location hash in the server format + maximum length of a fingerprint part
const minDigitsLHF = maxDigits + 1; //the minimum length of lhf string
const maxDigitsLHFMultiplier = Math.pow(10, maxDigitsLHF-1);
const minDigitsLHFMultiplier = Math.pow(10, minDigitsLHF-1);

var maxLHF = "9".repeat(maxDigitsLHF-1);
//for( var i = 0, len = maxDigitsLHF - 2; i < len; i++ ) { maxLHF += "9"; }
maxLHF  = 2 * maxDigitsLHFMultiplier + parseInt(maxLHF, 10); //a value of the max prefix = (4 * 10^N) + 999..999, 9 is repeted (N-1) times, where N = maxDigitsLHF
const minLHF = minDigitsLHFMultiplier + 10 + maxDigitsQuadrantLatAsMultiplier*10 ; //(10^minDigitsLHF = minDigitsLHFMultiplier) + (lng square num = 1 = maxDigitsQuadrantLatAsMultiplier*10) + (lat square num = 1 = 10) + (minimum fingerprint part = 0)

const maxDigitsMultiplier = Math.pow(10, maxDigits);
const maxDigitsMultiplierMult100 = maxDigitsMultiplier * 10 + 9;
const maxDigitsMultiplierMult1000 = maxDigitsMultiplier * 100 + 99;

var moduleSettings = {
    maxDigitsQuadrantLngAsMultiplier : maxDigitsQuadrantLngAsMultiplier,
    maxDigitsQuadrantLatAsMultiplier : maxDigitsQuadrantLatAsMultiplier,
    maxDigitsLHF : maxDigitsLHF,
    minDigitsLHF : minDigitsLHF,
    dividerForTimestampHash : dividerForTimestampHash,
    prefixForKeyUserID : prefixForKeyUserID,
    maxLHF : maxLHF,
    minLHF : minLHF
};

//return a fingerprint was fomed by fingerprint32 function and other operators for location hash in the server format
function getLocationHashFingerprint(locationHash) {
    return (fingerprint32(key3, locationHash) & key2) >>> rightShiftNumDigitsKey2;
}

//calculate a value of the K2 coeff
//resFingerprint max = 999
const maxK2 = parseInt("111111111111111111",2); 
const key_1 = parseInt("111011111101111011",2); //max = 1111111111111111
const key_2 = parseInt("000101111111111101",2); //max = 1111111111111111
const key_3 = parseInt("111011111011111111",2); //max = 1111111111111111
const key_4 = 34501;
const key_5 = 3;
const key_6 = 214;
function calcK2(resFingerprint){
    if ( resFingerprint > 20 ) {
        return ( (resFingerprint * key_5) & key_1) + key_4;    
    } else if ( resFingerprint > 500 ) {
        return ( (resFingerprint * key_6) & key_1) - key_4;    
    } else if ( resFingerprint > 123 ) {
        return ( (resFingerprint + key_4) | key_2) - key_5;
    } else {
        return ( (resFingerprint * key_5) | key_3) + key_6;
    }
}

/*encode location hash parts to a hash value, that will be returned to the user as a string
 locationHashParts = 
 Array[prefix,longitudeSquareNum,latitudeSquareNum, locationHash], where all items are integers
    prefix - depends on octothorpes of the longitude and latitude. Prefix is a one symbol
    longitudeSquareNum - amplified to maxDigitsQuadrantLng symbols length longitudeSquareNum
    latitudeSquareNum - amplified to maxDigitsQuadrantLat symbols length latitudeSquareNum
    locationHash - hash of the user location
 */

function encodeLocationHashParts(prefix, longitudeSquareNum, latitudeSquareNum, locationH) {
    // var intLocationHash = locationHashParts[3];
    // var prefix = locationHashParts[0];
    // var lonSquareNum = locationHashParts[1];
    // var latSquareNum = locationHashParts[2];
    var resFingerprint = getLocationHashFingerprint(locationH);
    
    var k2 = calcK2(resFingerprint); 
    var lh = prefix * prefixMultiplier + ( longitudeSquareNum ^ (k2 & maxLngPart) ) * maxDigitsQuadrantLatAsMultiplier + ( latitudeSquareNum ^ ( k2 & maxLatPart ) );
    var mult;
    if ( resFingerprint < 9 ) {
        mult = 10;
    } else if ( resFingerprint > 99 ) {
        mult = 1000; 
    } else if ( resFingerprint > 9 ) {
        mult = 100;    
    }
    return lh * mult + resFingerprint;
}

//encode location hash to a hash value, that will be returned to user as string
//intLocationHash = hash of a location in inner format
function encodeLocationHash(intLocationHash) {
    var squares = locationHashToSquaresNumbers(intLocationHash, true);
    return encodeLocationHashParts(squares[2], squares[0], squares[1], intLocationHash);  
}

//encode location hash to a hash value, that will be returned to user as string by the user's coordinates - longitude and latitude
//return location hash, that can be returned to the client side
function encodeLocationHashByCoords(longitude, latitude) {
    var res = locationHashParts(longitude, latitude);
    return encodeLocationHashParts(res[0],res[1],res[2],res[3]);
}

//encode an array, that is cointain a location hashes in the inner server format
//arrLocationsHashes = Array[locationHash1...locationHashN]
function encodeArrayLocationHashes(arrLocationsHashes){
    for( var i =0, len = arrLocationsHashes.length; i < len; i++ ) {
        arrLocationsHashes[i] = encodeLocationHash(arrLocationsHashes[i]);
    } 
    return arrLocationsHashes;
}

//decode a parts of the original location hash from a location hash for users
//return [prefix, lonSquareNum, latSquareNum, resFingerprintPart];
function decodeLocationHashAllPartsFromLHF(locationHashForUsers) { //LHF - location hash for users
    try {
        var multOrig_resFingerprint;
        if ( locationHashForUsers < maxDigitsMultiplierMult100 ) {
            multOrig_resFingerprint = 10;    
        } else if ( locationHashForUsers > maxDigitsMultiplierMult1000 ) {
            multOrig_resFingerprint = 1000;
        } else if ( locationHashForUsers > maxDigitsMultiplierMult100 ) {
            multOrig_resFingerprint = 100;
        }
        var lh = Math.trunc(locationHashForUsers / multOrig_resFingerprint);
        var squares = locationHashToSquaresNumbers(lh, true);
        var orig_resFingerprint = locationHashForUsers - lh * multOrig_resFingerprint;
        var orig_k2 = calcK2(orig_resFingerprint);
        var prefix = squares.prefix;
        if ( prefix < 1
            || prefix > 4 ) {
                return false;        
        }
        return [squares[2], squares[0] ^ (orig_k2 & maxLngPart), squares[1] ^ (orig_k2 & maxLatPart), orig_resFingerprint]; //decode the original locationHash
    } catch(e) {
        return false;    
    }
}

//decode the original locationHash in the server format from a parts of a lhf
//lhfParts = [prefix, lonSquareNum, latSquareNum]
function decodeLocationHashByParts(lhfParts){
  return lhfParts[0] * prefixMultiplier + (lhfParts[1] < 0 ? -lhfParts[1] : lhfParts[1]) * maxDigitsQuadrantLatAsMultiplier + (lhfParts[2] < 0 ? -lhfParts[2] : lhfParts[2]); //decode the original locationHash  
}

//decode the original location hash from a location hash for users
//return locationHash or false;
function decodeLocationHashFromLHF(locationHashForUsers) { //LHF - location hash for users
    var parts = decodeLocationHashAllPartsFromLHF(locationHashForUsers);
    if ( parts === false ) {
        return false;
    } else {
        return decodeLocationHashByParts(parts); //decode the original locationHash
    }
}

//decode the parts of the location hash in the server format from a location hash in the user format
//return [ 0:lonSquareNum, 1:latSquareNum ]
function decodeLocationHashPartsFromLHF(locationHashForUsers) { //LHF - location hash for users
    var parts = decodeLocationHashAllPartsFromLHF(locationHashForUsers);
    if ( parts === false ) {
        return false;
    } else {
        var signs = getCoordsSignsByPrefix(parts[0]); //return [lngSign, latSign]
        return [
            signs[0] === true ? -parts[1] : parts[1], //lng
            signs[1] === true ? -parts[2] : parts[2] //lat
        ];
    }
}

//decode the original location hash and a fingerprint part from a location hash for users
//return Array[ locationHash, fingerprintPart ]
//return false if an error
function decodeLocationHashFromLHFWithFingerprintPart(locationHashForUsers) { //LHF - location hash for users
    var parts = decodeLocationHashAllPartsFromLHF(locationHashForUsers);
    if ( parts === false ) {
        return false;
    } else {
        return [ decodeLocationHashByParts(parts), parts[3] ];
    }
}

//return true if an lhf is within the range of the lhf format
function lhfOrLocationHash(lhf){
    if ( !(lhf < minLHF //if too small to be a valid location hash
            || lhf > maxLHF) ) {//if too large to be a valid location hash
        return true;
    } else {
        return false;
    }
}

//check if the locationHash has a format for users, retrun true if it is
function ifLocationHashIsLHF(lhf){
    if (typeof(lhf) === "number"
        && (lhf & 1) === 0
        && lhfOrLocationHash(lhf) === true ) {
            return true;
    }
    else {
        return false;
    }
}

/*check if a location hash is valid
    LHF - location hash in the format for users
    return false if a wrong format
    return decoded locationHash if true format
*/
function decodeAndCheckLHFByFingerprint( lhf ) {
    if ( ifLocationHashIsLHF(lhf) !== true ) {
        return false;    
    } else {
        var lhfWithFingerprint = decodeLocationHashFromLHFWithFingerprintPart(lhf);
        if ( lhfWithFingerprint === false ) { //if it is a not valid location hash
            return false;    
        }
          
        var locationHash = lhfWithFingerprint[0];
        if (getLocationHashFingerprint(locationHash) === lhfWithFingerprint[1]) { //if the fingerprint is valid
            return locationHash;
        } else {
            return false;
        }
    }
}

var checkLonSquareNum = commonGeoF.checkLonSquareNumOrFalse; //check a number of a longitude square
var checkLatSquareNum = commonGeoF.checkLatSquareNumOrFalse; //check a number of a latitude square
var getPrefixByLngLat = commonGeoF.getPrefixByLngLat; //get prefix by a signs of a lng and lat or corresponding square numbers
function decodeAndCheckLHFByLocationHash( lhf ) {
    if ( ifLocationHashIsLHF(lhf) !== true ) {
        return false;    
    } else {
        var locationHashParts = returnLocationHashPartsInServerFormat(lhf); //get squares numbers by lhf
        var lng = locationHashParts[0];
        var lat = locationHashParts[1];
        if ( checkLonSquareNum(lng) !== false
                && checkLatSquareNum(lat) !== false ) {
                    return decodeLocationHashByParts([getPrefixByLngLat(lng, lat), lng, lat]);
        } else {
            return false;
        }
    } 
}

//convert a location hash from the lhf format to the server format and return it
function returnLocationHashInServerFormat(locationHash){
    return lhfOrLocationHash(locationHash) === true ? decodeLocationHashFromLHF(locationHash) : locationHash; //check if the location hash is in the LHF format, then decode it to the server format   
}

//convert a location hash from the lhf format to the server format and return a parts of it [0:lonSquareNumber, 1: latSquareNumber]
function returnLocationHashPartsInServerFormat(locationHash){
    return lhfOrLocationHash(locationHash) === true ? decodeLocationHashPartsFromLHF(locationHash) : locationHashToSquaresNumbers(locationHash); //check if the location hash is in the LHF format, then decode it to the server format   
}

/*
    calculate the nearest locations and convert them to the client format for the lhf(lcoation hash in the client format)
    lhf can be location hash in the server format or the location hash in the client format
    both of the formats are works
*/
function calculateNearestLHFByLocationHashOrLHF(lhf) {
    var locationHashParts = returnLocationHashPartsInServerFormat(lhf); //get squares numbers by lhf
    return encodeArrayLocationHashes(calculateNearestLocationsBySquaresNumbers(locationHashParts[0],locationHashParts[1])); //calculate the nearest locations and convert them to the client format
}

module.exports = {
    getTimestampHash : getTimestampHash,
    getTimestampByHash : getTimestampByHash,
    getHashUserIDWithTimestamp : getHashUserIDWithTimestamp,
    getTimestampAndUserIDByHash : getTimestampAndUserIDByHash,
    getHashOfLocalServer : getHashOfLocalServer,
    parseHashOfLocalServer : parseHashOfLocalServer,
    getKeyOfUserIDForDb : getKeyOfUserIDForDb,
    getUserIDFromDbKey  : getUserIDFromDbKey,
    getHashLocalServerLocation : getHashLocalServerLocation,
    getPrefixLocalServerLocationByHash : getPrefixLocalServerLocationByHash,
    encodeLocationHash : encodeLocationHash,
    encodeLocationHashByCoords : encodeLocationHashByCoords,
    encodeArrayLocationHashes : encodeArrayLocationHashes,
    decodeLocationHashFromLHF : decodeLocationHashFromLHF,
    decodeLocationHashPartsFromLHF : decodeLocationHashPartsFromLHF,
    decodeLocationHashFromLHFWithFingerprintPart : decodeLocationHashFromLHFWithFingerprintPart,
    decodeAndCheckLHFByFingerprint : decodeAndCheckLHFByFingerprint,
    decodeAndCheckLHFByLocationHash : decodeAndCheckLHFByLocationHash,
    maxLengthFingerprint : maxLengthFingerprint, //the maximum length of the fingerprint of the location hash
    isLocationHashIsLHF : ifLocationHashIsLHF,
    returnLocationHashInServerFormat : returnLocationHashInServerFormat,
    returnLocationHashPartsInServerFormat : returnLocationHashPartsInServerFormat,
    calculateNearestLHFByLocationHashOrLHF : calculateNearestLHFByLocationHashOrLHF,
    moduleSettings : moduleSettings
};