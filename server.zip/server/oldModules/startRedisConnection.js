var path = require("path");
var redis = require('thunk-redis');
var bluebird = require("bluebird");
var appSettings     = require("/home/ubuntu/workspace/settings/getSettings.js"),
    globalSettings  = appSettings.appSettings;
var EventEmitter = require("events").EventEmitter,
    eEmitter = new EventEmitter();
var Promise = require("bluebird");

var log = require("fm-log").module("redis");
    log.withSource();

function setDefaultMethodsOfRedisClient(redisClient) {

    if (redisClient._g_isRedisClientConnected) {  //if the property is exists, that means that all is already has been done
        return;
    }

    //properties
    redisClient._g_Reconnecting = false;

    //methods
    redisClient._g_isRedisClientConnected = isRedisClientConnected;
}

//return RedisClient instance or false if failed to establish the connection
function connectToRedis(hosts, options) {
    return new Promise(function (resolve, reject) {
        var redisClient = redis.createClient(hosts, options);

        var _g_intCheckC = setTimeout(function () { //check that the connection was established
            redisClient.quit();  //bad result, because the connection has not been established
            reject(new Error("Connection is time out"));
        }, 10000);

        redisClient.once("connect", function () {
            this.redisClient = redisClient;
            clearTimeout(_g_intCheckC);  //stop the checkout by a fact that the connection was established
            this.removeListener("close", connectionClosedOrError); //remove error and close events listeners
            this.removeListener("error", connectionClosedOrError);

            setDefaultMethodsOfRedisClient(redisClient); //extend methods for RedisClient
            setDefaultEventListenersOfRedisClient(redisClient); //events listeners

            console.log(module.filename + ". Redis client has connected");

            resolve(redisClient); //good result
        });

        function connectionClosedOrError(error) {
            setTimeout( //waiting for some time, may client will re-connect
                function(){
                    if ( isRedisClientConnected.call(redisClient) ) {  //client connected or is reconnecting
                        return;
                    }
                    redisClient.quit();   //if the connection to the redis cluster was closed or an error has occured
                    reject(error || new Error("Connection closed"));
                });
        }

        redisClient.on("close", connectionClosedOrError);
        redisClient.on("error", connectionClosedOrError);
        redisClient.on("reconnecting", function() {
            this._g_Reconnecting = true;  //flag means that reconnecting was started
        });
    });
}

function setDefaultEventListenersOfRedisClient(redisClient) {

    redisClient.on('close', function () {
        this._g_Reconnecting = false;
        console.log(module.filename + ". Redis client has been closed  ");
    });

    redisClient.on('error', function (error) {
        console.log(module.filename + ". Redis client caused an error  " + error);
    });

}

//checks is a connection to the redis cluster still working
function isRedisClientConnected() {
    var redisClient = this;
    if (!redisClient
            || !redisClient.clientState) {  //redis client instance is absent )
                return false;
    }
    if ((redisClient.clientState()).connected
            || redisClient._g_Reconnecting) {   //redis client is not connected
                return true;
    }
    return false;
}

//return promise, that call reject, when a connection to the redis cluster is not works
function checkConnectionToDB(redisClient) {
    return new Promise(function (resolve, reject) {
        redisClient.on("close", function(){
            if (!redisClient._g_isRedisClientConnected() ) {
                reject(new Error("The connection to the redis cluster is broken"));
            }
        });
        redisClient.on("error", function(){
            if (!redisClient._g_isRedisClientConnected() ) {
                reject(new Error("The connection to the redis cluster is broken"));
            }
        });
    });
}

//start connection with redis cluster
//function checks connection to redis client and tries to reconnect if the client will be closed
//callbackRedisClientChanged(redisClient) - called every time when the redis client has changed, because the previous was closed because of an error
//return an error if it has occurred
//callback when the first time connection will be established
function startConnection() {
    var self= this;
    connectToRedis(
        { host: "127.0.0.1", port:6379 },
        //[   
            // {host: "127.0.0.1", port: 7000},
            // {host: "127.0.0.1", port: 7001},
            // {host: "127.0.0.1", port: 7002},
            // {host: "127.0.0.1", port: 7003},
            // {host: "127.0.0.1", port: 7004},
            // {host: "127.0.0.1", port: 7005},
            // {host: "127.0.0.1", port: 7006}
        //],
        {
            database: 0,
            usePromise: bluebird,
            retryMaxDelay: 2000,
            maxAttempts: 20,
            commandsHighWater: 1000,
            noDelay: false,
            handleError: true
        }
    )
        .then(function (_redisClient) {
            self.redisClient = _redisClient;
            self.emit("connected", _redisClient);
            return checkConnectionToDB(_redisClient);   //whait when the redis client was closed because of an error;
        })
        .catch(function (err) {
            if (err instanceof Error) {
                log.error(err);
            }
            self.emit("closed");
            if ( self.redisClient ) {
                self.redisClient.quit(); //close the previous redis client
                self.redisClient = null;
            }
            self.startConnection(); //if an error, than try to start a new connection to the redis cluster once again
        });
}

//promise
function returnRedisClient() {
    var self = this;
    self.startConnection();
    function onRedisConnected(resolve, reject) {
        if ( self.redisClient 
                && self.redisClient.clientState
                && self.redisClient.clientState().connected ) {
                    resolve(self.redisClient);
        }
        self.once("connected", function(_redisClient){
            resolve(_redisClient);
        }); 
    }
    return new Promise(onRedisConnected);
}

function RedisConnector() {
    this.redisClient = null;  //redisClient connected to the redis cluster
}
RedisConnector.prototype = eEmitter;
RedisConnector.prototype.returnRedisClient = returnRedisClient;
RedisConnector.prototype.startConnection   = startConnection;


//emitted events:
//connected(redisClient) - first time connected to the redis cluster
//closed - when the connection to the redis was closed or absent because of any errors

module.exports = RedisConnector;