var path = require("path");
var redis = require('thunk-redis');
var Promise = require("bluebird");
var settings = require(path.resolve(__dirname,"settings/getSettings.js")).appSettings;
///!!!!
var setImmidiate = setTimeout;
var log = require("./logger.js").loggerDb(__filename);

//checks is a connection to the redis cluster still working
function isRedisClientConnected() {
    var redisClient = this;
    if (!redisClient
            || !redisClient.clientState) {  //redis client instance is absent )
                return false;
    }
    if ((redisClient.clientState()).connected
            || redisClient._g_Reconnecting) {   //redis client is not connected
                return true;
    }
    return false;
}

function setDefaultEventListenersOfRedisClient(redisClient) {

    redisClient.on('close', function () {
        this._g_Reconnecting = false;
        log("Redis client has been closed  ");
    });

    redisClient.on('error', function (error) {
        log("Redis client caused an error  " + error);
    });
    
    redisClient.on("reconnecting", function() {
        this._g_Reconnecting = true;  //flag means that reconnecting was started
    });

}

function setDefaultMethodsOfRedisClient(redisClient) {

    if (redisClient._g_isRedisClientConnected) {  //if the property is exists, that means that all is already has been done
        return;
    }

    //properties
    redisClient._g_Reconnecting = false;
    //methods
    redisClient._g_isRedisClientConnected = isRedisClientConnected;
}

//return RedisClient instance or false if failed to establish the connection
function connectToRedis(hosts, options) {
    return new Promise(function (resolve, reject) {
        var redisClient = redis.createClient(hosts, options);

        setDefaultMethodsOfRedisClient(redisClient);
        
        redisClient.once("connect", function () {
            this.redisClient = redisClient;
            this.removeAllListeners("close", connectionClosedOrError);
            setDefaultEventListenersOfRedisClient(redisClient);
            resolve(redisClient);
        });

        function connectionClosedOrError(error) {
            setImmidiate( //waiting next i/o events, may client will re-connect
                function(){
                    if ( redisClient._g_isRedisClientConnected() ) {  //client connected or is reconnecting
                        return;
                    }
                    redisClient.quit();   //if the connection to the redis cluster was closed or an error has occured
                    reject(error || new Error("Connection closed"));
                });
        }

        redisClient.on("close", connectionClosedOrError);
        redisClient.on("error", connectionClosedOrError);
        redisClient.on("reconnecting", function() {
            this._g_Reconnecting = true;  //flag means that reconnecting was started
        });
    });
}

function connect(){
    return connectToRedis(
        //{ host: "127.0.0.1", port:6379 },
        settings.redisHosts,
        {
            database: 0,
            usePromise: Promise,
            retryMaxDelay: 2000,
            maxAttempts: 20,
            commandsHighWater: 1000,
            noDelay: false,
            handleError: true
        }
    ).catch(function(err){
       log(err);
       return connect(); 
    });
}

function onClose(redisClient){
    return redisClient.then(function(_redisClientInstance){
            return new Promise(function(resolve, reject){
                function connectionClosedOrError(error) {
                    setImmidiate( //waiting a next i/o events, may the client will re-connect
                        function(){
                            if ( !_redisClientInstance._g_isRedisClientConnected() ) {  //client connected or is reconnecting
                                reject(error);
                            }
                    });
                }
                if ( !_redisClientInstance._g_isRedisClientConnected() ) {  //client connected or is reconnecting
                     reject(new Error("closed"));
                }
                _redisClientInstance.on("close", connectionClosedOrError);
                _redisClientInstance.on("error", connectionClosedOrError);    
            })
    });
}

function redisConnection(){
    var self = this;
    this.redisClient = connect();
    function onRedisConnectionClose(){
        onClose(self.redisClient)
        .catch(function(err){
            log("connection to the redis was closed");
            log(err);
            self.redisClient = connect();
            onRedisConnectionClose();
        });    
    }
    onRedisConnectionClose();
}

module.exports = redisConnection;