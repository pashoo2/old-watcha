/*jshint curly:true, debug:true */
//MESSAGES SCHEMAS

var patterns = require("./patterns.js"),
    jsen = patterns.jsen;

var schemasForMessages = {
    //request to chose another local server for the location
    //schema for ELS
    vSchemaIncomingMessage_clientChooseAnotherLS_fromELS : { 
        type: "object",
        additionalProperties : false,
        required : ["type","kind","body"],
        properties: {
            type: { "enum" : ["fromELS"] },
            kind: { "enum" : ["chooseAnotherLS"] },
            body: patterns.opVS_fromELS_userLocation //calcLocationHash = the current location hash for an els instance or an ils instance
        }
    },
    //request to chose another local server for the location
    //schema for ILS
    vSchemaIncomingMessage_clientChooseAnotherLS_fromILS : {
        type: "object",
        additionalProperties : false,
        required : ["type","kind","body"],
        properties: {
            type: { "enum" : ["fromILS"] },
            kind: { "enum" : ["chooseAnotherLS"] },
            body: {
                type : "object",
                required : ["locations, lsID"],
                properties : {
                    locations : patterns.opVS_fromELS_userLocation, //els locations
                    lsID      : patterns.optVS_userID               //id of a local server, to which the els is connected
                }
            }
        }
    },
    //incoming pong
    vSchemaIncomingMessage_LSPongResponse : {
        type: "object",
        additionalProperties : false,
        required : ["type","kind","body"],
        properties: {
            type: { "enum" : ["fromILS"] },
            kind: { "enum" : ["pong"] },
            body: patterns.optVS_locationHashNoFormat //calcLocationHash = the current location hash for an els instance or an ils instance
        }
    },
    //get a time offset beetween the server and the client in milliseconds
    vSchemaIncomingMessage_clientGetTimeUTCDifference : {
        type: "object",
        additionalProperties : false,
        required : ["type","kind","body"],
        properties: {
            type : { "enum" : ["main"] },
            kind : { "enum" : ["getTimeUTCDifference"] },
            body : {
                type : "object",
                additionalProperties : false,
                required : ["cDate","cMilliseconds"],
                properties : {
                    cDate         : {type : "string", format : "date-time"},
                    cMilliseconds : patterns.optVS_milliseconds    
                }
            }
        }
    },
    //get the local server id for the location from ils
    vSchemaIncomingMessage_lsGetLocalServerID_fromILS : {
        type: "object",
        additionalProperties : false,
        required : ["type","kind","body"],
        properties: {
            type: { "enum" : ["fromILS"] }, //from client(els)
            kind: { "enum" : ["getLSID"] },
            body: patterns.opVS_fromILS_ilsLocation_withOldLS
        }
    },
    //get the local server id for the location from els
    vSchemaIncomingMessage_lsGetLocalServerID_fromELS : {
        type: "object",
        additionalProperties : false,
        required : ["type","kind","body"],
        properties: {
            type: { "enum" : ["fromELS"] }, //from client(els)
            kind: { "enum" : ["getLSID"] },
            body: patterns.opVS_fromELS_userLocation //all an incoming descriptions of the user location comming with the id of the local server, to which an els is connected
        }
    },
    //request calculated hashes by the users lattitude and longitude
    vSchemaIncomingMessage_lsCalculateHashesUsersLocations_fromILS : {
        type: "object",
        minProperties : 1,
        maxProperties : 1000,
        format : "propertiesIsUsersID",
        additionalProperties : {
            type : "object",
            additionalProperties : false,
            required : ["lat","lng"],
            properties : {
                lat: patterns.optVS_latitude,
                lng: patterns.optVS_longitude    
            }
        }    
    }
};

var validatorsForMessages = {
    validationIncomingMessage_clientChooseAnotherLS_fromELS     : jsen(schemasForMessages.vSchemaIncomingMessage_clientChooseAnotherLS_fromELS),
    validationIncomingMessage_clientChooseAnotherLS_fromILS     : jsen(schemasForMessages.vSchemaIncomingMessage_clientChooseAnotherLS_fromILS),
    validationIncomingMessage_LSPongResponse                    : jsen(schemasForMessages.vSchemaIncomingMessage_LSPongResponse),
    validationIncomingMessage_clientGetTimeUTCDifference        : jsen(schemasForMessages.vSchemaIncomingMessage_clientGetTimeUTCDifference),
    validationIncomingMessage_lsGetLocalServerID_fromILS        : jsen(schemasForMessages.vSchemaIncomingMessage_lsGetLocalServerID_fromILS),
    validationIncomingMessage_lsGetLocalServerID_fromELS        : jsen(schemasForMessages.vSchemaIncomingMessage_lsGetLocalServerID_fromELS),
    validationIncomingMessage_lsCalculateHashesUsersLocations   : jsen(schemasForMessages.vSchemaIncomingMessage_lsCalculateHashesUsersLocations_fromILS)
};

module.exports = validatorsForMessages;