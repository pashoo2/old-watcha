var Promise = require("bluebird");

var contextForReturnResolvedPromise = {
    1 : Promise.resolve,
    0 : Promise.resolve(null)
};
//works as the standard Promise.resolve, but if given a null or undefined as the argument, then return the global resolved promise with a null as the result
Promise.resolve = Promise.fulfilled = Promise.cast = function returnResolvedPromise(value) {
    if ( value == null ) {
        var _globalResolvedPromise = this[0];
        if ( _globalResolvedPromise === undefined
            || _globalResolvedPromise[900000] !== undefined ) { //if too much inner references
                _globalResolvedPromise = this._r = this[1].call(this, null); //create a new resolved promise
        }
        return _globalResolvedPromise;
    } else {
        return this[1].call(this, value);
    }
}.bind(contextForReturnResolvedPromise);

//bind the given context to a promise
Promise.prototype.bindTo = function bindContext(newContext){
    this.__boundToContext = newContext; //bond a Promise to the new context
    return this;
}; 
Promise.prototype._oldThen = Promise.prototype.then;
/*
    Replace the old 'then' for this. 
    This method can bind a context to a promisfy function. To bind a context call it as : Promise.then(newContext, func)
    Can be used like the standard 'then' function: Promise.then(func...)
    but, if a context was bound to the Promise earlier with a bindTo, then this function automatically bind the previous context to each call of it
*/
Promise.prototype.then = function newThen(newContext, arg1, arg2, arg3) {
    var ret;
    var bindToContext = this.__boundToContext; //may already bound to a context
    if ( typeof(newContext) === "object" ) {
            return this._then(arg1, arg2, arg3, newContext); //apply the given context to _then
    } else if ( bindToContext != null ) {
        ret = this._then(newContext, arg1, arg2, bindToContext); //apply the bound context to _then
        if ( ret.__boundToContext === undefined ) {
            ret.__boundToContext = bindToContext;
        }
        return ret;
    } else { //if there is no context for this promise
        return this._oldThen(newContext, arg1, arg2);    
    }
};

module.exports = Promise;