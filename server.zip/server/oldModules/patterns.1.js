"use strict";

var path = require("path"),
    commonGEO = require("./commonGeoFunctions.js"),
    extend = require("extend"),
    dbGeo = require("./dbGeo.js"),
    getTimestamp = require("./getTimestamp.js"),
    commonF = require("./common.js"),
    _toInt = commonF.strToInt,
    _toStr = commonF.numToStr;
    
var log = require("./logger.js").loggerMsg(__filename);

var settings = {
    timestampSecondsDifferenceOverdueIncomingMessages : 10 //when this time is passed the message will become not overdue
};

//SchemaInspector-

//check the timestamp of the message
function vSchemaFunc_checkTimestamp(schema, post, callback) {
    if ( post.timestamp ) {
        var currTimestamp = getTimestamp();
        var diff = currTimestamp - post.timestamp;
        if ( diff < 0 ) { //if the timestamp of the message is bigger than the current timestamp
            if ( diff < -2 ) {
                this.report("The timestamp of the message is larger than the current timestamp");
            } else { //less than 2 seconds difference between the client and the server time
                post.timestamp = currTimestamp; //set timestamp of a message equl to the current timestamp
            }
        } else if ( diff > settings.timestampSecondsDifferenceOverdueIncomingMessages ) { //differense is more than the setting value
            this.report("The message is not overdue");
        }
    }    
    return post;
}

//calculate the hash of the location into the object by properties "lat"(or "latitude") and "lng"(or "longitude")
//function will be invoked by SchemaInspector depending on a validation schema
//put calcLocationHash - calculated location hash
//put flag _flLocationChanged if locationHash <> calcLocationHash
function vSchemaFunc_getLocationHash(schema, post, callback) {
    
    function _callback() {
        if (callback) callback();
    }
    
    if (!post //there is no needed properties for the calculation into the post object
        || ( post.lat === undefined && post.latitude === undefined )
        || ( post.lng === undefined && post.longitude === undefined ) ) {
            if (post.locationHash !== undefined ) { //if have no a latitude and a longitude, but have a location hash
                post.calcLocationHash = post.locationHash;	//set the property calculated hash of the location with the same value
            }
            _callback();
            return post;
    }
    var lat = post.lat || post.latitude,
        lng = post.lng || post.longitude;
        
    if ( typeof(lat) !== "number" || typeof(lng) !== "number" ) {
        this.report("The lattitude and the longitude must be a number");
        _callback();
        return;
    } else if ( lng > 180 || lng < -180  ) {
        this.report("The longitude must be greater than -180 and less than +180");
        _callback();
        return;
    }
     else if ( lat > 90 || lat < -90  ) {
        this.report("The latitude must be greater than -90 and less than +90");
        _callback();
        return;
    }

    post.calcLocationHash = commonGEO.locationHash(lat, lng);

    if (post.hasOwnProperty("locationHash")
        && post.locationHash != post.calcLocationHash) { //current and calculated hashes are not equals
            post._flLocationChanged = true; //put the flag into the messsage
    }
    _callback();
    return post;
}

//check the location, that is requested by the ils
//the location must be nearest location or location, that is maintained by the ils
function vSchemaFunc_checkILSLocation(schema, post, callback) {
    var lsID = this._custom && this._custom.hasOwnProperty("$_g_userID") && this._custom["$_g_userID"];
    var self = this;
    function _callback() {
        if (callback) callback();
    }
    var maintainedLocation = post.maintainedLocationHash;
    if ( !maintainedLocation ) {
        this.report("There is no the property, called 'maintainedLocation'");
        _callback();
        return;
    }
    //check is a local server really maintains this location
    dbGeo.isLocationsMaintainedByLS(lsID, maintainedLocation)
    .then(function(_res){
        if ( _res === false ) {
            self.report("The location with the hash = " + maintainedLocation + " is not maintained by the local server with the id = " + lsID);
            _callback();
            return;
        }
        var requestedLocationHash = post.locationHash;
        if ( requestedLocationHash ) { //the property, called "locationHash" is not absent and no need to chech is it a nearest location to the maintained location
           //check is the location, that are requested by the local server is the nearest location to the maintainedLocation
           if ( requestedLocationHash != maintainedLocation ) { //if the requested location is equal to the handled location
               var arrNearestLocations = commonGEO.calculateNearestLocationsByLocationHash(maintainedLocation); 
               if ( !arrNearestLocations
                    || arrNearestLocations.indexOf(requestedLocationHash,10) === -1 ) { //this is not one of the nearest locations
                        self.report("The location with the hash = " + maintainedLocation + " is not maintained by the local server and not one of the nearest locations with to the local server with the id = " + lsID);
               }
           }
        }
        _callback();
        return;
    })
    .catch(function(){
        self.report("The location with the hash = " + maintainedLocation + " was not maintained by the local server with the id = " + lsID);
        _callback();
        return;
    });
}

//-SchemaInspector
var patternUserID       = /^[0-9]+$/,
    patternLongitude    = commonGEO.patternLongitude,   //regular expression pattern for longitude coordinate
    patternLatitude     = commonGEO.patternLatitude,    //regular expression pattern for latitude coordinate
    patternLocationHash = commonGEO.patternLocationHash; //regular expression pattern for location hash
        
var mainPatterns = {
        patternLongitude    : patternLongitude,   //regular expression pattern for longitude coordinate
        patternLatitude     : patternLatitude,    //regular expression pattern for latitude coordinate
        patternLocationHash : patternLocationHash, //regular expression pattern for location hash
        patternUserID       : patternUserID, //pattern for ID of the user
        optVS_milliseconds  : { pattern : /^[0-9]{13}$/ },
        optVS_userID : {
            type    : "string",
            rules   : "trim",
            pattern : patternUserID,
            optional: false
        }, //for user ID fields
        optVS_lsID  : {
            type    : "string",
            rules   : "trim",
            pattern : [patternUserID,/(?:)/],
            optional: false
        },
        optVS_timestamp : {
            type: "number",
            gt: 1000000000,
            lt: 10000000000,
            optional: false
        },  //for timesamp fields
        optVS_locationHash : {
            type: "string",
            rules: "trim",
            pattern: [patternLocationHash, /(?:)/],
            optional: false
        },
        optVS_latitude : {
            type: ["string", "number"],
            rules: "trim",
            pattern: patternLongitude,
            gte : -90,
            lte : 90,
            optional: false
        },
        optVS_longitude : {
            type: ["string", "number"],
            rules: "trim",
            pattern: patternLatitude,
            gte : -180,
            lte : 180,
            optional: false
        }
};

var moduleProto = {
    opVS_fromELS_userLocation: {
        type: "object",
        strict: true,
        exec: vSchemaFunc_getLocationHash,
        properties: {
            locationHash: mainPatterns.optVS_locationHash,
            lat: mainPatterns.optVS_latitude, 
            lng: mainPatterns.optVS_longitude, 
            localServerID: mainPatterns.optVS_lsID
        }
    },
    opVS_fromILS_ilsLocation: {
        type    : "object",
        strict  : true,
        exec    : vSchemaFunc_checkILSLocation,
        properties: {
            locationHash            : mainPatterns.optVS_locationHash,
            maintainedLocationHash  : mainPatterns.optVS_locationHash
        }
    },
    opVS_fromILS_ilsLocation_withOldLS: {
        type    : "object",
        strict  : true,
        exec    : vSchemaFunc_checkILSLocation,
        properties: {
            locationHash            : mainPatterns.optVS_locationHash,
            maintainedLocationHash  : mainPatterns.optVS_locationHash,
            localServerID           : mainPatterns.optVS_userID //the current local server for locationHash, that is stored into the client (local server) side
        }
    },
    vSchemaIncomingMessage_mainSchema : {
        type: "object",
        strict: true,
        exec : vSchemaFunc_checkTimestamp,
        properties: {
            type: {eq: "_gServer"},
            body: {
                type: "object",
                properties : {
                    type : { type: ["string","number"], optional : false, maxLength : 30 },
                    kind : { type: ["string","number"], optional : false, maxLength : 30 }
                }
            },
            timestamp: mainPatterns.optVS_timestamp
        }
    }
};
extend(moduleProto,mainPatterns);
module.exports = moduleProto;