var path = require("path");
var Redis = require('ioredis');
var Promise = require("bluebird");
var modulesettings = require(path.resolve(__dirname,"settings/settings.js")).redisDB;
var redisCluster = new Redis.Cluster(modulesettings.redisHosts, modulesettings.ioRedisSttings);
module.exports = redisCluster;