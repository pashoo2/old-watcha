"use strict";
var Promise = require("bluebird");
var log = require("debug")("promise:" + __filename);
var resolvedPromise = Promise.resolve(null);

//_func - is a function to execute
//numAttemts - is a number of tries to execute the _func without any errors
//if the numAttemts is empty, then the function will use the option of the module module.exports.numOfAttempts
//flCheckForErrorResult - if it is set to true, then need to check whether a result of the _func is an error
//exucuteIfError - is a function that will be executed if all attempts are failed. If undefined this module will throw an Error. Will be executed with the same arguments as the main function
//throwErrorText - text for an error, that will be thrown if all attempts failed, after execution of the executeError
//return function, that will executing the given promise
function tryPromise(_func) {
    var attempt = 1;
    var flCheckForErrorResult, numAttemts, exucuteIfError, throwErrorText;
    //try to find all the arguments
    for( let _argNum = 1; _argNum < arguments.length; _argNum++ ) {
        let arg     = arguments[_argNum];
        let argType = typeof(arg);
        switch( argType ) {
            case "boolean" : 
                flCheckForErrorResult = arg;
                break;
            case "function" :
                exucuteIfError = arg;
                break;
            case "number" :
                numAttemts = arg;
                break;
            case "string" :
                throwErrorText = arg;
                break;
        }
    }
    numAttemts = numAttemts || module.exports.numOfAttempts || 1;

    return function execPromise(){
        var _args = arguments;
        var self = this;
        
        function tryAgain(e) { //try to exec once again
            log(e);
            log("Attempt: " + attempt);
            attempt++;
            if ( attempt > numAttemts ) {
               if ( exucuteIfError )  {//if a function for execution if all attempts are failed, is set
                    try {
						var ex = exucuteIfError.apply(self, _args || e);
					} catch(err) { //if an error while executing exucuteIfError
						log(err);
					    throwErrorText = throwErrorText || err.message; //reject the promise with the error message
				    }
                    if ( ex instanceof Promise
                        && throwErrorText) { //the function exucuteIfError return a Promise as the result
                            ex = ex
                            .then(function(){ //need to throw an error after execution of the throwErrorText
                                return Promise.reject(new Error(throwErrorText));
                            });    
                    } else if ( throwErrorText ) { //the function exucuteIfError result is not a Promise
                         return Promise.reject(new Error(throwErrorText)); //need to throw an error after execution of the throwErrorText
                    }
                    return ex; //return the result of the function exucuteIfError
               } else {
                     return Promise.reject( throwErrorText ? new Error(throwErrorText) : ( e instanceof Error ?  e : new Error("Can't to execute the function ")) ); //if all the attempts are failed
               }
            } else {
               return 
                resolvedPromise
                .then(execPromise.apply(self, _args));
            }
        }
        
        function testError(_res){ //test the result of the _func for an Error
            if ( flCheckForErrorResult
                && _res instanceof Error ) {
                    return tryAgain(_res);
            }
            return _res;
        }
        
        try {
            var _promiseToExecute = _func.apply(this, arguments); //try to execute the _func
        } catch (e) {
            return tryAgain(e); //if an error has occurred
        }
        if ( !(_promiseToExecute instanceof Promise) ) {//if the result of the _func is not a function
            if ( flCheckForErrorResult
                && _promiseToExecute instanceof Error ) { //but is an Error
                    return tryAgain(_promiseToExecute);
            }
            return _promiseToExecute; //if it is not an error or a Promise, simply return the result of the _func
        } else {
            var _result = _promiseToExecute;
            if (flCheckForErrorResult) { //need to check an error result
                _result = _result //if promise, then whaiting for it's result
                .then(testError); //if the result of the promise, that was returned by the _func, is an error
            }
            return _result
            .catch(tryAgain); //or an error was thrown;
            
        }
    };
}

module.exports = {
    tryPromise : tryPromise,
    numOfAttempts : 3
};

/*Example:
Promise.resolve("FFF")
.then(tryPromise(function(ar){
    return new Promise(function(res, rej){
        res(new Error("FFF"));    
    });    
}, true))
.catch(function(e){
    log.info("Finally error");
    log.info(e);
})
.then(function(res){
    log.info("Good");
    log.info(res);
});*/