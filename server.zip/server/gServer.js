var HandlerMessagesFromClient = require("./workersMessagesHandlers.js"),
    dbGeo = require("./dbGeo.js"),
    extend = require("extend"),
    common = require("./common.js"),
    WebSocket = require("wsMy"),
    CommunicationServer = require("./dbPubSub.js"),
    logMsg = require("./logger.js").loggerMsg(__filename),
    getTimestamp = require("./getTimestamp.js"),
    strMesageConnected = '{"type":"_gServer","body":{"type":"main","kind":"connected","body":{}},"timestamp":' + getTimestamp() + '}', //the mock message, that the client connected after the reconection
    objMesageConnected = {
        type : "_gServer",
        body : {
            type : "main",
            kind : "connected",
            body : {}
        },
        timestamp : getTimestamp(),
        userID : 0
    };

//web socket connections states    
var connectionStateClosing = WebSocket.CLOSING,
    connectionStateClosed = WebSocket.CLOSED,
    connectionStateConnecting = WebSocket.CONNECTING,
    connectionStateOpen = WebSocket.OPEN;

//settings
var appSettings = require("./settings/settings.js"),
    numberOfMainServers = appSettings.gServers.length; //the number of a PeerJS main servers
    
var moduleSettings = require("./settings/settings.js").gServerSettings,
    _defaultKey = moduleSettings.defaultKey;
 
 //LISTENERS--  
 //incoming message from the user by socket connection
function onMessage(message, socket, client) {
    if ( client._g_session == null 
         || typeof(client._g_session.userID) !== "number" ) {
            return false;
    } 
    this.handleMessage(message, client._g_session.userID); //handle this message
}

//--LISTENERS

//get the client instance by client ID
function getClient(userID) {
    if (!this._clients
        || !this._clients[_defaultKey]) {
            return null;
    }
 return this._clients[_defaultKey][userID];
}
  
//get socket connection with the client by client ID
//or return null if there is no client or connection with the client
function getConnectionByID(userID) {
      var client = this.getClient(userID);
      if (!client) {
          return null;
      }
      var connection = client.socket;  //connecction with the user
      if (!connection
          || connection.readyState != WebSocket.OPEN) {
            return null;
      }
      return connection;
  }
  
function sendMessage(userID, message) {
    var serverNumberForUser = userID % numberOfMainServers; //will return a number of the PeerJS server for the user ID
    if ( this.g_serverNumber === serverNumberForUser ) { //if it is this server
        var flTypeMessageString = (typeof(message) === "string"); //flag that the message is a string
        if (flTypeMessageString === true
            || (typeof(message) == "object"
                && common.isEmptyObject(message) === false) ) { //the resulted message is not empty
                    //if the result is a message for the client
                    var socket = this.getConnectionByID(userID);
                    if ( socket != null //check the connection state
                        && (socket.readyState === connectionStateConnecting || socket.readyState === connectionStateOpen) ) {
                            socket.send( flTypeMessageString === true ? message : JSON.stringify(message) ); //send the result message to the client
                            logMsg("Message was sent to the client for now");
                    }
        }
    } else if ( this.communicationServer != null ) { //if it is another server
        this.communicationServer.sendMessage(
            serverNumberForUser,
            { //descriptiuon for the message
                type    : "s", //to inform the other gServer, that is is necessary to send this message to the user
                userID  : userID,
                message : (flTypeMessageString === true ? message : JSON.stringify(message)) //stringify the message object
            }
        );    
    } else {
        logMsg("Some gServer is unreachable");
    }
  }
  
function closeUserConnection(userID, reason) {
    if ( !userID 
        || !reason ) {
            return;
    }
    var serverNumberForUser = userID % numberOfMainServers; //will return a number of the PeerJS server for the user ID
    if ( this.g_serverNumber === serverNumberForUser ) { //if it is this server
        var connection = this.getConnectionByID(userID);
        if ( connection ) {
          closeConnection(reason, connection);
        }
    } else if ( this.communicationServer != null ) { //if the user is maintained by another gServer
        this.communicationServer.sendMessage(
            serverNumberForUser,
            { //description for the message
                type   : "d", //to inform the other gServer, that is is necessary to disconnect the user
                userID : userID,
                message : reason
            }
        );
    } else {
        logMsg("Some gServer is unreachable");
    }
  }

function closeConnection(reason, connection) {
        var socket = this || connection;
        socket.send(JSON.stringify(
            {
                type: 'ERROR',
                payload: {msg: ('Closed' || reason) }
            }
        ));
        socket.close();
}

//when close a connection with the user
function onSocketClose(userID) {
    if ( userID != null
        && userID !== 0 ) {
            dbGeo.setExpireForAllLocationsByLS(userID); //set the expiration time for all location that are maintained by the user as a local server
    }
}

/*
Handle a message from another gServer
descMessage = {type, userID, message}. 
Type may be "s" that means that is necessary to send the message to the user, or "d", to disconnect the user
*/
function onSendMessageToAnotherUser(descMessage) {
    if ( typeof(descMessage) === "object" )  {
        switch( descMessage.type ) {
            case "d" : //disconnect the user with the given reason
                this.closeUserConnection(descMessage.userID, descMessage.message);
                break;
            case "s" : //send the mesage to the user
                this.sendMessage(descMessage.userID, descMessage.message);
        }    
    }
}

/*
    new incoming connection
*/
function onNewConnection(userID) {
    var msg;
    if ( this.flUseWorkers !== true ) { //if it is started without a workers, we can send an objects
        msg = this.objMesageConnected;
        msg.userID = userID; //add user ID to the mesage description object
    } else { //send text message tro the worker
        msg = this.strMesageConnected;    
    }
    
    this.handleMessage(msg, userID); //handle the message that the client establish the new connection
}

var moduleMethods = {
    getClient           : getClient,
    getConnectionByID   : getConnectionByID,
    closeUserConnection : closeUserConnection,
    sendMessage         : sendMessage,
    onMessage           : onMessage,
    onSocketClose       : onSocketClose,
    onNewConnection     : onNewConnection
};


function gServer(app) {
    var thisModule = Object.create(app); //app as prototype
    extend(thisModule, moduleMethods);
    thisModule.moduleSettings = moduleSettings;

    //start module to communicate with another gServers by messaging with them
    var communicationServer = new CommunicationServer(thisModule.g_serverNumber); //give it number of this gServer
    if ( communicationServer.started != false ) {
        thisModule.communicationServer = communicationServer;
        communicationServer.on("message", onSendMessageToAnotherUser.bind(thisModule));
    }
    
    //create workers for handling a messages
    var handlerMessagesFromClient = thisModule.handlerMessagesFromClient = new HandlerMessagesFromClient();
    thisModule.handleMessage      = handlerMessagesFromClient.handleMessage.bind(handlerMessagesFromClient); //function sends a messages from users to an idle worker for handling
    
    /*define options*/
    thisModule.strMesageConnected = strMesageConnected;
    thisModule.objMesageConnected = objMesageConnected;
    thisModule.flUseWorkers = appSettings.useWorkers; 
    
    //listeners for an events from a messages handlers
    thisModule.sendMessage = sendMessage.bind(thisModule);
    thisModule.closeUserConnection = closeUserConnection.bind(thisModule);
    
    handlerMessagesFromClient.on("disconnectUser"   , thisModule.closeUserConnection); //close the connection with the user
    handlerMessagesFromClient.on("sendMessageToUser", thisModule.sendMessage); //send a message to the user
  
    //set PeerJS server methods
    app["_gServer_onConnection"] = thisModule.onNewConnection.bind(thisModule);
   
    return thisModule;
}
module.exports = gServer;