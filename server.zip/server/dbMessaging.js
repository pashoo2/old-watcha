"use strict";

var path = require("path"),
    getTimestamp = require("./getTimestamp.js"),
    Promise = require("bluebird"),
    hashes = require("./hashes.js"),
    commonlib = require("./common.js"),
    PipeCommander = require("myPipeCommander");
    
var log = require("./logger.js").loggerMsg(__filename);

//start redis client with automatically pipelining and distribution
var appSettings = require(path.resolve(__dirname,"settings/settings.js"));
var settingsRedis = appSettings.redisDB;
var optionsPipelineCommander = {
    redisNodesSettings : settingsRedis.redisNodesForMessagingModule, //host and port of a redis nodes
    ioRedisOptions : settingsRedis.optionsIORedis, //specified by the ioredis library    
    options : settingsRedis.optionsPipelineCommander //especially for the PipelineCommander library
};
var redisClient = new PipeCommander(optionsPipelineCommander); //use as redisClient.commandName.then(afterResult)

var mSettings = appSettings.dbMessaging;
var moduleSettings = {
    isArray : commonlib.isArray,
    getTimestamp : getTimestamp,
    getHashOfLocalServer : hashes.getHashOfLocalServer,
    redisClient : redisClient,
    timeIntervalBetweenCheckWhaitingPongResponces : mSettings.timeIntervalBetweenCheckWhaitingPongResponces, //seconds between the two checkouts of the whaiting pong responces
    ttlPongResponseKeys : mSettings.ttlPongResponseKeys, //time to live of a redis keys with local servers hashes and timestamps of responces
    timeIntervalSecondsWhaitingPongResponse: mSettings.timeIntervalSecondsWhaitingPongResponse //seconds, whaiting time of the user pong response to the ping request
};

//add user ID to the table with users, from which is need to receive response to ping request
//add to the hash table, where is the key = userID, the value = current timestamp
var addWaitingPongResponse =
(function notBound_addWaitingPongResponse(localServerID, locationHash, timestamp) {
    if ( localServerID == null
         || localServerID === 0 ) {
            return;
    }
    
    var redisClient = this.redisClient;
    
    var lsHash = this.getHashOfLocalServer(localServerID, locationHash); //a hash value to identify loal server by its id and location
    var whaitingTimestamp = this.getTimestamp() + this.timeIntervalSecondsWhaitingPongResponse; //time when it is necessary to send pong responce
    var ttlForKeys =  this.timeIntervalSecondsWhaitingPongResponse+this.ttlPongResponseKeys; //after this time whaitingTimestamp and lsHash keys will be removed  
    
    redisClient
    .multi(
        whaitingTimestamp,
        [ //commands
            ["sadd"  , whaitingTimestamp, lsHash], //add local server hash to the set with timestamps when the pong for this local server will has been expired
            ["expire", whaitingTimestamp, ttlForKeys], //set ttk for whaitingTimestamp key
        ]
    );
    
    redisClient
    .set(lsHash, whaitingTimestamp, "EX", ttlForKeys, "NX"); //tie lsHash with whaitingTimestamp, to allow for removingpong responce for lsHash. will be automatically removed after this.timeIntervalSecondsWhaitingPongResponse+ttlForLocalServerHash seconds 
    
})
.bind(moduleSettings);

//////////////////////////////////////////////////

//after when the whaitingTimestamp was gotten
function afterGetLSHash(whaitingTimestamp){
    if ( whaitingTimestamp != null ) { //if a ping request(whaiting pong response) is exists in the db 
        this.redisClient
        .del(this.lsHash); //delete the correspondence of ls-timestamp
        this.redisClient
        .srem(whaitingTimestamp, this.lsHash); //delete the correspondence of timestamp-ls
    }    
}
//delete user ID from the table with users, from which is need to receive response to ping request
var removeWaitingPongResponse = 
(function notBound_removeWaitingPongResponse(localServerID, locationHash) {
    if (localServerID === 0
        || localServerID == null) {
            return;
    }
    
    var redisClient = this.redisClient;
    
    var lsHash = this.getHashOfLocalServer(localServerID, locationHash); //a hash value to identify loal server by its id and location
    redisClient
    .get(lsHash)
    .bind({
        lsHash : lsHash,
        redisClient : redisClient
    })
    .then(afterGetLSHash);
})
.bind(moduleSettings);

//////////////////////////////////////////////////

//return object lssLocations with the structure { lsID : [locationHash1,..., locationHashN ] }, that has been created from an object lsList with the structure { hashLocationHashWithLocalServerID : score }
function addPongsToResultList(lssLocations, lsList) {
    var _keys = Object.keys(lsList);
    for ( var i = 0, len = _keys.length; i < len; i++ ) {
        var hashLocalServerIDWithLocationHash = lsList[_keys[i]];
        var localServerIDWithLocationHash = hashes.parseHashOfLocalServer(hashLocalServerIDWithLocationHash);
        var localServerID = localServerIDWithLocationHash.localServerID;
        var locationHash  = localServerIDWithLocationHash.locationHash;
        if ( Array.isArray(lssLocations[localServerID]) === false ) { //if the local server is absent in the list
            lssLocations[localServerID] = [locationHash];   //put the resulted list for local server 
        } else if ( lssLocations[localServerID].indexOf(locationHash) === -1 ) {
            lssLocations[localServerID].push(locationHash); //put to the resulted list for local server
        }
    }
    return lssLocations;
}

//when after got all hashes with a local servers, from which whaiting pong responces to the server ping requests
function afterGetAllLSHashes(res){ //lsHashes = [[hashes1],...[hashesN]]
    
    var result;
    var isArray = this.isArray;
    if ( isArray(res) === true ) { //if the result is not empty
        result = {};
        for( var i = 0, len = res.length; i < len; i++ ) {
            var lsHashes = res[i];
            if ( isArray(res) === true ) {
                addPongsToResultList(result, lsHashes); //the result have the format local_server_id : [locationHash1...locationHashN]
            }
        }   
    } 
    if ( this.flRemoveKeysWithTimestamps === true ) { //remove keys with whaitingTimestamp
        this.redisClient.del(this.arrWhaitingTimestamps); //keys for which local servers were got
    }
    
    return result;
}

/*
    return an object with id of the local servers, which are outdated their response to ping request
    if timestamp === null, then timestamp = getCurrentTimestamp() and all responces between (the current timestamp - ttlForKeys) and the current timestamp will be removed
    return { lsID : [locationHash1,...,locationHashN] }
    return null if empty list
*/
var getAllWhaitingPongResponses =
(function notBound_getAllWhaitingPongResponses(timestamp) {
    var flTimestamp = typeof(timestamp) === "number";
    var nowTimestamp = (flTimestamp === true) ? timestamp : this.getTimestamp();
    //read all sets with local servers and locations, which must been send the pong responces, from (the current timestamp - ttlForKeys) to (the current timestamp)
    var currentTimestamp = nowTimestamp - this.timeIntervalBetweenCheckWhaitingPongResponces; //the first key = whaitingTimestamp
    
    var redisClient = this.redisClient;
    
    var arrWhaitingTimestamps = [currentTimestamp, nowTimestamp];
    var arrPromises = [redisClient.SMEMBERS(nowTimestamp), redisClient.SMEMBERS(currentTimestamp)]; //array with the promises for execution
    var ind = 0;
    
    while( ++currentTimestamp < nowTimestamp ) { //form the range of a timestamps, which are representing a keys for db(whaitingTimestamp)
        arrWhaitingTimestamps.push(currentTimestamp); 
        arrPromises[ind++] = redisClient.SMEMBERS(currentTimestamp);
    }
    
    return Promise.all(arrPromises) //read the last keys in number of ttlForKeys
    .bind({ //scope for the function afterGetAllLSHashes
        arrWhaitingTimestamps : arrWhaitingTimestamps,
        isArray : this.isArray,
        flRemoveKeysWithTimestamps : flTimestamp,
        redisClient : this.redisClient
    })
    .then(afterGetAllLSHashes);
})
.bind(moduleSettings);

//////////////////////////////////////////////////

//delete all tasks for the local server and the location
function onDeleteLocalServerForLocation(localServerID, locationHash) {
    removeWaitingPongResponse(localServerID, locationHash);
}

module.exports = {
    addWaitingPongResponse          : addWaitingPongResponse,
    removeWaitingPongResponse       : removeWaitingPongResponse,
    getAllWhaitingPongResponses     : getAllWhaitingPongResponses,
    onDeleteLocalServerForLocation  : onDeleteLocalServerForLocation
};