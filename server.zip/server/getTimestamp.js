var globalObj = {
   currentTimestamp : 0 //the global value of the current timestamp
};

var updateTimestamp = (function() { //function for updating the global value of the current timestamp
    this.currentTimestamp = Math.ceil(Date.now() / 1000);
}).bind(globalObj);

updateTimestamp();

setInterval(updateTimestamp, 1000); //one time per one second the timestamp will be updated

module.exports = (function(){
    return  Math.ceil(Date.now() / 1000); //this.currentTimestamp; //return the value of the current global timestamp
}).bind(globalObj);
