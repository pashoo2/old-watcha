var vd = require("validator"),
patternLongitude = /^([-+])?[ ]?(\d{1,3})(?:(?:[.,](\d{1,5}))|(?:))$/i,
patternLatitude  = /^([-+])?[ ]?(\d{1,2})(?:(?:[.,](\d{1,5}))|(?:))$/i,
patternLocationHash = /^[1,2,3,4][0-9]{11}$/;
var commonF = require("./common.js");
var _toInt = commonF.strToInt;
var _toStr = commonF.numToStr;
var getFStr = commonF.getFStr;

//!!!not valid function checks format of the coordinate
//returns false if the coordinates format is wrong
function checkCoordinatesFormat( longitude, latitude )
{
    var resultLongLat = [];
    for (var ind = 0;ind<arguments.length;ind++) {
        var coord = arguments[ind];
        var regExpPattern = (ind === 0) ? patternLongitude:patternLatitude;
        var flIsString = false;
        if (coord && (
                ( flIsString = (typeof(coord) === "string") && coord.length < 20 )
                || ( typeof(coord) === "number" && Math.abs(coord) < 180 && ( coord = Math.round(coord * 10000) / 10000 ) )
            )) {
                if (!flIsString) { resultLongLat[ind] = coord; } //if coordinate is already a number
                else {
                    //check longitude format
                    coord = vd.trim(_toStr(vd)).toUpperCase();
                    var resultCoord = regExpPattern.exec(coord);
                    if ( !resultCoord ) {resultLongLat[ind] = false;} //a match was not found
                    else{
                        //number sign
                        var numSign = !resultCoord[1] ? "" : resultCoord[1];
                        switch (numSign) {
                            case "W":
                            case "S":
                            case "-":
                                numSign = "-";
                                break;
                            default :
                                numSign = "";
                        }
                        var integerPart = !resultCoord[2] ? "0" : resultCoord[2];
                        var fractional = !resultCoord[3] ? "0" : resultCoord[3];
                        var result = vd.toFloat(numSign + integerPart + "." + fractional);
                        if ( ind === 0 && Math.abs(result) > 180 ) {resultLongLat[ind] = false; continue;} //if longitude > 180
                        if ( ind !== 0 && Math.abs(result) > 90 )  {resultLongLat[ind] = false; continue;} //if latitude > 90
                        if (isNaN(result)) {
                            resultLongLat[ind] = false;
                        }
                        else {
                            resultLongLat[ind] = result;
                        }
                    }
                }
        }
        else {
            resultLongLat[ind] = false;
        }
    }
    return resultLongLat;
}

function squaresSerialNumber( longitude, latitude, flReturnQuarters )
{
    var quarters = [0.15,0.95];
    var absLong  = Math.abs( longitude );
    var absLat   = Math.abs( latitude  );
    var latShape = absLat  * 556.6;//( absLat / 90 ) * 50094;    //200 meters
    var lonShape = absLong * 556.6;//( absLong / 180 ) * 100188; //200 meters

    if ( lonShape > 100188 ) { lonShape = 100188; }
    if ( latShape > 50094 )  { latShape = 50094; }
    if ( lonShape < 1 ) { lonShape = 1; }
    if ( latShape < 1 ) { latShape = 1; }

    var ceilLonShapeNum = Math.ceil(lonShape);
    var ceilLatShapeNum = Math.ceil(latShape);

    var hashOfShape = hashOfTheSquare(ceilLonShapeNum, ceilLatShapeNum);

	if ( flReturnQuarters ) {
	    var latShapeTempNumber = latShape - Math.floor(latShape);
	    var lonShapeTempNumber = lonShape - Math.floor(lonShape);
        var shapeQuarterNum;

	    if ( lonShapeTempNumber <= quarters[0] ){
	        //if 1 or 3
	        if ( latShapeTempNumber <= 0.5 ) {shapeQuarterNum = 3;}
	        else{shapeQuarterNum = 1;}}
	    else {
	        if ( lonShapeTempNumber >= quarters[1] ) {
	            //if 2 or 4
	            if ( latShapeTempNumber <= 0.5 ) {shapeQuarterNum = 4;}
	            else{shapeQuarterNum = 2;}}
	        else {
	            //may be any other
	            if ( lonShapeTempNumber <= 0.5 )
	            {
	                //1,3,5
	                if ( latShapeTempNumber <= quarters[0] ){shapeQuarterNum = 3;}
	                else{
	                    if ( latShapeTempNumber >= quarters[1] ){shapeQuarterNum = 1;}
	                    else{shapeQuarterNum = 5;}}
	            }
	            else{
	               //2,4,5
	               if ( latShapeTempNumber <= quarters[0] ){shapeQuarterNum = 4;}
	                else{
	                   if ( latShapeTempNumber >= quarters[1] ){shapeQuarterNum = 2;}
	                   else{shapeQuarterNum = 5;}}
	            }
	        }
	    }

	    //calculate what lonShapeNum will need to return, when nearest returns
	    var shapesToReturnLon = [];
	    switch( shapeQuarterNum )
	        {
	            case 1:
	            case 3:
	                //-1 or the same
	                shapesToReturnLon = [(ceilLonShapeNum-1),ceilLonShapeNum];
	                break;
	            case 5: //same
	                shapesToReturnLon = [ceilLonShapeNum];
	                break;
	            default: //if 2 or 4, then +1 or the same
	                shapesToReturnLon = [ceilLonShapeNum, (ceilLonShapeNum+1)];
	        }


	    //calculate what lonShapeNum will need to return, when nearest returns
	    var shapesToReturnLat = [];
	    switch( shapeQuarterNum )
	        {
	            case 1:
	            case 2:
	                //+1 or the same
	                shapesToReturnLat = [ceilLatShapeNum+1,ceilLatShapeNum];
	                break;
	            case 5: //same
	                shapesToReturnLat = [ceilLatShapeNum];
	                break;
	            default: //if 3 or 4, then -1 or the same
	                shapesToReturnLat = [ceilLatShapeNum, (ceilLatShapeNum-1)];
	        }


	    var nearestNumShapes = [];
	    for( var indLon = 0; indLon < shapesToReturnLon.length; indLon++ )
	    {
	        for( var indLat = 0; indLat < shapesToReturnLat.length; indLat++ )
	        {
	            //min max check
	            if ( shapesToReturnLon[indLon] > 100188 ) { shapesToReturnLon[indLon] = 100188; }
	            if ( shapesToReturnLat[indLat] > 50094 ) { shapesToReturnLat[indLat] = 50094; }
	            if ( shapesToReturnLon[indLon] < 1 ) { shapesToReturnLon[indLon] = 1; }
	            if ( shapesToReturnLat[indLat] < 1 ) { shapesToReturnLat[indLat] = 1; }
	            var shapeNum = hashOfTheSquare(shapesToReturnLon[indLon], shapesToReturnLat[indLat]);
	            nearestNumShapes[nearestNumShapes.length] = shapeNum;
	        }
	    }
		return [lonShapeNum, latShapeNum, hashOfShape, shapeQuarterNum, nearestNumShapes];
    }
	
    return [lonShapeNum, latShapeNum, hashOfShape];
}

function checkLonSquareNum(numSquareLon) {
			if ( numSquareLon > 0 ) {
				if (numSquareLon > 100188) {
	                numSquareLon = 100188;
				} else if (numSquareLon < 1) {
	                numSquareLon = 1;
				}
			} else {
				if (numSquareLon < -100188) {
	                numSquareLon = -100188;
				} else if (numSquareLon > -1) {
	                numSquareLon = -1;
				}	
			}
			return numSquareLon;
				
}
function checkLatSquareNum(numSquareLat) {
			if ( numSquareLat > 0 ) {
				if (numSquareLat > 50094) {
	                numSquareLat = 50094;
				} else if (numSquareLat < 1) {
	                numSquareLat = 1;
				}
			} else {
				if (numSquareLat < -50094) {
	                numSquareLat = -50094;
				} else if (numSquareLat > -1) {
	                numSquareLat = -1;
				}	
			}
			return numSquareLat;
}


//get lonSquareNum, latSquareNum, shapeQuarterNum by the longitude and latitude
//SquareQuarter calculated same for positive and negative numbers
//return { lonSquareNum, latSquareNum, squareQuarterNum } or, if getSquareQuarter = null, then { lonSquareNum, latSquareNum, false }
function getSquaresNumbers( longitude, latitude ) {
    var quarters = [0.15, 0.95],
		lonSquare  = longitude / 556.6,
		latSquare  = latitude  / 556.6,
	 	latSquareTempNumber = latSquare < 0 ? ( Math.ceil(latSquare) - latSquare ) : ( latSquare - Math.floor(latSquare) ),
	    lonSquareTempNumber = lonSquare < 0 ? ( Math.ceil(lonSquare) - lonSquare ) : ( lonSquare - Math.floor(lonSquare) );
			
        var squareQuarterNum;
        if (lonSquareTempNumber <= quarters[0]) {
            //if 1 or 3
            if (latSquareTempNumber <= 0.5) {
                squareQuarterNum = 3;
            }
            else {
                squareQuarterNum = 1;
            }
        } else {
            if (lonSquareTempNumber >= quarters[1]) {
                //if 2 or 4
                if (latSquareTempNumber <= 0.5) {
                    squareQuarterNum = 4;
                }
                else {
                    squareQuarterNum = 2;
                }
            }
            else {
                //may be any other
                if (lonSquareTempNumber <= 0.5) {
                    //1,3,5
                    if (latSquareTempNumber <= quarters[0]) {
                        squareQuarterNum = 3;
                    }
                    else {
                        if (latSquareTempNumber >= quarters[1]) {
                            squareQuarterNum = 1;
                        }
                        else {
                            squareQuarterNum = 5;
                        }
                    }
                }
                else {
                    //2,4,5
                    if (latSquareTempNumber <= quarters[0]) {
                        squareQuarterNum = 4;
                    }
                    else {
                        if (latSquareTempNumber >= quarters[1]) {
                            squareQuarterNum = 2;
                        }
                        else {
                            squareQuarterNum = 5;
                        }
                    }
                }
            }
        }
		return {
	        lonSquareNum: checkLonSquareNum(Math.ceil(lonSquare)),
	        latSquareNum: checkLatSquareNum(Math.ceil(latSquare)),
	        squareQuarterNum:  squareQuarterNum
	    };
}

//return an array, that contains hashes of a nearest locations to the user location
//the same to the user location will be excluded from the result if expectSameSquare = true
//if shapeQuarterNum = false, that it will not be counted in calculations
function calculateNearestLocationsBySquaresNumbers(lonSquareNum, latSquareNum, squareQuarterNum, expectSameSquare) {
    //calculate what lonShapeNum will need to return, when the nearest return
    var squaresToReturnLon = [],
        squaresToReturnLat = [];
	if (squareQuarterNum) {  //if need to use a quarters of a squares
        switch (squareQuarterNum) {
            case 1:
            case 3:
                //-1 or the same
                squaresToReturnLon = [(lonSquareNum - 1), lonSquareNum];
                break;
            case 5://same
                squaresToReturnLon = [lonSquareNum];
                break;
            default://if 2 or 4, then +1 or the same
                squaresToReturnLon = [lonSquareNum, (lonSquareNum + 1)];
        }


        //calculate what lonShapeNum will need to return, when nearest returns
        switch (squareQuarterNum) {
            case 1:
            case 2:
                //+1 or the same
                squaresToReturnLat = [latSquareNum + 1, latSquareNum];
                break;
            case 5://same
                squaresToReturnLat = [latSquareNum];
                break;
            default://if 3 or 4, then -1 or the same
                squaresToReturnLat = [latSquareNum, (latSquareNum - 1)];
        }
    } else {
        squaresToReturnLon = [(lonSquareNum - 1), (lonSquareNum + 1), lonSquareNum];
        squaresToReturnLat = [(latSquareNum - 1), (latSquareNum + 1), latSquareNum];
    }

    var nearestSquaresHashes = [];
    for (var indLon = 0; indLon < squaresToReturnLon.length; indLon++) {
        for (var indLat = 0; indLat < squaresToReturnLat.length; indLat++) {
            //min max check
            var numSquareLat = squaresToReturnLat[indLat];
            var numSquareLon = squaresToReturnLon[indLon];
			
				
            if ( expectSameSquare  //excepting the same square
                 && numSquareLon == lonSquareNum
                 && numSquareLat == latSquareNum ) {
                 	continue;
            }
            var shapeHash = hashOfTheSquare(numSquareLon, numSquareLat);
            nearestSquaresHashes.push(shapeHash);
        }
    }

    return nearestSquaresHashes;
}

//calculate hashes of a nearest locations to the location, represented by the longitude and latitude
//return an array: [nearestLocationHash]
function calculateNearestLocations(longitude, latitude) {
    var squaresNumbers = getSquaresNumbers(longitude, latitude); //calculate numbers for the squares, that are the representation of the current location
    //return array of a locations hashes, that are the nearest locations for the current location
    return calculateNearestLocationsBySquaresNumbers(squaresNumbers.lonSquareNum, squaresNumbers.latSquareNum, null, true);
}

function calculateNearestLocationsByLocationHash(locationHash) {
    var squaresNumbers = locationHashToSquaresNumbers(locationHash); //calculate numbers for the squares, that are the representation of the current location
    //return array of a locations hashes, that are the nearest locations for the current location
    return calculateNearestLocationsBySquaresNumbers(squaresNumbers[0], squaresNumbers[1], null, true);
}

//users quarter number based on longitude and latitude sqauares
function calculateQuarter(lonSquareNum, latSquareNum) {
    var quarters = [0.15, 0.95], shapeQuarterNum = 5;
    
    if (lonSquareNum <= quarters[0]) {
        //if 1 or 3
        if (latSquareNum <= 0.5) { shapeQuarterNum = 3; }
        else { shapeQuarterNum = 1; }
    }
    else {
        if (lonSquareNum >= quarters[1]) {
            //if 2 or 4
            if (latSquareNum <= 0.5) { shapeQuarterNum = 4; }
            else { shapeQuarterNum = 2; }
        }
        else {
            //may be any other
            if (lonSquareNum <= 0.5) {
                //1,3,5
                if (latSquareNum <= quarters[0]) { shapeQuarterNum = 3; }
                else {
                    if (latSquareNum >= quarters[1]) { shapeQuarterNum = 1; }
                    else { shapeQuarterNum = 5; }
                }
            }
            else {
                //2,4,5
                if (latSquareNum <= quarters[0]) { shapeQuarterNum = 4; }
                else {
                    if (latSquareNum >= quarters[1]) { shapeQuarterNum = 2; }
                    else { shapeQuarterNum = 5; }
                }
            }
        }
    }
    return shapeQuarterNum; 
}

//return shape hash depending on longitude and latitude
function locationHash( longitude, latitude )
{
    var absLong  = Math.abs( longitude );
    var absLat   = Math.abs( latitude  );
    var latShape = absLat / 556.6;  //90 ) * 50094;
    var lonShape = absLong / 556.6; // 180 ) * 100188;

    if ( lonShape > 100188 ) { lonShape = 100188; }
    if ( latShape > 50094 )  { latShape = 50094;  }
    if ( lonShape < 1 ) { lonShape = 1; }
    if ( latShape < 1 ) { latShape = 1; }

    return hashOfTheSquare(Math.ceil(lonShape), Math.ceil(latShape));
}

/*
    return [
        0:lonSquareNum,
        1:latSquareNum,
        2:squareQuarterNum
    ]
*/
function locationHashToSquaresNumbers(locationHash) {
    locationHash = _toStr(locationHash);
    var prefix = locationHash.substr(0, 1),
        octothorpeLon = "",
        octothorpeLat = "",
        lonSquareNumWithPrefixNulls = locationHash.substr(1, 6),
        latSquareNumWithPrefixNulls = locationHash.substr(7, 5);

    if (prefix == "2") {
        octothorpeLon = "W";
        octothorpeLat = "S";
    } else if (prefix == "3") {
        octothorpeLon = "W";
        octothorpeLat = "";
    } else if (prefix == "4") {
        octothorpeLon = "";
        octothorpeLat = "S";
    }

    var lonSquareNum = octothorpeLon + (lonSquareNumWithPrefixNulls.replace(/^[0]+/, ""));
    var latSquareNum = octothorpeLat + (latSquareNumWithPrefixNulls.replace(/^[0]+/, ""));
    return [
        lonSquareNum,
        latSquareNum,
        false
    ];
}

/*return hash representation of the longitude and latitude:
   prefix + longitude + latitude
   prefix - depends on octothorpes of the longitude and latitude. Prefix is a one symbol
   longitude - amplified to 6 symbols length longitudeShapeNum
   latitude - amplified to 5 symbols length latitudeShapeNum
 */
function hashOfTheSquare(_longitudeShapeNum, _latitudeShapeNum)
{
    var prefix = "1", ind;
    var octothorpeLon = _longitudeShapeNum < 0;
    var octothorpeLat = _latitudeShapeNum < 0;
    if ( octothorpeLon === true && octothorpeLat === true ) {
        prefix = "2";
		_longitudeShapeNum = - _longitudeShapeNum;
		_latitudeShapeNum  = - _latitudeShapeNum;
    } else if ( octothorpeLon === true && octothorpeLat === false ) {
		_longitudeShapeNum = - _longitudeShapeNum;
		prefix = "3";
    } else if ( octothorpeLon === false && octothorpeLat === true ) {
        prefix = "4";
		_latitudeShapeNum = - _latitudeShapeNum;
    }
	return _toInt(prefix + getFStr(longitudeShapeNum,6) + getFStr(latitudeShapeNum,5));
}

function quarterNumbers( longitude, latitude )
{
    var lonShapeNum = Math.ceil(( latitude / 180 ) * 100188);
    var latShapeNum = Math.ceil(( longitude / 90 ) * 50094);
    return [lonShapeNum, latShapeNum];
}

//check is it location hash
function isLocationHash(locationHash){
    var lh = _toStr(locationHash);
    return patternLocationHash.test(lh);
}

module.exports = exports = {
    checkCoordinatesFormat : checkCoordinatesFormat,
    shapesSerialNumber : squaresSerialNumber,
    locationHash : locationHash,
    calculateNearestLocationsBySquaresNumbers : calculateNearestLocationsBySquaresNumbers,
    calculateQuarter : calculateQuarter,
    patternLongitude : patternLongitude,
    patternLatitude  : patternLatitude,
    patternLocationHash : patternLocationHash,
    getSquaresNumbers : getSquaresNumbers,
    calculateNearestLocations : calculateNearestLocations,
    calculateNearestLocationsByLocationHash : calculateNearestLocationsByLocationHash,
    locationHashToSquaresNumbers : locationHashToSquaresNumbers,
    isLocationHash : isLocationHash
};