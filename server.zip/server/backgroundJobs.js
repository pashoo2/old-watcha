"use strict";

var path = require("path"),
    dbMesaging = require("./dbMessaging.js"),
    messageHandlers = require("./messagesHandlers.js"),
    dbGeo = require("./dbGeo.js"),
    Promise = require("bluebird"),
    getTimestamp = require("./getTimestamp.js"),
    hashes = require("./hashes.js"),
    common = require("./common.js");

var log = require("./logger.js").loggerDb(__filename);

var moduleSettings = require("./settings/settings.js").backgroundJobs;

//global variables
var schemaMessage_LSStopLocationHandling = messageHandlers.schemasResponses.schemaMessage_LSStopLocationHandling; //schema for message to stop a location handling
var messageLSStopLocationHandling = messageHandlers.messagesMakers.messageLSStopLocationHandling; //create a message for a local server to stop location handling by it


/////////////////////////////////////////////////////

//after get all local servers and locations maintained by them, from which we are waiting for pong responces
disconnectExpiredPongs.afterGetWhaitingPongResponces = function afterGetNextWhaitingPongResponces (lssLocations) { //lssLocations = { lsID : [locationHash1,..., locationHashN ] } 
    if ( lssLocations != null ) {
        //try to send ping once again to the next waiting pong responces
        var _keys = Object.keys(lssLocations);
        for( var i = 0, len = _keys.length; i < len; i++ ) { //form the result message for the local server
            var localServerID = _keys[i];
            var locationsHashes = lssLocations[localServerID];
            var resultMessage = {};
            for( var ii = 0, _len = locationsHashes.length; ii < _len; ii++ ) {
                var locationHash = locationsHashes[ii];
                resultMessage = messageHandlers.addResponceToRequestDesc(resultMessage, schemaMessage_LSStopLocationHandling, messageLSStopLocationHandling(locationHash)); //add message to the list of the messages for the local server
                //unset the local server as the handler of the location
                dbGeo.delLocalServerID(locationHash, localServerID);
            }
            //send the result message to the local server
            messageHandlers.sendMessageToClient(localServerID, null, resultMessage);
        }
    }
};

disconnectExpiredPongs.ifError = function(e){
    log(e);
};

//disconnect out of the local server, that are expired their pong responses
function disconnectExpiredPongs() {
    
    if ( common.isEmptyObject(messageHandlers)
        || common.isEmptyObject(dbGeo) ) {
           //the module is still not loaded
           return;
    }
    
    return 
        dbMesaging.getAllWhaitingPongResponses() //get users with expired pongs
        .then(disconnectExpiredPongs.afterGetWhaitingPongResponces)
        .catch(disconnectExpiredPongs.ifError);
        
}


/////////////////////////////////////////////////////


module.exports = {
    moduleSettings : moduleSettings,
    disconnectExpiredPongs : disconnectExpiredPongs
};