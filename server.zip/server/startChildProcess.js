var childProcess = require("child_process"),
    EventEmitter = require("events").EventEmitter,
    eventEmitter = new EventEmitter(),
    path = require("path"),
    Promise = require("bluebird");
    
var log = require("./logger.js").loggerDb(__filename);

//to acess to the forked process need to read this._process property. The type of this property is Promise
function startProcess(modulePath) {
    if ( modulePath ) {
      this.modulePath = path.resolve(__dirname, modulePath);  
    } else if ( this.modulePath ) {
      modulePath = this.modulePath; 
    } else {
        log("The module name is empty");
        return;
    }
    var _process = childProcess.fork(this.modulePath, [], {silent:true});
    if ( !(this._process instanceof Promise) ) {
        this._process = new Promise.resolve(_process);
    }
    this._processInstance = _process;
    this.addEventListeners();
    this.emit("connected", _process);
}
startProcess.prototype = eventEmitter;
startProcess.prototype.addEventListeners = addEventListeners;
startProcess.prototype.startProcess = startProcess;

function addEventListeners(){
    var self = this;
    function onError(err) {
        log(err); 
        var _process = this;
        if ( !_process.pid || !_process.connected ) { //if there is no process id or can't sending a messages for the child process
            onExit();
        }
    }
    function onExit(code, signal){
        if ( !signal ) {
            var _process = this;
            _process.kill("SIGKILL");
            self._process = new Promise(function(resolve, reject){
              self.on("connected", function(_process) { //whait until the process will be started
                  resolve(_process);
                  self.emit("restart", _process); //emit an event with the new process instance
              });
            });
            self._processInstance = null;
            self.startProcess(); //restart if the process closed not specially by the parent
        } else {
            self.emit("closed"); //if the process is closed purposely
        }
    }
    function onMessage(msg){
        if ( msg instanceof Error ) { //if exceprion in the child process
            console.log("child process has reached uncaughtException");
            onExit(); //restart the process
        }   
    }
    this._processInstance.on("error"        , onError);
    this._processInstance.on("exit"         , onExit);
    this._processInstance.on("close"        , onExit);
    this._processInstance.on("disconnect"   , onExit);
    this._processInstance.on("message   "   , onMessage);

}

module.exports = startProcess;

// example:
// var ChildProcess = require("./startChildProcess.js"),
//     childProcess = new ChildProcess("handleMassageFromAClient.js");
// var handlerMsg;
// childProcess._process.then(function(_handler){ //on the process has started
//     handlerMsg = _handler;
//     _handler.on("message", function(msg){
//          console.log("ms");
//          console.log(msg);
//     });
//     _handler.send("0");
// });
// childProcess.on("restart", function(_handler) { //on restarting the process
//     handlerMsg = _handler;
// });
