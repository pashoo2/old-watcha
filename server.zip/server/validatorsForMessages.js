/*jshint curly:true, debug:true */
//MESSAGES SCHEMAS

var patterns = require("./patterns.js");
var resolvePathMy = require("resolvePathMy");
var settings = require(resolvePathMy(__dirname, "settings/settings.js"));
var AJV = require("ajv");

var moduleSettings = settings.messagesValidatorsSettings;
var ajv = AJV(moduleSettings.AJVSettings);
var validator = ajv.compile;

var schemasForMessages = {
    vSchemaIncomingMessage_mainSchema : {
        type: "object",
        additionalProperties : false,
        required : ["type","body","timestamp"],
        properties: {
            type: {eq: "_gServer"},
            body: {
                type: "object",
                additionalProperties : {
                    uniqueID : {type:"number", minimum : 1, maximum : 1000000} //id of the incoming message
                },
                required : ["type", "kind", "body"],
                maxProperties : 5,
                properties : {
                    type : {type:"string", maxLength : 30},
                    kind : {type:"string", maxLength : 30},
                    body : {
                      oneOf : [
                            {type:"number"},
                            {type:"object", maxProperties : 10},
                            {type:"array", maxItems : 1000},
                            {type:"string"}
                        ]  
                    }
                }
            },
            timestamp: patterns.timestamp
        }
    },
    //request to chose another local server for the location
    //schema for ELS
    vSchemaIncomingMessage_clientChooseAnotherLS_fromELS : patterns.opVS_fromELS_userLocation, //calcLocationHash = the current location hash for an els instance or an ils instance
    //schema for ILS
    vSchemaIncomingMessage_clientChooseAnotherLS_fromILS : patterns.opVS_fromILS_ilsNearestLocationsWithLSID,
    //incoming pong
    vSchemaIncomingMessage_LSPongResponse : {
        anyOf : [
            patterns.locationHash, //the location must handled by the ils
            patterns.arrayOfLocations //list with the locations, that are handled by the ils
        ]
    }, 
    //get a time offset beetween the server and the client in milliseconds
    vSchemaIncomingMessage_clientGetTimeUTCDifference : {
        type : "object",
        additionalProperties : false,
        required : ["cDate","cMilliseconds"],
        properties : {
            cDate         : {type : "string", format : "date-time"},
            cMilliseconds : patterns.milliseconds
        }
    },
    //get the local server id for the location from ils
    vSchemaIncomingMessage_lsGetLocalServerID_fromILS : patterns.opVS_fromILS_ilsLocationWithNotRequiredLSID, //id of the current ls is not required
    //get the local server id for the location from els
    vSchemaIncomingMessage_lsGetLocalServerID_fromELS : patterns.opVS_fromELS_userLocation, //all an incoming descriptions of the user location comming with the id of the local server, to which an els is connected,
    //request calculated hashes by the users lattitude and longitude
    vSchemaIncomingMessage_lsCalculateHashesUsersLocations_fromILS : {
        type: "array",
        minItems : 1,
        maxItems : 1000,
        additionalItems : false,
        items : {
            type : "object",
            additionalProperties : false,
            required : ["lat","lng","userID"],
            properties : {
                userID  : patterns.userID,
                lat     : patterns.latitude,
                lng     : patterns.longitude    
            }
        }    
    },
    //message from the central server, to stop handling of the locations
    vSchemaIncomingMessage_lsStopLocationHandling_fromILS : {
        type : "object",
        required : ["listLocations","listNewLSs"],
        additionalProperties : false,
        properties : {
            listLocations : { //list of a locations, maintaince of which a ls want to stop
                type: "array",
                additionalItems : false,
                items : patterns.locationHash,
                minItems : 1,
                maxItems : 10,
                uniqueItems : true
            },
            listNewLSs : { //list of the users, which are the best choices as a new LSs for the locations, that will be stopped. locationHash = listLocations[i], new ls for this location = listNewLSs[i]
                type: "array",
                additionalItems : false,
                items : patterns.optVS_userID_orEmpty, //user id or empty user id
                minItems : 0,
                maxItems : 10
            },
            flForce : {
                type : "boolean"    
            }
        }
    },
    vSchemaIncomingMessage_lsIsLocationMaintained_fromILS : {
       type : "array",
       additionalItems : false,
       items : patterns.optVS_locationHash
    },
    vSchemaIncomingMessage_newLocalServers_fromILS : {
        type : "object",
        required : ["listLocations","listNewLSs"],
        additionalProperties : false,
        properties : {
            listLocations : { //list of a locations, maintaince of which a ls want to stop
                type: "array",
                additionalItems : false,
                items : patterns.locationHash,
                minItems : 1,
                maxItems : 10,
                uniqueItems : true
            },
            listNewLSs : { //list of the users, which are the best choices as a new LSs for the locations, that will be stopped. locationHash = listLocations[i], new ls for this location = listNewLSs[i]
                type: "array",
                additionalItems : false,
                items : patterns.optVS_userID_orEmpty, //user id or empty user id
                minItems : 0,
                maxItems : 10
            }
        }    
    },
    vSchemaIncomingMessage_onOut_main : {
        type : "object",
        maxProperties : 0
    }
};

var validatorsForMessages = {};
validatorsForMessages.validationIncomingMessage_mainMessageStructure            = validator(schemasForMessages.vSchemaIncomingMessage_mainSchema);
validatorsForMessages.validationIncomingMessage_clientChooseAnotherLS_fromELS   = validator(schemasForMessages.vSchemaIncomingMessage_clientChooseAnotherLS_fromELS);
validatorsForMessages.validationIncomingMessage_clientChooseAnotherLS_fromILS   = validator(schemasForMessages.vSchemaIncomingMessage_clientChooseAnotherLS_fromILS);
validatorsForMessages.validationIncomingMessage_LSPongResponse                  = validator(schemasForMessages.vSchemaIncomingMessage_LSPongResponse);
validatorsForMessages.validationIncomingMessage_clientGetTimeUTCDifference      = validator(schemasForMessages.vSchemaIncomingMessage_clientGetTimeUTCDifference);
validatorsForMessages.validationIncomingMessage_lsGetLocalServerID_fromILS      = validator(schemasForMessages.vSchemaIncomingMessage_lsGetLocalServerID_fromILS);
validatorsForMessages.validationIncomingMessage_lsGetLocalServerID_fromELS      = validator(schemasForMessages.vSchemaIncomingMessage_lsGetLocalServerID_fromELS);
validatorsForMessages.validationIncomingMessage_lsCalculateHashesUsersLocations = validator(schemasForMessages.vSchemaIncomingMessage_lsCalculateHashesUsersLocations_fromILS);
validatorsForMessages.validationIncomingMessage_lsStopLocationHandling_fromILS  = validator(schemasForMessages.vSchemaIncomingMessage_lsStopLocationHandling_fromILS);
validatorsForMessages.validationIncomingMessage_lsIsLocationMaintained_fromILS  = validator(schemasForMessages.vSchemaIncomingMessage_lsIsLocationMaintained_fromILS);
validatorsForMessages.validationIncomingMessage_onOut_main                      = validator(schemasForMessages.vSchemaIncomingMessage_onOut_main);

module.exports = validatorsForMessages;