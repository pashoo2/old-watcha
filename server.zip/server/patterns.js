//patterns.js
"use strict";

var common = require("./common.js");
var hashes = require("./hashes.js");
var resolvePathMy = require("resolvePathMy");
var settings = require(resolvePathMy(__dirname, "settings/settings.js"));  
    
var empty_user_id = settings.messagesSettings.empty_user_id; //the value, that is representation of an empty id of the user    
    
//functions from common.js
var _extend = common.extend;
    
//functions from hashes.js
var moduleSettingsHashes = hashes.moduleSettings,
    minLH = moduleSettingsHashes.minLHF,
    maxLH = moduleSettingsHashes.maxLHF;
        
////////////////////////////////////////

//the basic JSON SCHEMA formats
var basicFormats = {
    userID : {
        type    : "integer",
        minimum : 1,
        maximum : 9999999
    },
    locationHash : {
        type: "integer",
        minimum : minLH,
        maximum : maxLH  
    },
    timestamp : { //for timesamp fields
        type: "integer",
        minimum : 1432930986, //29.05.2015
        maximum : 1580515200  //01.12.2025
    },
    milliseconds : { //for field with full milliseconds values
        type: "integer",
        minimum : 1432930986000, //29.05.2015
        maximum : 1580515200000  //01.12.2025
    },
    latitude : {
        type: "number",
        minimum : -90,
        maximum : 90
        //multipleOf : 0.000001 //the precision is a 6 digitts after a comma
    },
    longitude : {
        type: "number",
        minimum : -180,
        maximum : 180
        //multipleOf : 0.0000001 //the precision is a 6 digitts after a comma
    }
};

////////////////////////////////////////

var basicPatterns = {};
basicPatterns.arrayOfLocations = { //array, contains only a locations hashes
    type    : "array",
    items   : basicFormats.locationHash, //locations hashes
    additionalItems : false        
};
basicPatterns.ilsLocations = { //contains the maintained locations and a locations, that are the nearest to the maintained
    maintainedLocations : basicPatterns.arrayOfLocations, //locations maintained by an ils
    nearestlocations    : basicPatterns.arrayOfLocations //locations, for that the list of the local servers id was requested
};

////////////////////////////////////////

var globalPatterns = {
    optVS_userID_orEmpty : {
        anyOf: [
            basicFormats.userID,
            { "enum" : [empty_user_id] } //an empty id of the user
       ]
    },
    opVS_fromELS_userLocation: {
        type: "object",
        additionalProperties : false,
        required : ["locationHash", "lat", "lng", "coordsTimestamp"],
        properties: {
            lat: basicFormats.latitude, //first it is necessary to check if lat and lng is exists
            lng: basicFormats.longitude,
            locationHash: {
                anyOf : [
                    {"enum":[0]}, //if it is unknown
                    basicFormats.locationHash //check this location hash as the previous location of the user and calculate a valid location hash for the user by his coords
                ],
            },
            localServerID: basicFormats.userID,
            timestamp : basicFormats.timestamp, //the last calculation of the location hash
            coordsTimestamp : basicFormats.timestamp //when the user has got coordinates from the navigator object (in browser)
        }
    },
    opVS_fromILS_ilsLocation: {
        type    : "object",
        required : ["maintainedLocations", "locations"], //maintainedLocations - loations, that are maintained by the ils, and locations - list of the locations, that are nearest to the maintained locations, and for this location local server was requested
        additionalProperties : false,
        properties : basicPatterns.ilsLocations
    },
    opVS_fromILS_ilsNearestLocationsWithLSID : {
        type : "object",
        required : ["locations", "lsID"],
        additionalProperties : false,
        properties : {
            locations : basicPatterns.ilsLocations,
            lsID      : basicFormats.userID  //id of a local server, to which the els(ils) is connected
        }    
    },
    opVS_fromILS_ilsLocationWithNotRequiredLSID : {
        type : "object",
        required : ["locations"], //id of the current ls is not required
        additionalProperties : false,
        properties : {
            locations : basicPatterns.ilsLocations, //els locations
            lsID      : basicFormats.userID              //id of a local server, to which the els is connected
        }    
    }
};

////////////////////////////////////////

module.exports = _extend(basicFormats, basicPatterns, globalPatterns);