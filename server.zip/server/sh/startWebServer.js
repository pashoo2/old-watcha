/**
 * Created by paul on 29.11.15.
 */
 
//////////////////////////////////modules
const resolvePathMy = require("resolvePathMy");
const appSettings = require(resolvePathMy(__dirname, "settings/settings.js"));
const fs = require("fs");
const path = require("path");
const server=require("node-http-server");

//////////////////////////////////variables

const capath   = path.resolve(__dirname, "..", "settings", 'certs', 'chain.pem');
const keypath  = path.resolve(__dirname, "..", "settings", 'certs', 'privkey.pem');
const certpath = path.resolve(__dirname, "..", "settings", 'certs', 'cert.pem');

require('ssl-root-cas').inject().addFile(capath);

/*
  key file  will be privkey.pem
  cert file will be cert.pem
  ca file ( AlphaSSL.crt in your example) will be chain.pem or fullchain.pem
*/

const webServerSettings = appSettings.webServer;
const optionsSSL = {
  port : webServerSettings.httpsPort,
  privateKey: keypath,
  // You don't need to specify `ca`, it's done by `ssl-root-cas`
  //, ca: [ fs.readFileSync(path.join(__dirname, 'certs', 'my-root-ca.crt.pem'))]
  certificate: certpath
}; 


//////////////////////////////////start web server
const flDebugMode = appSettings.debugmode;
const optionsWebServer = webServerSettings; //host and port and root path
const rootPath = optionsWebServer.root = resolvePathMy(__dirname, optionsWebServer.root); //the root path for web server

optionsWebServer.https = optionsSSL; 

if (flDebugMode === true) { //if debug mode then turn logging on
  optionsWebServer.log = resolvePathMy(rootPath, "logs/http_server.log");
  //optionsWebServer.verbose = true;
}

server.deploy(optionsWebServer);