( [ -d ./browserified ] || mkdir ./browserified ) &&
( (echo "start") && ( browserify -r jsenMy:jsenMy -o ./browserified/jsenMy.js ) && (echo "done") )