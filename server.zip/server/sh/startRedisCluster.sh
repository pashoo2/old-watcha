#!/bin/bash
#( cd ../redis-cluster && sudo bash ./startRedisCluster.sh ) &
(
    redis-server --port 7000 &
    redis-server --port 7001 &
    redis-server --port 7002 &
    redis-server --port 7003 &
    redis-server --port 7004
)