#!/bin/bash

#start redis
echo "Starting the redis geo" &&
sudo redis-server ./conf/redis.geo.master.6370.conf &&
sudo redis-server ./conf/redis.geo.master.6371.conf &&
sudo redis-server ./conf/redis.geo.salve6370.6372.conf &&
sudo redis-server ./conf/redis.geo.salve6371.6373.conf &&
echo "Starting the redis auth" &&
sudo redis-server ./conf/redis.auth.master.6390.conf &&
sudo redis-server ./conf/redis.auth.salve6390.6391.conf &&
sudo redis-server ./conf/redis.auth.salve6390.6392.conf &&
echo "Starting the sentinel" &&
sudo redis-server ./conf/sentinel.26391.conf --sentinel &&
sudo redis-server ./conf/sentinel.26392.conf --sentinel &&
sudo redis-server ./conf/sentinel.26390.conf --sentinel

#start monit