sudo rm -rf /etc/redis* &&
sudo rm -rf /var/run/redis* &&
sudo rm -rf /var/lib/redis* &&
sudo rm -rf /var/log/redis* &&
sudo rm -rf /etc/init.d/redis* &&
sudo update-rc.d redis_6370 remove