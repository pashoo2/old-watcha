//////////////////////////////////modules
var httpProxy = require('http-proxy');
var https = require('https');
var resolvePathMy = require("resolvePathMy");
var appSettings = require(resolvePathMy(__dirname, "settings/settings.js"));
var PeerServer = require("peerMy").PeerServer;
var extend = require(resolvePathMy(__dirname,"common.js")).extend;
var fs = require("fs");
var path = require("path");

//////////////////////////////////variables

const capath   = path.resolve(__dirname, "..", "settings", 'certs', 'chain.pem');
const keypath  = path.resolve(__dirname, "..", "settings", 'certs', 'privkey.pem');
const certpath = path.resolve(__dirname, "..", "settings", 'certs', 'cert.pem');

require('ssl-root-cas').inject().addFile(capath);

/*
  key file  will be privkey.pem
  cert file will be cert.pem
  ca file ( AlphaSSL.crt in your example) will be chain.pem or fullchain.pem
*/

const optionsSSL = {
  key: fs.readFileSync(keypath),
  // You don't need to specify `ca`, it's done by `ssl-root-cas`
  //, ca: [ fs.readFileSync(path.join(__dirname, 'certs', 'my-root-ca.crt.pem'))]
  cert: fs.readFileSync(certpath)
};

var servers = appSettings.gServers; //list of a servers [{host,port}]
var settingsPeerJS = appSettings.PeerJSServer; //main settings for each PeerJS server
var numOfServers = servers.length;

//////////////////////////////////functions


if ( numOfServers === 1 ) { //if only the one server
  const defSettings = extend(
                        {
                          serverNumber : 0,
                          host : "0.0.0.0",  //it must listen the main host and port
                          port : 8321,
                          proxied : false,
                          secure : true,
                          ssl : optionsSSL
                        },
                        settingsPeerJS
                      );
  PeerServer(defSettings);
} else {

  //start each PeerJS server
  var PeerServers = []; //list with all started peer servers
  var wsProxyServers = []; //list of the proxy servers for PeerJS servers
  for( var i = 0; i < numOfServers; i++ ) { //servers[i] = port and host for connection to the PeerServer, settingsPeerJS = setting especialy for PeerJS
    PeerServers[i] = PeerServer(extend({serverNumber : i}, servers[i], settingsPeerJS)); //start the PeerJS server
    wsProxyServers[i]  = httpProxy.createProxyServer({
      target : {
        host : servers[i].host,
        port : servers[i].port
      },
      ssl : optionsSSL,
      ws: true,
      xfwd : false
    });
  }
  
  //return integer value by the user id string
  function getUserIDHash(string) {
    var i, hash = 0;
    for (i = 0; i < ( string.length > 10 ? 10 : string.length ); i++) {
    		hash += string.charCodeAt(i);
    }
    return hash;   
  }
  
  //return string user id from the guven url(must contain substring like id=integer)
  var regExUserID = new RegExp(appSettings.patternUserIDFromURL);
  function userIDFromURL(_url){
    if (typeof(_url) !== "string"
        || _url.length > 2000 //if too long url string
        || _url.length < 4 ) { //or too short
          return false;
    } else {
      var result = _url.match(regExUserID);
      if ( result === null
        || result.length === 0) {
          return false; //if not found
      } else {
        var userIDString = result[0].substr(3);
        if ( userIDString.length === 0  ) {
          return false;  
        } else {
          var strUserID = result[0].substr(3);
          var res = parseInt(strUserID, 10); //if found transform it to an integer value
          if ( isNaN(res) === true  ) { //if it is a string
            return getUserIDHash(strUserID); //convert it ot the integer value  
          } else { //if an integer
            return res; //if found transform it to an integer value
          }
        }
      }
    }
  }
  
  //use web socket proxy server that defined by a user id
  var wsProxyFunc = (function (req, socket, head) { //var query = url.parse(socket.upgradeReq.url, true).query;
      
      var ipaddr = "";
      const conn = req.connection;
      const _socket = req.socket;
      if ( conn != null
        && typeof(conn.remoteAddress) === "string"
        && conn.remoteAddress.length > 0 ) {
          ipaddr = conn.remoteAddress; 
      } else
        if ( _socket != null
          && typeof(_socket.remoteAddress) === "string"
          && _socket.remoteAddress.length > 0 ) {
            ipaddr = _socket.remoteAddress; 
        }
        
      if ( ipaddr === "" ) { //if can't define the ip of the client
        socket.destroy();
      } else {
        req.headers["g_client_ip"] = ipaddr;
      }
      
      var userID = this.userIDFromURL(req.url); //parse the url to give the user id
      if ( typeof(userID) === "number" ) { //if found user id into the url
          //userID % numOfServers = a number of the chosen server
          var serv = this.wsProxyServers[userID % this.this.numOfServers];
          if ( serv != null ) {
            serv.ws(req, socket, head);  //this.servers[serverNum] = host and port for connecting to the server
          }
      } else {
        socket.destroy(); //close the socket, because the user id is not valid
      }
  })
  .bind({
    servers : servers,
    userIDFromURL : userIDFromURL,
    wsProxyServers : wsProxyServers,
    numOfServers : numOfServers
  });
  
  const proxyWSS = https.createServer(optionsSSL).listen(8321, "0.0.0.0");
  //on web socket connection
  proxyWSS.on('upgrade', wsProxyFunc);
}