#!/bin/bash
(bash ./startRedis.sh ) &
(bash ./startHTTPAndProxy.sh)