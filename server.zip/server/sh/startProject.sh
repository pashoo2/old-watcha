#!/bin/bash
#export SERVER_PATH = "/home/usree/http/gServer";
#export CLIENT_PATH = "/home/usree/http/client";
export SERVER_PATH = "~/workspace/gServer";
export CLIENT_PATH = "~/workspace/client";
(chmod +x $PATH/redis/startRedis.sh && cd $PATH/redis && $PATH/startRedis.sh) &&
( ( node $PATH/startWebServer.js && echo "Web server was started" ) || (echo "The web server won't start") )
#( ( nodejs ./startProxy.js && echo "Proxy has started" ) || (echo "The proxy server won't start") ) &
#( http-server ../../client/ -a 127.0.0.1 -p 8083 -c-1 --cors || ( sudo npm i http-server -g && http-server ../../client/  -a 127.0.0.1 -c-1 -p 8083 --cors ) )
#( http-server ~/workspace/workspace/client/ -p 8083 -c-1 || ( sudo npm i http-server -g && http-server ~/workspace/workspace/client/ -p 8083 ) )