var path = require("path"),
    PeerServer = require("peerMy").PeerServer,
    appSettings = require("./settings/settings.js"),
    fs = require("fs");

var settings = {
    path    : '/',
    secure  : false,
    proxied : true
};

module.exports = function(settings) {
    PeerServer(settings);
}

// var WebSocketServer = require('ws').Server
//   , wss = new WebSocketServer({ host:"127.0.0.1", path: "/peerjs", port: 7010});

// wss.on('connection', function connection(ws) {
//     console.log('vv: %s');
//   ws.on('message', function incoming(message) {
//     console.log('received: %s', message);
//   });

//   ws.send('something');
// });