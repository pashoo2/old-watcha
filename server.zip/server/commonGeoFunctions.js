var resolvePath = require("resolvePathMy"), 
    appSettings = require(resolvePath(__dirname, "settings/settings.js")),
    commonF = require("./common.js"),
    _toInt  = commonF.strToInt,
    _toStr  = commonF.numToStr,
    getFStr = commonF.getFStr;

var settings = appSettings.commonGeoFunctionsModule;

var moduleSettings = {
    quadrantSquare : settings.quadrantSquare, //a square of a quadrant in meters for calculations of the location hashes
    numberQuadrantsPerDegree : 0, //number of the quadrants per degree of lat or lng
    maxNumberQuadrantLat : 0, //the maximum number of the quadrants on lat
    maxNumberQuadrantLng : 0 //the maximum number of the quadrants on lng
};

//do calculations
var lengthEquator = 40075696;  //length of the earth equator in meters
var numberOfQuadrantsOnEquator = lengthEquator / moduleSettings.quadrantSquare; //a number of a quadrants, that can fit on the equator
var numberQuadrantsPerDegree = Math.floor(numberOfQuadrantsOnEquator / 360); //number of the quadrants per degree
moduleSettings.numberQuadrantsPerDegree = numberQuadrantsPerDegree;

var maxNumberQuadrantLat = Math.ceil(numberQuadrantsPerDegree * 90); //the maximum value of the quadrant lat
moduleSettings.maxNumberQuadrantLat = maxNumberQuadrantLat;
var maxDigitsQuadrantLat = maxNumberQuadrantLat.toString(10).length;
moduleSettings.maxDigitsQuadrantLat = maxDigitsQuadrantLat; //maximum number of a digits of the lat quadrant
var maxDigitsQuadrantLatAsMultiplier = Math.pow(10, maxDigitsQuadrantLat); //10 in maxDigitsQuadrantLat exponent
moduleSettings.maxDigitsQuadrantLatAsMultiplier = maxDigitsQuadrantLatAsMultiplier;

var maxNumberQuadrantLng = Math.ceil(numberQuadrantsPerDegree * 180); //the maximum value of the quadrant lng
moduleSettings.maxNumberQuadrantLng = maxNumberQuadrantLng;
var maxDigitsQuadrantLng = maxNumberQuadrantLng.toString(10).length;
moduleSettings.maxDigitsQuadrantLng = maxDigitsQuadrantLng; //maximum number of a digits of the lng quadrant
var maxDigitsQuadrantLngAsMultiplier = Math.pow(10, maxDigitsQuadrantLng); //10 in maxDigitsQuadrantLng exponent
moduleSettings.maxDigitsQuadrantLngAsMultiplier = maxDigitsQuadrantLngAsMultiplier;

var maxDigits = maxDigitsQuadrantLat + maxDigitsQuadrantLng + 1; //the maximum digits in the location hash = lat length + lng length 9 1 symbol for the prefix
moduleSettings.maxDigits = maxDigits;
var prefixMultiplier = maxDigitsQuadrantLngAsMultiplier * maxDigitsQuadrantLatAsMultiplier; //miltiplier to set prefix on the right position
moduleSettings.prefixMultiplier = prefixMultiplier;

//return hash of a user square depending on longitude and latitude coordinates
function locationHash( longitude, latitude )
{
    var latLon = quadrantNumbers( longitude, latitude );
    return hashOfTheSquare(latLon[0], latLon[1]);
}

/*return a parts of a hash of a user square depending on longitude and latitude coordinates
 Array[prefix,longitudeSquareNum,latitudeSquareNum, locationHash], where all items are integers
 prefix - depends on octothorpes of the longitude and latitude. Prefix is a one symbol
 longitudeSquareNum - amplified to maxDigitsQuadrantLng symbols length longitudeSquareNum
 latitudeSquareNum - amplified to maxDigitsQuadrantLat symbols length latitudeSquareNum
 locationHash
 */
function locationHashParts( longitude, latitude ) {
    var latLon = quadrantNumbers( longitude, latitude );
    return hashOfTheSquareParts(latLon[0], latLon[1]);
}

function quadrantNumbers( longitude, latitude ) {
    return [
        longitude < 0 ? Math.floor( longitude * numberQuadrantsPerDegree ) //if negative, then round to the max value by module,
                      : Math.ceil(  longitude * numberQuadrantsPerDegree ),
        latitude  < 0 ? Math.floor( latitude * numberQuadrantsPerDegree ) //if negative, then round to the max value by module,
                      : Math.ceil(  latitude * numberQuadrantsPerDegree ),
    ];
}

//lng, lat - longitude or latitude or corresponding square numbers
function getPrefixByLngLat(lng, lat) {
    var octothorpeLon = lng < 0;
    var octothorpeLat = lat  < 0;
    if ( octothorpeLon === true && octothorpeLat === true ) { //get abs and prefix
        return 2;
    } else if ( octothorpeLon === true && octothorpeLat === false ) {
        return 3;
    } else if ( octothorpeLon === false && octothorpeLat === true ) {
        return 4;
    } else {
        return 1;
    }
}

/*return a parts of the location hash:
 Array[prefix,longitudeSquareNum,latitudeSquareNum, locationHash], where all items are integers
 prefix - depends on octothorpes of the longitude and latitude. Prefix is a one symbol
 longitudeSquareNum - amplified to maxDigitsQuadrantLng symbols length longitudeSquareNum
 latitudeSquareNum - amplified to maxDigitsQuadrantLat symbols length latitudeSquareNum
 locationHash - hash of the user location
 */
function hashOfTheSquareParts(_longitudeShapeNum, _latitudeShapeNum) {
    var octothorpeLon = _longitudeShapeNum < 0;
    var octothorpeLat = _latitudeShapeNum  < 0;
    if ( octothorpeLon === true && octothorpeLat === true ) { //get abs and prefix
        _longitudeShapeNum = - _longitudeShapeNum;
        _latitudeShapeNum  = - _latitudeShapeNum;
    } else if ( octothorpeLon === true && octothorpeLat === false ) {
        _longitudeShapeNum = - _longitudeShapeNum;
    } else if ( octothorpeLon === false && octothorpeLat === true ) {
        _latitudeShapeNum = - _latitudeShapeNum;
    }
    var prefix = getPrefixByLngLat(_longitudeShapeNum, _latitudeShapeNum);
    return [prefix, _longitudeShapeNum, _latitudeShapeNum, prefix * prefixMultiplier + _longitudeShapeNum * maxDigitsQuadrantLatAsMultiplier + _latitudeShapeNum]; 
}

/*return hash representation of the longitude and latitude:
 prefix + longitude + latitude
 prefix - depends on octothorpes of the longitude and latitude. Prefix is a one symbol
 longitude - amplified to maxDigitsQuadrantLng symbols length longitudeShapeNum
 latitude - amplified to maxDigitsQuadrantLat symbols length latitudeShapeNum
 */
function hashOfTheSquare(_longitudeShapeNum, _latitudeShapeNum) {
    return hashOfTheSquareParts(_longitudeShapeNum, _latitudeShapeNum)[3];
}

//return right numSquareLon if invalid, then return the nearest right value
function checkLonSquareNum(numSquareLon) {
    var maxNumberQuadrantLng = moduleSettings.maxNumberQuadrantLng;
    if ( numSquareLon > 0 ) {
        if (numSquareLon > maxNumberQuadrantLng) {
            numSquareLon = maxNumberQuadrantLng;
        } else if (numSquareLon < 1) {
            numSquareLon = 1;
        }
    } else {
        if (numSquareLon < -maxNumberQuadrantLng) {
            numSquareLon = -maxNumberQuadrantLng;
        } else if (numSquareLon > -1) {
            numSquareLon = -1;
        }
    }
    return numSquareLon;

}

//return flae is invalid or numSquareLon
function checkLonSquareNumOrFalse(numSquareLon) {
    var maxNumberQuadrantLng = moduleSettings.maxNumberQuadrantLng;
    if ( numSquareLon > 0 ) {
        if (numSquareLon > maxNumberQuadrantLng) {
            return false;
        } else if (numSquareLon < 1) {
            return false;
        }
    } else {
        if (numSquareLon < -maxNumberQuadrantLng) {
            return false;
        } else if (numSquareLon > -1) {
            return false;
        }
    }
    return numSquareLon;

}

//return right numSquareLat if invalid, then return the nearest right value 
function checkLatSquareNum(numSquareLat) {
    var maxNumberQuadrantLat = moduleSettings.maxNumberQuadrantLat;
    if ( numSquareLat > 0 ) {
        if (numSquareLat > maxNumberQuadrantLat) {
            numSquareLat = maxNumberQuadrantLat;
        } else if (numSquareLat < 1) {
            numSquareLat = 1;
        }
    } else {
        if (numSquareLat < -maxNumberQuadrantLat) {
            numSquareLat = -maxNumberQuadrantLat;
        } else if (numSquareLat > -1) {
            numSquareLat = -1;
        }
    }
    return numSquareLat;
}

//return flae is invalid or numSquareLat
function checkLatSquareNumOrFalse(numSquareLat) {
    var maxNumberQuadrantLat = moduleSettings.maxNumberQuadrantLat;
    if ( numSquareLat > 0 ) {
        if (numSquareLat > maxNumberQuadrantLat) {
            return false;
        } else if (numSquareLat < 1) {
            return false;
        }
    } else {
        if (numSquareLat < -maxNumberQuadrantLat) {
            return false;
        } else if (numSquareLat > -1) {
            return false;
        }
    }
    return numSquareLat;
}

//return an array, that contains hashes of a nearest locations to the user location
//the same to the user location will be excluded from the result if expectSameSquare = true
//if shapeQuarterNum = false, that it will not be counted in calculations
function calculateNearestLocationsBySquaresNumbers(mainLonSquareNum, mainLatSquareNumber, squareQuarterNum, expectSameSquare) {
    //calculate what lonShapeNum will need to return, when the nearest return
    var squaresToReturnLon = [],
        squaresToReturnLat = [];
    if (squareQuarterNum == null) {  //if need to use a quarters of a squares
        squaresToReturnLon = [(mainLonSquareNum - 1), (mainLonSquareNum + 1), mainLonSquareNum];
        squaresToReturnLat = [(mainLatSquareNumber - 1), (mainLatSquareNumber + 1), mainLatSquareNumber];
    } else {
        //calculate what lonSquareNum will need to return, when nearest returns
        switch (squareQuarterNum) {
            case 1:
            case 3:
                //-1 or the same
                squaresToReturnLon = [(mainLonSquareNum - 1), mainLonSquareNum];
                break;
            case 5://same
                squaresToReturnLon = [mainLonSquareNum];
                break;
            default://if 2 or 4, then +1 or the same
                squaresToReturnLon = [mainLonSquareNum, (mainLonSquareNum + 1)];
        }


        //calculate what latSquareNum will need to return, when nearest returns
        switch (squareQuarterNum) {
            case 1:
            case 2:
                //+1 or the same
                squaresToReturnLat = [mainLatSquareNumber + 1, mainLatSquareNumber];
                break;
            case 5://same
                squaresToReturnLat = [mainLatSquareNumber];
                break;
            default://if 3 or 4, then -1 or the same
                squaresToReturnLat = [mainLatSquareNumber, (mainLatSquareNumber - 1)];
        }
    }

    var nearestSquaresHashes = [];
    for (var indLon = 0; indLon < squaresToReturnLon.length; indLon++) {
        for (var indLat = 0; indLat < squaresToReturnLat.length; indLat++) {
            //return all the variants of a combinations of a longitude and a lattitude squares
            var latSquareNum = checkLatSquareNumOrFalse(squaresToReturnLat[indLat]);
            if ( latSquareNum === false ) { //if invalid latSquareNum
                continue;    
            }
            var lonSquareNum = checkLonSquareNumOrFalse(squaresToReturnLon[indLon]);
            if ( lonSquareNum === false ) { //if invalid lonSquareNum
                continue;    
            }
            if ( expectSameSquare === false //necessary excepting the same square
                || lonSquareNum !== mainLonSquareNum
                || latSquareNum !== mainLatSquareNumber ) { //the current lon or lat square number is differ from one or all of the main square numbers
                    var shapeHash = hashOfTheSquare(lonSquareNum, latSquareNum);
                    if ( nearestSquaresHashes.indexOf(shapeHash) === -1 ) {
                        nearestSquaresHashes.push(shapeHash);
                    }
            }
        }
    }

    return nearestSquaresHashes;
}

//calculate hashes of a nearest locations to the location, represented by the longitude and latitude
//return an array: [nearestLocationHash]
function calculateNearestLocations(longitude, latitude) {
    var squaresNumbers = quadrantNumbers(longitude, latitude); //calculate numbers for the squares, that are the representation of the current location
    //return array of a locations hashes, that are the nearest locations for the current location
    return calculateNearestLocationsBySquaresNumbers(squaresNumbers[0], squaresNumbers[1], null, true);
}

function calculateNearestLocationsByLocationHash(locationHash) {
    var squaresNumbers = locationHashToSquaresNumbers(locationHash); //calculate numbers for the squares, that are the representation of the current location
    //return array of a locations hashes, that are the nearest locations for the current location
    return calculateNearestLocationsBySquaresNumbers(squaresNumbers[0], squaresNumbers[1], null, true);
}

function isItNearestLocationBySquaresNumbers(mainLonSquareNum, mainLatSquareNum, nearestLonSquareNum, nearestLatSquareNum, mainSquareQuarterNum) {
    if (mainSquareQuarterNum == null) {  //if need to use a quarters of a squares
        if ( (nearestLonSquareNum === mainLonSquareNum - 1)
             || (nearestLonSquareNum === mainLonSquareNum + 1)
             || (nearestLonSquareNum === mainLonSquareNum) )
                if ( (nearestLatSquareNum === mainLatSquareNum - 1)
                     || (nearestLatSquareNum === mainLatSquareNum + 1)
                     || (nearestLatSquareNum === mainLatSquareNum) ) {
                        return true;
                }
        return false; 
    } else {
        //calculate what lonSquareNum will need to return, when nearest returns
        switch (mainSquareQuarterNum) {
            case 1:
            case 3:
                //-1 or the same
                if ( nearestLonSquareNum !== (mainLonSquareNum - 1) 
                    && nearestLonSquareNum !== mainLonSquareNum ) {
                        return false;    
                }
                break;
            case 5://same
                if ( nearestLonSquareNum !== mainLonSquareNum ) {
                    return false;    
                }
                break;
            default://if 2 or 4, then +1 or the same
                if ( nearestLonSquareNum !== (mainLonSquareNum + 1) 
                    && nearestLonSquareNum !== mainLonSquareNum ) {
                        return false;    
                }
        }


        //calculate what latSquareNum will need to return, when nearest returns
        switch (mainSquareQuarterNum) {
            case 1:
            case 2:
                //+1 or the same
                if ( nearestLatSquareNum !== (mainLatSquareNum + 1) 
                    && nearestLatSquareNum !== mainLatSquareNum ) {
                        return false;    
                }
                break;
            case 5://same
                if ( nearestLatSquareNum !== mainLatSquareNum ) {
                    return false;    
                }
                break;
            default://if 3 or 4, then -1 or the same
                if ( nearestLatSquareNum !== (mainLatSquareNum - 1) 
                    && nearestLatSquareNum !== mainLatSquareNum ) {
                        return false;    
                }
        }
        return true;
    }
}

function isItNearestLocation(locationHash, nearestLocationHash) {
    var squaresNumbersMainLocation    = locationHashToSquaresNumbers(locationHash); //calculate a numbers for the squares, that are the representation of the main location
    var squaresNumbersNearestLocation = locationHashToSquaresNumbers(nearestLocationHash); //calculate a numbers for the squares, that are the representation of the nearest to the main location
    //return array of a locations hashes, that are the nearest locations for the current location
    return isItNearestLocationBySquaresNumbers(squaresNumbersMainLocation[0], squaresNumbersMainLocation[1], squaresNumbersNearestLocation[0], squaresNumbersNearestLocation[1]);
}

//get a signs for a latitude a longitude. Return [longitudeSign, latitudeSign]. If sign i s "-", then return true, otherwise false
function getCoordsSignsByPrefix(prefix){
    var signLng = false, //true - and false +
        signLat = false;
    if ( typeof(prefix) === "number" ) { //if a number
        switch ( prefix ) {
            case 2 : signLat = true;
            case 3 : signLng = true;
                    break;
            case 4 : signLat = true;
        }
    } else { //if a string
        switch ( prefix ) {
            case "2" : signLat = true;
            case "3" : signLng = true;
                        break;
            case "4" : signLat = true;
        }
    }
    return [signLng, signLat];
}

//return {lonSquareNum, latSquareNum, squareQuarterNum}
//flWOSign - do not return a signs of a lat and lng squares, then return:
// [
//   0: lonSquareNum,
//   1: latSquareNum,
//   2 : pefix a value of the prefix of a location hash, within a range from 1 to 4
// ]
var _m2 = 2*maxDigitsQuadrantLngAsMultiplier;
var _m3 = 3*maxDigitsQuadrantLngAsMultiplier;
var _m4 = 4*maxDigitsQuadrantLngAsMultiplier;
var _m5 = 5*maxDigitsQuadrantLngAsMultiplier;
function locationHashToSquaresNumbers(locationHash, flWOSign) {
    var lonSquareNum, prefix;
    var latSquareNum = locationHash % maxDigitsQuadrantLatAsMultiplier;
    var c = (locationHash - latSquareNum) / maxDigitsQuadrantLatAsMultiplier;
    if ( c < _m2 ) {
        lonSquareNum = c - maxDigitsQuadrantLngAsMultiplier;
        prefix = 1;
    } else if ( c < _m3 ) {
        lonSquareNum = c - _m2;
        prefix = 2;
    } else if ( c < _m4 ) {
        lonSquareNum = c - _m3;
        prefix = 3;
    } else if ( c < _m5 ) {
        lonSquareNum = c - _m4;
        prefix = 4;
    }
    if ( flWOSign !== true ) { //if a signs of a lat and lng squares are necessary
        var signs = getCoordsSignsByPrefix(prefix); //return [lngSign, latSign]
        return [
            (signs[0] === true ? -lonSquareNum : lonSquareNum),
            (signs[1] === true ? -latSquareNum : latSquareNum)
        ];
    } else {
        return [
            lonSquareNum,
            latSquareNum,
            prefix
        ];
    }
}

function isLocationHash(locationHash) {
    if ( locationHash == null ) {
        return false;    
    }
    var e, f;
    var locationHashInt = _toInt(locationHash);
    var a = (locationHashInt / maxDigitsQuadrantLatAsMultiplier);
    f = Math.round((a -Math.floor(a))*maxDigitsQuadrantLatAsMultiplier);
    var c = (locationHashInt - f) / maxDigitsQuadrantLatAsMultiplier;
    if ( c < _m2 ) {
        e = c - maxDigitsQuadrantLngAsMultiplier;
    } else if ( c < _m3 ) {
        e = c - _m2;
    } else if ( c < _m4 ) {
        e = c - _m3;
    } else if ( c < _m5 ) {
        e = c - _m4;
    }  else {
        return false;    
    }  
    if ( e > maxNumberQuadrantLng || e < 1 || f > maxNumberQuadrantLat || f < 1 ) {
        return false;
    }
    return true;
}

module.exports = exports = {
    hashOfTheSquare : hashOfTheSquare,
    locationHash : locationHash,
    calculateNearestLocationsBySquaresNumbers : calculateNearestLocationsBySquaresNumbers,
    calculateNearestLocations : calculateNearestLocations,
    calculateNearestLocationsByLocationHash : calculateNearestLocationsByLocationHash,
    locationHashToSquaresNumbers : locationHashToSquaresNumbers,
    isItNearestLocation : isItNearestLocation,
    isLocationHash : isLocationHash,
    moduleSettings : moduleSettings,
    locationHashParts : locationHashParts,
    getCoordsSignsByPrefix : getCoordsSignsByPrefix,
    checkLonSquareNumOrFalse : checkLonSquareNumOrFalse,
    checkLatSquareNumOrFalse : checkLatSquareNumOrFalse,
    getPrefixByLngLat : getPrefixByLngLat
};