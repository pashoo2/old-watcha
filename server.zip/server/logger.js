const debug = require("debug");
const logMsg = debug("MSG");
const logSrv = debug("SRV");
const logDb  = debug("DB");
const logOther = debug("OTHER");
const util = require("util");
const path = require("path");
const fs = require('fs');

const msgQueue = {};

const writoLogToFile = (function writoLogToFile() { //write log messages to a files

    const msgQueue = this.msgQueue; //queue of the messages
    const filenames = Object.keys(msgQueue); 
    const cdate = (new Date()).toUTCString(); //the current date string
    const optionsFS = this.optionsFS; //options for fs.createWriteStream
    const dirname = this.dirnameForLogs;
    
    if ( filenames.length != null ) {

        for( var ii = 0, _len = filenames.length; ii < _len; ii++ ) {
                
            var filename = filenames[ii]; //filename of the module to log
            var logMessages = msgQueue[filename]; //messages from the module with the filename
            if ( logMessages != null 
                && logMessages.length != null
                && logMessages.length > 0 ) {
                    
                    var resMsg = '';
                    for( var i = 0, len = logMessages.length; i < len; i++ ) {
                        resMsg += logMessages[i] + '\n';            
                    }
                    
                    try {
                        var filepath = path.join(dirname,  cdate + ' ' + path.basename(filename) + '.log');
                        __dirname;
                        //write messages to the file
                        fs.appendFile(filepath, resMsg, optionsFS, err => console.log(err)); //create WriteStream
                        msgQueue[filename] = null;
                    } catch(e) {
                        console.log(e);    
                    }
                        
            }
        
        }
    }
}).bind({
    msgQueue  : msgQueue,
    optionsFS : { //options for fs.createWriteStream
      flags: 'a',
      encoding : 'utf8'
    },
    dirnameForLogs : path.join(__dirname, "/logs")
});

setInterval(writoLogToFile, 120000); //each 2 minutes create a logfile

const logThis = (function logThis(logger, filename) {
    const msgQueue = this;
    return function(msg){
        var fmsg;
        const modulefilename = filename == null ? "" : filename; 
        
        if ( msg.constructor === Array ) {
            fmsg += modulefilename + ": \n"
            for( var i = 0, len = msg.length; i < len; i++ ) {
                fmsg += util.inspect(msg[i]) + "\n";    
            }    
            logger(fmsg);
        } else if ( msg instanceof Error ) {
            fmsg = util.inspect(msg);
            logger(modulefilename + ": " + fmsg);
        } else {
            fmsg = util.inspect(msg);
            logger(modulefilename + ": " + fmsg);    
        }
        
        var moduleQueue;
        if ( msgQueue[modulefilename] == null ) { //if there is no queue for the module filename
            moduleQueue = msgQueue[modulefilename] = [];    
        } else {
            moduleQueue = msgQueue[modulefilename];    
        }
        
        moduleQueue[moduleQueue.length] = fmsg; //put the message to write it into the logfile
    };   
}).bind(msgQueue);

function loggerMsg(filename) {
    return logThis(logMsg,filename);    
}
function loggerSrv(filename) {
    return logThis(logSrv,filename);    
}
function loggerDb(filename) {
    return logThis(logDb,filename);    
}
function logger(filename) {
    return logThis(logOther,filename);    
}

module.exports = {
   loggerMsg : loggerMsg,
   loggerSrv : loggerSrv,
   loggerDb  : loggerDb,
   logger    : logger
};