"use strict";
var EventEmitter = require("events").EventEmitter,
    eEmitter = new EventEmitter(),
    extend = require("extend"), //npm install extend
    dbGeoMethods = require("./dbGeo.js"),
    getTimestamp = require("./getTimestamp.js"),
    Promise = require("bluebird"),
    common = require("./common.js"),
    hashes = require("./hashes.js"),
    log = require("./logger.js").loggerMsg(__filename),
    resolvePath = require("resolvePathMy");

//settings
var settings = require(resolvePath(__dirname, "settings/settings.js"));
var ILSSetting = settings.ILSSetting;
var messagesSettings = settings.messagesSettings,
    messageKindSetClientServerTimeDifference = messagesSettings.messageKindSetClientServerTimeDifference,
    empty_user_id = messagesSettings.empty_user_id; //the value, that is representation of an empty id of the user

//a functions that are often used
var isEmptyLSID = common.isEmptyLSID; //check if an id of the user is empty
var encodeLocationHashForUser = hashes.encodeLocationHash; //encode location hash from the server format
var encodeLocationHashByCoords = hashes.encodeLocationHashByCoords; 
var decodeLocationHashForUser = hashes.decodeLocationHashFromLHF; //decode location hash to server format from the client format
var returnLocationHashInServerFormat = hashes.returnLocationHashInServerFormat; //conver a location has hfrom th e lhf format to the server format
var calculateNearestLHFByLocationHashOrLHF = hashes.calculateNearestLHFByLocationHashOrLHF; //return an array with the nearest locations in the client format by the location hash in any(client or server) format
var isEmptyObject = common.isEmptyObject;
var isArray = common.isArray;
var resolvedPromiseTrue  = common.resolvedPromiseTrue; //Promise, resolved with true value
var resolvedPromiseFalse = common.resolvedPromiseFalse; //Promise, resolved with false value
var returnFalse = common.returnFalse;  //the function that always returns false

//MAIN MESSAGING FUNCTIONS

/* 
*   add response to the request desc if several responses are needed to be sent
*   serverRespons - a full server response, which was formed before the added response
*   responseSchema - schema of the response with all headers
*   response - body of the response (without headers)
*   return serverResponse = { _several: true, _responses:[{response:response1, responseSchema:responseSchema1},...,{response:responseN, responseSchema:responseSchemaN}] }
*/
function addResponceToRequestDesc(serverResponse, responseSchema, response) {

    if ( serverResponse == null 
        || isEmptyObject(serverResponse) === true ) {
            var resultResponse = {}; //after the response that will be formed, it returned as the result of the function   
    } else {
        resultResponse = serverResponse;   
    } 
        
    if (isEmptyObject(responseSchema) === true || isEmptyObject(response) === true) {
        throw new Error("The necessary parameters are absent or empty");
    } else {
        if ( isEmptyObject(resultResponse) === false //if the response already is not empty
            && isArray(resultResponse._responses) === false) { //and not contains a several responses in itself
                log("The response has been lost!"); //the given main response will be lost, because we don't know its schema
                log(serverResponse);
                resultResponse = {};
        }
        if (resultResponse != null 
            && Array.isArray(resultResponse._responses) === true) { //if the given existing response is empty
                resultResponse._responses.push(
                    { response: response,
                      responseSchema: responseSchema }
                ); 
        } else { //if the given main response is not empty and already contains one more responses
                resultResponse._several = true;
                resultResponse._responses = [ //the result response will contain only the given response, which is necessary to be added to the result response
                    { response: response,
                      responseSchema: responseSchema }
                ]; 
        }
    }
    return resultResponse;
}

/*
*   emit an event of this module, that needed to send a message to the user
*   messageSchema - main schema of the message(headers without a body)
*   message - body of the message
*/
function sendMessageToClient(userID, messageSchema, message) {
    var messageDesc = {
        userID: userID,
        responseSchema: messageSchema,
        serverResponse: message
    };   //form the message description
    thisModule.emit("sendMessage", messageDesc); //emit an event to send the message
}

//from = {localServerID, locationHash} or from = [{locationHash, localServerID [, timestamp]}] will be converted to { locationHash : localServerID } or { locationHash : {localServerID, timestamp} }
function convertToObjectWithLocations(from) {
    var resulted;
    if ( isArray(from) === true
        && from.length > 0 ) { //[{locationHash, localServerID [, timestamp]}]
            var flTimestampExists = false; //if the results with a timestamps
            for ( var i = 0, len = from.length; i < len; i++ ) {
                var res = from[i];
                if ( flTimestampExists === false //check if the timestamp exists into the results
                    && res.timestamp !== undefined ) {
                        flTimestampExists = true;
                }
                if ( res.locationHash != null ) {
                    if ( flTimestampExists === true ) {
                        resulted[res.locationHash] = {
                            localServerID : res.localServerID,
                            timestamp : res.timestamp
                        };
                    } else {
                        resulted[res.locationHash] = res.localServerID;
                    }
                }
            }
    } else { //{localServerID, locationHash}
        resulted[from.locationHash] = from.localServerID;
    }
    return resulted;
}

/*
    send to a ls with the ID = userID a message to stop handling of the given location
    arguments can be passed through the context:
        context = array[
            0 : undefined/aother value - check or not the result of the previous command. If false, then do not check, if another value, then arguments[0] must be equal to this value, othervise this function will not be executed
            1 => userID
            2 => locationHash
        ]
*/
function stopLocationHandling(userID, locationHash) {
    
    if ( arguments.length === 1 ) { //if it is necessary to get the arguments from the context
        
        if ( this[0] !== undefined //it is necessary to check the result of the previous command execution
            && this[0] !== arguments[0] ) { //check the result of the previous command execution
            return false; //if the result of the previous funtion not equals to the necessary value    
        }
        
        //get the arguments from the context
        userID = this[1];
        locationHash = this[2];
    } else if ( typeof(userID) !== "number" ) {
        return false;    
    }
    
    sendMessageToClient(userID, schemaResponseTo_stopLocationHandling_fromILS, messageLSStopLocationHandling(locationHash));
}


/*---------------------------------------------------------------------------------------*/

//MESSAGING HANDLERS

/*
*   determine handler function, validation schema and response scchema by the kind of a message
*   {
*     "message type" : {
*   		"message kind" : {
*     		handler   : handler function
*         	schema    : schema for the message kind
*   			response  : schema for the server response to the client message
*   		}
*   	}
*   }
*/

//form the list of the local servers in the format, that a client can recognize
//nearestLSs = {locationHash : lsID} or [locationHash]
function formListNearestLocalServersForClient(nearestLSs) {
    if ( nearestLSs == null ) {
        return null;
    }
    var locationHash, nearestLSDesc, lsID, timestamp, i,
        result = {};
       
    if ( isArray(nearestLSs) === true ) { //nearestLSs is a list with the nearewst locations without the id of the local servers
        for ( i =0; i < nearestLSs.length; i++ ) {
            result[nearestLSs[i]] = {
                localServerID : empty_user_id,
                timestamp : getTimestamp()
            }; 
        }
    } else { //nearestLSs = {locationHash : lsID} or { locationHash : { localServerID, timestamp } }
        var _keys = Object.keys(nearestLSs);
        for ( i =0; i < _keys.length; i++ ) {
            locationHash = _keys[i];
            nearestLSDesc = nearestLSs[locationHash]; //the description of the nearest local server
            if ( nearestLSDesc == null ) { //if there is no id of a local server for the nearest location
                lsID = null;
                timestamp = null;
            } else if ( typeof(nearestLSDesc) === "object" ) { //if the description is an object has the structure : {localServer, timestamp} 
                lsID = nearestLSDesc.localServerID;
                timestamp = nearestLSDesc.timestamp; 
            } else { //if the description simply is the id of the nearest local server
                lsID = nearestLSDesc; //id of the nearest local server
                timestamp = null;   //the timestamp, that describes when this local server has become it, is absent 
            }
            result[locationHash] = 
                        { //return to the client the structure, that describes the nearest local server
                            localServerID : (lsID == null) ? empty_user_id : lsID,
                            timestamp     : (timestamp == null) ? getTimestamp() : timestamp
                        };
        }
    }
    return result;
}

//outcoming ping--
var schemaMessage_LSPing = function(){
    return {
        type: "CSToILS",
        kind: "ping",
        body: null
    };
};
function messageLSPing(locationHash) {
    
    var currentTimestamp = getTimestamp();
    console.log(currentTimestamp);
    
    return {
        locationHash : locationHash,
        nearestLocations : formListNearestLocalServersForClient(calculateNearestLHFByLocationHashOrLHF(locationHash)), //form the nearest locations to the location hash
        timestamp    : currentTimestamp
    };
}
//--outcoming ping

/*
    send the ping request to the local server with ID
    flWOaddWaitingPongResponse - not needed to exec addWaitingPongResponse
    arguments can be passed through the context:
        context = array[
            0 : undefined/aother value - check or not the result of the previous command. If false, then do not check, if another value, then arguments[0] must be equal to this value, othervise this function will not be executed
            1 => localServerID
            2 => locationHash
            3 => flWOaddWaitingPongResponse
        ]
*/
function checkLocalServer(localServerID, locationHash, flWOaddWaitingPongResponse) {
    
    if ( arguments.length === 1 ) { //if it is necessary to get the arguments from the context
        
        if ( this[0] !== undefined //it is necessary to check the result of the previous command execution
            && this[0] !== arguments[0]  ) { //check the result of the previous command execution
                return false; //if the result of the previous funtion not equals to the necessary value    
        }
        
        //get the arguments from the context
        localServerID = this[1];
        locationHash = this[2];
        flWOaddWaitingPongResponse = this[3];
    } else if ( typeof(localServerID) !== "number" ) {
        return false;    
    }
    
    var messagePing = messageLSPing(locationHash); //form ping message
    console.log("ping for " + locationHash);
    sendMessageToClient(localServerID, schemaMessage_LSPing, messagePing);
    if ( flWOaddWaitingPongResponse !== true ) {
        dbGeoMethods.setExpLocalServerLocation(localServerID, locationHash, true); //set the short time to live for the local server
    }
    
    return true;
}

/*---------------------------------------------------------------------------------------
onNewConnection---*/

/*
    a new connection with the client
*/
function onNewConnection(message) {
    dbGeoMethods.getLocationsByLS(message.userID, false, true) //get all handled locations by the local server
                .then(onNewConnection.afterGetAllLocationsByLocalServer);
}

//after got locations by the local server id
onNewConnection.afterGetAllLocationsByLocalServer = function(locationsList) {
    var resultedMessage = {};
    var len = locationsList.length;
    if ( len > 0 ) {
        for( var i = 0; i < len; i++ ) {
            addResponceToRequestDesc(resultedMessage, schemaMessage_LSPing, messageLSPing(locationsList[i])); //add ping for the maintained location   
        }
    } 
    return resultedMessage;
};

/*---------------------------------------------------------------------------------------
---onNewConnection*/

/*---------------------------------------------------------------------------------------
addMessagesIfUserLocationChanged---*/

//bounded promises functions for addMessagesIfUserLocationChanged----

//after when the message that the user was chosen as the ls was sent to him
addMessagesIfUserLocationChanged.afterMessageClientBecomeLocalServer = function afterMessageClientBecomeLocalServer(msgClientBecomeLocalServer){
    this.resultResponse = addResponceToRequestDesc(this.resultResponse, schemaResponce_ClientBecomeLocalServer, msgClientBecomeLocalServer); //add the first responce
    return this;
};

//after when the user has become the local server
addMessagesIfUserLocationChanged.afterSetLocalServerID = function afterSetLocalServerID(err) {
    if ( err !== false 
        && ( err instanceof Error ) === false ) { //if the user was set as the local server for the location
            //form the message that he is a local server
            return messageClientBecomeLocalServer(this.calcLocationHash)
                    .bind(this.resultMessage)
                    .then(addMessagesIfUserLocationChanged.afterMessageClientBecomeLocalServer);
    } else { //if the client was not set as the local server
        return this.resultMessage;
    }
};

//after when id of the ls of the user location will be given
addMessagesIfUserLocationChanged.afterGetLocalServerID = function afterGetLocalServerID(_validLocalServerID) { 
    
    if ( _validLocalServerID === false
        || _validLocalServerID instanceof Error) {
            return null;        
    }
    
    //get a values for the variables from the local context of this promise
    var userID = this.userID;
    var _flLocationChanged = this["_flLocationChanged"];
    var calcLocationHash = this.calcLocationHash;
    var flLocalServerTimestamp = this.flLocalServerTimestamp; //with timestamp of the local server
    var currLocationHash = this.currLocationHash;
    var currLSID = this.currLSID;
    
    var newLocalServerID; //id of the valid local server for the requested location
    var localServerTimestamp; //the timestamp of the valid local server
    if ( flLocalServerTimestamp === true ) { //if the result is { localServerID, timestamp }
        newLocalServerID = typeof(_validLocalServerID.localServerID) !== "number" ? empty_user_id : _validLocalServerID.localServerID; //check if empty local server for the location    
        localServerTimestamp = _validLocalServerID.timestamp; 
    } else {
        newLocalServerID = typeof(_validLocalServerID) !== "number" ? empty_user_id : _validLocalServerID; //check if empty local server for the location    
        localServerTimestamp = getTimestamp();
    }
     
    
    //if a local server is exists for this location
    if (newLocalServerID !== empty_user_id) {
        var resultResponse = {};
        if ( newLocalServerID === userID ) { //send the message that the client became the local server, because the client may not knows that he is the local server for this location
            var msgClientBecomeLocalServer = messageClientBecomeLocalServer(calcLocationHash, true);
            resultResponse = addResponceToRequestDesc(resultResponse, schemaResponce_ClientBecomeLocalServer, msgClientBecomeLocalServer);
        }
        if (_flLocationChanged === true) { //if the user location has changed
            //form the message that the user location has changed
            var msgLocationChanged = messageClientLocationChanged(currLocationHash, currLSID, calcLocationHash, newLocalServerID, localServerTimestamp);
            resultResponse = addResponceToRequestDesc(resultResponse, schemaResponce_ClientLocationChanged, msgLocationChanged); //add the first responce
        }
        return {
                changed: _flLocationChanged,
                resultResponse: resultResponse,
                localServerID: newLocalServerID
            };
    } 
    else { //if a local server is not exists for the location and the user becomes the local server for this location
        var resultMessage = 
                this.resultMessage = 
                    {   //the resulted message for the client. Add it to the local context
                        changed: _flLocationChanged,
                        localServerID: (flLocalServerTimestamp === true)
                                        ? { 
                                            localServerID : userID,
                                            timestamp : getTimestamp()
                                          }
                                        : userID, //user is the local server for now
                        resultResponse: {}
                    };
        
        if (_flLocationChanged === true) { //if it is necessary to send the two messages - the first is that the user becomes a local server
            //the second message is that the user location has changed
            msgLocationChanged = messageClientLocationChanged(currLocationHash, currLSID, calcLocationHash, userID); //new local server ID = user ID
            resultMessage.resultResponse = addResponceToRequestDesc(resultMessage.resultResponse, schemaResponce_ClientLocationChanged, msgLocationChanged); //add the first responce
        }

        return dbGeoMethods.setLocalServerID(calcLocationHash, userID) //set the user as the local server for this location
                .bind(this)
                .then(addMessagesIfUserLocationChanged.afterSetLocalServerID);
    }
};

//-----bounded promises functions for addMessagesIfUserLocationChanged

//responce schemas for addMessagesIfUserLocationChanged--

//if a client location has changed--
var schemaResponce_ClientLocationChanged = function(){
    return {
        type: "CSToELS",
        kind: "locationChange",
        body: null
    };
};
function messageClientLocationChanged(previousLocationHash, oldLSID, newLocationHash, newLSID, _timestamp) {
    return {
        newLocationHash: newLocationHash,
        previousLocationHash: previousLocationHash,
        newLSID: newLSID || empty_user_id,
        oldLSID: oldLSID || empty_user_id,
        timestamp: typeof(_timestamp) === "number" ? _timestamp : getTimestamp()
    };
}
//--if a client location has changed

//if a client has became the ls--
var schemaResponce_ClientBecomeLocalServer = function(){
    return {
        type: "CSToILS",
        kind: "addLocationForHandling",
        body: null
    };
};
//promise, if flGetOnlyNearestLocationsHashes === false or not promise
//flGetOnlyNearestLocationsHashes - no need to get the local servers id's

//funcs for bound promises for messageClientBecomeLocalServer--
function afterGetNearestLS(nearestLSs) {
    
    if ( nearestLSs === false
        || nearestLSs instanceof Error ) {
            return null;        
    }
    
    var locationHash = this.locationHash;
    if ( common.isEmptyObject(nearestLSs) === true ) { //the description of the nearest local servers is absent
        return { //if the list with the nearest local servers is empty
            locationHash: locationHash,
            nearestLocalServers: formListNearestLocalServersForClient(calculateNearestLHFByLocationHashOrLHF(locationHash)) //add the list of a nearest locations without a local servers
        };
    }
    return {
        locationHash: locationHash,
        nearestLocalServers: formListNearestLocalServersForClient(nearestLSs) //form the list of a nearest locations and their local servers
    };
}
//--funcs for bound promises for messageClientBecomeLocalServer
function messageClientBecomeLocalServer(locationHash, flGetOnlyNearestLocationsHashes) {
    if ( flGetOnlyNearestLocationsHashes === true ) {
        return { //if the list with the nearest local servers is empty
                locationHash: locationHash,
                nearestLocalServers: formListNearestLocalServersForClient(calculateNearestLHFByLocationHashOrLHF(locationHash)) //add the list of a nearest locations without a local servers
        };    
    }
    return dbGeoMethods.getNearestLS(locationHash) //get the nearest local servers to the current location
            .bind({locationHash : locationHash})
            .then(afterGetNearestLS);
}
//--if a client has became the ls

//--responce schemas for addMessagesIfUserLocationChanged

/*
* Promise
*  check user change location
*  1)    if the User location changed return a Promise with a result :
*  {
*  changed:true,
*  resultResponse - result response for the user,with messages with local server id or message, that the user location changed, or message that the user is become a local server
*  localServerID - local server for the user location
*  }
*  2)    if not changed, than return Promise, wth the result :
*   if not changed and the user was not become a local server
*   {
*  changed: false,
*  resultResponse : false,
*  localServerID  - local server for the user location
*  } or the second variant
*   {
*  changed: false,
*  resultResponse  - message that the user is become a local server
*  localServerID: userID
*  }
*  3) An error, if it has occurred
*  If flLocalServerTimestamp = true, in the result localServerID is an object { localServerID, timestamp }, timestamp - timestamp, when the local server has become it
*  flILS means that the userLocation.calcLocationHash is absent, and needed to use userLocation.locationHash instead of this field
*/
function addMessagesIfUserLocationChanged(messageDesc, flLocalServerTimestamp, flILS) {
    var userLocation = messageDesc.message; //the message body is the description of the user location
    var currLocationHash = userLocation.locationHash; //current location
    var calcLocationHash = (userLocation.calcLocationHash == null || userLocation.calcLocationHash === 0)
                            ? ( flILS === true ? currLocationHash : null ) //if it is ILS, then the calculated hash of the location is equals to the hash of the maintained location, that was received from the ILS
                            : userLocation.calcLocationHash; //hash of the user location
    var _flLocationChanged = (userLocation._flLocationChanged === true);
    if (typeof(calcLocationHash) !== "number") { //the hash of the location have not been calculated
        throw new Error("The user's location hash is empty");
    } else {
        var _context = { //form the local context for the Promise
           userID : messageDesc.userID,
           _flLocationChanged : _flLocationChanged,
           calcLocationHash : calcLocationHash,
           flLocalServerTimestamp : flLocalServerTimestamp,
           currLocationHash : currLocationHash,
           currLSID : userLocation.localServerID //current ls
        };
        return dbGeoMethods.getLocalServerID(calcLocationHash, flLocalServerTimestamp) //get an ID of a local server for the location hash
                .bind(_context)
                .then(addMessagesIfUserLocationChanged.afterGetLocalServerID);
    }
}

/*---addMessagesIfUserLocationChanged
---------------------------------------------------------------------------------------*/



/*---------------------------------------------------------------------------------------
chooseAnotherLS(from ELS)---*/

//responce schemas for chooseAnotherLS_FromELS--
//request to chose another local server for the location from ELS
var responseTo_clientChooseAnotherLS_fromELS = function(){
    return null;
};
//--responce schemas for chooseAnotherLS_FromELS
       
//Promise
//handler for a message from ELS
function chooseAnotherLS_FromELS(messageDesc) {
    var userLocation = messageDesc.message,
        calcLocationHash = userLocation.calcLocationHash; //hash of the user location in the lhf format
    if ( typeof(calcLocationHash) !== "number" 
        || calcLocationHash === 0) { //if a hash of the location was not calculated
            throw new Error("The user location hash is empty");
    }
    return addMessagesIfUserLocationChanged(messageDesc, false) //check is user location changed or there is no local server for the user location
            .bind(userLocation)
            .then(chooseAnotherLS_FromELS.afterAddMessagesIfUserLocationChanged);
}

//funcs for bound promises for chooseAnotherLS_FromELS --

/*
    after checking if the user location was changed
*/
chooseAnotherLS_FromELS.afterAddMessagesIfUserLocationChanged = function afterAddMessagesIfUserLocationChanged(res) { //this = userLocationDesc
    
    //variables from the context
    var localServerIDFromClient = this.localServerID; //local server id to which the client is connected
    var calcLocationHash = this.calcLocationHash; //calculated by coords
    
    //only the local server ID or the local server ID wth a timestamp
    var localServerID = res.localServerID;
    if (res.changed !== true) { //if the user's location was not changed and we've got only the local server's id
        if (typeof(localServerID) === "number"
            && localServerID !== empty_user_id
            && localServerIDFromClient === localServerID) { //if the current server from db and the server to which the client is connected are equals
                checkLocalServer(localServerID, calcLocationHash);	//check this local server
        } else { //if the current server from db and the server to which the client is connected are not equals
            //send the current local server id to the client
            return addResponceToRequestDesc({}, schemaResponseTo_lsGetLocalServerID_fromELS, formResponceTo_elsGetLocalServerID(calcLocationHash, localServerID, localServerIDFromClient));
        }
    } else { //if the user has changed his location or there is no local server, and this is cause for chosing the user as a local server
        return res.resultResponse; //return response with this information
    }
};

//--funcs for bound promises for chooseAnotherLS_FromELS

/*---chooseAnotherLS(from ELS)
---------------------------------------------------------------------------------------*/



/*---------------------------------------------------------------------------------------
chooseAnotherLS(from ILS)---*/

//responce schemas for chooseAnotherLS_FromILS--

//request to chose another local server for the location from ILS
//the server response to the "chose another ls" request from an ILS
var responseTo_clientChooseAnotherLS_fromILS = function(){
    return {
        type: "CSToILS", //this type of a messages is handled by an ELS, that is started by an ILS for handling a locations
        kind: "newLocalServerID",
        body: null
    };
};
    
//--responce schemas for chooseAnotherLS_FromILS    

//funcs for bound promises for chooseAnotherLS_FromILS --

//when the id of a local servers was given for a locations, that are the nearest to the ILS locations
chooseAnotherLS_FromILS.afterGetLSIDForSeveralLocations = function afterGetLSIDForSeveralLocations(result) { //result = { lostionHash : lsID }
    //variables from the context
    var elsLocations = this.elsLocations;
    var oldLSID = this.oldLSID;
    oldLSID = ( typeof(oldLSID) !== "number" ) ? empty_user_id : oldLSID;  
    
    var changedLocalServersForLocations = {}; //{ lostionHash : lsID }
    var flChangedLocalServersForLocations = false; //if ls changed for some of the requested locations
    
    //check all the els locations.
    for( var i = 0, len = elsLocations.length; i < len; i++ ) {
        var elsLocationHash = elsLocations[i]; //location, that are handled by the els
        var lsID = ( typeof(result[i]) !== "number" ) ? empty_user_id : result[i];
        
        if ( lsID !== oldLSID ) { // if the id of the local server was changed for the location, then send it to els
            changedLocalServersForLocations[elsLocationHash] = lsID;  
            flChangedLocalServersForLocations = true;
        }
        else 
            if ( lsID !== empty_user_id
                && oldLSID !== empty_user_id ) { //if the lsID was not changed, then send ping request to this server
                    checkLocalServer(lsID, elsLocationHash); //send ping for the location to the local server
            }
    }
    
    changedLocalServersForLocations.oldLocalServerID = oldLSID; //put the previous id of the local server, to which the els had been connected
    //send the list with the changed id of a local servers for the chosen locations to the els
    
    return ( flChangedLocalServersForLocations === true ) ? changedLocalServersForLocations : null;  ////send a message with the locations with a new LSs or nothing
};

//-- funcs for bound promises for chooseAnotherLS_FromILS

//handler for a message from ILS
//Promise
function chooseAnotherLS_FromILS(messageDesc) {
    var message = messageDesc.message,
        elsLocations = message.locations.nearestLocations; //the locations, that are handled by the els
    return dbGeoMethods.getLocalServerID(elsLocations) //the result must be in the format { locationHash : localServerID }
            .bind({
                oldLSID : message.lsID, //local server id to which the client is connected
                elsLocations : elsLocations
            })
            .then(chooseAnotherLS_FromILS.afterGetLSIDForSeveralLocations);
}

/*---chooseAnotherLS (from ILS)
---------------------------------------------------------------------------------------*/



/*---------------------------------------------------------------------------------------
incoming pong (from ILS)---*/

//the client answer to the server ping request or client add the location for handling by another reason
function onLSPongResponse(messageDesc) {
    var ilsLocationHash = messageDesc.message, //one or several locations, that are maintained by the ils, and that has a formed ping request from the cs
        ilsID = messageDesc.userID; //id of the ls
    
    console.log("Incoming pong for :");
    console.log(ilsLocationHash);
    
    dbGeoMethods.getLocationsByLS(ilsID) //get the handled locations from the db
        .bind({
            ilsLocationHash : ilsLocationHash,
            ilsID : ilsID
        }) //bind to the locations from the ils request
        .then(onLSPongResponse_updateTTLForLS);
}

//check if the locations from the request are valid
function onLSPongResponse_updateTTLForLS(validLocationsList) {
    
    var locationsFromRequest = this.ilsLocationHash;
    var ilsID = this.ilsID;
    var validLocationsFromRequested = []; //list of the requested locations, that are valid(checked by db)
    
    if ( typeof(locationsFromRequest) === "number" ) { //if requested only the one location
        if ( validLocationsList.indexOf(locationsFromRequest) !== -1 ) { //if the location is valid
            console.log("pong for " + locationsFromRequest);
            validLocationsFromRequested[0] = locationsFromRequest;
        } else { //if not handled by this ls
            console.log("not valid pong for " + locationsFromRequest);
            onLSPongResponse_setLSForLocation(ilsID, locationsFromRequest);
        } 
    } else { //if several locations were requested
        validLocationsFromRequested = []; //valid locations from the list of the requested
        var ind = 0; //the current index into the validLocationsFromRequested
        
        for( var i = 0, len = locationsFromRequest.length; i < len; i++ ) { //check each requested location. is it the valid location
            var lh = locationsFromRequest[i]; //one location hash
            if ( validLocationsList.indexOf(lh) !== -1 ) { //if the location is valid
                console.log("pong for " + lh);
                validLocationsFromRequested[ind++] = lh;  //add to the list of the valid locations
            } else if ( typeof(lh) === "number" ) {
                console.log("not valid pong for " + lh);
                onLSPongResponse_setLSForLocation(ilsID, lh);
            } 
        }
        
    }
    
    if ( validLocationsFromRequested.length > 0 ) {
        return dbGeoMethods.setExpLocalServerLocation(ilsID, validLocationsFromRequested, false, true); //update the ttl for the local server
    }
    
}

//try to set the given user as the local server for the location or set stop location handling for him
function onLSPongResponse_setLSForLocation(ilsID, lh) {
    return dbGeoMethods.setLocalServerID(lh, ilsID) //try to set this ls as the handler for this location(it will be set if a local server is absent for this location)  
                .bind([true, ilsID, lh, true]) //check that the result of setLocalServerID return true as the result, then send ping without setting of the short ttl for the ls
                .then(checkLocalServer) //if this local server was set as the local server for the location, then check it by ping request
                .bind([false, ilsID, lh]) //if the false result of the setLocalServerID
                .then(stopLocationHandling); //if the local server is not valid and was not set, then send the message to stop handling of this location    
}

/*---incoming pong (from ILS)
---------------------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------------------
getTimeUTCDifference---*/

//schemas for responces of onClientGetTimeUTCDifference--
/*get a time offset beetween the server and the client in milliseconds
the server response to the "time offset" request from a client*/
var responseTo_clientGetTimeUTCDifference = function() {
    return {
        type: "timeUTCDifference",
        kind: "timeUTCDifference",
        body: null
    };
};
//--schemas for responces of onClientGetTimeUTCDifference

//get a time offset beetween the server and the client in milliseconds
function onClientGetTimeUTCDifference(messageDesc) {
    var clientDate  = messageDesc.message;
    var sendingDateMilliseconds = Date.parse(clientDate.cDate);
    var currentDate = new Date();
    var receivingDateMilliseconds = Date.UTC(currentDate.getUTCFullYear(), currentDate.getUTCMonth(), currentDate.getUTCDate(),  currentDate.getUTCHours(), currentDate.getUTCMinutes(), currentDate.getUTCSeconds(), currentDate.getUTCMilliseconds());
    return {
        difference  : (receivingDateMilliseconds - sendingDateMilliseconds), //difference between the time when the client sent the request and the server got it
        sDate       : currentDate.toUTCString(), //date, when the server has received the client request
        cDate       : clientDate.cDate //date when the client has formed the request
    };
}

/*---getTimeUTCDifference
---------------------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------------------
------getLSID(fromILS)---*/

//schemas for responces of onLSGetLocalServerID_fromILS--
//get the local server id for the location
var responseTo_lsGetLocalServerID_fromILS = function() {
    return {
        type: "CSToILS", //this type of a messages is handled by an ELS, that is started by an ILS for handling a locations
        kind: "newLocalServerID",
        body: null
    };
};

//Promise
//return an ID of a local server for the locations, that are requested by the ils
//return message
//{ locationHash  - user location hash
//  localServerID - local server ID
//  timestamp }
function onLSGetLocalServerID_fromILS(messageDesc) {
    var incomingMsg = messageDesc.message; 
    var reqLocationsHashes = incomingMsg.locations.nearestLocations; //the hashes of the locations for which the ID of the local servers are requested
    var oldLocalServerID   = incomingMsg.lsID;
    
    var resPromise = dbGeoMethods.getLocalServerID(reqLocationsHashes, false, true);
    if ( oldLocalServerID != null
        && oldLocalServerID !== empty_user_id ) {
            resPromise = 
                    resPromise.bind({
                        oldLocalServerID: oldLocalServerID
                    });        
    }
    
    return resPromise
            .then(onLSGetLocalServerID_fromILS.afterGetLSIDForSeveralLocations);
}

/*
    when all an id of a ls for the requested locations, was received from the db
    return Object { locationHash : lsID, oldLocalServerID } only with the locations, where the id has changed in comparation to the client data
*/
onLSGetLocalServerID_fromILS.afterGetLSIDForSeveralLocations = function afterGetLSIDForSeveralLocations(results){ //results = [{locationHash, localServerID}] or {locationHash, localServerID}
    
    var result = {}; //result for the user
    var flArray = isArray(results);
    var oldLocalServerID = this.oldLocalServerID; //id of the ls, given by the user
    
    if ( flArray === false //if not an array (for several locations)
        && ( typeof(results) !== "object" || typeof(results.locationHash) !== "number" ) ) { //and not an object with the location hash property (for only one location)
            return null;        
    }
    
    var flSendTheResult = false; //the flag means that the result must be sent back to the client
    if ( flArray === false ) { //if not an array (only the one location). result = { locationHash, localServerID }
        flSendTheResult = onLSGetLocalServerID_fromILS.addToResult(result, results.locationHash, results.localServerID, oldLocalServerID);
    } else { //if array ( ls id for a several locations )
        for ( var i = 0, len = results.length; i < len; i++ ) { //result = [ locationHash : localServerID ]
            if ( onLSGetLocalServerID_fromILS.addToResult(result, results[i].locationHash, results[i].localServerID, oldLocalServerID) === true ) {
                flSendTheResult = true;    
            }
        }
    }
    
    if ( flSendTheResult === true ) { //if necessary to send the result to the user
        if ( isEmptyLSID(oldLocalServerID) === false ) { //add the given id of the local server to the result
            result.oldLocalServerID = oldLocalServerID;
        }
        
        return result;
    }
    

};

/*
    add the given ls id for the location hash to the result
    objResult = { locationHash : lsID }
    returns true if the id fom the client differs fromthe valid ID, otherwise eturns false
*/
onLSGetLocalServerID_fromILS.addToResult = function(objResult, locationHash, validLSID, lsIDFromClient) {
    
    if ( isEmptyLSID(validLSID) === true && isEmptyLSID(lsIDFromClient) === true ) { //both id (the old from the client and the valid from the db) are empty
        return false;        
    } else { //if the id from the db differs from the old ls id
        objResult[locationHash] = validLSID;
        return true;
    }
    
};


/*---getLSID (from ILS)
---------------------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------------------
getLSID (from ELS)---*/

//schemas for responces of onLSGetLocalServerID--
//request from a peer to get a local server ID for his location
var schemaResponseTo_lsGetLocalServerID_fromELS = function() { //schema
    return {
        type: "CSToELS",
        kind: "newLocalServerID",
        body: null
    };
};
function formResponceTo_elsGetLocalServerID(locationHash, newLocalServerID, oldLocalServerID, timestamp) {
    var msg = {
        locationHash  : locationHash, //location of the local server
        timestamp     : typeof(timestamp) === "number" ? timestamp : getTimestamp(), //timestamp when the local server has became the local server for the location
        localServerID : newLocalServerID == null ? empty_user_id : newLocalServerID //empty_user_id means that there is no local server for the requested location
    };
    if ( oldLocalServerID != null ) { //if the old local server is not empty
        msg.oldLocalServerID = oldLocalServerID;    
    }
    return msg;
}
//--schemas for responces of onLSGetLocalServerID

//funcs for bound promises for onLSGetLocalServerID--
//after checking if the location of the user has changed
function afterAddMessagesIfUserLocationChanged(res) {
    
    //from the context.
    //this = userLocationDesc
    var _flLocationChanged = (this._flLocationChanged === true);
    var calcLocationHash = this.calcLocationHash;
    var msgLocalServerID = this.localServerID;
    
    var resultResponse = res.resultResponse; //a response that was prepared by the addMessagesIfUserLocationChanged, if the user location changed
    var flEmptyResultResponse = (isEmptyObject(resultResponse) === true);
    var lsDesc = res.localServerID; //id of a local server for the requested location
    if ( lsDesc != null
         && (flEmptyResultResponse === true //if the response was not formed by the addMessagesIfUserLocationChanged function, this is means that the user location has not been changed
            || _flLocationChanged === false) //or if the location was not changed but the id of the ls has not been given by any reasons
        ) { //if the user's location was not changed and we got only the id of the local server for the user location
            
            var timestamp, validLSID;
            if ( typeof(lsDesc) === "object" ) { //if the descriptin with the timestamp and ID
                timestamp = lsDesc.timestamp;
                validLSID = lsDesc.localServerID;
            } else 
                if ( typeof(lsDesc) === "number" ) { //only ID of the local server
                    validLSID = lsDesc;
                }
            else {
                validLSID = empty_user_id;    
            }
            
            var messageLSID = formResponceTo_elsGetLocalServerID(calcLocationHash, validLSID, msgLocalServerID, timestamp); //send the message with the new local server ID and the old local server id, that was got from the incoming message;
            if ( flEmptyResultResponse === true ) { //if the responce is empty, return the new formed response
                return messageLSID;
            } else { //if the responce is not empty add the new formed responce to the resulted responce 
                return addResponceToRequestDesc(resultResponse, schemaResponseTo_lsGetLocalServerID_fromELS, messageLSID);
            }
    } else if ( flEmptyResultResponse !== true ) { //if the server's response already has been formed by the function addMessagesIfUserLocationChanged
        return res.resultResponse; //return it as the result
    }
}
//--funcs for bound promises for onLSGetLocalServerID

/*Promise
return an ID of a local server for the user location
return message in the format:
{ 
    locationHash  - user location hash
    localServerID - local server ID
    timestamp
} */
function onLSGetLocalServerID(messageDesc) {
    var userLocation = messageDesc.message;
    var calcLocationHash = userLocation.calcLocationHash; //the hash of the user location, that is calculated according to a coordinates, that are specefied in the message
    
    if (calcLocationHash == null) { //can't calculate hash of the location
        throw new Error("The user location hash is empty");
    } else {
        return addMessagesIfUserLocationChanged(messageDesc, true)
                .bind(userLocation)
                .then(afterAddMessagesIfUserLocationChanged);
    }
}

/*---getLSID (from ELS)
---------------------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------------------
onCalculateHashesUsersLocations (from ILS)---*/

//schemas for responces of onLSGetLocalServerID--
var responseTo_lsCalculateHashesUsersLocations = function() {
    return {
        type: "CSToILS",
        kind: "calculatedHashesUsersLocations",
        body: null
    };
};
//--schemas for responces of onLSGetLocalServerID

//calculate hashes of the users, that are on the handled by the ils locations
function onCalculateHashesUsersLocations(messageDesc) {
    var maintainedUsers = messageDesc.message;
    var calculatedHashes = {}; //the resultof the calculation
    for( var i=0, len = maintainedUsers.length; i < len; i++ ) {
        var userDesc = maintainedUsers[i]; //the user coordinates
        calculatedHashes[userDesc.userID] = encodeLocationHashByCoords(userDesc.lng, userDesc.lat); //calculate the lcoation hash by the coordinates
    }
    return calculatedHashes; //return all the calculated hashes { userID : locationHash }
}

/*---onCalculateHashesUsersLocations (from ILS)
---------------------------------------------------------------------------------------*/



/*---------------------------------------------------------------------------------------
onStopLocationsHandling (from ILS)---*/

//schemas for responces of onStopLocationsHandling--
var schemaResponseTo_stopLocationHandling_fromILS = function(){
    return {
        type: "CSToILS",
        kind: "stopLocationHandling",
        body: null
    };
};
function messageLSStopLocationHandling(locationHash) {
    if ( isArray(locationHash) === false ) {
        locationHash = [locationHash];
    }
    return {
        locations : [locationHash]    
    }; 
}
//--schemas for responces of onStopLocationsHandling


//funcs for bound promises for onStopLocationsHandling--

//if can't remove it from the db, then delete it from the array with locations to remove, wich will be sent to the local server

function onStopLocationsHandling_returnTheResult(results) { //return the locations which can be removed from the maintenance list to the local server
    
    if ( isArray(results) !== true ) { //if an error
        return null;    
    }
    
    //from the context
    var listNewLSForMaintaindLocationsToStopMaintaince = this.listNewLSForRequestedLocationsToStopMaintaince; //id of the users, which were chosed by the current local server for the locations, as the new local servers   
    var maintaindLocationsToStopMaintaince = this.maintaindLocationsToStopMaintaince; //list of the locations, that are really maintained by the ls. This locations will be removed from the db by the cs as maintained by the ls
    var requestedLocationsToStopMaintaince = this.requestedLocationsToStopMaintaince; //list of the requested locations, handling of which can be stopped by the ls
    
    var locationsCanStopped = []; //the list of a locations, that can be stopped, that will be returned to the ls
    var newLSIDForLocations = []; //the list of a new local servers for the locations
    var lenLocationsCanStopped = locationsCanStopped.length;
    
    var len, i;
    for( i = 0, len = maintaindLocationsToStopMaintaince.length; i < len; i++ ) { //for each localtion, that was removed from the db
        if ( results[i] === true ) { //if the new local server was set for the location
            //maintaindLocationsToStopMaintaince[i] - location hash from the list of the locations, ls id of which must had to be removed
            locationsCanStopped[lenLocationsCanStopped] = maintaindLocationsToStopMaintaince[i]; //add to the list of the locations that can be stopped and a local servers for them
            //listNewLSForMaintaindLocationsToStopMaintaince[i] - id from the list of the users, that are chosen as a local servers
            newLSIDForLocations[lenLocationsCanStopped++] = listNewLSForMaintaindLocationsToStopMaintaince[i];
        }
    }
        
    /*
        the resulted locations, that can be stopped is the summ of the requestedLocationsToStopMaintaince with the maintaindLocationsToStopMaintaince
        return the valid id form the db for the locations from the requestedLocationsToStopMaintaince list
        the results of the promises, that returns the valid id from the db are going after the setNewLS promises
    */
    var resultsStartInd = maintaindLocationsToStopMaintaince.length; //the first index number for reading the results of the promises execution
    var validLSID; //ID of the local server for this location from the db
    for( i = 0, len = requestedLocationsToStopMaintaince.length; i < len; i++ ) {
        locationsCanStopped[lenLocationsCanStopped] = requestedLocationsToStopMaintaince[i]; //the next location from the list with locations that maintained by another local servers
        validLSID = results[resultsStartInd + i]; //ID of the local server for this location from the db
        newLSIDForLocations[lenLocationsCanStopped++] = (typeof(validLSID) === "number") ? validLSID : empty_user_id; //return the valid id from the db or set the empty local server for this location
    }
                
    if ( locationsCanStopped.length > 0 ) {
        return {
            locations : locationsCanStopped, //locations, that can be stopped
            newLSID : newLSIDForLocations //a new ls for the locations
        };  
    }
    
}

//after a locations, which are maintained by the ils returned from the db
//maintainedLocationsWithTimestamps = [ empty_user_id or { localServerID, locationHash, timestamp  } ]
function onStopLocationsHandling_afterGetLocationsByLS(validMaintainedLocationsList){
    
    if ( validMaintainedLocationsList instanceof Error
        || isArray(validMaintainedLocationsList) === false ) {
            return null;        
    }
    
    //from the context
    var requestedLocationsList = this.requestedLocationsList; //list of a locations, that are requested to stop maintaince of them
    var newLSList = this.newLSList; //list of an id of athe users, that are chosen by the ils as the new LSs for the locations
    var thisLSID = this.thisLSID; //id of this local server
    var flForce = this.flForce; //maintenance of the locations already was stopped by the ils
    
    //resulted lists
    var requestedLocationsToStopMaintaince = []; //list of the requested locations, handling of which can be stopped by the ls
    var maintaindLocationsToStopMaintaince = []; //list of the locations, that are really maintained by the ls. This locations will be removed from the db by the cs as maintained by the ls
    
    //check the result form the db
    if ( validMaintainedLocationsList.length === 0 ) { //if there is no locations, that are maintained by this local server
        requestedLocationsToStopMaintaince = requestedLocationsList; //return all the requested locations to the user, it can stop maintenance of them all
    
    } else { //if a maintained locations are exists
        
        //options
        var timeSecondsStopLocationMaintaince = ILSSetting.timeSecondsStopLocationMaintaince; //a time between when a location was added for maintenance and the current time, after when it has passed maintenance of a location can be stopped
        var minMaintainedLocations = ILSSetting.minMaintainedLocations; //the minimal number of the location that can be handled by the local server
        
        //globals
        var currTimestamp = getTimestamp();
        var numOfMaintainedLocations = validMaintainedLocationsList.length; //a number of the locations, that are really handled by the local server
        
        if ( numOfMaintainedLocations < minMaintainedLocations ) { //if there is no enough number of the maintained locations
            return null;    
        }
        
        //resulted numbers
        var numLocationsToStopMaintaince = 0; //a number of a locations, maintenance of which will be stopped on the cs side (will be removed from the db)
        var numRequestedLocationsToStopMaintaince = 0; //a number of the locations which allowed to stop and which were requested to stop their maintenance
        
        //resulted list
        var listNewLSForMaintainedLocationsToStopMaintaince = []; //id of the users, which were chosen as the new local servers by the current ls for the requested locations, handling of wich will be stopped
       
        //the resulted list of the locations and id of the local servers, that will be return back to the local server will be formed as the summ of the two lists: requestedLocationsToStopMaintaince and maintaindLocationsToStopMaintaince, id will be gotten from the listNewLSForMaintainedLocationsToStopMaintaince, for a locations from the requestedLocationsToStopMaintaince id of the local server will be empty
        
        var promisesToExecute = [];
        for( var i =0, len = requestedLocationsList.length; i < len; i++ ) { //check if the requested locations are really maintained by the ls
            
            var requestedLocationHash = requestedLocationsList[i]; //location, requested by the ls
            var newLSID = (newLSList[i] == null) ? empty_user_id : newLSList[i]; //id of the user, that was chosen by the local server as the new local server for this requested location
           
            if ( validMaintainedLocationsList.indexOf(requestedLocationHash) === -1 ) { //if the requested location is not really maintained
                //if the location is not really maintained by the ls, do not remove it from the db
                requestedLocationsToStopMaintaince[numRequestedLocationsToStopMaintaince++] = requestedLocationHash; //allow to stop location handling for the local server
                
            } else { //if the requested location is really handled by this local server
                
                maintaindLocationsToStopMaintaince[numLocationsToStopMaintaince] = requestedLocationHash; //remove from the db the current ls
                listNewLSForMaintainedLocationsToStopMaintaince[numLocationsToStopMaintaince++] = newLSID; //and set the new chosen ls
                
                var promiseToDo; 
                
                if ( newLSID === empty_user_id  ) { //if the new ls was not choosen by this ls, then return empty id of the new ls
                    promiseToDo = dbGeoMethods.delLocalServerID(requestedLocationHash, thisLSID); //delete this ls as the handler for this location
                } else { //if the id was chosen by this ls
                    promiseToDo = dbGeoMethods.setLocalServerID(requestedLocationHash, newLSID, thisLSID)//delete the local server for the location from the db
                                                .bind([true, requestedLocationHash, newLSID, true]) //arguments for checkLocalServer 
                                                .then(checkLocalServer); //send ping to the new ls
                }
                
                if ( flForce !== true ) { //if not necessary to send the result for the ls
                    promisesToExecute[promisesToExecute.length] = 
                                                                promiseToDo
                                                                .catch(returnFalse);
                }
            }
        }
        
    }
    
    if ( flForce === true ) { //if not necessary to send the result for the ls
    
        //add to the end of the list promises to get the valid local servers for the locations, that are not handled by this local server
        for( i = 0, len = requestedLocationsToStopMaintaince.length; i < len; i++ ) { //get the local servers for the locations, that have been requested to stop, but really not maintained by this local server
            promisesToExecute[i] = dbGeoMethods.getLocalServerID(requestedLocationsToStopMaintaince[i]);
        }
        
        if ( promisesToExecute.length > 0 ) {
            return Promise.all(promisesToExecute) //after the removing will be ended
                    .bind({
                        maintaindLocationsToStopMaintaince : maintaindLocationsToStopMaintaince,
                        requestedLocationsToStopMaintaince : requestedLocationsToStopMaintaince,
                        listNewLSForRequestedLocationsToStopMaintaince : listNewLSForMaintainedLocationsToStopMaintaince //list with the id of the new local servers for the locations
                    }) //return the resulted lists back to the local server
                    .then(onStopLocationsHandling_returnTheResult);
        } else {
            return null;    
        }
    }
}

//after the ls was removed as the local server for the requested location
function onStopLocationsHandling_RequestedOneLocation(res) {
    if ( res === true ) { //if the ls id for the lcoation was removed
        
        //send the message to the local server to stop the maintaince of the location
        var resp = {
            locations   : [this.locationHash],
            newLSID     : [this.idNewLS]
        };
            
        return resp;
    }
}

//after received an id of the ls for the requested location
function onStopLocationsHandling_afterGetLocalServerID(res){ //res = { localServerID, timestamp} - the timestamp, when the user has became the local server for the location
    
    if ( res === false
        || res instanceof Error ) {
            return null;        
    }
    
    //from the context
    var userID = this.userID; //an id of a ls from which the request has came
    var locationHash = this.locationHash; //hash of the location, that was requested to stop
    var idNewLS = (typeof(this.idNewLS) === "number") ? this.idNewLS : empty_user_id; //id of a client that was chosen by the ils as the new LSs
    var flForce = this.flForce; //stop maintaince by this ILS anyway
    
    var idLSForLocation = res.localServerID; //the right local server for the location
    var currTimestamp = getTimestamp();
    var timeSecondsStopLocationMaintaince = ILSSetting.timeSecondsStopLocationMaintaince; //a time between when a location was added for maintenance and the current time, after when it has passed maintenance of a location can be stopped 
    if ( res != null
        && idLSForLocation === userID //if the id of the local server for the location is equals to the ls, which has requested to stop location maintaince
        && (currTimestamp - res.timestamp) > timeSecondsStopLocationMaintaince ) {  //enough time has passed
            var promiseToDo;
            if ( idNewLS !== empty_user_id ) { //if new user was chosen as ls for this location
                    promiseToDo = 
                        dbGeoMethods.setLocalServerID(locationHash, idNewLS, userID) //delete the local server for the location from the db
                            .bind([true, locationHash, idNewLS, true]) //arguments for checkLocalServer 
                            .then(checkLocalServer) //send ping to the new ls
                            .catch(returnFalse);    
            } else { //if there is no local server was chosen for this location
                promiseToDo = dbGeoMethods.delLocalServerID(locationHash, userID); //delete this local server for the location from the db
            }
            
            if ( flForce !== true ) { //if already stopped on the local server, not necessary for waiting the result of the promise to inform the ls about it
                return promiseToDo //delete a local server for the location from the db
                    .bind(
                        {
                            locationHash : locationHash,
                            idNewLS : idNewLS
                        }
                    )
                    .then(onStopLocationsHandling_RequestedOneLocation);
            } 
    } else 
        if( flForce !== true //if maintenance by the server was not stopped already(if stopped already, then it is not necessary to inform the ls about it)
            && ( res == null //if there is no ls for the location or it is deffer from the local server id, from which this request has come
                || idLSForLocation !== userID ) ) { //the ls can stop maintaince of this location
                    return {
                       locations : [locationHash],
                       newLSID   : [idLSForLocation]
                    };    
    }
}

//--funcs for bound promises for onStopLocationsHandling

/*  the local server have too much locations for maintaince by it
    it sends the message to the central server to stop maintenance of some locations
    to the us send the array with locations, maintenance of which can be stopped    */
function onStopLocationsHandling(messageDesc) {
    var msg = messageDesc.message;
    var requestedLocationsList = msg.listLocations; //locations, handling of which is requested to stop by the local server
    var userID  = messageDesc.userID; //an id of a ls from which this request has came
    if ( requestedLocationsList.length > 1 ) { //if more than one locations ils wants to stop
        return dbGeoMethods.getLocationsByLSCheckID(userID) //get the list with a locations that are maintained by the ils and a timestamps when the locations are added for maintaince by the ls
                .bind({
                    requestedLocationsList : requestedLocationsList,
                    newLSList : msg.listNewLSs,
                    thisLSID  : userID,
                    flForce   : msg.flForce //ILS stop maintaince anyway, independent from the cs 
                })
                .then(onStopLocationsHandling_afterGetLocationsByLS);
    } else { //if the ls wants to stop only a one location
        var locationHash = msg.listLocations[0]; //locations, handling of which is requested to stop by the local server
        return dbGeoMethods.getLocalServerID(locationHash, true) //with the timestamp
                .bind({
                    userID : userID,
                    flForce   : msg.flForce, //ILS stop maintaince anyway, independent from the cs,
                    locationHash : locationHash,
                    idNewLS      : msg.listNewLSs[0] //id of a clients wich are chosen by the ils as the new LSs
                })
                .then(onStopLocationsHandling_afterGetLocalServerID);
    }
}

/*---onStopLocationsHandling (from ILS)
---------------------------------------------------------------------------------------*/



/*---------------------------------------------------------------------------------------
onStopLocationsHandling (from ILS)---*/

//schemas for responces of onStopLocationsHandling--
//send to the ls that it is maintained the requested location
// var schemaResponseTo_isLocationMaintained_fromILS = function() {
//     return {
//         type: "CSToILS",
//         kind: "locationsAreMaintained",
//         body: null
//     };
// };
//--schemas for responces of onStopLocationsHandling

//local server asks if the location is maintained by it
function onIsLocationMaintained(messageDesc) {
    var ilsLocationsHashes = messageDesc.message, //the location, that is maintained by the ils, and that has a formed ping request from the cs
        ilsID = messageDesc.userID; //id of the ls
    if ( ilsLocationsHashes.length > 1 ) { //if there are a several locations to check
        return  dbGeoMethods.getLocationsByLS(ilsID) //check if the location is handled by the ls and return the right ls id
                .bind({
                    ilsLocationsHashes : ilsLocationsHashes,
                    ilsID : ilsID
                })
                .then(onIsLocationMaintained.afterGotLocationsByLS);
        
    } else { //if necessary to check an only one locations
        return  dbGeoMethods.getLocalServerID(ilsLocationsHashes[0]) //check if the location is handled by the ls
                .bind({
                    ilsLocationHash : ilsLocationsHashes[0],
                    ilsID : ilsID
                })
                .then(onIsLocationMaintained.afterGotLSIDForLocation);
    }
}

//funcs for bound promises for onStopLocationsHandling--


//after checking if the locations are maintained by the ils
onIsLocationMaintained.afterGotLocationsByLS = function afterGotLocationsByLS(arrListValidLocations) {
    
    if ( arrListValidLocations === false
        || arrListValidLocations instanceof Error) {
            return null;        
    }
    
    //equals to false if not maintained or the list of a maintained locations
    //arrListValidLocations = [locationHash1..locationHashN]
    //from context
    var requestedILSLocations = this.ilsLocationsHashes; //the incoming list of the requested locations
    var ilsID = this.ilsID;
    
    var listValidFromRequested = []; //the list with the valid locations from the requested list
    var listNotValidFromRequested = []; //the list invalid locations from the requested list
    var validIDs = []; //valid id's of unvalid locations
    var ind1 = 0;
    var ind2 = 0;
    for( var i = 0, len = requestedILSLocations.length; i < len; i++ ) { //for an each of the requested locations
        var requestedLocationHash = requestedILSLocations[i];
        if ( arrListValidLocations.indexOf(requestedLocationHash) !== -1 ) { //if the location is maintained by the ILS
            //listValidFromRequested[ind1++] = requestedLocationHash; //do not send anything if the location is really handled by this local server
        } else { //if the location is not maintained by the ILS
            listNotValidFromRequested[ind2++] = requestedLocationHash;
        }
    }

    if ( listValidFromRequested.length > 0 //if the locations from the requested list are maintained by this ILS
        && listNotValidFromRequested.length === 0 ) { //and there is no locations from the requested that are not maintained by the ils
            //return listValidFromRequested; //return nothing
    } else 
        if ( listNotValidFromRequested.length > 0 ) { //if exists a locations that are not maintained by the ILS
            return dbGeoMethods.getLocalServerID(listNotValidFromRequested, false, true) //get id of a local servers for all invalid locations with unknown ids of a local servers
                    .bind({
                        ilsID : ilsID
                    })
                    .then(onIsLocationMaintained.afterGetLSIDForSeveralLocations);
        }
};

//after checking if the location are maintained by the ils
onIsLocationMaintained.afterGotLSIDForLocation = function afterGotLSIDForLocation(validLSID) { //equals to false if not maintained
    
    if ( validLSID === false
        || validLSID instanceof Error ) {
            return null;    
    }
    
    if ( validLSID !== this.ilsID ) { //if not maintained by the ls and the valid ls id is returned as Array[validLSID]
        return { locations : [this.ilsLocationHash], newLSID : [validLSID]}; //addResponceToRequestDesc(null, schemaResponseTo_stopLocationHandling_fromILS, { locations : [this.ilsLocationHash], newLSID : validLSID}); //send the message that the location maintaince must be stopped with the id of the current local server for the lcoation
    } else { //if the location is maintained by the ls
        return null; //return nothing //[this.ilsLocationHash]; //return the responce that the location is maintained
    }
};

//--funcs for bound promises for onStopLocationsHandling

//when all an id of local servers was gotten
onIsLocationMaintained.afterGetLSIDForSeveralLocations = function afterGetLSIDForSeveralLocations(validIdsOfLSs){ //validIdsOfLSs = [{locationHash, localServerID}]
    
    if ( validIdsOfLSs === false
        || validIdsOfLSs instanceof Error) {
            return null;        
    }
    
    //from the context
    var ilsID = this.ilsID;

    var i, len;
    var listLocationsStop = []; //list with the locations, that must be stopped by the ls
    var listLSForLocationsStop = []; //list with the valid local servers for stopping location
    var resInd = 0;
    for ( i = 0, len = validIdsOfLSs.length; i < len; i++ ) { //give an id of a ls for the locations
        var res = validIdsOfLSs[i];
        var locationHash = res.locationHash;
        if ( res.localServerID === ilsID ) { //if the valid ls ID is equals to this LS
            //listValidFromRequested[listValidFromRequested.length] = locationHash; //add this location to valid list
        } else {
            listLSForLocationsStop[resInd] = res.localServerID;
            listLocationsStop[resInd++] = locationHash; //list with the location, that will not be handled
        }
    }

    return { //send the message that the location maintaince must be stopped with the id of the current local server for the lcoation
        locations: listLocationsStop,
        newLSID : listLSForLocationsStop
    };
};

/*---isLocationMaintained (from ILS)
---------------------------------------------------------------------------------------*/



/*---------------------------------------------------------------------------------------
onNewLocalServers (from ILS)---*/

function schemaResponseTo_onNewLocalServers_fromILS() {
    return {
        type: "CSToILS",
        kind: "validLocalServers", //the valid local servers or local servers that were set for the locations
        body: null
    };
}

/*
    ILS want to set a new local servers for a locations
    message = {
        listLocations = [locationHash] - the locations without LS (by opinion of the ils)
        listNewLSs = [lsIDForLocation] - the chosen ls for this location
    }
*/
function onNewLocalServers(message){
    
    var msg = message.message;
    var locations = msg.listLocations; //list with a locations
    var localServers = msg.listNewLSs; //list with a new local servers ID
    var userID = message.userID; //id of this user
    
    return dbGeoMethods.getLocalServerID(locations, false, true, true) //return the valid local servers for the locations in the format : { locationHash : validLocalServerID }
            .bind({
                locations : locations,
                localServers : localServers,
                userID : userID
            })
            .then(onNewLocalServers_afterLocalServersIDTaken);
}

/*
    when the valid ids were received from the db
    resultsFromDB : { locationHash : validLSID }
*/
function onNewLocalServers_afterLocalServersIDTaken(resultsFromDB){
    
    if ( isEmptyObject(resultsFromDB) === "object" ) { //must be an object with the locations and local servers for it
        return null;        
    }
    
    var locations    = this.locations; //list with a locations requested by ils
    var localServers = this.localServers; //list with a new local servers ID requested by ils
    var userID       = this.userID;
    
    var promisesToDo = []; //array with promises to set id of the ls
    var locationsNewLS = []; //promisesToDo[i] is corresponding to locationsToSetLS[i]
    
    var i, len;
    
    for ( i = 0, len = locations.length; i < len; i++ ) {
        var locationHash = locations[i]; //location hash
        var idFromDB = resultsFromDB[locationHash].localServerID; //the valid is of the local server from the db
        
        if ( idFromDB !== undefined
            && idFromDB !== empty_user_id ) { //if the ls is exists for this location
                localServers[i] = idFromDB; //put it to the list of the valid ls. localServers[i] => locations[i]        
        } else { //set the user from the message as the local server for the location
            locationsNewLS[locationsNewLS.length] = locationHash;
            promisesToDo[promisesToDo.length] = dbGeoMethods.setLocalServerID(locationHash, localServers[i]); //set the id of the local server, received from the ils
        }
        
    }
    
    if ( promisesToDo.length === 0 ) { //if not necessary to set a new ls for any location
        
        var thisLSID = this.userID, //this ls id
            messagesPings = [],
            indPingMessage = 0;
            
        for ( i = 0, len = localServers.length; i < len; i++ ) {
            var lsID = localServers[i];
            if ( lsID === thisLSID ) { //if this local server is becoming the new local server for the location
                messagesPings[indPingMessage++] = messageLSPing(locations[i]); //add ping for this ls
            } 
        }
        
        return {
            locations : locations,
            lsID      : localServers,
            messagesPings : (messagesPings.length > 0) ? messagesPings : undefined //pings messages for this local server
        }; 
        
    } else {
        return Promise
            .all(promisesToDo)
            .bind({
                locations : locations,
                localServers : localServers,
                userID : userID,
                locationsNewLS : locationsNewLS
            })
            .then(onNewLocalServers_afterSetLocalServersID);    
    }
        
}

/*
    resultsFromDB[i] = true/false is local server was set for the location locationsToSetLS[i]
*/
function onNewLocalServers_afterSetLocalServersID(resultsFromDB){
    
    var locationsNewLS = this.locationsNewLS; //locations corrsponding to results of setLocalServerID. locationsToSetLS[i] => results[i]
    var locations = this.locations; //list with a locations requested by ils
    var localServers = this.localServers; //list with a new local servers ID requested by ils
    var thisLSID = this.userID; //this ls id
    var messagesPings = []; //ping messages for this local server, if he becomes the new local server for the location
    var indPingMessage = 0;
    
    var locationHash, i, len;
    if (resultsFromDB instanceof Error) { //if the operation is resulted with an error
        return null;
    } else {
        
        for( i =0, len = resultsFromDB.length; i < len; i++ ) {
            locationHash = locationsNewLS[i]; //ls had to be set for this location. Was set or not can be defined by the value of resultsFromDB[i]
            var ind = locations.indexOf(locationHash); //index into the list "localServers"
            var lsID = localServers[ind]; //local server id from the user request
            if ( resultsFromDB[i] === false ) { //if the ls was not set for the location by any reason
                localServers[ind] = empty_user_id; //set the empty id of the ls for this location, because the new server for this location was not set
            } else { //send ping to the new local server
                if ( lsID === thisLSID ) { //if this local server is becoming the new local server for the location
                    messagesPings[indPingMessage++] = messageLSPing(locationHash); //add ping for this ls
                } else { //if another local server was as the local server for the location
                    checkLocalServer(lsID, locationHash, true); //do not set the ls for location once again
                }
            }
        }
            
    }
    
    return {
        locations : locationsNewLS, //locations hashes
        lsID      : localServers, //valid or empty id of the local servers for the locations. locations[i] => lsID[i]
        messagesPings : (messagesPings.length > 0) ? messagesPings : undefined //pings messages for this local server
    };
    
}

/*---onNewLocalServers (from ILS)
---------------------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------------------
---onOut (main)*/

/*
   when the user has closed the browser window
*/
function onOut(message){
    var userID = message.userID; //id of this user
    dbGeoMethods.clearLocationsByLS(userID); //delete all maintained locations for this local server
}

/*---onOut (main)
---------------------------------------------------------------------------------------*/

var _handlers = {
    "main": {
        [messageKindSetClientServerTimeDifference] : {
            handler: onClientGetTimeUTCDifference,
            schema: "validationIncomingMessage_clientGetTimeUTCDifference",
            response: responseTo_clientGetTimeUTCDifference
        },
        "connected": { //when a new connection with the client established
            handler : onNewConnection,
            schema  : "",
            response: schemaMessage_LSPing 
        },
        "out" : {
            handler : onOut,
            schema  : "vSchemaIncomingMessage_onOut_main"
        }
    },
    "fromELS": {
        "getLSID": {
            handler : onLSGetLocalServerID,
            schema  : "validationIncomingMessage_lsGetLocalServerID_fromELS",
            customFunctionName : "getLocalServerID_fromELS",
            response: schemaResponseTo_lsGetLocalServerID_fromELS
        },
        "chooseAnotherLS": {
            handler: chooseAnotherLS_FromELS,
            schema: "validationIncomingMessage_clientChooseAnotherLS_fromELS",
            customFunctionName : "chooseAnotherLS_fromELS",
            response: responseTo_clientChooseAnotherLS_fromELS
        }
    },
    "fromILS": {
        "getLSID": {
            handler: onLSGetLocalServerID_fromILS,
            schema: "validationIncomingMessage_lsGetLocalServerID_fromILS",
            customFunctionName : "getLocalServerID_fromILS",
            response: responseTo_lsGetLocalServerID_fromILS
        },
        "chooseAnotherLS": {
            handler  : chooseAnotherLS_FromILS,
            schema   : "validationIncomingMessage_clientChooseAnotherLS_fromILS",
            customFunctionName : "chooseAnotherLS_fromILS",
            response : responseTo_clientChooseAnotherLS_fromILS
        },
        "pong": {
            handler: onLSPongResponse,
            schema: "validationIncomingMessage_LSPongResponse",
            response: schemaResponseTo_stopLocationHandling_fromILS //if not maintained, then stop location handling
        },
        "calculateHashesUsersLocations" : {
            handler : onCalculateHashesUsersLocations,
            schema  : "validationIncomingMessage_lsCalculateHashesUsersLocations",
            response: responseTo_lsCalculateHashesUsersLocations
        },
        "stopLocationsHandling" : {
            handler : onStopLocationsHandling,
            schema  : "validationIncomingMessage_lsStopLocationHandling_fromILS",
            response: schemaResponseTo_stopLocationHandling_fromILS
        },
        "isLocationMaintained": {
            handler : onIsLocationMaintained,
            schema  : "validationIncomingMessage_lsIsLocationMaintained_fromILS", //same as pong respoce
            response: schemaResponseTo_stopLocationHandling_fromILS // - may be only the one message type - stop location handling. schemaResponseTo_isLocationMaintained_fromILS 
        },
        "newLocalServers": {
            handler : onNewLocalServers,
            schema  : "validationIncomingMessage_newLocalServers_fromILS",
            response: schemaResponseTo_onNewLocalServers_fromILS 
        }
    }
};

//functions, that returns a schema for a messages to a clients
var schemasResponses = {
    schemaMessage_LSStopLocationHandling   : schemaResponseTo_stopLocationHandling_fromILS,
    schemaMessage_LSPing                   : schemaMessage_LSPing
};

//creates a messages for a clients
var messagesMakers = {
    messageLSStopLocationHandling : messageLSStopLocationHandling,
    messageLSPing : messageLSPing,
    checkLocalServer : checkLocalServer,
    stopLocationHandling : stopLocationHandling
};

var thisModuleProperties = {
    handlers : _handlers,
    sendMessageToClient : sendMessageToClient,
    schemasResponses : schemasResponses,
    messagesMakers   : messagesMakers,
    addResponceToRequestDesc : addResponceToRequestDesc
};

var thisModule = Object.create(eEmitter);
extend(thisModule, thisModuleProperties);
//emitted events
//sendMessage(messageDesc) - send a message to a client
//messageDesc = { 
//userID - user ID
//responseSchema - main schema of the response
//serverResponse - body of the message
//}
//checkNewLocalServer(lsID, locationHash, msgClientBecomeLocalServer, timestampWhenTheUserBecomeLocalServer) - ned to check the new local server

module.exports = thisModule;