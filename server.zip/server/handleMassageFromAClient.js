"use strict";
var extend = require("extend"), //npm install extend
    handlersByMessageTypeAndKind = require("./messagesHandlers.js"),  //list of handlers for messages from client
    Promise = require("bluebird"),
    common = require("./common.js"),
    messagesHandlers = handlersByMessageTypeAndKind.handlers,
    getTimestamp = require("./getTimestamp.js"),
    util = require("util"),
    log = require("./logger.js").loggerMsg(__filename),
    customValidationFunctions = require("./customValidationFunctions.js"),
    validatorsForMessages = require("./validatorsForMessages.js"),
    apsSettings = require("./settings/settings.js"),
    messagesSettings = apsSettings.messagesSettings;

//settings
var empty_user_id = messagesSettings.empty_user_id; //the value, that is representation of an empty id of the user
var flUseWorkers = apsSettings.useWorkers;

//options
var messageMainSchema = validatorsForMessages.validationIncomingMessage_mainMessageStructure, //validation schema that describes the common  messages structure
    gServerAllowedMessageTypes = messagesSettings.gServerAllowedMessageTypes,
    timestampSecondsDifferenceOverdueIncomingMessages = messagesSettings.timestampSecondsDifferenceOverdueIncomingMessages,
    messagesKindsWithoutTimestamp = [messagesSettings.messageKindSetClientServerTimeDifference.trim(), messagesSettings.messageKindSendPingForAllLocations.trim(), messagesSettings.messageKindBrowserClosed.trim()]; //kinds of the messages for which not necesary to check it's timestamp

//often used functions
var _hasProperty = common.hasProperty;
var getCopyOfVal = common.getCopyOfVal;
//listeners-

//emit an event to send the message by the gServer to the client
function onSendMessage(arg) {
    try {
        sendMessageToClient(arg);
    } catch(e) {
       onError(e); //while an error has occurred
    }
}

handlersByMessageTypeAndKind.on("sendMessage", onSendMessage);

//-listeners

//MAIN

//Promise
//validate and sanitize a message by a schema
//messageDesc = { 
//	handler = handler function for the message
//	schema  = schema of the message
//	responseSchema = schema of the server response to the client request
//	message  = message from the user
//	userID  = user ID
//}
//return true or false if not valid
function validateAndSanitize(msgDesc) {
    var message = msgDesc.message,
        schema;
    if ( msgDesc.schema !== "" ) {
        schema = validatorsForMessages[msgDesc.schema];
    }
    if ( schema !== undefined
        && schema( message ) === false ) { //wait until checking of the message will not be completed
            log(schema.errors);
            onError(new Error("The message is not valid")); //the message is not valid
            return false;
    } else { //the message is valid
        var funcName = msgDesc.customValidationFunction; //name of the customm function necessary to call for validating the message
        if ( funcName != null
            && common.hasProperty(customValidationFunctions, funcName) === true ) {
                var validationResult = customValidationFunctions[funcName]( message, msgDesc, msgDesc.userID ); //message - inspected object and msgDesc - object that must be returned if success validation
                if ( ( validationResult instanceof Promise ) === true ) { //if a validation result is a promise
                    return validationResult
                            .then(performHandler) //execute the handler, but after execution of the custom function
                            .catch(onError);
                } else if ( validationResult instanceof Error === true ) { //if an errors
                    return validationResult;
                }
        }
        performHandler(msgDesc); //execute the handler for the message
    }
}

//determine handler function by the kind of a message
//return object = { 
//	handler = handler function for the message
//	schema  = schema of the message
//	responseSchema = schema of the server response to the client request
//	message  = message from the user
//	userID  = user ID
//}
function formMessageDescription(message, userID) {
    if ( message.hasOwnProperty("type") === true ) {
        var msgType = (message.type + "").trim(); //determine the type of the message
        if (msgType != ""
            && common.hasProperty(messagesHandlers, msgType) === true) {  //if a handler for the kind is exists
            var handlersByMessageKind = messagesHandlers[msgType];
            if (message.hasOwnProperty("kind") === true) {
                var msgKind = (message.kind + "").trim(); //determine the kind of the message
                if (msgKind != ""
                    && handlersByMessageKind.hasOwnProperty(msgKind) === true) {  //if a handler for the kind is exists
                        log("Incoming message with type = " + msgType + " and kind = " + msgKind);
                        var handlerDesc = handlersByMessageKind[msgKind];
                        var handler = handlerDesc.handler;
                        if (typeof(handler) !== "function") {
                            return new Error("The handler for the message kind '" + msgKind + "' is not a function");
                        }
                        return {
                            handler: handler, //handler for the message
                            schema: handlerDesc.schema, //name of the function to validate the message
                            customValidationFunction : handlerDesc.customFunctionName, //name of the fcustom function to call for the message body to validate it
                            responseSchema: handlerDesc.response, //schema of the server response to the client request
                            message: message.body, //for the next handling only the body of the message is necessary
                            messageType : message.type, //type of the message
                            uniqueID : message.uniqueID, //the unique id of the incoming message
                            propertiesToCopy : handlerDesc.propertiesToCopy, // a properties of the body, that are must be copied to the new properties of the message's body
                            userID : userID //id of the client
                        };
                } else {
                    return new Error("There is no handler function for the message kind: " + msgKind);
                }
            } else {
                return new Error("There is no message kind");
            }
        } else {
            return new Error("Unknown message type" + msgType);
        }
    } else {
        return new Error("There is no message type");
    }
}


/*
    call the handler function and put the result from it to the descMessage, if it is not empty 
    return descMessage with the new property serverResponse
    flPromiseContext - executed under Promise context
*/
function performHandler(descMessage) {
    var respMsg;
    try {
        respMsg = descMessage.handler( descMessage.propertiesToCopy != null ? copyMesageBodyProperties(descMessage) : descMessage); //call handler and get the result from it
    } catch(e) {
        onError(e);
        return e;
    }

    if ( respMsg != null ) { //if the result is not empty
        if ( respMsg instanceof Promise ) { //handler function return a promise
             return respMsg
                    .bind(descMessage)
                    .then(afterPromiseHandlerExecuted)
                    .bind(descMessage)
                    .then(sendMessageToClient)
                    .catch(onError);
        } else if ( respMsg instanceof Error === true ) { //if the result is an error
            return onError(respMsg);
        } else {
            sendMessageToClient(afterPromiseHandlerExecuted(respMsg, descMessage)); //form the message description with the result from the handler and send message to the user
        }
    }
}

//main shema of a server response to a cliet request
var mainSchemaMessageFromServerToClient = function(){
    return {
        _flFromCS: true,
        _flSeveralMessages: false,
        type: null,
        kind: null,
        body: null
    };
};
//main shema of a server response to a cliet request
var mainSchemaMessageFromServerToClient_severalResponses = function(){
    return {
        _flFromCS: true,
        _flSeveralMessages: true,
        _messages: []
    };
};

/*
    form a message to a client:
    descMessage = { 
    	handler = handler function for the message
    	schema  = schema of the message
    	responseSchema = schema of the server response to the client request
    	message  = message from the user
    	userID  = user ID,
    	serverResponse = server response,
      				 if there are several responses need to be sent to the client, than serverResponse = { _several: true, _responses:[{response:response1, responseSchema:responseSchema1},...,{response:responseN, responseSchema:responseSchemaN}] }
    }
    return {
    		message = message for a client,
          userID  = user ID
    }
    , or null if no need for sending a message 
    if flPromiseContext === true, then the function is executing with a promise wrapping
*/

var typeMapping = { //mapping of the messages types from the server and the client
    "CSToILS" : "fromILS",  //server type : corresponding client type  
    "CSToELS" : "fromELS"
};

function formMessageForClient(descMessage) {

    if (descMessage == null //empty message
        || common.isEmptyObject(descMessage) === true
        || common.isEmptyObject(descMessage.serverResponse) === true) { //empty server responce
            return null;
    }
    
    if ( descMessage instanceof Error ) {
        return onError(descMessage);    
    }
        
    var serverResponse = descMessage.serverResponse;
    var resMessage;
    var uniqueID = descMessage.uniqueID;
    var messageClientType = descMessage.messageType; //message has came from this type instance
    var correspondingMessageClientType; //type of the outcoming server message, that corresponded to the incoming message's type 
    if (serverResponse._several === true) { //if needed to send a several responses
        resMessage = mainSchemaMessageFromServerToClient_severalResponses();
        var responsesKeys = Object.keys(serverResponse._responses);
        for (var i=0, len = responsesKeys.length; i < len; i++) {
            var resID = responsesKeys[i],
                responseDesc = serverResponse._responses[resID],
                thisServerResponse = responseDesc.response,
                thisResponseSchema = responseDesc.responseSchema;
            if (common.isEmptyObject(thisServerResponse) === true) { //the response is absent
                continue;
            }
            var responseToSend  = thisResponseSchema(); //base schema for the message is the schema
            responseToSend.body = thisServerResponse; //the given response become the body of the one of the messages
            if ( uniqueID != null ) { //put the unique id of the client request to the server response
                
                correspondingMessageClientType = typeMapping[responseToSend.type];
                if ( correspondingMessageClientType === messageClientType ) { //if the outcoming message's type equals to the incoming message type
                    responseToSend.uniqueID = uniqueID;  //insert the unique ID  
                }
                
            }
            responseToSend.timestamp = getTimestamp();
            resMessage["_messages"].push(responseToSend); //put one of the messages to the resulting message
        }
    } else { //if it is necessary to send the one response
        if (typeof(descMessage.responseSchema) !== "function") {
            return onError("The server response without a schema " + serverResponse);
        }
    
        resMessage = mainSchemaMessageFromServerToClient();
        extend(resMessage, descMessage.responseSchema()); //extend the main response message by the given(formed by a message handler function) response message
        
        if ( uniqueID != null ) { //put the unique id of the client request to the server response
            
            correspondingMessageClientType = typeMapping[resMessage.type];
            if ( correspondingMessageClientType === messageClientType ) { //if the outcoming message's type equals to the incoming message type
                resMessage.uniqueID = uniqueID;  //insert the unique ID  
            }
            
        }
        
        resMessage.body = serverResponse; //put the body into the message
        resMessage.timestamp = getTimestamp();
    }
    
    return {
        message : resMessage,
        userID  : descMessage.userID
    }; //message for the client
    
}

/*
    send a message to a client
    messageDesc = { message, userID }
    if flPromiseContext === true, then the function is executing with a promise wrapping
*/
function sendMessageToClient(messageDesc) {
    
    var descMessage = formMessageForClient(messageDesc);
    
    if ( descMessage == null
        || descMessage instanceof Error ) {
            return null;    
    } else {
        if ( common.isEmptyObject(descMessage) === false
            && typeof(descMessage.userID) === "number"
            && common.isEmptyObject(descMessage.message) === false ) { //is an empty message
                //combine user id and the stringified message to the one string and send it to the main process of gServer                
                if ( flUseWorkers === true ) {
                    process.send(common.getFStr(descMessage.userID, 9) + JSON.stringify(descMessage.message)); //the first 9 characters contain user id, the string before this is the stringified message
                } else {
                    thisModule.emit("message", common.getFStr(descMessage.userID, 9) + JSON.stringify(descMessage.message));    
                }
        }
    }
}

//log and return an error or throw exceprion if flPromiseContext == true
function onError(_err) {
    if ( _err instanceof Error === false ) {
        _err = new Error(util.inspect(_err));    
    }
    log(_err); //log an error
    return _err;
}

/*
    handle the incoming message
    incomingMsg is a JSON string "{ type, kind, body }"
    or a plain object { userID, type, body : { type, kind, body } }
*/
var EMPTY_OBJECT = {}.__proto__;
function handleMessage(incomingMsg) {
    var userID,
        message,
        messageBody;
    
    if ( typeof(incomingMsg) === "string" ) { //if necessary to parse a JSON string
        try {
            userID  = common.strToInt(incomingMsg.substr(0,9)); //user id from the message
            message = JSON.parse(incomingMsg.substr(9)); //try to parse the message
        } catch(e) {
            onError(e);
            return;
        }
    
    } else if ( typeof(incomingMsg) === "object" ) { //if object is given as the message description
        message = incomingMsg;
        userID = incomingMsg.userID;
        delete incomingMsg.userID; //delete unnecessary property from the object
    }

    if (typeof(userID) !== "number"
        || userID === empty_user_id ) { //user id
            onError(new Error("Wrong message"));
            return;
    }

    if (typeof(message.type) === "string"
        && gServerAllowedMessageTypes.indexOf(message.type) !== -1 //if a message for the gserver
        && messageMainSchema(message) !== false) {  //the message is valid

            messageBody = message.body;
            if ( messagesKindsWithoutTimestamp.indexOf(messageBody.kind) === -1 ) { //if not message without the timestamp
                //check if the message is not overdue
                var currTimestamp = getTimestamp();
                var msgTimestamp  = message.timestamp;
                var diff = currTimestamp - msgTimestamp;
                if ( diff < 0 ) { //if the timestamp of the message is bigger than the current timestamp
                    if ( diff < -10 ) { //difference is more then 10 seconds
                        onError(new Error("The timestamp of the message is larger than the current timestamp"));
                    }
                } else if ( diff > timestampSecondsDifferenceOverdueIncomingMessages ) { //differense is more than the setting value
                    onError(new Error("The message has been overdue"));
                    return;
                }
            }

    } else {
        onError(messageMainSchema.errors);
        return;
    }
    
    var msgDesc = formMessageDescription(messageBody, userID);
    if ( msgDesc instanceof Error ) {
        onError(msgDesc);
    } else {
        try { 
            var res = validateAndSanitize(msgDesc);
            if ( res instanceof Error ) {
                onError(res);    
            }
        } catch(e) {
            console.log(e.stack);
            onError(e);
        }
    }

}

//copy some of annincoming message properties if it is necessary
function copyMesageBodyProperties(msgDesc){
    if ( msgDesc.propertiesToCopy != null ) { //if it is necessary to copy some properties to the new properties with a given names
        var propertiesToCopy = msgDesc.propertiesToCopy;
        var message = msgDesc.message;
        var listPropertiesNamesToCopy = Object.keys(propertiesToCopy);
        for ( var i =0, len = listPropertiesNamesToCopy.length; i < len; i++ ) {
            var propertyName = listPropertiesNamesToCopy[i]; //copy from
            var newPropertyName = propertiesToCopy[propertyName]; //copy to this property name
            if ( _hasProperty(message, propertyName) === true ) {
                message[newPropertyName] = getCopyOfVal(message[propertyName]); //copy the value to the new property of the message
            }
        }
    }
    return msgDesc;
}

/*
    after handler, that returns a Promise, will be executed
    messageDescription may be null, then this must be the message description
*/
function afterPromiseHandlerExecuted(result, messageDescription){
    var msgDesc = (messageDescription === undefined) ? this : messageDescription;
    if ( result instanceof Error === true ) {
        onError(result)
        return null;    
    }
    if ( result == null ) {
        return null;
    } else {
        msgDesc.serverResponse = result; //put the result of handler to the message description
        return msgDesc;
    }
}

if ( flUseWorkers === true ) { //use Workers for messages handling
    process.on("message", handleMessage);
    process.on('uncaughtException',function(err){
        log(err);
    });
} else {
    var events = require("events");
    var ee = new events.EventEmitter();
    ee.handleMessage = handleMessage;
    var thisModule = module.exports = ee;
}