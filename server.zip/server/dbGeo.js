//global modules
var path = require("path"),
    getTimestamp = require("./getTimestamp.js"),
    PipeCommander = require("myPipeCommander"), //redisClient = require("./startRedisConnection.js"),
    commonGEO = require("./commonGeoFunctions.js"),
    Promise = require("bluebird"),
    hashes = require("./hashes.js"),
    commonF = require("./common.js"),
    appSettings = require(path.resolve(__dirname,"settings/settings.js")),
    _log = require("./logger.js").loggerDb(__filename);

//settings for this module
var empty_user_id = appSettings.messagesSettings.empty_user_id; //the value, that is representation of an empty id of the user
var moduleSettings = appSettings.dbGeoModule;

//start redis client with automatically pipelining and distribution
var settingsRedis = appSettings.redisDB;
var optionsPipelineCommander = {
    redisNodesSettings : settingsRedis.redisNodes, //host and port of a redis nodes
    ioRedisOptions : settingsRedis.optionsIORedis, //specified by the ioredis library    
    options : settingsRedis.optionsPipelineCommander //especially for the PipelineCommander library
};
var redisClient = new PipeCommander(optionsPipelineCommander); //use as redisClient.commandName.then(afterResult)

//list with lua scripts to load
var luaScripts = []; //[scriptName1, script1....scriptNameN, scriptN]
//load lua script to the redis cache
redisClient.start //after the redis has started
        .then(function(redisClient){
            "use strict";
            for( let i = 0, len = luaScripts.length; i < len; i++ ) { //for each script that was defined
                redisClient.scriptLoad(luaScripts[i], luaScripts[++i]) //load it to the redis
                    .then(function(res){
                        if ( res !== true ) { //if an error
                            _log("Can't load script called " + luaScripts[i]);    
                        }    
                    });
            }    
        });

//hashes
var calculateNearestLHFByLocationHashOrLHF = hashes.calculateNearestLHFByLocationHashOrLHF; //return an array with the nearest locations in the client format by the location hash in any(client or server) format
var encodeArrayLocationHashes = hashes.encodeArrayLocationHashes; //encode an array with a location hashes

//common functions
var _toInt   = commonF.strToInt;
var _toStr   = commonF.numToStr;
var _isArray = commonF.isArray;
var _checkInteger = commonF.checkInteger;
var callFunctionWithArguments = commonF.callFunctionWithArguments;
var resolvedPromiseTrue  = commonF.resolvedPromiseTrue; //Promise, resolved with true value
var resolvedPromiseFalse = commonF.resolvedPromiseFalse; //Promise, resolved with false value
var returnFalse          = commonF.returnFalse;  //the function that always returns false

//check if a value is an integer and not empty user id or throw an error
function checkInteger(val) {
    var _val = _checkInteger(val);
    if ( _val === empty_user_id ) {
        return NaN;    
    } else {
        return _val;    
    }
    
    return _val;
}
  
/*
    return the time to live for a single handled location and for the location into the list of a handled locations
    flShortTTL - short or locng location
    return [ 0: ttl, 1:  ];
*/
var getTTL = (function notBound_getTTL(flShortTTL) {
    var ttl = ((flShortTTL === true) ? this.ttlLocalServerBeforePong : this.ttlLocalServer); //time to live for the one location
    return [ttl, (hashes.getTimestampHash( getTimestamp() - this.ttlLocalServer  + ttl ))];    
}).bind(moduleSettings);
  
/////////////////////////////////////////////////  deleteKeyFromDB--
  
 /*
    do the redis command with the given arguments. Make several attempts if failed
    return:
        1) if flReturnResult != true, true or false if some errors has occurred within the command execution
        2) if flReturnResult == true, then return the result not just true or false
 */
function doCommand( commandName, args, flReturnResult ) {
    
    var flResultIsError = commandName instanceof Error; //if the result is an Error
    
    if ( this != global //if commandName is the result of the previous execution
        && this.commandName !== undefined ) {
            return (this.flReturnResult === true) ? commandName : true; //return the result of the operation or true
    }
    
    if ( commandName === undefined //the key is not defined
        || flResultIsError === true ) { //or error while del
            if ( this.commandName === undefined ) { //not defined in the context
                return true;    
            } else {
                commandName = this.commandName; //get all from the context
                args = this.args;
                if ( this.attempts === undefined ) {
                    this.attempts = 1;    
                } else if ( this.attempts++ > 4 ) { //too much attempts were failed
                    _log(commandName);
                    return false; //try to expire with 0 ttl    
                }    
            }  
    }
    
    return callFunctionWithArguments(redisClient, commandName, args) //apply the given arguments to the redis client method(command) 
            .bind( this.commandName !== undefined ? this : {commandName : commandName, args : args, flReturnResult : flReturnResult, attempts : this.attempts === undefined ? 0 : this.attempts}) //bind to the existing context or create the new context
            .then(doCommand, doCommand);
}

/////////////////////////////////////////////////  --deleteKeyFromDB


///////////////////////////////////////////////// setExp --
/*
    set the expiration time for the local server of the location
*/

/*
    check the user for the location 
*/
luaScripts.push("setTTLForLS");
luaScripts.push("local res = redis.call('GET', KEYS[1]) \
                 if type(res) ~= 'string' or (res == '" + empty_user_id + "') then \
                    return 0 \
                 end \
                 local validID = string.sub(res, 1, string.len(res) - 7) \
                 if validID == ARGV[1] then \
                    return redis.call('EXPIRE', KEYS[1], ARGV[2]) \
                 else \
                    return 0 \
                 end");

/*
    update the time to life for the location and the list of the local server locations, that handled by the local server
    return 1 if all is ok or 0
    if locationHash is an Array, then return array with the results for each of the locations in order they were given
    if flShortTTL === true, then set ttl === ttlLocalServerBeforePong for the key
    if flSetTTLForAllList === true, then it is necessary to set ttl for the local server key
*/
var setExpLocalServerLocation = (function notBound_setExpLocalServerLocation(localServerID, locationHash, flShortTTL, flSetTTLForAllList) {
    
    var promiseToDo;
    var lsKey = hashes.getKeyOfUserIDForDb(localServerID); //key for the list of locations, handled by the ls
    
    var resTTL = getTTL(flShortTTL); //get time to live for ls and for location ino the list of the handled locations
    var timestampForLocations = resTTL[1];  //calculate the timestamp for the location, that defines, that the location will be expired after the "ttl" seconds after the current timestamp  
    locationHash = (typeof(locationHash) !== "number" && locationHash.length === 1) ? locationHash[0] : locationHash; //check if the given array size is only the one location
    
    if ( typeof(locationHash) === "number" ) { //if only a one location
        if ( flSetTTLForAllList === true ) {
            promiseToDo = redisClient.multi(
                lsKey,
                [
                    ["expire", lsKey, resTTL[0]],   
                    ["hset", lsKey, locationHash, timestampForLocations]    
                ]
            );        
        } else {
            promiseToDo = doCommand("hset", [lsKey, locationHash, timestampForLocations]);    
        }
    } else { //if there are several locations
        var params;
        var ind; //the current index into the params for hmset operation
        if ( flSetTTLForAllList === true ) {
            params = ["hmset", lsKey]; //params for multi operation
            ind = 2;    
        } else {
            params = [lsKey]; //params for hmset
            ind = 1;
        }
        for( var i = 0, len = locationHash.length; i < len; i++ ) {
            params[ind++] = locationHash[i]; //get one location from the given list
            params[ind++] = timestampForLocations; 
        }
        if ( flSetTTLForAllList === true ) {
            promiseToDo = redisClient.multi(
                lsKey,
                [
                    ["expire", lsKey, resTTL[0]],
                    params   
                ]
            );
        } else {
            promiseToDo = doCommand("hmset", params); //set the ttl for several locations 
        }
    }
    
    //set the expiration for the list of the locations, that are handled by the local server
    return promiseToDo
            .bind(
                {
                    localServerID : localServerID,
                    locationHash : locationHash,
                    ttl : resTTL[0]
                }    
            )
            .then(setExpLocalServerLocation_afterTTLForList);
    
}).bind(moduleSettings);

//after the expiration time was set for the list of the handled locations
function setExpLocalServerLocation_afterTTLForList(res){
    if (( _isArray(res) === true && res[0] === 1 ) //result for multi operation
            || res === true //result for a one location
            || res === "OK" ) { //if the previous operation was done without an errors
            
            var argsForScript = [this.localServerID, this.ttl];
            
            if ( typeof(this.locationHash) === "number" ) { //if only the one location
                return redisClient.scriptExec("setTTLForLS", this.locationHash, argsForScript);
            } else { //if there is a number of locations
                var promisesToDo = []; //promises for each of the locations
                for ( var i =0 , len = this.locationHash.length; i < len; i++ ) { //do the operation for each of the locations
                    promisesToDo[i] = redisClient.scriptExec("setTTLForLS", this.locationHash[i], argsForScript);
                }
                return Promise.all(promisesToDo);
            }
        
    } else {
        return 0;    
    }
}

///////////////////////////////////////////////// --setExp
 
    
/////////////////////////////////////////////////

/*
    get a local server ID for a location hash
    return local server ID
    if flTimestamp = true and/or flLocationHash = true  return { localServerID, timestamp, locationHash }
    locationHash may be an array then return [ { localServerID, timestamp, locationHash } ]
    if id is empty return the value from empty_user_id setting
    if flResultIndexesMustBeLocationsHashes = true, then result must be in the format: result[flResultIndexesMustBeLocationsHashes] = { localServerID, timestamp }
*/
var getLocalServerID = (function _getLocalServerID(locationHash, flTimestamp, flLocationHash, flResultIndexesMustBeLocationsHashes) {
    
    var resultedPromise; //if requested only the one location
    var _locationHash;
    var flOnlyOneLocation = ( _isArray(locationHash) === false ); //if only one location is requeted
    if ( flOnlyOneLocation === false ) {
        var promisesToDo = []; //array of a promises to do
        for( var i = 0, len = locationHash.length; i < len; i++ ) {
            _locationHash = locationHash[i] =  checkInteger(locationHash[i]);
    
            if ( isNaN(_locationHash) === true 
                || _locationHash === 0 ) {
                    return resolvedPromiseFalse; //return Promise with the false result
            }
            
            promisesToDo[i] = redisClient.get(locationHash[i]); //get id for the several given locations
        }
        resultedPromise = Promise.all(promisesToDo);    
    } else {
        _locationHash = checkInteger(locationHash);
        
        if ( isNaN(_locationHash) === true 
            || _locationHash === 0 ) {
                return resolvedPromiseFalse; //return Promise with the false result
        }
        
        resultedPromise = redisClient.get(locationHash); //get user ID, which is the local server for the location with the hash = locationHash    
    }
    return resultedPromise
            .bind(
                (flTimestamp === true || flLocationHash === true || flResultIndexesMustBeLocationsHashes === true) //if one of the condition flags is set
                    ?   {
                            flTimestamp     : flTimestamp,
                            flLocationHash  : flLocationHash,
                            flResultIndexesMustBeLocationsHashes : flResultIndexesMustBeLocationsHashes,
                            locationHash    : locationHash
                        }
                    :   null
            )
            .then(
                getLocalServerID.afterGetLocalServerID, //after get id for all the given locations
                returnFalse //if error
            );

}).bind(moduleSettings);

//when an id for the location of the ls was got
getLocalServerID.afterGetLocalServerID = function (localServersIDWithTimestamp) {
    
    //this = object { [flTimestamp, flLocationHash, locationHash] }
    var flEmptyContext = (this === global); //if the contet is global and empty
    var flOnlyOneLocation =  (_isArray(this.locationHash) === false); //requested only the one location

    var lsIDsWithTimestamp, i, len,
        resultToReturn = [], //array with the result for each given location hash
        locationsHashes = this.locationHash; //given locations hashes
    if ( flEmptyContext === true ) { //if there is no any conditions
        if ( _isArray(localServersIDWithTimestamp) === true ) { //if there is a several locations in the result
            for( i = 0, len = localServersIDWithTimestamp.length; i < len; i++ ) { //convert the empty values to the numbers
                resultToReturn[i] = typeof(localServersIDWithTimestamp[i]) === "string" ? hashes.getTimestampAndUserIDByHash(localServersIDWithTimestamp[i]).userID : empty_user_id;
            }    
        } 
        else { //if there is only a one location
            resultToReturn = typeof(localServersIDWithTimestamp) === "string" ? hashes.getTimestampAndUserIDByHash(localServersIDWithTimestamp).userID : empty_user_id;    
        }
    }
    else 
        if ( flOnlyOneLocation === true ) { //if it is necessary to return the result only for the one location
            return (getLocalServerID.formTheResultForLocationHash( resultToReturn, locationsHashes, localServersIDWithTimestamp, this ))[0];
        } 
        else {
    
            if ( localServersIDWithTimestamp != null 
                && localServersIDWithTimestamp !== empty_user_id ) { //if the local server for the location is exists
                    
                    if (_isArray(localServersIDWithTimestamp) === true) {
                        lsIDsWithTimestamp = localServersIDWithTimestamp;
                    } else {
                        lsIDsWithTimestamp = [localServersIDWithTimestamp];
                    }
                    
                    for( i = 0, len = lsIDsWithTimestamp.length; i < len; i++ ) { //for each location
                        getLocalServerID.formTheResultForLocationHash( resultToReturn, locationsHashes[i], lsIDsWithTimestamp[i], this);
                    }
            } else { //if the result is null
                for( i = 0, len = locationsHashes.length; i < len; i++ ) { //for each location
                    getLocalServerID.formTheResultForLocationHash( resultToReturn, locationsHashes[i] , null, this);
                } 
            }
            
        }
        
    return resultToReturn;
 
};

/*
  forms the result only for the one location hash
  locationHash - location hash or null
  lsIDWithTimestamp - result(ls ID and timestamp from the db) for the location hash
  conditions - conditions, that are determine the format of the result (or null if there is no conditions)
*/
getLocalServerID.formTheResultForLocationHash = function(resultedObject, locationHash, lsIDWithTimestamp, conditions){
    var resultToReturn = resultedObject,
        result;
    var flResultIsNULL = (lsIDWithTimestamp == null) || (lsIDWithTimestamp === empty_user_id); //the result is empty
    
    lsIDWithTimestamp = (flResultIsNULL === true) ? null : hashes.getTimestampAndUserIDByHash(lsIDWithTimestamp);
    
    if ( conditions !== global ) { //the flag shows if it is necessary or not necessary to return timestamp(when the local server began maintenance of the location) with a local server ID
        result = {localServerID : (flResultIsNULL === true || isNaN(lsIDWithTimestamp.userID) === true) ? empty_user_id : lsIDWithTimestamp.userID};
        if ( conditions.flTimestamp === true ) {
            result.timestamp = (flResultIsNULL === true) ? null : lsIDWithTimestamp.timestamp; //the timestamp, when the user has became the local server for the location
        }
        if ( conditions.flLocationHash === true ) { //it is necessary to return the location hash
            result.locationHash = locationHash;
        }
        if ( _isArray(this.locationHash) === false //if only the one location is requested
            && conditions.flResultIndexesMustBeLocationsHashes === false ) { //and it is not necessary to return the requested location hash as the index of the result
                resultToReturn = result;    
        } else {
            resultedObject[ conditions.flResultIndexesMustBeLocationsHashes === true ? locationHash : resultedObject.length ] = result; //put to the result with the following index or under the location hash as the index
        }
    } else { //if requested only id of the local server for the one location
        resultToReturn = (flResultIsNULL === true || isNaN(lsIDWithTimestamp.userID) === true) ? empty_user_id : lsIDWithTimestamp.userID;
    } 
    return resultToReturn;
};

////////////////////////////////////////////

/*
    set the new LS instead of the previous for the location
    keys -: 1) location hash
    arguments : 
        1) id of the new LS
        2) time to live for the new ls
        3) id of the previous LS
*/
luaScripts.push("setLS");
luaScripts.push("local res = redis.call('GET', KEYS[1]) \
                 if type(res) ~= 'string' or (res == '" + empty_user_id + "') then \
                    return redis.call('SET', KEYS[1], ARGV[1], 'EX', ARGV[2]) \
                 end \
                 local validID = string.sub(res, 1, string.len(res) - 7) \
                 if table.getn(ARGV) == 2 or ( table.getn(ARGV) == 3 and ARGV[3] == validID ) then \
                    return redis.call('SET', KEYS[1], ARGV[1], 'EX', ARGV[2]) \
                 else \
                    return 0 \
                 end");

/*
    set a local server ID for a location hash
    throw an error if something wrong or return an Error if a local server is already exists for the lcoation
    flLongTTL = true, then the long ttl must be used for the handled location
    
    arguments can be passed through the context:
        context = array[
            0 : false/aother value - check or not the result of the previous command. If false, then do not check, if another value, then arguments[0] must be equal to this value, othervise this function will not be executed
            1 => locationHash
            2 => localServerID
            3 => flLongTTL
            4 => previousLSID
            5 => attempts
        ]
    
*/
var setLocalServerID = (function _setLocalServerID(locationHash, localServerID, flLongTTL, previousLSID, attempts) {
    
    if ( arguments.length < 2
        && this.locationHash !== undefined ) { //get the arguments from the context
           
            if ( this[0] !== false
                && this[0] !== arguments[0] ) { //if necessary to check the result of the previous operation
                    return false; //if the result of the previous operation not equals to the necessary   
            }
           
           locationHash = this[1]; 
           localServerID = this[2];
           flLongTTL = this[3];
           previousLSID = this[4];
           attempts = this[5];
    }
    
    if (this.attempts != null 
        && this.attempts++ > 3 ) {
            return false; //if too much attempts
    }
    
    locationHash  = checkInteger(locationHash);
    localServerID = checkInteger(localServerID);
    
    if ( isNaN(localServerID) === true 
        || localServerID === empty_user_id ) {
            return resolvedPromiseFalse; //return Promise with the false result
    }
    
    if ( isNaN(locationHash) === true 
        || locationHash === empty_user_id ) {
            return resolvedPromiseFalse; //return Promise with the false result
    }
    
    var resTTL = getTTL(flLongTTL !== true); //get short time to live for a single handled location and for location into the list of the handled locations. We are using resTTL[0] - for a single location
   
    var promiseToDO; //resulted promise
    if ( previousLSID != null ) { //if the id of the previous local server for this location is given, then chose another method to set the new loal server for the location    
        promiseToDO = redisClient.scriptExec("setLS", locationHash, [localServerID, resTTL[0], previousLSID ])
                            .bind(["OK", locationHash, previousLSID]) //the right result of the redis.set must be "OK" 
                            .then(removeLocationForLS); //remove location from the list of handled locations for the previous ls
    } else { //if not necessary to replace the previous local server
       promiseToDO = doCommand( "set", [locationHash , hashes.getHashUserIDWithTimestamp(localServerID), "EX", resTTL[0], "NX"], true ); //set the new ls only if the ls is absent for the location and save local server ID with an addition of the current timestamp 
    }
    
    return promiseToDO
            .bind([ //bind to the context
               locationHash,
               localServerID,
               previousLSID,
               flLongTTL,
               (attempts === undefined) ? 0 : attempts //a number of attempts to set the local server for the location hash
            ])
            .then(setLocalServerID.afterSetLSForLocation, setLocalServerID); //set the new ls only if the ls is absent for the location
}).bind(moduleSettings);

//when after the new ls was set for the location hash and a ttl was set for the new ls 
setLocalServerID.afterSetLSForLocation = function(res) { //set the new ls only if the ls is absent for the location
            
    if ( res === null ) { //if the local server for the location is already exists
        return false;    
    } else if ( res !== "OK" 
            && res !== true ) { //if something is wrong
                if ( this.attempts++ < 3 ) {
                    return setLocalServerID(this[0], this[1], this[2], this[3], this[4], this[5]);    
                } else { //if too much attempts been fault
                    return false;    
                }
        
    } else { //if OK, then add the location to the list of the local server
        return addLocationForLS(this[1], this[0], (this[3] !== true) )
                .bind(this)
                .then(setLocalServerID.ifFaultAddLocationForLS, setLocalServerID.ifFaultAddLocationForLS); //check the result of the removeLocationForLS
    }
};

//check the resut of add the location into the list of maintained local servers
setLocalServerID.ifFaultAddLocationForLS = function(res){
    if ( res !== true ) { //the result must be true
        _log("An error has occurred. May be local server for the location was already defined");
        delLocalServerID(this[0], this[1]); //delete the local server id for the location
        return false;
    } else {
        return true;    
    }      
};

//////////////////////////////////////////////////////////////////////////////////////// delLocalServerID--


/*
    load lua script called "delLocalServerID". 
    has two arguments:
        1) local server id 
        2) 1 or 0 - it is necessary to check if the id of the local server matches to the given
    and the key = location hash
    script check that the given id is the real for the location, if it is, then delete the given location as the key
    not depending the second argument, the script will return an id of the local server for the location or 0 if the key not removed
*/
luaScripts.push("delLocalServerID");
luaScripts.push("local res = redis.call('GET', KEYS[1]) \
                 if type(res) ~= 'string' or (res == '" + empty_user_id + "') then \
                    return 0 \
                 end \
                 local validID = string.sub(res, 1, string.len(res) - 7) \
                 if (ARGV[2] == '0') then \
                    if redis.call('DEL', KEYS[1]) == 1 then \
                        return validID \
                    else \
                        return 0 \
                    end \
                 else \
                    if validID == ARGV[1] then \
                        if redis.call('DEL', KEYS[1]) == 1 then \
                            return validID \
                        else \
                            return ARGV[1] \
                        end \
                    else \
                        return ARGV[1] \
                    end \
                 end");

/*
    delete from the db the record with a local server ID by the location hash key
    localServerID may be empty
    return true if one of the operations had been done
    flDoNotRemoveLocationFromList - if true, then do not remove location from the list of the locations handled by the local server
*/
var delLocalServerID = (function _delLocalServerID(locationHash, localServerID, attempts, flDoNotRemoveLocationFromList) {
    
    if ( localServerID != null ) {
        localServerID == checkInteger(localServerID);
        if ( isNaN(localServerID) === true ) {
            localServerID = empty_user_id; //return Promise with the false result
        }
    } else {
        localServerID = empty_user_id; 
    }
    
    locationHash = checkInteger(locationHash);
    if ( isNaN(locationHash) === true 
        || locationHash === empty_user_id ) {
            return resolvedPromiseFalse; //return Promise with the false result
    }
    
    return redisClient.scriptExec("delLocalServerID", locationHash, [localServerID, (localServerID !== empty_user_id ? 1 : 0) ]) //delete the id of the local server for the location? if the ls from the db matches to this ls
                .bind({
                    localServerID   : localServerID,
                    locationHash    : locationHash,
                    attempts        : (attempts != null) ? attempts : 0,
                    flDoNotRemoveLocationFromList : flDoNotRemoveLocationFromList
                })
                .then(delLocalServerID.afterDEL, delLocalServerID.afterDEL);
}).bind(moduleSettings);

//after got the current id of the local server for the location
delLocalServerID.afterDEL = function(result) {
    
    if ( result instanceof Error ) { //if the id of the local server for the location not mathes to this local server
        if ( this.attempts < 4 ) { //try once again
            return delLocalServerID(this.locationHash, this.localServerID, this.attempts);    
        } else { //return false if too many attempts has been
            return false;    
        }
    } else if ( this.flDoNotRemoveLocationFromList !== true ) { //remove from the list of the handled locations
        if ( this.localServerID == empty_user_id ) { //if the given id of the local server is absent
            result == checkInteger(result); //try to get it from the result of the script
            if ( isNaN(result) === false
                && result !== 0
                && result !== empty_user_id ) {
                    this.localServerID = result;        
            } else {
                if ( result === 0 ) { //nothing to remove
                    return true; //may be another local server handles this location
                } else {
                    return false;  //if not removed
                }
            }
        }
        return removeLocationForLS(this.localServerID, this.locationHash);    
    }

};
///////////////////////////////////////////////////////////////////////////////////////////// --delLocalServerID




/////////////////////////////////////////////////////////////////////////////////////////////

//get IDs of the nearest local servers for the location
//argument "location hash" can be used instead of the latitude
//return { nearestLocationHash : {localServerID, timestamp} }
//timestamp - is a time when the local server began maintaince of the location
var getNearestLS = (function _getNearestLS(latitude, longitude) {
    
    latitude = checkInteger(latitude);
    longitude = checkInteger(longitude);    
    
    var nearestLocations = ( arguments.length == 1 ) //the latitude argument is the location hash in fact
        ? calculateNearestLHFByLocationHashOrLHF(latitude) //if latitude argument is the location hash
        : encodeArrayLocationHashes(commonGEO.calculateNearestLocations(latitude, longitude)); //get an array of the nearest locations to the user location
    var promises = [];
    for (var i =0, len = nearestLocations.length; i < len; i++) { //for an each nearest location
        promises[i] = getLocalServerID(nearestLocations[i], true, true); //return with timestamp and locationHash {localServerID, timestamp, locationHash}
    }
    return Promise.all(promises) //all the nearest local servers were got
        .then(getNearestLS.returnResult)
        .catch(returnFalse);
}).bind(moduleSettings);

//after all promises for getting id of a local servers were done
getNearestLS.returnResult = function (results){
    if ( commonF.isArray(results) === true ) {
        var result = {}; //result will be returned to a caller function
        for( var i = 0 , len = results.length; i < len; i++ ) { //for each of the promises
            var res = results[i];
            var locationDesc = res[0]; //is an array, where is [0] = {locationHash, lsID, timestamp}
            if ( locationDesc != null
                && locationDesc.locationHash != null ) {
                    result[locationDesc.locationHash] = { //put into the result with the index = locationHash
                        localServerID : locationDesc.localServerID,
                        timestamp : locationDesc.timestamp
                    };
            } //a local server for the location is absent or return an id of the locatl server
        }
        return result;
    } else { //an unknown result
        return new Error("An unknown result");
    }
};


///////////////////////////////////////////

/*
    add a location to the list of the locations, that are handled by the local server client
    flAddWaitingPong - set the short ttl for the location
    return true if all is ok or false if an error
*/
var addLocationForLS = (function _addLocationForLS(lsID, locationHash, flAddWaitingPong, attempts) {
    
    lsID = checkInteger(lsID);
    locationHash = checkInteger(locationHash);
    
    if ( isNaN(lsID) === true 
        || lsID === empty_user_id ) {
            return resolvedPromiseFalse; //return Promise with the false result
    }
    
    if ( isNaN(locationHash) === true 
        || locationHash === empty_user_id ) {
            return resolvedPromiseFalse; //return Promise with the false result
    }
    
    var keyUserID = hashes.getKeyOfUserIDForDb(lsID); //get id with the prefix. prefix is to distinguish a locations and the users into the same redis db 
    var resTTL = getTTL(flAddWaitingPong); //get time to live for ls and for location ino the list of the handled locations. We are using resTTL[1] - for location into the list, within this function
    
    var resultPromise = 
        redisClient.multi(
            keyUserID,
            [
                ["hset",   keyUserID, locationHash, resTTL[1]], //set the value of the key = location hash to the current timestamp, this is for checking to the future if the local server for the location is expired
                ["expire", keyUserID, this.ttlLocalServer] //all the recoredes will be deleted from the db after the specified time
            ]
        )
        .bind({
            lsID : lsID,
            locationHash : locationHash,
            flAddWaitingPong : flAddWaitingPong,
            attempts : attempts || 0 //a number of attempts to do this operation
        });
     
    return resultPromise
            .then(addLocationForLS.checkResult, addLocationForLS.ifError);
}).bind(moduleSettings);

//add whaiting pong response from the ls to validate that he added the location for handling
addLocationForLS.checkResult = function(res) {
    if ( _isArray(res) === true
        && res.length === 2) {
            return res[1] === 1; //the right result of hset command may be 1 - if new locationHash or 0 if location is already into the list, then it was uptadet by new timestamp
                                //the right result of expire command must be 1    
    } else {
        return false;
    }
};

//if an error while add a location for the ls
addLocationForLS.ifError = function (err) {
    _log("Can't to add location " + this.locationHash + " for handling by the local server " + this.lsID);
    _log(err);
    if ( ++this.attempts > 3 ) { //if more then 3 operations to do this
        removeLocationForLS(this.lsID, this.locationHash);
        return false;
    } else { //try once again
        return addLocationForLS(this.lsID, this.locationHash, this.flAddWaitingPong, this.attempts);    
    }
};

///////////////////////////////////////////

/*
    remove a location from the list of the locations, that are handled by the local server client
    arguments can be passed through the context:
        context = array[
            0 : false/aother value - check or not the result of the previous command. If false, then do not check, if another value, then arguments[0] must be equal to this value, othervise this function will not be executed
            1 => lsID
            2 => locationHash
            3 => attempts
        ]
        
    return true or false
*/
var removeLocationForLS = (function _removeLocationForLS(lsID, locationHash, attempts) {
    
    if ( arguments.length < 2
        && _isArray(this) === true ) { //get the arguments from the context
           
            if ( this[0] !== false
                && this[0] !== arguments[0] ) { //if necessary to check the result of the previous operation
                    return false; //if the result of the previous operation not equals to the necessary   
            }
           
           lsID = this[1]; 
           locationHash = this[2];
           attempts = this[3];
    }
    
    lsID = checkInteger(lsID);
    locationHash = checkInteger(locationHash);
    
    if ( isNaN(lsID) === true 
        || lsID === empty_user_id ) {
            return resolvedPromiseFalse; //return Promise with the false result
    }
    
    if ( isNaN(locationHash) === true 
        || locationHash === empty_user_id ) {
            return resolvedPromiseFalse; //return Promise with the false result
    }
    
    return redisClient.hdel(hashes.getKeyOfUserIDForDb(lsID), locationHash)
            .bind({
                lsID : lsID,
                locationHash : locationHash,
                attempts : attempts || 0
            })
            .then(removeLocationForLS.afterRemoveLocation)
            .catch(removeLocationForLS.ifError);
}).bind(moduleSettings);


/*
    remove all whaiting pong responces for the location and the local server
*/
removeLocationForLS.afterRemoveLocation = function (res){
    if ( res instanceof Error ) { //the location may absent into the list of the handled locations, this causes checking only for an error result
        throw res; //if the result is instance of an error throw with it as the result   
    } else if ( typeof(res) !== "number" ) {
        return false;    
    }

    return true;
};

//if error
removeLocationForLS.ifError = function (err) {
    if ( err instanceof Error ) { //if error is an error
        _log(err);    
    }
    if ( ++this.attempts < 3 ) { //try once again if attempts still not left
        return removeLocationForLS(this.lsID, this.locationHash, this.attempts);   
    } else if ( ++this.attempts < 5 ) { //try to set zero as the time to live for the location into the list
        return redisClient.hset(this.keyLSID, this.locationHash, 0) //instead of delete a key locationHash, set zero as the local server id for it
                .bind(this)
                .then(removeLocationForLS.afterRemoveLocation);   
    } else { //if all attempts  failed
        _log("Something wrong while removing location from the list of local server locations. ID = " + this.lsID + " and location hash " + this.locationHash);
        return false;     
    }
};

/////////////////////////////////////////// clearLocationsByLS--


//clear all locations from the list of the locations, that are handled by the local server client
var clearLocationsByLS = (function _clearLocationsByLS(lsID) { //on user disconnected
    
    lsID = checkInteger(lsID);
    
    if ( isNaN(lsID) === true 
        || lsID === empty_user_id ) {
            return resolvedPromiseFalse; //return Promise with the false result
    }

    return getLocationsByLS(lsID) //get locations, that are maintained by the local server
            .bind({
                lsID : lsID    
            })
            .then(
                clearLocationsByLS.afterGotLocationsByLS,
                returnFalse
            );
}).bind(moduleSettings);

//when got the locations which are handled by the local server
//locations = array or id of the local server
clearLocationsByLS.afterGotLocationsByLS = function(locations){
    
    if ( locations === false ) { //if can't get the lcoations
        if ( this.attempts == null  ) {
            this.attempts = 1;    
        } else {
            this.attempts++;   
        }
        
        if ( this.attempts > 4 ) { //if too much attempts were failed
            return false;    
        } else {
            return clearLocationsByLS(this.lsID);    
        }
    }
    
    var flLocationsIsLSID = (typeof(locations) === "number"); //variable locations may be the id of the local server for real. This may caused by clearLocationsByLS.returnResult if an eeror has occurred 
    var _lsID = (flLocationsIsLSID === true) ?  locations : this.lsID; 
    
    if ( flLocationsIsLSID !== true ) { //if the locations is the id of the ls
        for (var i =0, len = locations.length; i < len; i++) {  //for each location delete the local server
            delLocalServerID(locations[i], _lsID, null, true); //true - do not remove the location from the list of the handled locations    
        }
    }
    
    //remove all locations from the list of the handled locations ls
    return doCommand("del", hashes.getKeyOfUserIDForDb(_lsID));
    
};

//return the result or try one again
clearLocationsByLS.returnResult = function(res){
    
    if ( this.attempts == null ) {
        this.attempts = 1;   
    } else {
        this.attempts++;    
    }
    
    if ( res instanceof Error ) { //if an error has occurred
        if ( this.attempts < 4 ) {
            return clearLocationsByLS.afterGotLocationsByLS.call(this, this.lsID); //try to remove the list with the handeld locations once again
        } else { //all attempts were failed
            return false;    
        }    
    } else {
        return true;    
    }
    
};


/////////////////////////////////////////// --clearLocationsByLS



///////////////////////////////////////////setExpireForAllLocationsByLS--

/*
    load lua script called "setExpireForAllLocationsByLS". 
    has two arguments: 
        1) first  - local server id 
        2) second - time to live for the key
    and the key = location hash
    script check that the given id is the real for the location, if it is, then set the time to live for the location
*/
luaScripts.push("setExpireForLocation");
luaScripts.push("local res = redis.call('GET', KEYS[1]) \
                if type(res) ~= 'string' or (res == '" + empty_user_id + "') then \
                    return 0 \
                end \
                if string.sub(res, 1, string.len(res) - 7) == ARGV[1] then \
                    return redis.call('EXPIRE', KEYS[1], ARGV[2]) \
                 else \
                    return 0 \
                 end");

/*
    set time to live for all locations, that are handled by the local server
    flLongTTL - if true, then set the long time to life for the local server
    flDoNotCheckTTL - if true, then do nit check ttl firstly
*/
var setExpireForAllLocationsByLS = (function _setExpireForAllLocationsByLS(lsID, flLongTTL, flDoNotCheckTTL, attempts) { //on user disconnected
    
    lsID = checkInteger(lsID);
    
    if ( isNaN(lsID) === true 
        || lsID === empty_user_id ) {
            return resolvedPromiseFalse; //return Promise with the false result
    }
    
    if ( flLongTTL !== true //if it is not the locang time to life
        && flDoNotCheckTTL !== true ) { //or not necessary to check the tll
            return redisClient.ttl(hashes.getKeyOfUserIDForDb(lsID)) //check the current ttl for the local server list
                    .bind({
                        lsID : lsID,
                        flLongTTL : flLongTTL,
                        ttl  : ( flLongTTL === true ) ? this.ttlLocalServer : this.ttlAfterLSDisconnected, //time to live for all location of the local server
                        attempts : attempts    
                    })
                    .then(setExpireForAllLocationsByLS.retry);
    } 
    
    return getLocationsByLS(lsID, true) //get locations, that are maintained by the local server
            .bind({
                lsID : lsID,
                flLongTTL : ( flLongTTL === true ),
                flDoNotCheckTTL : ( flDoNotCheckTTL === true ),
                attempts : ( attempts === undefined ) ? 0 : attempts,
                ttl  : ( flLongTTL === true ) ? this.ttlLocalServer : this.ttlAfterLSDisconnected //time to live for all location of the local server
            })
            .then(
                setExpireForAllLocationsByLS.afterGotLocationsByLS,
                setExpireForAllLocationsByLS.retry
            );
}).bind(moduleSettings);

/*
    retry to setExpireForAllLocationsByLS or check doCommand("ttl"
    res may be an error or result of doCommand("ttl"..., then it is the time to life
*/
setExpireForAllLocationsByLS.retry = function(res) {
    if (  res instanceof Error
        && this.attempts++ > 3 ) {
         return false; 
    } else if ( typeof(res) === "number" ) {//if it is ttl for the local server
            if ( res < this.ttl ) { //if it less, then ttl, that we trying to set
                return false;    
            } else { //if all is ok do not check tl for th location anymore
                this.flDoNotCheckTTL = true;    
            }
    }
    
    return setExpireForAllLocationsByLS(this.lsID, this.flLongTTL, this.flDoNotCheckTTL, this.attempts);

};

//when got the locations which are handled by the local server set ttl for all of them
setExpireForAllLocationsByLS.afterGotLocationsByLS = function(locations) {
    
    if ( locations === null ) { //locations are absent
        return true;    
    } else if ( locations !== false
            && locations.length !== undefined
            && locations.length > 0
            && locations instanceof Error === false ) {
            
                if ( locations === undefined ) {
                    if ( this.locations !== undefined ) { //if this function was called because of an error occurred within the script
                        locations = [this.locations]; //get one location from the context
                    } else {
                        return false;    
                    }
                    
                    if ( this.attemptsScript !== undefined 
                        && this.attemptsScript > 4 ) {
                            return false;    
                    } else {
                        if ( this.attemptsScript === undefined ) {
                            this.attemptsScript = 1;    
                        } else {
                            this.attemptsScript++;
                        }    
                    }
                    
                }
                
                var ttl  = this.ttl;
                var lsID = this.lsID;
                for( var i = 0, len = locations.length; i < len; i++ ) { //for each given location
                    var locationHash = locations[i];
                    redisClient.scriptExec("setExpireForLocation", locationHash, [lsID, ttl]) //check if the local server is the real ls for it. If it is true, then set the time to live for the location
                        .bind({
                            ttl: ttl,
                            lsID : lsID,
                            locations : locationHash
                        })
                        .catch(setExpireForAllLocationsByLS.afterGotLocationsByLS); //if error then try once again
                }
                
                return doCommand("expire", [hashes.getKeyOfUserIDForDb(lsID), ttl]); //set ttl for the list of the handled locations
            
    } else if ( this.locations === undefined ) { //if error has occured not into the script
        return setExpireForAllLocationsByLS.retry.apply(this);
    } else { //if some error within the script
        return false;    
    }
};

/////////////////////////////////////////// --setExpireForAllLocationsByLS




/////////////////////////////////////////// getLocationsByLSCheckID--

/*
    return the list with all valid locations which are handled by the ls with checking of the real id (is it equals to the id of this local server) of a local server for each location
    return Array[locationHash1,...,locationHashN] with the list of the handled locations
*/
var getLocationsByLSCheckID = (function _getLocationsByLSCheckID(lsID, attempts) {
    
    lsID = checkInteger(lsID);
    
    if ( isNaN(lsID) === true 
        || lsID === empty_user_id ) {
            return resolvedPromiseFalse; //return Promise with the false result
    }
    
    var context = {lsID:lsID};
    if ( attempts != null ) { //bind the number of attempts to the context
        context.attempts = attempts;    
    }
    
    return redisClient.hgetall(hashes.getKeyOfUserIDForDb(lsID))
            .bind(context)
            .then(
                getLocationsByLSCheckID.afterGotListLocationsForLS,
                getLocationsByLSCheckID.tryAgain    
            );
}).bind(moduleSettings);

//try getLocationsByLSCheckID once again
getLocationsByLSCheckID.tryAgain = function(){
    if ( this.attempts > 3 ) { //if too much attempts
        return false;    
    } else { //try again
        return getLocationsByLSCheckID(this.lsID, this.attempts);    
    }
};

//when got the locations which are handled by the local server
//return [locationHash] with locations, that are maintained by the local server
getLocationsByLSCheckID.afterGotListLocationsForLS = function(locations) { //{ locationHash : timestamp }
    var lsID = this.lsID,
        outdated = [], //list of outdated locations
        indOutdated = 0,
        currTimestamp = getTimestamp(),
        locationsHashes = Object.keys(locations),
        resulted = [],
        ind = 0;
    for (var i=0, len = locationsHashes.length; i < len; i++) {  //for each of the locations
        //check is the location handling has outdated
        var locationHash = locationsHashes[i];
        var timestampWhenAdded = hashes.getTimestampByHash(locations[locationHash]);
        if (  (currTimestamp - timestampWhenAdded) > this.ttlLocalServer ) {
            outdated[indOutdated++] = locationHash; //put into list of outdated locations
            continue;    
        }
        resulted[ind++] = locationHash;
    }
    if ( outdated.length !== 0 ) { //remove outdated locations from the list of handled locations
        for ( i = 0; i < outdated.length; i++ ) {
            removeLocationForLS(lsID, outdated[i]);
        }
    }
    
    return getLocalServerID(resulted, false, true) //get the id of the local servers for the locations
            .bind({lsID:this.lsID})
            .then(getLocationsByLSCheckID.afterGotListLSForLocations)
            .catch(returnFalse);
};

//result = [ {localServerID, locationHash} ], where localServerID - is an id of the local server for the location
getLocationsByLSCheckID.afterGotListLSForLocations = function(localServersForLocations){
    var listValidLocations = []; //locations that are really handled by the local server
    var ind = 0;
    var lsID = this.lsID; //id of this ls
    var len = localServersForLocations.length;
    if ( _isArray(localServersForLocations) === true
        && len > 0 ) {
            for( var i = 0; i < len; i++ ) {
                var lh = localServersForLocations[i].locationHash;
                if ( localServersForLocations[i].localServerID === lsID ) { //if the valid id of the local server for the location is equals to the id of the current local server
                    listValidLocations[ind++] = lh; //put the location into the list of the handled locations
                } else {
                    removeLocationForLS(lsID, lh);    
                }  
            }
    }
    return listValidLocations;
};


/////////////////////////////////////////// --getLocationsByLSCheckID




////////////////////////////////////////// getLocationsByLS--

/*
    return the list with all valid locations which are handled by the ls
    return Array[locationHash1,...,locationHashN] with the list of the handled locations (integers)
    if flFastMode = true, then do not remove outdated locations
    if flDoNotConvertToIntegers = true, then do not convert the locations from the resulted list into an integers
    if flWithTimestamps === true, then retuns { locationHash : timestamp }
*/
var getLocationsByLS = (function _getLocationsByLS(lsID, flFastMode, flDoNotConvertToIntegers, flWithTimestamps) {
    
    lsID = checkInteger(lsID);
    
    if ( isNaN(lsID) === true 
        || lsID === empty_user_id ) {
            return resolvedPromiseFalse; //return Promise with the false result
    }
    
    return redisClient.hgetall(hashes.getKeyOfUserIDForDb(lsID))
            .bind({
                lsID : lsID,
                flFastMode : ( flFastMode === true ),
                flDoNotConvertToIntegers : ( flDoNotConvertToIntegers === true ),
                flWithTimestamps : ( flWithTimestamps === true )
            })
            .then(
                getLocationsByLS.afterGotListLocationsForLS,
                returnFalse
            );
}).bind(moduleSettings);

//when got the locations which are handled by the local server
//return Array [locationHash], that contains a locations, that are maintained by the local server
getLocationsByLS.afterGotListLocationsForLS = function(locations) { //{ locationHash : timestamp }
    var lsID = this.lsID,
        flFastMode = this.flFastMode,
        flDoNotConvertToIntegers = this.flDoNotConvertToIntegers,
        flWithTimestamps = this.flWithTimestamps,
        outdated = [], //list of outdated locations
        indOutdated = 0,
        currTimestamp = getTimestamp(),
        locationsHashes = Object.keys(locations),
        resulted = [],
        ind = 0;
    for (var i=0, len = locationsHashes.length; i < len; i++) {  //for each of the locations
        //check is the location handling has outdated
        var locationHash = locationsHashes[i];
        var timestampWhenAdded = hashes.getTimestampByHash(locations[locationHash]);
        if ( flWithTimestamps === false
            && (currTimestamp - timestampWhenAdded) > this.ttlLocalServer ) {
                if ( flFastMode !== true ) { //if not in the fast mode
                    outdated[indOutdated++] = locationHash; //put into list of outdated locations    
                }
        } else {
            if ( flWithTimestamps === true ) {
               resulted[locationHash] = timestampWhenAdded;
            } else {
                resulted[ind++] = ( flDoNotConvertToIntegers === true ) ? locationHash : _toInt(locationHash); //return integer (by default) or string if flDoNotConvertToIntegers === true  
            }
        }
    }
    if ( flFastMode !== true //if not in fast mode, then remove the outdated locations from the list of handled locations
        && outdated.length !== 0 ) { //remove outdated locations from the list of handled locations
            for ( i = 0; i < outdated.length; i++ ) {
                removeLocationForLS(lsID, outdated[i]);
            }
    }
    return resulted;
};


/////////////////////////////////////////// --getLocationsByLS



module.exports = {
    getLocalServerID : getLocalServerID,
    setLocalServerID : setLocalServerID,
    delLocalServerID : delLocalServerID,
    getNearestLS     : getNearestLS,
    addLocationForLS : addLocationForLS,
    removeLocationForLS     : removeLocationForLS,
    clearLocationsByLS      : clearLocationsByLS,
    setExpireForAllLocationsByLS : setExpireForAllLocationsByLS,
    getLocationsByLS        : getLocationsByLS,
    getLocationsByLSCheckID : getLocationsByLSCheckID,
    setExpLocalServerLocation : setExpLocalServerLocation,
    start : redisClient.start
                .then(function(res){ //check the connection to the redis nodes
                    if ( res == null
                        || res instanceof Error ) {
                            throw (res instanceof Error ? res : new Error("Can't connect to the redis nodes"));
                    }
                    return redisClient;
                }),
    redisClient : redisClient
};
