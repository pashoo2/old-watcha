const prefixMessagesForGServer = "#&!^@",
    webSocketHeartbeatMessage = "$@!",
    flUseWorkers = true,
    flDebug = true,
    envVariables = process.env;

module.exports = {
    "debugmode" : flDebug, 
    "workersToStart" : 2,
    "serviceName" : "testService",
    "useWorkers" : flUseWorkers,
    "mainDomain" : envVariables.IP   || "0.0.0.0", //adress where is the app
    "mainPort"      : envVariables.PORT || "8080", //port for adress
    "mainPageName"  : "connectToPeerJS.html",
    "loginPageName" : "login",
    "regPageName"   : "reg",
    "returnBuffersToUser"   : true,
    "redisGeoReturnBuffers" : true,
    "cookiesSettings" : {
        "secret" : "Jnfjro2394u__333090-KK",
        "httpOnly" : true,
        "maxAge"   : false,
        "secure"   : false,
        "expires"  : false,
        "port"     : 9000,
        "domain"   : "localhost",
        "nameRandomValueCookieName" : "cKdjdjaSNSjjfnNSJjnnSJJS"
    },
    "sessionSettings" : {
        "name"    : "a_p_p.s_id",
        "rolling" : false,
        "resave"  : false,
        "proxy"   : false,
        "saveUninitialized" : false,
        "cookieLifeTime" : 3600000
    },
    "geoServerSettings": {
        "deprecated" : true,
        "host": "127.0.0.1",
        "port": 8080,
        "webSocketMaxDataFrameSize": 10240,
        "webSocketMaxDataSize": 20480,
        "lengthOfClientsList" : 50000 //how many items will be created into the array with connected clients
    },
    "messagesSettings" : {
        "empty_user_id" : 0, //the value, that is representation of an empty id of the user
        "webSocketHeartbeatMessage" : webSocketHeartbeatMessage, 
        "prefixMessagesForGServer" : prefixMessagesForGServer, //prefix for all messages, that are for the gServer
        "webSocketMaxDataFrameSize": 1024,
        "webSocketMaxDataSize": 10240,
        "gServerAllowedMessageTypes" : ["_gServer"],
        "timestampSecondsDifferenceOverdueIncomingMessages" : 2000, //!!!20 as default //when this time is passed the message will become not overdue
        "messageKindBrowserClosed" : "out", //when the user has closed the browser
        "messageKindSendPingForAllLocations" : "connected", //type of the message, when a new connection is established
        "messageKindSetClientServerTimeDifference" : "getTimeUTCDifference" //type of a messages for setting a time difference between a client and the server
    },
    "gServerSettings" : {
        "defaultKey" : "peerjs",
        "sendPingAfterRecconnection" : false //send the ping message for each of the known handled locations
    },
    "backgroundJobs" : {
        "timeCandidateForPongOutdating" : 10000, //current timestamp + this time - to get a next waiting pong responses
        "timeIntSecondsDisconnectExpiredPongs" : 60, //one time per one minute disconnectExpiredPongs
        "timeIntervalSecondsToCheckTheNewLocalServer" : 20 //time for a user as a local server to add the location for maintaince. Before this time send a message again and after thet will send the ping for the handled location
    },
    "swigOptions": {
        "cache": false
    },
    "bodyParserOptions" : {
        "limit"  : 1000,
        "parametrLimit" : 10,
        "type" : "urlencoded",
        "extended" : true
    },
    "requiredFieldsForRegistration" : {
        "usrLogin":"Your login",
        "usrEmail":"Your email",
        "usrPassword":"Your password"
    },
    "ttlUsersWithNoEmailConfirmation" : 259200,
    "nodeMailerTransporterSettings" : {
        "service" : "Mail.ru",
        "auth": {
            "user": "",
            "pass": ""}
    },
    "serviceEmailAddress" : "test_project@bk.ru",
    "redisDB" : {
        "redisNodes" : [  //host and port of a redis nodes
            {sentinels:[{ host: '127.0.0.1', port: 26390 }, { host: '127.0.0.1', port: 26391 }, { host: '127.0.0.1', port: 26392 } ], name: 'geomaster6370'},
            {sentinels:[{ host: '127.0.0.1', port: 26390 }, { host: '127.0.0.1', port: 26391 }, { host: '127.0.0.1', port: 26392 } ], name: 'geomaster6371'}
        ],
        /*"redisNodesForMessagingModule" : [  //host and port of a redis nodes
            {"host": "127.0.0.1", "port": 7003},
            {"host": "127.0.0.1", "port": 7004}
        ],*/
        "redisNodesForIdentification" : [ //identification user id in social network - user id in this app
           {sentinels:[{ host: '127.0.0.1', port: 26390 }, { host: '127.0.0.1', port: 26391 }, { host: '127.0.0.1', port: 26392 } ], name: 'geomaster6390'}
            //{"host": "127.0.0.1", "port": 7004}
        ],
        "redisNodesForPubSub" : [ //nodes for redis instances for messaging between gServers
        ],
        "optionsIORedis" : { //specified by the ioredis library. new Redis(port, host, optionsIORedis)
            parser : "hiredis",
            dropBufferSupport : true,
            autoResendUnfulfilledCommands : true,
            connectTimeout : 2000,
            enableReadyCheck : true,
            enableOfflineQueue : true,
            timeInterval : 200, //in milliseconds. One time per this interval pipelines for all nodes will be performed
            maxQueueLength : 1000 //maximum length for a queue of the commands. If more tha maximum command into a queue, then pipeline for the node will be performed 
        },
        "optionsPipelineCommander" : { //options especially for the PipelineCommander library
            "timeInterval" : 100,
            "maxQueueLength" : 1000
        }
    },
    "commonGeoFunctionsModule" : {
        "quadrantSquare" : 200, //default : 50. a square of a quadrant in meters for calculations of the location hashes   
    },
    "dbGeoModule" : {
      "ttlLocalServer" : 3600, //default:3600. time to live(seconds) of the local server for the location key
      "ttlLocalServerBeforePong" : 5, //default:5, //time to live(seconds) of the local server for the location key, before it return the pong responce
      "ttlAfterLSDisconnected" : 10, //default:10, //when a local server disconnected from the cs for all his locations this time to live will be set
      "flAddWaitingPong" : false //is it necessary to add whaiting pong, after a location added for maintaince by it
    },
    "dbMessaging" : {
        ttlPongResponseKeys : 20, //time to live of a redis keys with local servers hashes and timestamps of responces
        timeIntervalSecondsWhaitingPongResponse: 15, //seconds, whaiting time of the user pong response to the ping request,
        timeIntervalBetweenCheckWhaitingPongResponces : 5 //seconds between the two executions of the procedure for checking of the waiting pong responses
    },
    "ILSSetting" :{ //settings for InnerLocalServer
        "minMaintainedLocations" : 1,
        "timeSecondsStopLocationMaintaince" : 60
    },
    "messagesValidatorsSettings" : {
        "AJVSettings" : { //settings for ajv validator
          "allErrors":        false,
          "removeAdditional": false,
          "verbose":          false, //include the reference to the part of the schema and validated data in errors (false by default).
          "format":           'full',
          "uniqueItems":      true,
          "unicode":          false, //calculate correct length of strings with unicode pairs (true by default). Pass false to use .length of strings that is faster, but gives "incorrect" lengths of strings with unicode pairs - each unicode pair is counted as two characters
          "jsonPointers":     true,
          "messages":         true
        }    
    },
    "webServer" : {
        host : process.env.IP || "0.0.0.0",
        httpsPort : 8443,
        port : 8080,
        root : "client",
        server : {
            index   : 'index.html',
            noCache : flDebug,
            timeout : 60000
        },
        contentType : {
            html    : 'text/html',
            css     : 'text/css',
            js      : 'text/javascript',
            json    : 'application/json',
            txt     : 'text/plain',
            jpeg    : 'image/jpeg',
            jpg     : 'image/jpeg',
            png     : 'image/png',
            gif     : 'image/gif',
            ico     : 'image/x-icon',
            appcache: 'text/cache-manifest',
            svg     : 'image/svg+xml'
        }
    },
    "gServers" : [ //connections to the main servers
        {host : '0.0.0.0', port : 8085}
    ],
    "PeerJSServer" : { //connections to the main servers
        path    : '/',
        secure  : false,
        proxied : true
        
    },
    "integration" : {
        "facebook" :  {
            "libOptions" : {
              appId     : '911820115617926',
              scope     : 'user_photo',
              xfbml     : true,
              version   : 'v2.6' 
            },
            "dbKeyPrefix" : "fb",
            "query" : "",
            "get"   : "me"
        },
        "microsoft" : {
           "dbKeyPrefix" : "ms",
           "query" : "",
           "get"   : "me"
        },
        "google" : {
           "dbKeyPrefix" : "gog",
           "query" : "plus",
           "get"   : "people/me"
        }
    },
    "patternUserIDFromURL" : "(?:id=)[a-zA-Z0-9]*(?=[$&])" //reg ex pattern that defines how to get user id from an url, wich a web socket user connection uses
};