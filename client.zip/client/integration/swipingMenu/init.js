/*global $*/
/*global jQuery*/

const thisModule = this;
const _ui = thisModule.ui = $(".ui-header-hiding");

_ui.enhanceWithin();
_ui.find("div, span, p").enhanceWithin();

_ui.each( //set the necessary properties for each element
    function(){
        var thisUI = $(this);
        jQuery.data(this, "_swipingMenu", {
            maxHeight   : Number(thisUI.css("max-height").replace("px", "")),
            baseHeight  : Number(thisUI.height())
        });
    }    
);

function onVerticalSwipe(_ui, dy, last_dy) {
    
    const el = _ui.get(0);
    const data = jQuery.data(el, "_swipingMenu");
    const maxHeight   = data.maxHeight;
    const baseHeight  = data.baseHeight;
        
    var newHeght, newOpacity;
    
    if ( typeof(dy) === "number" ) {
        el.style.webkitAnimation = el.style.animation = "";
        if ( dy > 0 ) {
            newHeght = baseHeight + dy;
        } else {
            newHeght = _ui.height() + dy;
        }
        newOpacity = newHeght / maxHeight;
        _ui.animate({"height" : newHeght}, {queue : false, duration: 5});
        el.style.opacity = newOpacity;
    } else { //on touch event is ended
        if ( last_dy < baseHeight / 2 ) { //if too small, then hide 
            el.style.webkitAnimation = el.style.animation = "minimize 1s linear forwards";
            /*clear the current timeout and set the new*/
            if ( data.timeout != null ) {
                clearTimeout(data.timeout);
            }
          } else { //show it
            el.style.webkitAnimation = el.style.animation = "maximize 1s linear forwards";
        }
    }
 
}

//on touch on the menu increase the height to the 50% of the maximum
function onTouchStart(_ui) {
    const el = _ui.get(0); //DOM element
    const data = jQuery.data(el, "_swipingMenu"); //get JQuery Data assigned to the element
    const maxHeight   = 0.5 * data.maxHeight;
    const currentHeight = _ui.height(); //get the current height of the element

    /*clear the current timeout and set the new*/
    if ( data.timeout != null ) {
        clearTimeout(data.timeout);
    }
    data.timeout = setTimeout(function(){
       el.style.webkitAnimation = el.style.animation = "minimize 1s linear forwards"; 
    }, 10000);
    
    if ( currentHeight < maxHeight ) { //if smaller than 50% of maximum height
        el.style.webkitAnimation = el.style.animation = "ontouch 0.1s linear forwards";
    }
}

_ui.touchwipe({
    wipeDown : onVerticalSwipe,
    wipeUp : onVerticalSwipe,
    Touch : onTouchStart,
    min_move_y : 4
});

_ui.hide();

thisModule.open = (function(){
    this.ui.get(0).style.animation = "maximize 0.1s linear forwards"; 
}).bind(thisModule);

thisModule.close = (function(){
    this.ui.get(0).style.animation = "minimize 0.1s linear forwards"; 
}).bind(thisModule);

thisModule.show = (function(){
    const _ui = this.ui;
    _ui.css("display", "block");
    _ui.show();    
}).bind(thisModule);

thisModule.hide = (function(){
    this.ui.hide();    
}).bind(thisModule);