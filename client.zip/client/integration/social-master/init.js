/*global $*/

var thisModule = this;

var EventEmitter = require("eventemitter");
thisModule.__proto__ = Object.create(new EventEmitter());

//this - settings for the module
var availSocialNetworks = this.networks = [
    "facebook",
    "pinterest",
    "dribbble",
    "skype",
    "twitter",
    "linkedin",
    "apple",
    "myspace",
    "xbox",
    "tumblr",
    "vimeo",
    "foursquare",
    "lastfm",
    "google",
    "youtube",
    "flickr",
    "instagram"    
];

/*
    click on social button
*/
function onClickSocialProfile(){
    var ui = $(this);
    var classname = ui.prop("class").trim();
    var socialName = classname.slice(1).toLowerCase(); //social network name
    var profile = ui.attr("data-ui-social-profile");
    if ( typeof(profile) === "string" ) {
        profile.trim(); //profile name    
    }
    var popupUI = $("#socialMasterPopUp"); 
    popupUI.find("h2").html(socialName);
    var input = popupUI.find("input");
    input.prop("name", classname);
    if ( profile === undefined ) { //if the profile is not defined
        input.prop("value",  "");
    } else {
        input.prop("value",  profile);
    }
    popupUI.popup("open"); //open popup to input profile name in social network
}

/*
    save the user profile name    
*/
function saveSocialProfile() {
    var popupUI = $("#socialMasterPopUp");
    var input = popupUI.find("input");
    var classname = input.prop("name").trim(); //name of the class
    var profile   = input.prop("value");
    var socialName = classname.slice(1).toLowerCase(); //social network name
    $("a." + classname).attr("data-ui-social-profile", profile); //set profile
    thisModule.emit("saveprofile", socialName, profile);
}

/*
    when editing of the user profiles is completed
    emit event saveprofiles with argument { 'social network name' : 'profile' } 
*/
function onNetworksClose() {
    var profilesRes = {}; //the resulted objec with social links
    $(".arthref a") //get
        .each(
            function(){
                var ui = $(this);
                var classname = ui.prop("class").trim();
                var socialName = classname.slice(1).toLowerCase(); //social network name
                var profile = ui.attr("data-ui-social-profile");
                if ( profile === undefined ) {
                    profile = null;    
                }
                profilesRes[socialName] = profile;
            }    
        );
    thisModule.emit("saveprofiles", profilesRes);    
}

this.showProfiles = 
    function(ui, links) {
        var socialProfiles = {}; //{ network name : porfile }
        var i, len;
        if ( links == null ) {
            for ( i=0, len = availSocialNetworks.length; i < len; i++) {
               socialProfiles[availSocialNetworks[i].trim()] = ""; //empty profile
            } 
        } else {
            for ( i=0, len = availSocialNetworks.length; i < len; i++) {
                var socialNetworkName = availSocialNetworks[i].trim();
                var profile = links[socialNetworkName]; //user profile in this network
                if ( profile == null ) { //if the user has no profile in this social network
                    socialProfiles[socialNetworkName] = ""; //empty link
                } else { //set the exists link
                    socialProfiles[socialNetworkName] = profile;
                }
            } 
        }
        
        $(ui).mySocialProfiles(socialProfiles); //links to the user profiles
        $(".arthref a")
            .each(
                function(){
                    var ui = $(this);
                    ui.on("click touchend", onClickSocialProfile);
                    ui.prop("href", "javascript:void(0);");
                }    
            );
        
        var uiPopUp = $("#socialMasterPopUp");
        
        if ( uiPopUp.length === 0 ) {
            var popupHTML = '<div data-role="popup" id="socialMasterPopUp" data-theme="b" data-shadow="true"><h2></h2><p><input id="socialMasterInputProfile" type="text" name="" value=""></p></div>';
            $(".arthref").append(popupHTML); 
            uiPopUp = $("#socialMasterPopUp");
        }
        
        uiPopUp.on("popupafterclose", saveSocialProfile);
        uiPopUp.popup();
        
        $('.arthrefSocialProfiles').find('.overlay').on('_hide', onNetworksClose); //when the panel with networks closed
        
    };