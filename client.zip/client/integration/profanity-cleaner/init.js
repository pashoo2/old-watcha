/*global $*/
/*global localStorage*/

var _self = this;

/*  https://github.com/LDNOOBW/List-of-Dirty-Naughty-Obscene-and-Otherwise-Bad-Words
    load banned words list into the array window._gBannedWordsList 
*/

/*
    make an array with a words, that are divided by line feed
*/
function makeArray(str) {
    
    if ( Array.isArray(str) === true ) {
        return str;    
    } else 
        if ( typeof(str) === "string" ) {
            var swearsArr = str.split("\n");
            var resArr = [];
            var indRes = 0;
            for( var i = 0, len = swearsArr.length; i < len; i++ ) {
                var swear = swearsArr[i].trim().replace(" ","");  
                if ( resArr.includes(swear) === false
                    && swear.length > 2 ) { //if not found into the array
                        resArr[indRes++] = swear; //put into the result array
                }
            }
            
            return resArr;
        } 
    else {
        return [];    
    }
}

/*
    load text file with a string, contains the banned words and make array with words from it   
*/ 
function loadJSON(lang) {
    return new Promise(
        function(res, rej) {
            $.get(_self._dir + '/content/' + lang + '.txt',
                function(data){
                    if ( typeof(data) === "string" ) { //if string was loaded from JSON
                        localStorageSetItem(lang + "_bannedWords", data); //store the list into the local storage
                        localStorageSetItem(lang + "_bannedWords_date", Date.now()); //store the list into the local storage
                        res(data);
                    } else {
                        res([]);
                    }          
                }
            ).fail(function(e) {
                rej(e);
            });    
        }
    );
}

/*
    Promise wrapper for the localStorage.getItem
*/
function localStorageGetItem(keyName) {
    return new Promise(
        function(resolve, reject) {
            try{
                resolve(localStorage.getItem(keyName));
            } catch(e){
                reject(e);    
            }
        }
    );    
}

/*
    Promise wrapper for the localStorage.setItem
*/
function localStorageSetItem(keyName, value) {
    return new Promise(
        function(resolve, reject) {
            try{
                resolve(localStorage.setItem(keyName, value));
            } catch(e){
                reject(e);    
            }
        }
    );  
}
 
/*
    load banned words string from local storage or if there is no words stored into the storagem, then load it from the files
*/
function loadBannedWordsList(lang) {
    return localStorageGetItem(lang + "_bannedWords_date")
            .then(function(res) {
                return loadJSON(lang);
                if ( res == null
                    || ( typeof(res) === "string"
                        && ( Date.now() - parseInt(res, 10) ) / 1000 > 432000 ) //list is more than 5 days old
                ) {
                    return loadJSON(lang);
                } else {
                    return localStorageGetItem(lang + "_bannedWords") //get banned words
                    .then(function(listBannedWords){ //try to get banned words from local storage
                        if ( listBannedWords == null
                            || listBannedWords === "undefined" ) { //if there is no list
                                return loadJSON(lang);    
                        } else {
                            return listBannedWords;
                        }
                    }); 
                }
            });
} 
   
/*fullfield when JSON loaded, parsed and regexp will be made*/ 
this.ready = new Promise(
    function(resolve, reject) {
        
        var _lang = window.navigator.language || window.navigator.browserLanguage; //user language
        var lang;
        switch( _lang ) {
            case "fr" :
                lang = "fr";
                break;
            case "it" : 
                lang = "fr";
                break;
            case "de" :
                lang = "fr";
                break;
            case "ru" :
                lang = "ru";
                break;
            default:
                lang = "default";
                break;
        }
        
        var allBannedWords = ""; //string with all the banned words
        loadBannedWordsList(lang)
            .then(function(listBannedWords) {
                allBannedWords = listBannedWords;
                if ( lang !== "default" ) { //it is necessary to merge language specified words with the default words list
                    return loadBannedWordsList("default");
                }
            })
            .then(function(defaultListBannedWords){
                if ( typeof(defaultListBannedWords) === "string" ) {
                    allBannedWords += defaultListBannedWords;
                }
                if ( typeof(allBannedWords) === "string"
                    && allBannedWords.length > 0 ) { //if got an Array with the banned words
                        window._gBannedWordsList = makeArray(allBannedWords);
                }
                resolve(true);
            })
            .catch(function(e){
                reject(e);
            });
    }    
);