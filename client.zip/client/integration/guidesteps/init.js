/*this is step by step guide for the application*/

/*global EnjoyHint*/
/*global $*/

const enjoyhint_script_steps = 
{
  "map" : [
    // {
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : 'Hello! This guide will explain you how to use this application. To go to the next step please swipe from left to right on the screen',
    //     ru  : 'Привет! Это руководство познакомит Вас с этим приложением. Для перехода к следующему шагу проведите по экрану слева направо' 
    //   }
    // },
    // {
    //   event    : 'next_slide',
    //   selector : "#ui-header-hiding",
    //   lang_description : {
    //     def : "To see the main menu you need to tap on the bottom of the screen, then hold it and swipe up",
    //     ru  : "Чтобы увидеть глваное меню нажмите на нижней части экрана, затем, удерживая, проведите вверх"
    //   },
    //   shape : "rect"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.getIntegrationPlugins().getPlugin("swipingMenu").open();  
    //   },
    //   event    : 'next_slide',
    //   selector : "#a_page_main",
    //   lang_description : {
    //     def : "This button shows you the main page with the map",
    //     ru  : "Эта кнопка показывает главную страницу с картой"
    //   },
    //   shape : "circle",
    //   radius : 15
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.getIntegrationPlugins().getPlugin("swipingMenu").open();  
    //   },
    //   event    : 'next_slide',
    //   selector : "#a_page_lookingtags",
    //   lang_description : {
    //     def : "This page helps to choose people around, which can to interest you",
    //     ru  : "Эта страница поможет выбрать тех людей вокруг, которые интересны вам"
    //   },
    //   shape : "circle",
    //   radius : 15
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.getIntegrationPlugins().getPlugin("swipingMenu").open();  
    //   },
    //   event    : 'next_slide',
    //   selector : "#a_page_about",
    //   lang_description : {
    //     def : "You need to fill some information about you and your current status on here",
    //     ru  : "Здесь вам необходимо заполнить немного информации о себе и вашем текущем состоянии"
    //   },
    //   shape : "circle",
    //   radius : 15
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.getIntegrationPlugins().getPlugin("swipingMenu").open();  
    //   },
    //   event    : 'next_slide',
    //   selector : "#a_page_users",
    //   lang_description : {
    //     def : "If you click on this button you will go to the user list. You can see information about all users around you, chat with them or watching their video broadcast",
    //     ru  : "Нажав на эту кнопку, вы увидите список пользователей, которые находятся вокруг вас. Вы сможете увидеть информацию о них, поговорить с ними или посмотреть видео трансляции этих пользователей"
    //   },
    //   shape : "circle",
    //   radius : 15
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.getIntegrationPlugins().getPlugin("swipingMenu").open();  
    //   },
    //   event    : 'next_slide',
    //   selector : "#a_videobroadcast",
    //   lang_description : {
    //     def : "Start video broadcast with the camera of your phone",
    //     ru  : "Начните видеотрансляцию с камеры своего телефона"
    //   },
    //   shape : "circle",
    //   radius : 15
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.getIntegrationPlugins().getPlugin("swipingMenu").open();  
    //   },
    //   event    : 'next_slide',
    //   selector : "#a_help",
    //   lang_description : {
    //     def : "Shows an information about the current page",
    //     ru  : "Показывает информацию о текущей странице"
    //   },
    //   shape : "circle",
    //   radius : 15
    // },
    // {
    //   event    : 'next_slide',
    //   selector : "#mapPageContainer",
    //   lang_description : {
    //     def : "This is the map, where you can see a people around you. People are shown as markers on the map. Click on a marker to see some information about the user or chat with him.",
    //     ru  : "Это карта, на которой вы видите людей вокруг. Люди на карте представлены как маркеры. Нажмите на маркер, чтобы увидеть информацию о пользователи или начать чат"
    //   },
    //   shape : "circle",
    //   radius : 15
    // },
    // {
    //   event    : 'next_slide',
    //   selector : "#mainMap_userMarker",
    //   lang_description : {
    //     def : "This is your marker. If you click on it will show you: 'This is you'.",
    //     ru  : "Это ваш маркер. Нажмите на него и он покажет вам: 'Это вы'"
    //   },
    //   shape : "circle",
    //   radius : 15
    // },
    // {
    //   event    : 'next_slide',
    //   selector : ".leaflet-control-layers",
    //   lang_description : {
    //     def : "Switching between the map layers is on here. Choose layer that you like and you will see how the map display will change",
    //     ru  : "Здесь вы можете переключать слои карты. Выберите слой который вам нравится и отображение карты изменится"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   event    : 'next_slide',
    //   selector : "#mainMap_showMe",
    //   lang_description : {
    //     def : "This is your marker. If you click on it will show you: 'This is you'",
    //     ru  : "Это ваш маркер. Нажмите на него и он покажет вам: 'Это вы'"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   event    : 'next_slide',
    //   selector : ".leaflet-control-geocoder",
    //   lang_description : {
    //     def : "Click on the magnifier, type an address and this will be shown for you on the map",
    //     ru  : "Нажмите на лупу, введите адрес и он будет показан вам на карте"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.getIntegrationPlugins().getPlugin("swipingMenu").open();  
    //   },
    //   event    : 'next_slide',
    //   selector : "#a_page_about",
    //   lang_description : {
    //     def : "For now, click on here to fill some information about yourself",
    //     ru  : "Нажмите здесь, чтобы заполнить информацию о себе"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.getIntegrationPlugins().getPlugin("swipingMenu").close();
    //     window.interface.showPage("aboutuser");
    //   },
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "This is the page with information about you and some settings. If you see a shaking element, that means, that this field is required to be filled out by some information",
    //     ru  : "Эта страница с информацией о вас и некоторыми настройками. Если вы увидели дрожащие элементы, это означает что они должны быть заполнены"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("aboutuser");
    //   },
    //   selector : '#page_about_header_navbar',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "This is navigation bar. You can switch between tabs by clicking on the buttons on here",
    //     ru  : "Это панель навигации. Вы можете переключаться на разные закладки, нажимая на кнопки, расположенные здесь"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("aboutuser");
    //     $("#a_page_about_tab_aboutme").click();
    //   },
    //   selector : '#a_page_about_tab_aboutme',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "On this tab you need to fill something important about yourself",
    //     ru  : "На этой закладке нужно заполнить кое-что важное о себе"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("aboutuser");
    //   },
    //   selector : '[data-ui-userproperty="name"]',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "Type your name right here",
    //     ru  : "Здесь введите своё имя"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("aboutuser");
    //   },
    //   selector : '[data-ui-userproperty="age"]',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "Type your age on here",
    //     ru  : "Здесь введите свой возраст"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("aboutuser");
    //   },
    //   selector : '[data-ui-userproperty="gender"]',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "Are you a male or a female?",
    //     ru  : "Вы мужчина или женщина?"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("aboutuser");
    //   },
    //   selector : '#photo',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "Please, log in to your profile and choose your photo from the Facebook",
    //     ru  : "Пожалуйста, войдите в ваш профиль и выберите своё фото на Facebook"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("aboutuser");
    //     $("#a_page_about_tab_mycontacts").click();
    //   },
    //   selector : '#a_page_about_tab_mycontacts',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "Please, go on here to specify your contacts",
    //     ru  : "Пожалуйста, заполните здесь свои контакты"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("aboutuser");
    //     $("#a_page_about_tab_mycontacts").click();
    //   },
    //   selector : '[data-ui-userproperty="phone"]',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "You can add your phone",
    //     ru  : "Вы можете указать ваш телефон"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("aboutuser");
    //     $("#a_page_about_tab_mycontacts").click();
    //   },
    //   selector : '[data-ui-userproperty="email"]',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "And email",
    //     ru  : "И электронную почту"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("aboutuser");
    //     $("#a_page_about_tab_mycontacts").click();
    //   },
    //   selector : '[data-ui-sociallinks]',
    //   event    : 'next_slide', event_type : 'custom',
    //   lang_description : {
    //     def : "Here you can specify links to a social profiles",
    //     ru  : "Здесь можно указать ссылки на социальные профили"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("aboutuser");
    //     $("#a_page_about_tab_mycontacts").click();
    //     $("[data-ui-sociallinks]").click();
    //   },
    //   event    : 'next_slide', event_type : 'custom',
    //   lang_description : {
    //     def : "This is a wide list of available social networks",
    //     ru  : "Это большой список доступных социальных сетей"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     $(".aTwitter").click();
    //   },
    //   event    : 'next_slide', event_type : 'custom',
    //   lang_description : {
    //     def : 'For example, choose one. Type your profile name (not a link, but a short string or your login) for this social network if you want (for exapmle, type "your_login" or "CoolGuy" or "CharmingGirl"). Click on any place outside the input box to close it',
    //     ru  : 'Для примера можно выбрать этот. Введите имя профиля для этой социальной сети. ( Не полную ссылку! Введите, например, ваш логин - "myLogin"). Нажмите где-либо чтобы закрыть поле ввода'
    //   },
    //   margin : 600,
    //   shape : "rectangle"
    // },
    // {
    //   event    : 'next_slide', event_type : 'custom',
    //   lang_description : {
    //     def : 'Click somewhere to close the list',
    //     ru  : 'Нажмите где-нибудь, чтобы закрыть список'
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     $(".icon-container").click();
    //   },
    //   event    : 'next_slide', event_type : 'custom',
    //   lang_description : {
    //     def : 'Excellent!',
    //     ru  : 'Отлично!'
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("aboutuser");
    //     $("#a_page_about_tab_mytags").click();
    //   },
    //   selector : '#a_page_about_tab_mytags',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "Here you can specify your status, tags to filter the users, that surround you and tags, that would describe you",
    //     ru  : "Здесь вы можете указать свой статус, теги для фильтрации пользователей, которые окружают вас и теги, которые описывают вас"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("aboutuser");
    //     $("#a_page_about_tab_mytags").click();
    //   },
    //   selector : '[data-ui-userproperty="status"]',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "What do you feel right now? What do you want to do? What would you like to share with others?",
    //     ru  : "Что вы чувствуете сейчас? Что бы вы хотели сделать? Чем бы вы хотели поделиться с другими?"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("aboutuser");
    //     $("#a_page_about_tab_mytags").click();
    //     $("#panel_mytags").panel("open");
    //   },
    //   selector : '[data-ui-userproperty="chosentags"]',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "Select a short words to describe yourself",
    //     ru  : "Выберите короткие слова, чтобы описать себя"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     $("#a_page_about_tab_mytags").click();
    //     $("#panel_mytags").panel("open");
    //   },
    //   selector : 'label[for="listview_availtagslist"]',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "Select a tag on here. Click to choose it",
    //     ru  : "Выберите тэг из списка. Нажмите, чтобы выбрать его"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     $("#panel_mytags").panel("open");
    //   },
    //   selector : 'label[for="listview_mytagslist"]',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "Selected tags are placed on here. They are visible for other users, who can choose you by this tags. Click on one to delete it from the list and make it invisible for others.",
    //     ru  : "Выбранные тэги размещены здесь. Они видны другим пользователям, которые могут выбрать вас по этим тэгам. Нажмите на один из них, чтобы удалить его из списка и сделать невидимым для других пользователей."
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     $("#panel_mytags").panel("close");
    //   },
    //   selector : '[data-ui-userproperty="lookingtags"]',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "Managing the displaying of the users, that have surround you",
    //     ru  : "Упарвление отображением пользователей вокруг вас"
    //   }, 
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     $("#panel_lookingtags").panel("open");
    //   },
    //   selector : 'label[for="panel_lookingtags-listview_availtagslist"]',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "Short words, which are describe that users,who may be of interest to you.",
    //     ru  : "Короткие слова, которые описывают тех пользователей, которые могут вас заинтересовать"
    //   }, 
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     $("#panel_lookingtags").panel("open");
    //   },
    //   selector : 'label[for="listview_lookingtagslist"]',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "Users around will be shown on the map only if they have a tags, that you had chosen into this list.",
    //     ru  : "Пользователи вокруг будут показаны на карте, только если у них есть тэги выбранные вами в этот список."
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     $("#panel_lookingtags").panel("close");
    //     $("#a_page_about_tab_appsettings").click();
    //   },
    //   selector : "#a_page_about_tab_appsettings",
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "Well done! Go ahead, to the application settings",
    //     ru  : "Хорошо! Идём дальше, к настройкам приложения "
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     $("#a_page_about_tab_appsettings").click();
    //   },
    //   selector : '[data-ui-userproperty="locationmethod"]',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "Choose a method for determining how the application must finding where you are located",
    //     ru  : "Выберите метод определения вашего местоположения"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     $("#a_page_about_tab_appsettings").click();
    //   },
    //   selector : 'label[for="radio-choice-location-1"]',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : 'The "Automatic" method is used to find you by the gps on your device. GPS must be turned on and permitted to use it for the browser(or for the application)',
    //     ru  : "Автоматический метод испльзуется чтобы найти вас по gps на вашем устройстве. GPS должен быть включен и разрешен к использованию браузером(или приложением)"
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     $("#a_page_about_tab_appsettings").click();
    //   },
    //   selector : 'label[for="radio-choice-location-2"]',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : 'The "Manual" method allows you to set your location by the manual dragging of your marker onto the right place on the map. You will display with the mark "Coordinates untrusted" for the others.',
    //     ru  : 'Ручной способ позволяет установить ваше местоположение ручным перетаскиванием маркера в нужное место на карте. Вы будите отображаться с пометкой "Coordinates untrusted" для других пользователей.'
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("main");
    //     window.interface.getIntegrationPlugins().getPlugin("swipingMenu").open();
    //   },
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "That's all on this page. Let's review the remaining pages",
    //     ru  : 'Давайте перейдём к оставшимся страницам'
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("main");
    //     window.interface.getIntegrationPlugins().getPlugin("swipingMenu").open();
    //   },
    //   selector : '#a_page_lookingtags',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "This page is for the quick access to the filtering tags",
    //     ru  : 'Эта страница для быстрого пользователя к тэгам'
    //   },
    //   shape : "circle",
    //   radius : 15
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("lookingtags");
    //     window.interface.getIntegrationPlugins().getPlugin("swipingMenu").close();
    //   },
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : 'This page is similar to the panel on the settings page. It allows you doing the same things with a quick access from the main page. You can filter a displayed people around on the map by the tags you choose on here',
    //     ru  : 'Эта страница аналогична панели со страницы настроек, но позволяет вам делать тоже самое имея быстрый доступ с главной страницы. Вы можете фильтровать отображающихся вокруг вас людей на карте'
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("lookingtags");
    //     window.interface.getIntegrationPlugins().getPlugin("swipingMenu").close();
    //   },
    //   selector : '#page_lookingtags_listview_availtagslist>li[data-ui-disabled]',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : 'Click on a tag from this list to allow the displaying of a people with this tag',
    //     ru  : 'Нажмите на какой-либо тэг из этого списка чтобы позволить отображаться пользователям с таким тэгом'
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("lookingtags");
    //   },
    //   selector : '#page_lookingtags_listview_lookingtagslist>li[data-ui-disabled]',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : 'All the tags that you had chosen is on here. Users, which have any tag from this list, will be displayed on the map.',
    //     ru  : 'Здесь находятся все выбранные вам тэги. Пользователи с каким-лиюо тэгом из этого списка будут отображаться на карте.'
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("lookingtags");
    //   },
    //   selector : '#a_btn_scrl_up_page_lookingtags_listview_lookingtagslist',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "This button is for scrolling up the list below",
    //     ru  : 'Эта кнопка для прокрутки вверх списка ниже'
    //   },
    //   shape : "circle",
    //   radius : 15
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("lookingtags");
    //   },
    //   selector : '#a_btn_scrl_down_page_lookingtags_listview_lookingtagslist',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "This is for scrolling down the same list",
    //     ru  : 'Эта кнопка для прокрутки вниз того же списка'
    //   },
    //   shape : "circle",
    //   radius : 15
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("lookingtags");
    //   },
    //   selector : '#a_btn_lookup_page_lookingtags_listview_lookingtagslist',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "It opens the input field for the tags list filtering.",
    //     ru  : 'Открывает поле ввода для фильтрации списка тэгов'
    //   },
    //   shape : "circle",
    //   radius : 15
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("lookingtags");
    //   },
    //   selector : '#a_panel_listview_lookingtagslist_page_lookingtags_listview_availtagslist',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : 'From this panel you can do the same, but with another list below it',
    //     ru  : 'Эта панель позволяет делать тоже самое, но с другим списком'
    //   },
    //   shape : "rectangle"
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("main");
    //     window.interface.getIntegrationPlugins().getPlugin("swipingMenu").open();
    //   },
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "Still quite a bit left to do",
    //     ru  : 'Ещё совсем немного'
    //   }
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("main");
    //     window.interface.getIntegrationPlugins().getPlugin("swipingMenu").open();
    //   },
    //   selector : '#a_page_users',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "This way",
    //     ru  : 'Нам сюда'
    //   },
    //   shape : "circle",
    //   radius : 15
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("listusers");
    //     window.interface.getIntegrationPlugins().getPlugin("swipingMenu").close();
    //   },
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "All the people around you will be shown on here",
    //     ru  : 'Все люди, находящиеся вокруг вас, будут показаны здесь'
    //   }
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("listusers");
    //     window.interface.getIntegrationPlugins().getPlugin("swipingMenu").close();
    //   },
    //   selector : "#page_users-visible_users",
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "People, which are visible as a markers on the map, are placed on here. They have chosen a tag, which was chosen by you as a one of the filtering tags on the previously reviewed page.",
    //     ru  : 'Люди, которые видны как маркеры на карте, расположены здесь. Они выбрали тэг, который был выбран вами в качестве фильтрующего тэга, на рассмотренной ранее странице.'
    //   }
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("listusers");
    //     window.interface.getIntegrationPlugins().getPlugin("swipingMenu").close();
    //   },
    //   selector : "#page_users-invisible_users",
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "Users who do not have a tags, that matches your 'filtering' tags, are placed on here. They are invisible on the map",
    //     ru  : 'Пользователи, у которых нет тэгов, совпадающих с вашими "фильтрующими" тэгами, находятся здесь.'
    //   }
    // },
    // {
    //   onBeforeStart : function() {
    //     window.interface.showPage("main");
    //     window.interface.getIntegrationPlugins().getPlugin("swipingMenu").open();
    //   },
    //   selector : '#a_videobroadcast',
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "And finally, let's look at the video broadcasting capability. It's at very early stage now",
    //     ru  : 'В заключении давайте посмотрим на возможности видеовещания. Сейчас оно на ранней стадии разработки.'
    //   },
    //   shape : "circle",
    //   radius : 15
    // },
    // {
    //   onBeforeStart : function() {
    //     const _interface = window.interface; 
    //     _interface.showPage("main");
    //     _interface.getIntegrationPlugins().getPlugin("swipingMenu").close();
    //     _interface.videoTranslation.showCameraPopup();
    //   },
    //   event    : 'next_slide',
    //   lang_description : {
    //     def : "You can broadcast video from a camera of your device to a people near you. This feature is like Periscope(tm) or will be.",
    //     ru  : 'Вы можете транслировать видео с камеры вашего устройства другим пользователям рядом с вами. Эта возможность похожа на Periscope(tm) или будет такой.'
    //   }
    // },
    {
      onBeforeStart : function() {
        const _interface = window.interface; 
        _interface.showPage("main");
        _interface.getIntegrationPlugins().getPlugin("swipingMenu").close();
        _interface.videoTranslation.showCameraPopup();
      },
      selector : '[name="jqi_state0_buttonStartbroadcasting"]',
      event    : 'next_slide',
      lang_description : {
        def : "Press this button to start broadcasting",
        ru  : 'Нажмите эту кнопку чтобы начать вещание'
      },
      shape : "rectangle"
    },
    {
      onBeforeStart : function() {
        const _interface = window.interface; 
        _interface.showPage("main");
        _interface.getIntegrationPlugins().getPlugin("swipingMenu").close();
        _interface.videoTranslation.showCameraPopup();
      },
      selector : '#videoTranslationBox',
      event    : 'next_slide',
      lang_description : {
        def : "The preview of your broadcast will be on here.",
        ru  : 'Предварительный просмотр вашего вещания будет здесь.'
      },
      shape : "rectangle"
    },
    {
      onBeforeStart : function() {
        const _interface = window.interface; 
        _interface.showPage("main");
        _interface.getIntegrationPlugins().getPlugin("swipingMenu").close();
        _interface.videoTranslation.showCameraPopup();
      },
      selector : '#videoTranslationBox_broadcastDescription',
      event    : 'next_slide',
      lang_description : {
        def : "You can specify a description for the broadcast.",
        ru  : 'Вы можете задать описание для трансляции.'
      },
      shape : "rectangle"
    },
    {
      onBeforeStart : function() {
        const _interface = window.interface; 
        _interface.showPage("main");
        debugger;
        _interface.videoTranslation.stopVideo();
      },
      event    : 'next_slide',
      lang_description : {
        def : "Hope you will enjoy all the features of this application. We will be glad to see you! Thank you and good luck!.",
        ru  : 'Надеемся что вы будите пользоваться всеми функциями этого приложения. Будем рады видесть Вас снова! Спасибо и удачи Вам!'
      }
    }
  ],
  def : [{
    event    : 'next_slide',
    lang_description : {
      def : "Sorry! There is no information about",
      ru  : "Извините! Инфрмация отсутствует"
    },  
  }]
};

this.enjoyhint_script_steps = enjoyhint_script_steps;

this.startTour = (function(pageName, language) {  
  
  if ( this.enjoyhint_instance != null ) { //clear the previous instance
    this.enjoyhint_instance.clear();  
  }  
  
  if ( this._uiWipe != null ) {
    const ev = new Event("touchwipestop"); //remove all listeners from DOM elements
    this._uiWipe.each(function(){
      this.dispatchEvent(ev);
    });
  }
  
  const enjoyhint_instance = this.enjoyhint_instance = new EnjoyHint({
    showSkip : false,
    showNext : false
  });
  
  var steps_desc = this.enjoyhint_script_steps[pageName];
  const flMakeDesc = steps_desc == null;
  if ( flMakeDesc === true ) {
    steps_desc = this.enjoyhint_script_steps["def"];
  }
  
  if ( steps_desc != null ) {
    if ( this.lang !== language //if the language for the guide is changed
    || flMakeDesc === true ) { //or necessary to rebuild for empty information
      const guideLang = this.lang = language; 
      
      //make the script configurqation for the specified interface language
      for( var i =0, len = steps_desc.length; i < len; i++ ) { //set description, specified for the chosen language
        var step = steps_desc[i];
        var lang_description = step.lang_description;
        var desc;
  
        if ( typeof(lang_description) === "string" ) {
          desc = lang_description;
        } else
          if ( lang_description != null ){
            if ( lang_description[guideLang] == null ) {
              desc = lang_description["def"];   
            } else {
              desc = lang_description[guideLang];
            }  
          }
        step.description = desc;
      }
    
    }
      
    enjoyhint_instance.set(steps_desc);
          
    const touchTrigger = (function(){
      this.trigger("next_slide");
    }).bind(enjoyhint_instance);
      
    const _uiWipe = this._uiWipe = $("div.enjoyhint_disable_events");  
    _uiWipe.touchwipe({
        wipeLeft : touchTrigger,
        min_move_y : 40,
        doNotCallListenersOnCancel : true
    });
    
    this.enjoyhint_instance.run();
    
  } 
}).bind(this);