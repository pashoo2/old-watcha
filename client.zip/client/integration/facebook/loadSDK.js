/*global FB*/
/*global hello*/

var thisModule = this;
thisModule.ready = 
    new Promise(function(res, rej){
         window.fbAsyncInit = function() {
            FB.init({
              appId      : '911820115617926',
              xfbml      : true,
              version    : 'v2.8'
            });
          };
        
          (function(d, s, id){
             var js, fjs = d.getElementsByTagName(s)[0];
             if (d.getElementById(id)) {return;}
             js = d.createElement(s); js.id = id;
             js.src = "//connect.facebook.net/en_US/sdk.js";
             fjs.parentNode.insertBefore(js, fjs);
           }(document, 'script', 'facebook-jssdk'));
    });
