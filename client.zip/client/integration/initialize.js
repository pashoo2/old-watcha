/*global $*/

/*
  window["_integrationPlugins"]
  methods:
    1) ready - promise, fulfilled when all integration plugins will be loaded, but not initiated
    2) getPlugin(pluginName) - object with methods and options, provided by the plugin
*/

var commonlib = require("commonlib");
var _baseURL = window.interfacePlugins.options.urlIntegration;

function getPlugin(pluginName) {
    var _integrationPlugins = window["_integrationPlugins"];
    if ( _integrationPlugins[pluginName] == null ) {
        return _integrationPlugins[pluginName] = {};    
    } else {
        return _integrationPlugins[pluginName];    
    } 
}

if ( window["_integrationPlugins"] == null ) { //global settings for integration
    var EventEmitter = require("eventemitter");
    var _integrationPlugins = window["_integrationPlugins"] = Object.create(new EventEmitter()); 
    _integrationPlugins.getPlugin = getPlugin;
    
    _integrationPlugins.ready = new Promise(
        function(resolve, reject){
            _integrationPlugins.on("ready", resolve);
        }
    );
    
}

/*
    initialize integration
*/
$.ajax({
    dataType: "json",
    url: commonlib.resolvePath(_baseURL,"/settings.json"),
    success: 
    function(objSettings, txtStatus, jqxhr) { //on setting for integration with another services is loading
        if (jqxhr.status === 200
            && objSettings != null
            && typeof(objSettings) === "object") {
                var _interfacePlugins = window.interfacePlugins;
                _interfacePlugins.integrationSettings = objSettings;
                
                var ajaxMethods = _interfacePlugins.ajax;
                var services = Object.keys(objSettings); //name of the services
                var toLoad = [],
                    ind = 0;
                for( var i = 0, len = services.length; i < len; i++ ) {
                    var serviceName = services[i];
                    var serviceURL  = commonlib.resolvePath(_baseURL, serviceName);
                    var serviceContentURL = commonlib.resolvePath(serviceURL, "content");
                    var settingsForService = objSettings[serviceName]; //settings for this service
                    
                    if ( window["_integrationPlugins"][serviceName] == null ) { //global object to save the integration plugin options
                        window["_integrationPlugins"][serviceName] = {};
                    }
                    
                    if ( settingsForService.css != null ) { //load css if it necessary
                        toLoad[ind++] = ajaxMethods.loadFile("css", settingsForService.css, serviceContentURL);
                    }
                    if ( settingsForService.js != null ) { //load js if it is necessary
                        toLoad[ind++] = ajaxMethods.loadFile("js", settingsForService.js, serviceContentURL);
                    }
                    if ( typeof(settingsForService.init) === "string" ) { //load and execute script file to initialize integration with the service
                        toLoad[ind++] = ajaxMethods.loadFile("ejs", settingsForService.init, serviceURL, getPlugin(serviceName) );
                    }
                }
                
                Promise.all(toLoad)
                    .then(function(){
                        window["_integrationPlugins"].emit("ready");   
                    });
                
        } else {
            console.log(txtStatus);
            console.log("Unable to load settings.json for integration modules");    
        }
    }
});