/*global $*/
var EventEmitter = require("eventemitter");
var commonlib = require("commonlib");

var htmlForChatBox = 
        '<table data-role="table" id="my-table" data-mode="ui-responsive" width="100%" height="100%">\
            <thead> \
            <tr> \
              <th></th> \
            </tr> \
            </thead> \
            <tbody> \
                <tr ><td>\
                    <ul data-role="listview" data-inset="true" data-chatbox-list-messages></ul> \
                </td></tr> \
                <tr><td> \
                    <textarea style="resize: none" data-chatbox-input-message></textarea> \
                    <label data-chatbox-show-state style="height: 1em; font-size:1em"></label> \
                    <button class="ui-btn" data-chatbox-send-message>Send</button> \
                </td></tr> \
            </tbody> \
        </table>';

var htmlForMessage = '<p><strong class="ui-li-aside" data-chatbox-message-head></strong></p> \
                      <p data-chatbox-message-body></p>';

/*
    make a chatbox DIV and add it to the document
*/
function chatbox(id) {
    var ui = this.ui = $("#" + id);
    if ( ui.length === 0 ) { //if chatbox container is not visible
        //ui = this.ui = $("<div></div>").appendTo("body");
        
        var docWidth = $(window.document).width();
        var docHeight = $(window.document).height();
        var popupHeight = docHeight * 0.7;
        
        ui = this.ui = 
            $(  '<div/>', 
                {   id: id,
                    html: this.htmlForChatBox }
            )
            .appendTo("body") //add chatbox div container
            .attr("style",
                "width : "  + ( docWidth * 0.7 ) + "px !important;" + "max-width : "  + ( docWidth * 0.7 ) + "px !important;" + "height : "  + popupHeight + "px !important;" + "max-height : "  + popupHeight + "px !important"
            );
    }
    
    var listMessagesHeight = (popupHeight * 0.6);
    this.listMessages = 
        ui.find('[data-chatbox-list-messages]') //ui element, contains messages
        .attr("style", 
            "min-height: " + listMessagesHeight + "px !important; max-height: " + listMessagesHeight + "px !important; overflow-y: auto !important"
        );
        
    this.contentMessage = ui.find('[data-chatbox-input-message]'); //input field with text of the message
    this.btnSend = this.ui.find('[data-chatbox-send-message]');
    this.uiState = this.ui.find('[data-chatbox-show-state]');
   
    this.btnSend.on('click', this.sendMessage.bind(this)); //onclick send button
    
    //create popup
    ui
    .trigger('create')
    .enhanceWithin() //make all jquery enchancments for added elements
    .popup(this.optionspopup);
    
    this.uiState.hide({duration :0}); //hide the state label
    
    this.setListenersForChatbox(); //listen for close events of chatbox ui   
    
    this.closed = true; //if popup closed
    
    this.userID = null;
    
}

/*
    events : send(userID, message)
*/
chatbox.prototype = Object.create(new EventEmitter());

/*
    options for jquery mobile popup widget
*/
chatbox.prototype.optionspopup = {
    positionTo: "window",
    shadow : true,
    theme : "a",
    overlayTheme : "b",
    transition: "pop"
};

/*
    layouts
*/
chatbox.prototype.htmlForChatBox = htmlForChatBox;
chatbox.prototype.htmlForMessage = htmlForMessage;

/*
    listen for some events fired by chatbox ui
*/
chatbox.prototype.setListenersForChatbox = function() {
    var chatbox = this;
    chatbox.ui.on( "popupafterclose", chatbox.close.bind(this) );
    chatbox.ui.on( "popupafteropen" , chatbox.open.bind(this)  );
};

/*
    open the chatbox window
*/
chatbox.prototype.open = function(userID){
    
    if ( typeof(userID) === "string"
       || typeof(userID) === "number" ) {
            this.userID = userID; //set the current user ID
    }
    
    this.closed = false; //change the state

    this
        .ui
        .enhanceWithin()
        .removeClass('PopUp')
        .addClass('PopUp-focus')
        .popup("open");
    
    this.listMessages.scrollTop(this.listMessages.height()); //scroll to the borrom of the messages list
    this.unlockSendButton(userID);
    
};

/*
    close the chatbox window
*/
chatbox.prototype.close = function(userID){
    
    if ( this.userID === userID ) { //if the user to close chatbox is equals to the current user
        this.listMessages.empty(); //clean the messages list
        this.closed = true;
        this.ui.popup("close");
    }
    
};

/*
    show message in the chat window
*/
chatbox.prototype.showMessage = function(message, userID, flDoNotOpen) {
       
    if ( typeof(userID) === "boolean" ) {
        flDoNotOpen = userID;
        userID = null;    
    } 
        
    if ( this.closed === false //if shown on the screen
        && userID !== this.userID ) { //and the message is not from the current user
            return; //do not show the message    
    }
        
    var uiMessage = 
            $("<div></div>")
            .html(this.htmlForMessage)
            .appendTo(this.listMessages);
    
    var msgHead,
        msgBody;
        
    if ( message instanceof Error ) {
        msgHead = "Error";
        msgBody = message.message;
    } else {
        msgHead = commonlib.getMessageHeadFromDescriptionObj(message);
        msgBody = commonlib.getMessageUserFromDescriptionObj(message) + " : " + commonlib.getMessageTextFromDescriptionObj(message);    
    }
    
    uiMessage.children("[data-chatbox-message-head]").html(msgHead);
    uiMessage.children("[data-chatbox-message-body]").html(msgBody);
    
    if ( flDoNotOpen !== true ) {
        this.open(userID);
    }
    
};

/*
    show messages in the chat window
    messages - array with message object
*/
chatbox.prototype.showMessages = function(messages, userID, flDoNotOpen){
    
    if ( typeof(userID) === "boolean" ) {
        flDoNotOpen = userID;
        userID = null;
    } else
        if ( typeof(userID) === "string"
            || typeof(userID) === "number" ) {
                this.userID = userID; //set the current user ID
        }
    
    this.listMessages.empty(); //delete all previous messages from the list
    
    if ( Array.isArray(messages) === true ) { //if it is array
        for( var i = 0, len = messages.length; i < len; i++ ) {
            this.showMessage(messages[i], userID, true);
        }
    }
    
    if ( flDoNotOpen !== true ) {
        this.open();
    }
        
};

/*
    emit the event "send"
*/
chatbox.prototype.sendMessage = function(){
    this.emit("send", this.userID, this.contentMessage.val());   //emit "send" event
    this.contentMessage.val(""); //clear the message in input field
};

/*
    et the text for the current state and show it if hidden
*/
chatbox.prototype.showState = function(userID, text) {
   if ( this.userID === userID ) {
        this.uiState.show('fast').text('State : ' + text); //show the state string
    }  
};

/*
    set the text for the current state but not show it if hidden
*/
chatbox.prototype.setStateText = function(userID, text) {
   if ( this.userID === userID ) {
        this.uiState.text(text); //show the state string
    }  
};

/*
    return true or false if the send button is locked or not
*/
chatbox.prototype.isSendButtonLocked = function() {
    return this.btnSend.prop('disabled') === 'disabled';
};

/*disable the send button*/
chatbox.prototype.lockSendButton = function(userID, state) {
    if ( this.userID === userID ) {
        if ( typeof(state) === "string" ) {
            this.showState(userID, state); //show the state string
        }
        return this.btnSend.prop('disabled', 'disabled');    
    }
};

/*enable the send button*/
chatbox.prototype.unlockSendButton = function(userID) {
    if ( this.userID === userID ) {
        this.uiState.hide('slow'); //hide the state string
        debugger;
        return this.btnSend.prop('disabled', ''); //unloch the button for a click
    }
};
window.chatbox = new chatbox("chatbox");