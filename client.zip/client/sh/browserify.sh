#!/bin/bash
cd .. &&
( [ -d ./sourcesJS ] && [ -d ./b ] ) &&
(
    cd ./sourcesJS &&
    (
        ([ -f ./_mainpatterns.js ] && (echo "browserify mainpatterns" && browserify --no-bundle-external  -r ./_mainpatterns.js:mainpatterns -o ../b/mainpatterns.js) || echo "Not found .sourcesJS/_mainpatterns.js") &&
        ([ -f ./_commonlib.js ] && (echo "browserify commonlib" && browserify --no-bundle-external -r ./_commonlib.js:commonlib -o ../b/commonlib.js) || echo "Not found ./sourcesJS/_commonlib.js") &&
        ([ -f ./_glib.js ] && (echo "browserify glib" && browserify --no-bundle-external -r ./_glib.js:glib -o ../b/glib.js) || echo "Not found ./sourcesJS/_glib.js") &&
        ([ -f ./_neighborUser.js ] && (echo "browserify neighborUser" && browserify --no-bundle-external -r ./_neighborUser.js:NeighborUser -o ../b/neighborUser.js) || echo "Not found ./sourcesJS/_neighborUser.js") &&
        ([ -f ./_user.js ] && (echo "browserify user" && browserify --no-bundle-external -r ./_user.js:User -o ../b/user.js) || echo "Not found ./sourcesJS/_user.js") &&
        ([ -f ./_timestamps.js ] && (echo "browserify timestamps" && browserify -r ./_timestamps.js:timestamps -o ../b/timestamps.js) || echo "Not found ./sourcesJS/_timestamps.js") &&
        ([ -f ./_timeIntervals.js ] && (echo "browserify timeIntervals" && browserify -r ./_timeIntervals.js:timeIntervals -o ../b/timeIntervals.js) || echo "Not found ./sourcesJS/_timeIntervals.js") &&
        ([ -f ./_mainpeer.js ] && (echo "browserify mainpeer" && browserify --no-bundle-external -r ./_mainpeer.js:mainpeer -o ../b/mainpeer.js) || echo "Not found ./sourcesJS/_mainpeer.js") &&
        ([ -f ./_ILS.js ] && (echo "browserify ILS" && browserify --no-bundle-external -r ./_ILS.js:InnerLocalServer -o ../b/ILS.js) || echo "Not found ./sourcesJS/_ILS.js") &&
        ([ -f ./_ELS.js ] && (echo "browserify ELS" && browserify --no-bundle-external -r ./_ELS.js:ExternalLocalServer -o ../b/ELS.js) || echo "Not found ./sourcesJS/_ELS.js") &&
        ([ -f ./_validatorsMainPeer.js ] && (echo "browserify validatorsMainPeer" && browserify --no-bundle-external  -r ./_validatorsMainPeer.js:validatorsMainPeer -o ../b/validatorsMainPeer.js) || echo "Not found ./sourcesJS/_validatorsMainPeer.js") &&
        ([ -f ./_validatorsILS.js ] && (echo "browserify validatorsILS" && browserify --no-bundle-external  -r ./_validatorsILS.js:validatorsILS -o ../b/validatorsILS.js) || echo "Not found ./sourcesJS/_validatorsILS.js") &&
        ([ -f ./_validatorsELS.js ] && (echo "browserify validatorsELS" && browserify --no-bundle-external  -r ./_validatorsELS.js:validatorsELS -o ../b/validatorsELS.js) || echo "Not found ./sourcesJS/_validatorsELS.js") &&
        ([ -f ./_validatorsUser.js ] && (echo "browserify validatorsUser" && browserify --no-bundle-external  -r ./_validatorsUser.js:validatorsUser -o ../b/validatorsUser.js) || echo "Not found ./sourcesJS/_validatorsUser.js") &&
        ([ -f ./_globalSettings.js ] && (echo "browserify globalSettings" && browserify --no-bundle-external -r ./_globalSettings.js:globalSettings -o ../b/globalSettings.js) || echo "Not found ./sourcesJS/_globalSettings.js") &&
        ([ -f ./_logger.js ] && (echo "browserify logger" && browserify -x globalSettings -r ./_logger.js:logger -o ../b/logger.js) || echo "Not found ./sourcesJS/_logger.js") &&
        ([ -f ./_connectorWithMainThread.js ] && (echo "browserify connectorWithMainThread" && browserify --no-bundle-external -r ./_connectorWithMainThread.js:ConnectorWithMainThread -o ../b/connectorWithMainThread.js) || echo "Not found ./sourcesJS/_connectorWithMainThread.js") &&
        ([ -f ./_connectorWithAppWorker.js ] && (echo "browserify ConnectorAppWorker" && browserify --no-bundle-external -r ./_connectorWithAppWorker.js:ConnectorWithAppWorker -o ../b/connectorWithAppWorker.js) || echo "Not found ./sourcesJS/_connectorWithAppWorker.js") &&
        ([ -f ./_dataConnector.js ] && (echo "browserify DataConnector" && browserify -x logger -x eventemitter --no-bundle-external -r ./_dataConnector.js:DataConnector -o ../b/dataConnector.js) || echo "Not found ./sourcesJS/_dataConnector.js") &&
        ([ -f ./_webWorkerDataConnection.js ] && (echo "browserify WebWorkerDataConnection" && browserify --no-bundle-external -r ./_webWorkerDataConnection.js:WebWorkerDataConnection -o ../b/webWorkerDataConnection.js) || echo "Not found ./sourcesJS/_WebWorkerDataConnection.js") &&
        ([ -f ./_commandsListener.js ] && (echo "browserify CommandsListener" && browserify --no-bundle-external -r ./_commandsListener.js:CommandsListener -o ../b/commandsListener.js) || echo "Not found ./sourcesJS/_commandsListener.js") &&
        ([ -f ./_libMainP2P.js ] && (echo "browserify libMainP2P" && browserify --no-bundle-external -r ./_libMainP2P.js:libMainP2P -o ../b/libMainP2P.js) || echo "Not found ./sourcesJS/_libMainP2Ps.js") &&
        ([ -f ./_messagingconnection.js ] && (echo "browserify MessagingConnection" && browserify --no-bundle-external -r ./_messagingconnection.js:MessagingConnection -o ../b/messagingconnection.js) || echo "Not found ./sourcesJS/_messagingconnection.js") &&
        ([ -f ./_mainmap.js ] && (echo "browserify MainMap" && browserify --no-bundle-external -r ./_mainmap.js:MainMap -o ../b/mainmap.js) || echo "Not found ./sourcesJS/_mainmap.js") &&
        ([ -f ./_interface.js ] && (echo "browserify UI" && browserify --no-bundle-external -r ./_interface.js:UI -o ../b/interface.js) || echo "Not found ./sourcesJS/_interface.js") &&
        ([ -f ./_interfacePlugins.js ] && (echo "browserify interfacePlugins" && browserify --no-bundle-external -r ./_interfacePlugins.js:interfacePlugins -o ../b/interfacePlugins.js) || echo "Not found ./sourcesJS/_interfacePlugins.js") &&
        ([ -f ./_positionWatcher.js ] && (echo "browserify positionWatcher" && browserify --no-bundle-external -r ./_positionWatcher.js:positionWatcher -o ../b/positionWatcher.js) || echo "Not found ./sourcesJS/_positionWatcher.js")
    )
) || echo "./sourcesJS or ./b not found"