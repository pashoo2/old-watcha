#!/bin/bash
cd .. &&
( [ -d ./sourcesJS ] && [ -d ./b ] ) &&
(
    cd ./sourcesJS &&
    (
        ([ -f ./_mainpeer.js ] && (echo "browserify mainpeer" && browserify --no-bundle-external -r ./_mainpeer.js:mainpeer -o ../b/mainpeer.js) || echo "Not found ./sourcesJS/_mainpeer.js") &&
        ([ -f ./_ILS.js ] && (echo "browserify ILS" && browserify --no-bundle-external -r ./_ILS.js:InnerLocalServer -o ../b/ILS.js) || echo "Not found ./sourcesJS/_ILS.js") &&
        ([ -f ./_ELS.js ] && (echo "browserify ELS" && browserify --no-bundle-external -r ./_ELS.js:ExternalLocalServer -o ../b/ELS.js) || echo "Not found ./sourcesJS/_ELS.js") &&
        ([ -f ./_validatorsMainPeer.js ] && (echo "browserify validatorsMainPeer" && browserify --no-bundle-external  -r ./_validatorsMainPeer.js:validatorsMainPeer -o ../b/validatorsMainPeer.js) || echo "Not found ./sourcesJS/_validatorsMainPeer.js") &&
        ([ -f ./_validatorsILS.js ] && (echo "browserify validatorsILS" && browserify --no-bundle-external  -r ./_validatorsILS.js:validatorsILS -o ../b/validatorsILS.js) || echo "Not found ./sourcesJS/_validatorsILS.js") &&
        ([ -f ./_validatorsELS.js ] && (echo "browserify validatorsELS" && browserify --no-bundle-external  -r ./_validatorsELS.js:validatorsELS -o ../b/validatorsELS.js) || echo "Not found ./sourcesJS/_validatorsELS.js") &&
        ([ -f ./_globalSettings.js ] && (echo "browserify globalSettings" && browserify -r ./_globalSettings.js:globalSettings -o ../b/globalSettings.js) || echo "Not found ./sourcesJS/_globalSettings.js") &&
        ([ -f ./_connectorWithMainThread.js ] && (echo "browserify connectorWithMainThread" && browserify --no-bundle-external -r ./_connectorWithMainThread.js:ConnectorWithMainThread -o ../b/connectorWithMainThread.js) || echo "Not found ./sourcesJS/_connectorWithMainThread.js") &&
        ([ -f ./_connectorWithAppWorker.js ] && (echo "browserify ConnectorWithAppWorker" && browserify --no-bundle-external -r ./_connectorWithAppWorker.js:ConnectorWithAppWorker -o ../b/сonnectorWithAppWorker.js) || echo "Not found ./sourcesJS/_connectorWithAppWorker.js") &&
        ([ -f ./_dataConnector.js ] && (echo "browserify DataConnector" && browserify -x logger -x eventemitter --no-bundle-external -r ./_dataConnector.js:DataConnector -o ../b/dataConnector.js) || echo "Not found ./sourcesJS/_dataConnector.js") &&
        ([ -f ./_timeIntervals.js ] && (echo "browserify timeIntervals" && browserify -r ./_timeIntervals.js:timeIntervals -o ../b/timeIntervals.js) || echo "Not found ./sourcesJS/_timeIntervals.js") &&
        ([ -f ./_webWorkerDataConnection.js ] && (echo "browserify WebWorkerDataConnection" && browserify --no-bundle-external -r ./_webWorkerDataConnection.js:WebWorkerDataConnection -o ../b/webWorkerDataConnection.js) || echo "Not found ./sourcesJS/_WebWorkerDataConnection.js") &&
        ([ -f ./_validatorsMainPeer.js ] && (echo "browserify validatorsMainPeer" && browserify --no-bundle-external  -r ./_validatorsMainPeer.js:validatorsMainPeer -o ../b/validatorsMainPeer.js) || echo "Not found ./sourcesJS/_validatorsMainPeer.js") &&
        ([ -f ./_validatorsILS.js ] && (echo "browserify validatorsILS" && browserify --no-bundle-external  -r ./_validatorsILS.js:validatorsILS -o ../b/validatorsILS.js) || echo "Not found ./sourcesJS/_validatorsILS.js") &&
        ([ -f ./_validatorsELS.js ] && (echo "browserify validatorsELS" && browserify --no-bundle-external  -r ./_validatorsELS.js:validatorsELS -o ../b/validatorsELS.js) || echo "Not found ./sourcesJS/_validatorsELS.js") &&
        ([ -f ./_mainpatterns.js ] && (echo "browserify mainpatterns" && browserify --no-bundle-external  -r ./_mainpatterns.js:mainpatterns -o ../b/mainpatterns.js) || echo "Not found .sourcesJS/_mainpatterns.js") &&
        ([ -f ./_hidden.js ] && (echo "browserify hidden" && browserify --no-bundle-external  -r ./_hidden.js:hidden -o ../b/hidden.js) || echo "Not found .sourcesJS/_hidden.js")
       
   )
) || echo "./sourcesJS or ./b not found"    