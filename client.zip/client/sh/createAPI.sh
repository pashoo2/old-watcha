#!/bin/bash
cd ../sourcesJS &&
((smartcomments --generate) || ( (npm install -g smartcomments) && (smartcomments --generate) )) &&
cd .. &&
((yuidoc -c yuidoc.json) || ( (npm install -g yuidocjs) && (yuidoc -c yuidoc.json) ))