#!/bin/bash
cd .. &&
( [ -d ./sourcesJS ] && [ -d ./b ] ) &&
(
    cd ./sourcesJS &&
    (
        ([ -f ./_dataConnector.js ] && (echo "browserify DataConnector" && browserify -x commonlib -x logger -x eventemitter -x WebWorkerDataConnection -r ./_dataConnector.js:DataConnector -o ../b/dataConnector.js) || echo "Not found ./sourcesJS/_dataConnector.js") &
        ([ -f ./_WebWorkerDataConnection.js ] && (echo "browserify WebWorkerDataConnection" && browserify -x logger -x eventemitter -r ./_WebWorkerDataConnection.js:WebWorkerDataConnection -o ../b/WebWorkerDataConnection.js) || echo "Not found ./sourcesJS/_WebWorkerDataConnection.js")
    )
) || echo "./sourcesJS or ./b not found"    