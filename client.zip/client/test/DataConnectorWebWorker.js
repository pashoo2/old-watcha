importScripts("../libJS/eventemitter.js"); //<!-- eventemitter	-->
importScripts("../libJS/setImmediate2.js");// <!-- setimmediate2	-->
importScripts("../libJS/JSONWebWorker/json.async.js"); //add JSON.parseAsync and JSON.stringifyAsync
importScripts("../libJS/JSONWebWorker/json.worker.js");
importScripts("../libJS/jsonTry.js");

importScripts("../b/globalSettings.js"); //<!--logger        -->
importScripts("../b/logger.js"); //<!--logger        -->
importScripts("../b/WebWorkerDataConnection.js"); //<!--WebWorkerDataConnection        -->
importScripts("../b/dataConnector.js"); //<!--DataConnector        -->
importScripts("../b/commonlib.js"); //<!--commonlib        -->
importScripts("../b/commandsListener.js"); //<!--CommandsListener        -->

var DataConnector = require("DataConnector").DataConnector;
var dataConnector = new DataConnector(); //instanceof DataConnector
var prevJSONParse = JSON.parse;
JSON.parse = function(data){
    var res;
    try{
        res = prevJSONParse.call(this, data);
    } catch(e) {
        if ( typeof(data) === "string" ) {
            res = data;    
        } else {
            res = null;    
        }   
    }
    return res;
};

self.onmessage = function(msg){
    var message = msg.data;
    switch( message ) {
        case "start":
           dataConnector.open()
            .then(function(userID){
                console.log(userID);
                dataConnector.socket.on("message", function(msg){
                   dataConnector.socket.send({type:"1", kind: "ddd"});
                });
            });
            dataConnector.on("connection", function(connection){
                console.log("incoming connection");
                console.log(connection.metadata);
                connection.on("data", function(data){
                    console.log(data);
                    connection.send("hi");
                    connection.num = connection.num || 1;
                    connection.num++;
                    if ( connection.num > 2 ) {
                        connection.close();    
                    }
                });
                connection.on("close", function(data){
                    console.log("CONNECTION CLOSED!");  
                });
            });
        break;
        case "conn":
            var connection = dataConnector.connect(12223, {metadata:{_test:true}});
            connection.on("open", function() {
                console.log("connection opened");
                connection.send("hello");
                connection.on("data", function(data){
                    console.log(data);
                    connection.send("hello");
                });
                connection.on("close", function(data){
                    console.log("Data connection closed");    
                });
            }); 
            var connection2 = dataConnector.connect(12224, {metadata:{_test:true}});
            connection2.on("open", function() {
                console.log("connection opened");
                connection2.send("hello");
                connection2.on("data", function(data){
                    console.log(data);
                    connection2.send("hello");
                });
                connection2.on("close", function(data){
                    console.log("Data connection closed");    
                });
            });
        default:
            if ( Array.isArray(message) === true )
            switch( message[0] ) {
                case "JSONMessagePort":
                    JSON._setMessagePort(message[1]);
                    break;
                case "DataConnectorPort":
                    dataConnector.setMessagePort(message[1]);
                    break;
            }    
        break;
    }
};