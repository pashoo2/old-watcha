var connected = 0;
var ports = [];
self.onconnect = function(ev){
    var port = ev.ports[0];    
    port.onmessage = function(ev){
        console.log(ev.data);    
    };
    port.start();
    ports.push(port);
};

setInterval(
    function(){
        for( var i =0, len = ports.length; i < len; i++ ) {
            var port = ports[i];
            port.postMessage("Port num: " + i);
        }    
    }, 5000    
);