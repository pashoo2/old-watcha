Измененные библиотеки:
1)peerMy
3)jsenMy