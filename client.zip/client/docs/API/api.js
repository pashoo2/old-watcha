YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "ExternalLocalServer",
        "InnerLocalServer",
        "MainP2P"
    ],
    "modules": [],
    "allModules": [],
    "elements": []
} };
});