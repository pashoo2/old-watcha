self.dataMaskPatterns = {  
    phone : "0000000000"
};