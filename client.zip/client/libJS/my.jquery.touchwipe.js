/**
 * jQuery Plugin to obtain touch gestures from iPhone, iPod Touch and iPad, should also work with Android mobile phones (not tested yet!)
 * Common usage: wipe images (left and right to show the previous or next image)
 * 
 * @author Andreas Waltl, netCU Internetagentur (http://www.netcu.de)
 * @version 1.1.1 (9th December 2010) - fix bug (older IE's had problems)
 * @version 1.1 (1st September 2010) - support wipe up and wipe down
 * @version 1.0 (15th July 2010)
 */
(function($) { 
   $.fn.touchwipe = function(settings) {
     var _config = {
    		min_move_x: 20,
    		min_move_y: 20,
 			wipeLeft: function() { },
 			wipeRight: function() { },
 			wipeUp: function() { },
 			wipeDown: function() { },
 			Touch: function() { },
			preventDefaultEvents: true,
			cancelTouch : false,
			doNotCallListenersOnCancel : false
	 };
     
     if (settings) $.extend(_config, settings);
 
     this.each(function() {
    	 var startX;
    	 var startY;
		 
		 const config = _config;
		 const _self = this;
		 const _ui = $(this);
		 const isMobile = $.browser.mobile === true;
		 
		 var last_dy = 0;
		 var last_dx = 0;
		 
    	 var isMoving = false;
   		 var isDragging = false;
   		
    	 function cancelTouch() {
    		if ( isMoving === true ) {
	    		_self.removeEventListener( isMobile === true ? 'touchmove' : 'mousemove', onTouchMove);
		    	startX = null;
		    	isMoving = false;
		    	
		    	if ( config.doNotCallListenersOnCancel === true
		    		&& isDragging !== true ) {
		    	} else {
				    //call all listeners with undefined to inform them about the moving's end
					config.wipeLeft(_ui, undefined, last_dx);
					config.wipeRight(_ui, undefined, last_dx);
					config.wipeUp(_ui, undefined, last_dy);
					config.wipeDown(_ui, undefined, last_dy);
		    	}
		    	
		    	isDragging = false;
    		}
    	 }	
    	 
    	 function onTouchMove(e) {
    		 if(isMoving === true
    			&& config.preventDefaultEvents === true) {
    				e.preventDefault();
    		 }
    		 
    		 if ( isMoving === true
    			&& isMobile !== true
    			&& e.buttons === 0 ) { //if no buttons pressed on mouse when it is moving on menu
	    			cancelTouch();	

	    	 } else
    		 
    		 if(isMoving === true) {
	    		 
	    		 var x = isMobile === true ? e.touches[0].pageX : e.clientX;
	    		 var y = isMobile === true ? e.touches[0].pageY : e.clientY;
	    		 var dx = startX - x;
	    		 var dy = startY - y;
	    		 if(Math.abs(dx) >= config.min_move_x) {
	    		 	if ( config.cancelTouch == true ) {
	    				cancelTouch();
	    		 	}
	    			if(dx > 0) {
	    				config.wipeLeft(_ui, dx, last_dx);
	    			}
	    			else {
	    				config.wipeRight(_ui, dx, last_dx);
	    			}
	    			last_dx = dx;
	    			isDragging = true;
	    		 }
	    		 else if(Math.abs(dy) >= config.min_move_y) {
		    			if ( config.cancelTouch == true ) {
		    				cancelTouch();
		    		 	}
		    			if(dy > 0) {
		    				config.wipeDown(_ui, dy, last_dy);
		    			}
		    			else {
		    				config.wipeUp(_ui, dy, last_dy);
		    			}
		    			last_dy = dy;
		    			isDragging = true;
		    		 }
    		 }
    	 }
    	 
    	 function onTouchStart(e)
    	 {
    		 if ( ( isMobile === true 
    				&& e.touches.length == 1 )
    			 || isMobile === false ) {
	    			startX = isMobile === true ? e.touches[0].pageX : e.clientX;
	    			startY = isMobile === true ? e.touches[0].pageY : e.clientY;
	    			isMoving = true;	
	    			config.Touch(_ui);
	    			this.addEventListener( isMobile === true ? 'touchmove' : 'mousemove', onTouchMove, false);
    		 }
    		 
    	 }    	 
    	 
    	 this.addEventListener(isMobile === true ? 'touchstart' : 'mousedown', onTouchStart, false);
    	 this.addEventListener(isMobile === true ? 'touchend'   : 'mouseup', cancelTouch , false);
    	 
    	 if ( isMobile !== true ) { //if mouseup not on the element
    		document.body.addEventListener('mouseup', cancelTouch , false);		
    	 }
    	 
    	function removeAllListeners() {
            _self.removeEventListener( isMobile === true ? 'touchmove' : 'mousemove' , onTouchMove , false);
            _self.removeEventListener( isMobile === true ? 'touchstart' : 'mousedown', onTouchStart, false);
            _self.removeEventListener( isMobile === true ? 'touchend'   : 'mouseup'  , cancelTouch , false);
            if ( isMobile !== true ) { //if mouseup not on the element
                document.body.removeEventListener('mouseup', cancelTouch , false);		
            }

            _self.removeEventListener("touchwipestop", removeAllListeners);
        }
    	 
    	 this.addEventListener(
    	     "touchwipestop", 
        	 removeAllListeners
    	 );
    	 
     });
 
     return this;
   };
 
 })(jQuery);