//try to parse the data, if can't return dat if it is a string or null if it is not
var prevJSONParse = JSON.parse;
JSON.parse = function(data){
    var res;
    try{
        res = prevJSONParse.call(this, data);
    } catch(e) {
        if ( typeof(data) === "string" ) {
            res = data;    
        } else {
            throw e;    
        }   
    }
    return res;
};