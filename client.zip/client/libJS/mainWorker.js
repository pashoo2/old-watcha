//start and handle connection of the main thread with the gClient thread
var MainP2P, InnerLocalServer, ExternalLocalServer;

//libjs
importScripts("../libJS/JSONWebWorker/json.async.js");
importScripts("../libJS/peerMy.js"); //<!-- eventemitter	-->
importScripts("../libJS/eventemitter.js"); //<!-- eventemitter	-->
importScripts("../libJS/setImmediate2.js");// <!-- setimmediate2	-->
importScripts("../libJS/jsenMy.js"); //<!-- setimmediate2	-->
importScripts("../libJS/jsonTry.js"); //JSON parse with try catch

//browserified
importScripts("../b/geolib.js");       //<!-- geolib -->
importScripts("../b/commonlib.js");     //<!--commonlib		-->
importScripts("../b/mainpatterns.js"); // <!--mainpatterns    -->
importScripts("../b/timestamps.js");   // <!--timestamps      -->
importScripts("../b/mainpeer.js");     // <!--mainpeer        -->
importScripts("../b/ELS.js"); <!--//ELS        -->
importScripts("../b/mainfunctions.js");// <!--mainfunctions        -->
importScripts("../b/timeIntervals.js"); //<!--timeIntervals        -->
importScripts("../b/ILS.js"); <!--//ILS        -->
importScripts("../b/validatorsMainPeer.js");// <!--validatorsMainPeer        -->
importScripts("../b/validatorsELS.js"); //<!--validatorsELS        -->
importScripts("../b/validatorsILS.js"); //<!--validatorsELS        -->
importScripts("../b/user.js"); //<!--//user        -->
importScripts("../b/handlerMessagesAppWorker.js"); //<!--handlerMessagesAppWorker        -->
importScripts("../b/globalSettings.js"); //<!--globalSettings        -->
importScripts("../b/logger.js"); //<!--logger        -->
importScripts("../b/WebWorkerDataConnection.js"); //<!--WebWorkerDataConnection        -->
importScripts("../b/dataConnector.js"); //<!--DataConnector        -->

MainP2P = require("mainpeer").mainpeer;
InnerLocalServer = require("ILS").ILS;
ExternalLocalServer = require("ELS").ELS;

var logger = require("logger").logger;
var commonlib     = require("commonlib");

//object to control and handling messages for and of the gClient
//workerGlobalContext - global context of the worker 
//EventEmitter
function AppWorker(workerGlobalContext) {
    this.thread = workerGlobalContext; //reference to the worker global context
    this.onmessage = this.onMessageMainThread.bind(this);
    self.onmessage = this.onmessage;
};

var AppWorkerProto = Object.create(new EventEmitter());

//set message port of the JSON shared worker, that execute JSON metods in a child thread
AppWorkerProto.setJSONMessagePort = function(messagePort){
    if ( JSON._setMessagePort !== undefined ) { //if the JSON method for setting a message port is available
        JSON._setMessagePort(messagePort);    
    }   
};

//define handlers for a messages from the main thread
//structure for object: {messageType:{ messageKind : functionHandler }}
//messageType = type of a message
//messageKind = kind of a message
//functionHandler = function (messageBody){...}
var messagesHandlers = {
    "main" : {
        "start" : onStart
    },
    "settings" : {
        "JSONMessagePort" : ["ww_setJSONMessagePort", null]  //message port of the json shared worker is received. This is message only for the ww side  
    }
}

//message from the main thread with the structure : { type, kind, body }
AppWorkerProto.onMessageMainThread = function(msg){
    var message = msg.data;
    //validate the message structure
    if ( commonlib.hasProperty(message,"type") === true
        && commonlib.hasProperty(messagesHandlers,message.type) === true
        && commonlib.hasProperty(message,"kind") === true
        && commonlib.hasProperty(message,"body") === true ) {
            var handler = messagesHandlers[message.type][message.kind];    
            if ( handler != null ) { //if handler for the message has been found
                handler(message.body); //execute it   
            }
    }
};