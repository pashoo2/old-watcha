/*global navigator*/
/*global $*/
const EventEmitter = require("eventemitter");
const geo = require("glib");
const moduleSettings =  require("globalSettings").positionWatcher;
const commonlib = require("commonlib");
const logger = require("logger").logger;
logger.namespace = "PositionWatcher";

/*
    the current coordinates of the user, updated by the Geolocation.watchPosition()
    if flUseGetCurrentPosition === true, then get coordinates by the Geolocation.watchPosition
*/

/*
    wathing for user coordinates, converts it to the known forms and performs another geolocation functions
*/
function PositionWatcher() {
    
    this._callbacksForGetCurrentPosition = []; //callbacks queue for Geolocation.getCurrentPosition()
    
    this.latitude  = null; //coordinates
    this.longitude = null;
    
    this.restartTimeout = null; //timeout after which the current Geolocation.watchPosition() will be restarted    
    this.flErrorWhileWatching = false; //set true if error returned by the last position watching as a result
    this.currentWatching = null; //an instance, returned by Geolocation.watchPosition()
    this.currGetCurrentPosition = null; //if Geolocation.getCurrentPosition() is performing for now
   
    //bind to this context
    this.getUserCoordinates = this.getUserCoordinates.bind(this);
    this.onGotLocation = this.onGotLocation.bind(this);
    this.onSuccessWatching = this.onSuccessWatching.bind(this);
    this.onErrorWatching = this.onErrorWatching.bind(this);
    this.onErrorGetCurrentPosition = this.onErrorGetCurrentPosition.bind(this);
    this.getCurrentPosition = this.getCurrentPosition.bind(this);
    this.checkWatching = this.checkWatching.bind(this);
    
    if ( $.browser.mobile === true ) { //enable high accuracy coordinates for mobile browser
       this.optionsForGeolocation = {
           enableHighAccuracy : true,
           maximumAge:30000,
           timeout: 10000
       }
       logger("High accuracy was enebled");
    } else {
        this.optionsForGeolocation = {};    
    }
    
    commonlib.extend(this.optionsForGeolocation, moduleSettings.optionsForGeolocation); //extend with defaults
    
    debugger;
    this.getCurrentPosition();

    //if it is necessary to use Geolocation.watchPosition()
    if ( moduleSettings.flUseGetCurrentPosition !== true ) {
        this.startWatching();  //start watching procedure      
    }
}

/*
    description of the current state of the user position
*/
var PositionWatcherProto = Object.create(new EventEmitter());

/*
    events : "newcoordinates" ({lattitude, longitude})
*/

commonlib.extend(
    PositionWatcherProto, 
    { 
        geo : geo,
        moduleSettings : moduleSettings, //settings by the global object
        flUseGetCurrentPosition : moduleSettings.flUseGetCurrentPosition, //corrdinate
        Geolocation : navigator.geolocation,
    }
);

/*
    check for the current wathching
*/
PositionWatcherProto.checkWatching = function() {
    if ( this.currentWatching == null ) { //if the watching is disabled
       this.restartWatching(); 
    }  else { //if a watching is active
        const lastWatchingTimestamp = typeof(this._timestampSuccessWatching) === "number" ? this._timestampSuccessWatching : 0;
        const diff = Date.now() - lastWatchingTimestamp;
        if ( diff > this.optionsForGeolocation.timeout ) { //more than 20 seconds since the last success watching
            this.getCurrentPosition();   
        }
        if ( diff > this.optionsForGeolocation.timeout * 3 //if more than 3 minute has passed since the last watching
            && this.restartTimeout == null ) { //if there is no timeout to restart the current watching
                this.restartWatching();
        }
    }  
};

/*
    start usage of the Geolocation.watchPosition()
*/
PositionWatcherProto.startWatching = function() {
    try {
        this._timestampSuccessWatching = Date.now();
        this.currentWatching = this.Geolocation.watchPosition(
                                    this.onSuccessWatching,
                                    this.onErrorWatching,
                                    this.optionsForGeolocation
                                ); //start watching for the user positions
        setInterval(this.checkWatching, this.optionsForGeolocation.timeout); //start watching for the position watching
    } catch(e) {
        logger(e);
        this.flUseGetCurrentPosition = true; //can't use the Geolocation.watchPosition()
    }
};

/*
    restart Geolocation.watchPosition() - clear the previuos watcjing and start a new
*/
PositionWatcherProto.restartWatching = function() {
    if ( this.currentWatching != null ) { //if the current watching is exists
        this.Geolocation.clearWatch(this.currentWatching);
    }
    
    if ( this.restartTimeout != null ) { //if timeout for restart the current watching is exists
        clearTimeout(this.restartTimeout);    
    }
    
    this.startWatching(); //start a new watching
};

/*
    set a timeout after which it is necessary to restartWatching() 
*/
PositionWatcherProto.setTimeoutToRestartWatching = function() {
    if ( this.restartTimeout == null ) { //if the current timeout is absent
        this.restartTimeout = setTimeout(this.restartWatching.bind(this), this.moduleSettings.watchingTimeout);    
    }
};

/*
    stop the timeout after which it is necessary to restartWatching() 
*/
PositionWatcherProto.stopTimeoutToRestartWatching = function() {
    if ( this.restartTimeout == null ) { //if the current timeout is absent
        clearTimeout(this.restartTimeout);    
    }
};

/*
    callback for succesfully result of the Geolocation.watchPosition()
*/
PositionWatcherProto.onSuccessWatching = function (position) {
    
    logger("coords updated");
    var currCoords = position.coords;
            
    if ( typeof(currCoords) !== "object"
        || currCoords === null
        || typeof(currCoords.latitude) !== "number"
        || typeof(currCoords.longitude) !== "number" ) { //it is not the valid coordinates
            this.onErrorWatching(new Error("Wrong coordinates"));
    } else {
    	var latitude  = this.geo.convertCoordsToDecimal( currCoords.latitude  ); //transformm the coordinates into the known form
    	var longitude = this.geo.convertCoordsToDecimal( currCoords.longitude );
    	
    	if ( typeof(latitude.numberDecimalForm) !== "number"
    	    || typeof(longitude.numberDecimalForm) !== "number" ) { //if can't convert the given coordinates into the valid form
    	        this.onErrorWatching(new Error("Error during coordinates convertation"));
    	} else {
    	   this.flErrorWhileWatching = false; //reset the flag that error
    	   this.stopTimeoutToRestartWatching(); //stop the current timeout for restarting the position watching
    	   
    	   var _latitude  = latitude.numberDecimalForm;
    	   var _longitude = longitude.numberDecimalForm;
    	   
    	   this.latitude  = _latitude; //set the current coordinates of the user
    	   this.longitude = _longitude;
    	   
    	   var result = { latitude : _latitude, longitude : _longitude };
    	   this.emit("newcoordinates", result); //emit event with the new coordinates
    	   this._timestampSuccessWatching = Date.now();
    	   return result;
    	}
    }
              
};


/*
    error callback for Geolocation.watchPosition()
*/
PositionWatcherProto.onErrorWatching = function(err) {
    this.flErrorWhileWatching = true; //reset the flag that error
    if ( err instanceof Error ) {
        logger(err);    
    }
    this.setTimeoutToRestartWatching(); //restart watching
};

/*
    return the result for all waiting callbacks
*/
PositionWatcherProto.returnResultedCoords = function(result) {
    if ( result != null ) {
        var _callbacksForGetCurrentPosition = this._callbacksForGetCurrentPosition; //callbacks queue
        this._callbacksForGetCurrentPosition = []; //clear the current queue
        
    	for ( var i =0, len = _callbacksForGetCurrentPosition.length; i < len; i++ ) {
        	var cbDesc= _callbacksForGetCurrentPosition[i]; //may be array with this context for the callback function or only the function
        	if ( typeof(cbDesc) === "function" ) {
    			cbDesc(result);	
    		} else 
    		    if ( cbDesc != null //cbDesc = [context, function]
    		         && typeof(cbDesc[1]) === "function"  ) {
    		            cbDesc[1].call(cbDesc[0], result);  //call the callback with the context     
    		    }
    	}
    }    
};

/*
    on location returned by the Geolocation.getCurrentPosition
*/
PositionWatcherProto.onGotLocation = function(position) {
    var result = this.onSuccessWatching(position);
    
    this.currGetCurrentPosition = null; //reset the current performing of the Geolocation.getCurrentPosition()
    this.returnResultedCoords(result);
};

/*
    on location returned by the Geolocation.getCurrentPosition
*/
PositionWatcherProto.onErrorGetCurrentPosition = function(e) {
    logger(e);

    var numOfFails = this.numOfFails_getCurrentPosition;
    if ( typeof(numOfFails) === "number" ) {
       this.numOfFails_getCurrentPosition = ++numOfFails; //increase the number of faild attempts to get the current user position
    } else {
       this.numOfFails_getCurrentPosition = numOfFails = 1;
    }
    
    if ( numOfFails > 3 ) { //if there were many attempts made
        setTimeout(this.getCurrentPosition, 5000); //set timeout for 5 second before get the coords
        this.returnResultedCoords(e); //return an error for all the callbacks
        this.numOfFails_getCurrentPosition = 1;
    } else {
        this.getCurrentPosition(); //try once again    
    }
    
};

/*
    use Geolocation.getCurrentPosition to get the current user's coordinates
*/
PositionWatcherProto.getCurrentPosition = function() {
    if ( this.currGetCurrentPosition == null ) {
        this.currGetCurrentPosition = this.Geolocation.getCurrentPosition(this.onGotLocation, this.onErrorGetCurrentPosition, this.optionsForGeolocation);
    }
};

/**
 * return the current {latitude, longitude}
 * if can't get the current position, then returns {latitude:null, longitude:null}
 * @method getUserCoordinates
 * @param {} callback
 * @param {} _this
 * @return 
 */
PositionWatcherProto.getUserCoordinates = function (callback, _this) {
	
	if (this.Geolocation == null) {
        return {
    	    latitude : null,
            longitude : null
    	};
	}
	
	if ( this.flUseGetCurrentPosition === true //if flag, that means get current position by the geolocation.getCurrentPosition
	    || this.flErrorWhileWatching === true //if flag that error has occurred while Geolocation.watchPosition
	    || this.currentWatching == null ) { //if watching was not started
	        var cb; //may be array [this, callback] or callback
	        if ( typeof(callback) === "function" ) {
    			if ( _this !== null ) {
        		    cb = [_this, callback];	
        		} else {
        		   cb = callback;     
        		}	
    		}
	        var _callbacksForGetCurrentPosition = this._callbacksForGetCurrentPosition;
	        _callbacksForGetCurrentPosition[_callbacksForGetCurrentPosition.length] = cb;
	        this.getCurrentPosition();
	} else {
	    var result = { 
	        latitude : this.latitude,
	        longitude : this.longitude
	    };
	    
	    if ( typeof(callback) === "function" ) {
			if ( _this != null ) {
    		    callback.call(_this, result);	
    		} else {
    		   callback(result);     
    		}	
		} else {
	        return result;   
		}
	}
    
};

PositionWatcher.prototype = PositionWatcherProto;

module.exports = PositionWatcher;