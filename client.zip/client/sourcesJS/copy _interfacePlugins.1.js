/*global $*/
/*global _gPages*/
/*global FB*/

var commonlib = require("common");
var logger = require("logger").logger;
logger.namespace = "interfacePlugins";

/*
    data-ui-disabled            - disable this element
    data-ui-onevent = "true"    - have a listeners for the events (panels, pages)
    data-dad-connectable="true" - connectable listviews
    data-role-ui-load-conten-dynamically  - load the page content from pages directory
    data-role-ui-load-scripts-dynamically - load the page content from pages directory
*/

/**
 * remove all items from the listview
 * flExpectDisabled = true, than expect the disabled items
 * @method clearListview
 * @param {} listview
 * @param {} flDoNotUpdate
 * @param {} flExpectDisabled
 * @return 
 */
function clearListview(listview, flDoNotUpdate, flExpectDisabled){
    var _uiListview = $(listview);
    
    if ( flExpectDisabled === true ) { //expect the disaled items
        _uiListview.children(":not([data-ui-disabled='true'])").remove();
    } else {
        _uiListview.empty(); //clear the retrieved listview elements
    }
    
    if ( flDoNotUpdate !== true ) {
        updateListview(_uiListview);    
    }
    
}

/**
 * return array with items = values of the given listview element    
 * @method getListviewItems
 * @param {} listview
 * @param {} flExpectDisabled
 * @return result
 */
function getListviewItems(listview, flExpectDisabled) {
    var _uiListview = $(listview);
    var _uiListviewItems;
    
    if ( flExpectDisabled === true ) { //expect the disaled items
        _uiListviewItems = $(listview).children("li:not([data-ui-disabled='true'])");
    } else {
        _uiListviewItems = _uiListview.children("li");    //get li elements, which are the child elements for the listview ul element    
    }
    
    var result = [];
    var indResult = 0;
    
    for( var i = 0, len = _uiListviewItems.length; i < len; i++ ) {
        result[indResult++] = $(_uiListviewItems[i]).text().trim(); //put the value of the element to the resulted array
    }
    
    return result;
}

/**
 * refresh the listview and call another methods for the given listview according to it's tags
 * @method updateListview
 * @param {} listview
 * @return 
 */
function updateListview(listview) {
    var _uiListview = $(listview);
    
    _uiListview.listview('refresh');
    
    var flConnectable = _uiListview.data("dad-connectable") === true
                            || _uiListview.data("dad-connectable") === "true";
    if ( flConnectable === true) { //if necessary to make it connectable
        makeConnectableListviews(listview);    
    } 
    
}

/**
 * append a new element with the given vlue and icon element to the given listview
 * @method appendElementToListview
 * @param {} listview
 * @param {} name
 * @param {} icon
 * @param {} flDoNotUpdate
 * @return 
 */
function appendElementToListview(listview, name, icon, flDoNotUpdate) {
    var _uiListview = $(listview);
    var flWithIcon = typeof(icon) === "string";
    
    var htmlForElement = "<li " 
                        + ( flWithIcon === true ? "data-icon='"+ icon +"'" : "" ) + ">"
                        + ( flWithIcon === true ? "<a href='#'>" : "" )
                        + name
                        + ( flWithIcon === true ? "</a>" : "" )
                        + "</li>";
    
    _uiListview.append(htmlForElement);
                        
    if ( flDoNotUpdate !== true ) {
        updateListview(listview);
    }
}

/**
 * add the given list of an elements into the list of the listview element
 * elements = { value : icon } or [],
 * listview - string, or ui
 * @method appendListToListview
 * @param {} listview
 * @param {} elements
 * @param {} flDoNotUpdate
 * @return 
 */
function appendListToListview(listview, elements, flDoNotUpdate) {
    
    var elementsList;
    var flArray = Array.isArray(elements);
    
    if ( flArray === true ) { //if an array is given
        elementsList = elements;
    } else { //if object
        elementsList = Object.keys(elements);
    }
    
    for ( var i = 0, len = elementsList.length; i < len; i++ ) { //for each element
        var elementName = elementsList[i];
        appendElementToListview(listview, elementName, flArray === true ? undefined : elements[elementName], true ); //appenfd one element to the listview    
    }
    
    if ( flDoNotUpdate !== true ) {
        updateListview(listview);
    }
    
}

/**
 * on a panel event fired
 * ui  - the panel jQuery element
 * @method onPanelEvent
 * @param {} e
 * @param {} ui
 * @return 
 */
function onPanelEvent(e, ui) {
    var loadedPanel  = $(e.target); //the page that is loaded 
    var panels = window._gPages.panels;
    
    var panelID = loadedPanel.attr("id");
    if ( typeof(panelID) === "string"
        && typeof(panels[panelID]) === "object") { //id of the page
            var func = panels[panelID][e.type]; //call the function named "onload"
            if ( typeof(func) === "function" ) { //if the function "onload" is defined
                func(loadedPanel); //call it 
            }
    }
    
}

/**
 * on page sucessfully loaded on the user main screen,
 * ui = { toPage, prevPage }, toPage - the destination page DOM element
 * @method onPageShown
 * @param {} e
 * @param {} ui
 * @return 
 */
function onPageShown(e, ui) {
    var loadedPage  = $(ui.toPage); //the page that is loaded
    var pages = window._gPages.pages;
    
    var pageID = loadedPage.attr("id");
    if ( typeof(pageID) === "string"
        && typeof(pages[pageID]) === "object") { //id of the page
            var func = pages[pageID][e.type]; //call the function named "onload"
            if ( typeof(func) === "function" ) { //if the function "onload" is defined
                func(loadedPage); //call it 
            }
    }
    
}

/**
 * set the given value for the corresponding field value to show it on the user interface
 * @method showValue
 * @param {} name
 * @param {} value
 * @return 
 */
function showValue(name, value) {
    
    var options = thisModule.options;
    
    var valueName = name.trim().toLowerCase();
    var fieldID = options.correspondenceValueNameDOMId[valueName];

    if (typeof(fieldID) === "string") {
        $("#" + fieldID).val(value).text(value);
    }

}
/**
 * return a value from the corresponding field of the user interface
 * @method getValue
 * @param {} name
 * @return 
 */
function getValue(name) {
    
     var options = thisModule.options;
    
    var valueName = name.trim().toLowerCase();
    var fieldID = options.correspondenceValueNameDOMId[valueName];

    if ( typeof(fieldID) === "string" ) {
        return $("#" + fieldID).val();
    }

}

/**
 * change the current page on the main screen to the target page
 * targetPage - id of the target page
 * @method changeToTargetPage
 * @param {} targetPage
 * @return 
 */
function changeToTargetPage(targetPage){
   var options = thisModule.options;
   
   $("body")
        .pagecontainer( //change the current page to the target page
            'change',
            ('#' + targetPage), //to the page with id = targetPage
            {  //options for page changing
                changeHash: true,
                translition: options.translitionPageChanging
            }
        ); 
};

/**
 * show the page with the given name on the main user's browser screen
 * @method showPage
 * @param {} pageName
 * @return 
 */
function showPage(pageName) {
    
    var options = thisModule.options;
    
    var _pageName = pageName.trim().toLowerCase();
    var pageID = options.correspondencePageNameDOMId[_pageName];
    
    if ( typeof(pageID) === "string" ) {
        changeToTargetPage(pageID);    
    }

}

/**
 * change the current page, depending on swipe duration
 * @method onDocumentSwipeChandePage
 * @param {} direction
 * @param {} distance
 * @param {} duration
 * @param {} startHorizontal
 * @param {} startVertical
 * @return 
 */
function onDocumentSwipeChandePage(direction, distance, duration, startHorizontal, startVertical) {
    
    var options     = thisModule.options,
        flags       = thisModule.flags,
        innerFlags  = thisModule.innerFlags;
        
    var windowHorizontalEvDetectDistance = options.windowWidth / options.eventHappenDelimetr,
        windowVerticalEvDetectDistance = options.windowHeight / options.eventHappenDelimetr,
        windowHorizontalEvDetectRight = options.windowWidth / options.eventDetectionDelimetr,
        windowHorizontalEvDetectLeft = options.windowWidth - windowHorizontalEvDetectRight,
        windowVerticalEvDetectDown = options.windowHeight / options.eventDetectionDelimetr,
        windowVerticalEvDetectUp = options.windowHeight - windowVerticalEvDetectDown;
    
    var flCan = innerFlags.documentReady === true
                && flags.userConnected === true; //if user was connected ad the document was loaded

    if (flCan === true 
        && duration > options.eventDetectionDuration) {

            if (event.currentTarget === document) {
                var currentPage = $("body").pagecontainer("getActivePage");
    
                var targetPage = null;
                var translition = null;
    
                switch (direction) {
                case "left":
                    if (distance > windowHorizontalEvDetectDistance
                        && startHorizontal > windowHorizontalEvDetectLeft) {
                            targetPage = currentPage.data("leftpage");
                            translition = "slide";
                    }
                    break;
                case "right":
                    if (distance > windowHorizontalEvDetectDistance
                        && startHorizontal < windowHorizontalEvDetectRight) {
                            targetPage = currentPage.data("rightpage");
                            translition = "slidefade";
                    }
                    break;
                case "up":
                    if (distance > windowVerticalEvDetectDistance
                        && windowVerticalEvDetectUp > windowVerticalEvDetectUp) {
                            targetPage = currentPage.data("uppage");
                            translition = "slidefade";
                    }
                    break;
                case "down":
                    if (distance > windowVerticalEvDetectDistance
                        && startVertical < windowVerticalEvDetectDown) {
                            targetPage = currentPage.data("downpage");
                            translition = "slidefade";
                    }
                    break;
                default:
                    break;
    
                }
    
                if (typeof (targetPage) === "string") {
                    showPage(targetPage);
                }
    
            }
    }
}

/**
 * on swipe touch on the document's page
 * e - jQuery 'swipe' event
 * @method onDocumentSwipe
 * @param {} e
 * @return 
 */
function onDocumentSwipe(e) {

    var direction,
        distance,
        duration,
        startHorizontal,
        startVertical;
    var swipestart = e.swipestart,
        swipestop = e.swipestop,
        startX = swipestart.coords[0],
        startY = swipestart.coords[1],
        stopX = swipestop.coords[0],
        stopY = swipestop.coords[1],
        distanceX = stopX - startX,
        distanceY = stopY - startY,
        distanceHor = Math.abs(distanceX), //horizontal distance
        distanceVert = Math.abs(distanceY); //vertical distance

    if (distanceHor > distanceVert) { //horizontal swipe
        distance = distanceHor;
        if (distanceX > 0) { //check for horizontal direction
            direction = "right";
        }
        else {
            direction = "left";
        }
    }
    else { //vertical swipe
        distance = distanceVert;
        if (distanceY > 0) { //check for vertical direction
            direction = "down";
        }
        else {
            direction = "up";
        }
    }

    startHorizontal = startX;
    startVertical = startY;
    duration = swipestop.time - swipestart.time;
    
    onDocumentSwipeChandePage(direction, distance, duration, startHorizontal, startVertical);

}

/**
 * when drop on the connective list
 * @method connectiveListOnDrop
 * @param {} event
 * @param {} ui
 * @return 
 */
function connectiveListOnDrop( event, ui ) {
    if ( ui.draggable[0] ) {
        $(this).append($(ui.draggable));
        $(this).listview('refresh');
    }    
}

/**
 * make all listviews with the attribute data-dad-connectable="true" connectable
 * li elements may be dragged and dropped on that elements
 * @method makeConnectableListviews
 * @param {} listview
 * @return 
 */
function makeConnectableListviews(listview) {
    var _uiListview;
    
    if ( listview == null ) { //if called for all document
        _uiListview = $('ul[data-role="listview"][data-dad-connectable="true"]');
    } else { //if called for a listview or a parent element
        _uiListview = $(listview);
        if ( _uiListview.data("role") !== "listview" ) { //if a parent element for the listview
            _uiListview = _uiListview.children('ul[data-role="listview"][data-dad-connectable="true"]'); //search for a childrens listviews     
        } 
    }
    
    _uiListview
        .children('li')
        .draggable({
            appendTo:"ul",
            helper:"drag it to another list",
            iframeFix:true,
            revert:true,
            scope:"drop"
        });
                    
    _uiListview
        .droppable({
            accept:"li",
            scope: "drop",
            greedy: true,
            drop : connectiveListOnDrop
        })
        .sortable();
}

/**
 * set handlers for all events for panels and pages wich are match to selector data-ui-onevent='true'
 * @method setEventHandlersForPagesAndPanels
 * @return 
 */
function setEventHandlersForPagesAndPanels(){
    
    //events listeners for pages and panels
    var selectedElements = $("div[data-ui-onevent='true']");
    
    for ( var i = 0, len = selectedElements.length; i < len; i++ ) {
        var _uiElement = $(selectedElements[i]);
        
        if ( _uiElement.data("role") === "panel" ) { //if the element is a panel
            _uiElement.panel(
                { //set listeners for a panels events
                    beforeopen  : onPanelEvent, //on panel opened
                    close       : onPanelEvent,
                    open        : onPanelEvent,
                    beforeclose : onPanelEvent 
                }
            );    
        }
                
    }
}

/**
 * make droppable elements wich contains property named data-dad-ondrop
 * and set the method of value of this property
 * @method setEventHandlersOnDropEvent
 * @return 
 */
function setEventHandlersOnDropEvent(){
    
    //events listeners for pages and panels
    var selectedElements = $("[data-dad-ondrop]");
    var availableHandlersOnDrop = _gPages.handlers.ondrop;
    
    for ( var i = 0, len = selectedElements.length; i < len; i++ ) {
        var _uiElement = $(selectedElements[i]);
        var onDropHanlder = _uiElement.data("dad-ondrop");
        
        if ( typeof(onDropHanlder) === "string"
            && typeof(availableHandlersOnDrop[onDropHanlder]) === "function" ) { //if the handler is set and exists
                _uiElement
                    .droppable({
                        greedy: true,
                        drop : availableHandlersOnDrop[onDropHanlder]
                    });    
        }
                
    }
}

/**
 * must be called when the document has loaded
 * @method onDocumentReady
 * @return 
 */
function onDocumentReady() {
    return;
    if ( typeof(thisModule.innerFlags) === "object"
        && thisModule.flags !== null ) {
            thisModule.innerFlags = {};    
    }
    var _uiBody =$("body");
    _uiBody.on("swipe", onDocumentSwipe);
        _uiBody.pagecontainer({
      defaults: true
    });
    
    thisModule.innerFlags.documentReady = true;
    
    makeConnectableListviews(); 
    
    setEventHandlersForPagesAndPanels();
    setEventHandlersOnDropEvent();
    
    $("[data-ui-disabled='true']").addClass("ui-state-disabled"); //add class for disabled elements
    
} 

/**
 * add a dynamic script for a pages with the tag data-role-ui-load-scripts-dynamically="true"    
 * @method loadDynamicScripts
 * @param {} _callback
 * @return 
 */
function loadDynamicScripts(_callback) {
    var numberWaitingFor = 0;
    var _selected = $('[data-role-ui-load-script-dynamically="true"]');
    
    _selected.each(function(){ //load html content
            var pageID = $(this).prop("id"); 
            numberWaitingFor++;
            $(this).load('../pages/'+ pageID +'/script/index.js',
                    function (){ //on content was loaded
                        numberWaitingFor--;
                        if ( numberWaitingFor === 0 ) {
                            _callback;    
                        }
                    }
                );
        });
        
        if ( _selected.length === 0 ) {
            _callback();    
        }
}

/**
 * load a dynamic pages data-role-ui-load-scripts-dynamically="true"
 * toLoad = ['id of a page 1', ... 'id of a page N']
 * @method loadDynamicPage
 * @param {} toLoad
 * @param {} _callback
 * @return 
 */
function loadDynamicPage(toLoad, _callback) {
    
    var loadingPages = []; //pages that are loading for now
    
    if ( Array.isArray(toLoad) ) {
        
        var intCheckLoading = setInterval( //each 5 seconds check for pages, that are not loaded succesfully
            function(){
                
                if ( loadingPages.length === 0 ) { //if all was done, then load scripts for the page
                    loadDynamicScripts(_callback);
                    clearInterval(intCheckLoading);
                }
                
                for ( var i = 0, len = loadingPages.length; i < len; i++ ) { //try to load pages once again
                    var pageID = loadingPages[i]; 
                    $("body").load('../pages/'+ pageID +'/content/index.html'); //load html content for the page
                }
                
            }
            , 5000);
        
        $("body").on("load",
                function(event, ui) { //on one of the pages loaded
                    var loadedPageID = $(ui).prop("id");    
                    commonlib.deleteFromArray(loadingPages, loadedPageID); //remove the page from the list of the loading pages
                    if ( loadingPages.length === 0 ) { //if all was done, then load scripts for the page
                        loadDynamicScripts(_callback);
                        clearInterval(intCheckLoading);
                    }
                }
            );        
            
        for ( var i = 0, len = toLoad.length; i < len; i++ ) {
            var pageID = toLoad[i]; 
            loadingPages[i] = pageID;
            $("body").load('../pages/'+ pageID +'/content/index.html'); //load html content for the page
        }
        
    }
        
    if ( loadingPages.length === 0 ) { //if all was done, then load scripts for the page
        loadDynamicScripts(_callback); //load the    
    }
}

/**
 * call this before onDocumentReady, when loading
 * @method onInit
 * @return 
 */
function onInit() {
    
    var _uiBody =$("body");
        
    _uiBody.pagecontainer({
        defaults: true
    });   
    
    return;
    
    //initialize services if it is necessary
    var integrationSettings = thisModule.integration; //integration with another services
    var services = Object.keys(integrationSettings);
    for( var i = 0, len = services.length; i < len; i++ ) {
        var serviceDesc = integrationSettings[services[i]];
        if ( typeof(serviceDesc.init) === "function" ) { //if the init function is exists
            serviceDesc.init();    
        }
    }  
} 

var thisModule =
    module.exports =
            {
                main : {
                    changeToTargetPage : changeToTargetPage,
                    showPage : showPage,
                    showValue : showValue,
                    getValue : getValue,
                    onDocumentReady : onDocumentReady,
                    onInit : onInit,
                    onPageShown : onPageShown
                },
                ajax : {
                    loadDynamicPage     : loadDynamicPage,
                    loadDynamicScripts  : loadDynamicScripts
                },
                dragAndDrop : { //plugins for Drag And Drop events
                    makeConnectableListviews : makeConnectableListviews,
                    onDocumentSwipe : onDocumentSwipe
                },
                lists : { //for work with the listviews
                    appendListToListview : appendListToListview,
                    appendElementToListview : appendElementToListview,
                    updateListview : updateListview,
                    getListviewItems : getListviewItems,
                    clearListview : clearListview
                },
                integration : { //integration with services
                    facebook : { //integration with the facebook
                        /**
                         * Description
                         * @method init
                         * @return 
                         */
                        init : function() { //initialize facebook SDK
                            $.getScript("../libJS/integration/facebook/loadFacebookSDK.js", _gPages.integration.facebook.methods.checkFacebookLoginStatus);    
                        } 
                    }
                },
                options : {},
                flags   : {},
                innerFlags : {}
            };