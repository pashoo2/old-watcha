/*global Peer*/
/*global $*/

var globalObj;
try {
    globalObj = self; //reference to the global object
} catch(e) {
    globalObj = window.self;
}

//window._globalDataConnector - instanceof 

var EventEmitter = require("eventemitter");
var logger = require("logger").logger;

var WWDataConnection; //mock data connection for ww side
var CommandsListener = require("CommandsListener").CommandsListener;
var isDataConnection = require("libMainP2P").isDataConnection;
var timeIntervals = require("timeIntervals");
var getTimestamp = require("timestamps").getCurrentTimestamp;

var appSettings = require("globalSettings");

var predefinedMessages      = appSettings.predefinedMessages;
var prefixForMessagesToGServer = appSettings.prefixMessagesForGServer || ""; //prefix for all messages, that are will be sent to the gServer
var _flThisIsWorkerConext = (globalObj.document === undefined); //ww context or main thread context

//for using Peer.js into a thread
//this need to use on the WebWorker side and the main thread side
//ON THE MAIN THREAD side it is necessary to give a WebWorker instance as the argument "_webWorker" when the DataConnector created
//and the settings = { maxDataConnections, settingsPeerJS } are necessary only in main thread
//!ON THE WORKER side settings = messagePort
/**
 * Description
 * @method DataConnector
 * @param {} settings
 * @param {} userID
 * @return 
 */
function DataConnector(settings, socialUserID, accessToken) {
    
    this._thisID = DataConnectorProto._counterDataConnectorID++; //id for this instance of the data connector
    this.mode = (_flThisIsWorkerConext !== true); //true - main thrad mode
    
    logger.namespace = this.mode === true ? "DataConnectorMainThread" : "DataConnectorWorker";
    logger("Create the data connector");
    
    this.settings = settings;
    this.destroyed    = false;
    this.disconnected = true;
    
    //bind this context of the methods to the current object
    this.onIncomingDataConnection = this.onIncomingDataConnection.bind(this);
    this.onPeerOpen = this.onPeerOpen.bind(this);
    this.createConnectionToCS = this.createConnectionToCS.bind(this);
    this.closeExpiredDataConnections = this.closeExpiredDataConnections.bind(this);
    this.sendHeartbeatToServer = this.sendHeartbeatToServer.bind(this);
    this.checkConnectionToServer = this.checkConnectionToServer.bind(this);
   
    this.commandsPrefix = this.moduleSettings.prefixForCommandsListener; //prefix for all command form one side to the other side
    this.pingRequest    = this.moduleSettings.pingMessage; //ping message sending through a data connection to check DataConnection state
    this.pongResponse   = this.moduleSettings.pongMessage; //pong response to ping request
    this.parseIncomingDataOnWW = this.moduleSettings.parseIncomingDataOnWW; //parse and stringify all the data on the ww side
    
    //messages
    this._messageForCSOnBrowserClosed = predefinedMessages.forCSOnOut; //message for cs when the browser has closed by the user
    this._messageForELSOnBrowserClosed = predefinedMessages.forELSOnOut; //message for users (ELS and ILS instances) when the browser has closed by this user. message as ILS for ELS
    this._messageForILSOnBrowserClosed = predefinedMessages.forILSOnOut; //as ILS for ILS
    this._heartbeatMessagesForServer =  this.moduleSettings.heartbeatMessagesForServer;
    
    this.messagePort = null; //message port for exchanging information between instances of DataConnector on the two sides - ww and mt
    this.commandsQueue = []; //commands that are waiting for the opening of the message port
    
    if ( this.mode === true ) { //main thread mode
        
        this._flDataConnectorSet = false; //flag that the data connector id was set
        
        this.timestamps = {
            disconnected : null, //timestamp when disconnected from the cs
            timestampDisconnectedFromCS : getTimestamp()
        };
        
        try{
            if ( typeof(Peer) === "undefined" ) {
                throw new Error("Peerjs is unavailable");    
            }
            if ( typeof(window) === "undefined" ) {
                throw new Error("Call with an instance of WebWorker as the argument only in the scope of a main thread");
            }
        } catch(e){
            throw e;    
        }
        
        this.socialUserID = socialUserID;
        
        var settingsPeerJS = settings.settingsPeerJS;
        var freeice = require("freeice");
        this.settingsPeerJS = { //settings for creating a new instance of Peer(new Peer(settings))
            key     : settingsPeerJS.key  || "peerjs",
            host    : settingsPeerJS.host || window.hostname,
            path    : settingsPeerJS.path || "/",
            port    : settingsPeerJS.port || null,
            secure  : settingsPeerJS.secure || false,
            debug   : settingsPeerJS.debug || false,
            turn    : settingsPeerJS.turn || false,
            config  : {
                iceServers : freeice() //set STUN servers
            },
            token : accessToken
        };
        this.maxDataConnections = settings.maxDataConnections;//maximum number of a DataConnections with another peers
        this.queuedCommands = []; //until ID form the ww side will not came, an all commands for the ww side will been put to the queue
        
        this.intCloseExpiredDataConnections = null; //each 120 seconds close the expired Data Connections
        this.intSendHeartbeatToServer = null; //send heartbeat messages
        this.intCheckConnectionToCS = null; //check the connection state to the central server
        
        $(window).on('beforeunload', this.onBrowserClose.bind(this));
         
    } else { //if executed on the ww side    
        this.id = 0;
        WWDataConnection = require("WebWorkerDataConnection").WebWorkerDataConnection; //load the libruary for mock data connection especially for ww side
        
        if (settings instanceof MessagePort ) { //on the ww side connect to the cs immediately if a MessagePort is defined
            var _self = this;
            this.setMessagePort(settings);
            this.beenConnected = false; //means that the dataConnector has been connected at least a once
            this.open(); //create connection with the cs
        }
    }
    
    this.incoming_dataConnections = []; //incoming data connections store. All data connections has an id, that is the index number in this array
    this.incoming_idDataConnection = 0; //if it is more than globalSettings.maxDataConnections, then it be reset to zero
    
    this.created_dataConnections = []; //created data connection
    this.created_idDataConnection = 0; //if it is more than 100000, then it be reset to zero
    
    this.timeIntervalSecondsDataConnectorNotConnectedConnectionToCSExpired = timeIntervals.timeIntervalSecondsDataConnectorNotConnectedConnectionToCSExpired; //interval of a disconnection from the cs, before it is necessary to drop the current connection and reconnect to the cs
    
    // if ( _flThisIsWorkerConext === false ) {
    //     setTimeout(
    //         (function cls(){ //disconnect from server after 25 seconds
    //             this.flClosed = true;
    //             this.socket.close();
    //             setTimeout(cls.bind(this), 15000);
    //         }).bind(this)
    //     , 60000);    
    // }
    logger("!!!The data connector was created");

    globalObj._globalDataConnector = this; //set the global reference to this data connector instance
      
}

/**
 * emulation of the WebSocket connection to the server for Worker
 * @method wwSocket
 * @param {} dataConnector
 * @return 
 */
function wwSocket(dataConnector) { //emulation of WebSocket.send
    this.dataConnector = dataConnector; 
    wwSocketProto.sendAfterJSONStringify = wwSocketProto.sendAfterJSONStringify.bind(this); //bind to allow for the method sendAfterJSONStringify to have an acess to the dataConnector.sendCommand method
}
var wwSocketProto = Object.create(new EventEmitter());

/**
 * Description
 * @method constructor
 * @return 
 */
wwSocketProto.constructor = function Socket(){};
//emulation of WebSocket.send for Worker
/**
 * Description
 * @method send
 * @param {} data
 * @return 
 */
wwSocketProto.send = function(data) {
    if ( this.dataConnector.sendCommand != null ) { //if the method is exists
        JSON.stringifyAsync(data, this.sendAfterJSONStringify); //stringify object
    }
};
//send the data as a stringified object
/**
 * Description
 * @method sendAfterJSONStringify
 * @param {} dataStr
 * @return 
 */
wwSocketProto.sendAfterJSONStringify = function(dataStr){
    //prefixForMessagesToGServer - prefix, allows for gServer to recognize that this is message for it
    if ( this.dataConnector.sendCommand != null ) { //send the command to the main thread to send this message to the gServer
        this.dataConnector.sendCommand("Socket", "send", prefixForMessagesToGServer + dataStr);  //send the command to the mt side for sending the data through the PeerJS.socket.send           
    }
};
wwSocket.prototype = wwSocketProto; 

var DataConnectorProto = Object.create(new EventEmitter());

DataConnectorProto._counterDataConnectorID = 0; //a new instance will increment this counter to 1
//set the id for this instance of the data connector
/**
 * Description
 * @method setDataConnectorID
 * @param {} ID
 * @return 
 */
DataConnectorProto.setDataConnectorID = function(ID) {
    if ( this._flDataConnectorSet === false ) { //if ID for this instance already was set
        this._thisID = ID; //set the new id for this instance
        this._flDataConnectorSet = true; //set the flag that the id was set already
        if ( this.commandsListener != null ) {
            this.commandsListener.setCommandsPrefix(this.commandsPrefix + this._thisID);    
            this.sendCommand = this.commandsListener.sendCommand; //send commands to the other side of DataConnector through the message port
            this.sendQueuedCommands(); //send the waiting command if they are exists
        }
        logger.namespace = logger.namespace + "["+ this._thisID +"]";
    }    
};

//mask the DataConstructor as the PeerJS
/**
 * Description
 * @method constructor
 * @return 
 */
DataConnectorProto.constructor = function Peer(){
};


//global settings of the DataConnector
DataConnectorProto.moduleSettings = {
  timeIntervalSecondsConnectionAttemptToCSOverdue : timeIntervals.timeIntervalSecondsConnectionAttemptToCSOverdue, //time interval since the last disconnection when the connection to the server will become overdue
  pingMessage : "!@#$ping",
  pongMessage : "!@#$pong",
  heartbeatMessagesForServer : appSettings.heartbeatMessagesForGServer, //ping/pong message for gServer, to prevent a connection timeout
  parseIncomingDataOnWW : true, //parse incoming message on the ww side
  intervalCheckExpiredDataConnections : 120000,
  prefixForCommandsListener : " _DC" //prefix(zero-index element in a command array) for commands, that are handled by the commandListener
};

DataConnectorProto.commandsListener = null;
DataConnectorProto.listenCommands = null;

//put the commands to the queue, until this method will be replaced with commandsListenr.sendCommand
/**
 * Description
 * @method sendCommand
 * @return 
 */
DataConnectorProto.sendCommand = function(){
  this.queuedCommands[this.queuedCommands.length] = arguments;
};

//events : 
//close - DataConnector closed manually
//disconnected - DataConnector closed manually
//error - DataConnector closed manually
//open - DataConnector opens new connection to the central server
//connection - new incoming connection emitted with an argument = dataConnection
//newDC(DataConnector) - if the new instance of DataConnector has been created
//onSetMessagePort(MessagePort) - message port was set

//cap for WebSocket connection, while the PeerJS not started connection to the CS
DataConnectorProto.socket = {}; 

//on the mt side - create the new message port to connect data connector in the mt side and the ww side and return it
//on the ww side st the given port as the promary cport for exchanging
/**
 * Description
 * @method setMessagePort
 * @param {} messagePort
 * @return 
 */
DataConnectorProto.setMessagePort = function(messagePort) {
    var flCreateNew = ( this.mode === true && messagePort == null);
    if ( flCreateNew === true ) { //on the mt side if need to create the new message port
        //create the new message port
        var messageChannel = new MessageChannel();
        messagePort = messageChannel.port1;
    } 
    if ( this.messagePort instanceof MessagePort ) { //close the previous port
        this.messagePort.postMessage("_closeMessagePort");
        this.messagePort.close();    
    }
    if ( messagePort instanceof MessagePort 
        && messagePort._closed !== true ) { //message port has not been closed
            logger("!!!The messagePort was set");
            //set the given or created message port as the primary message port
            this.messagePort = messagePort;
            //create the new listener for commands form the other side
            //set the default prefix, until it will not be formed and sent from the ww side
            var commandsListener = new CommandsListener(this, messagePort, this[this.getMethodByName("incomingCommandHandlers")], this.commandsPrefix ); //form the prefix by the index of the instance of the data connector
            this.commandsListener = commandsListener;
            commandsListener.on("messageAfterStopped", this.handlerNoHandlerOrStopped ); //on incoming message after the commands listener has stopped
            
            messagePort.start();
            this.emit("onSetMessagePort", messagePort); //emit the event that the message port is set
            if ( flCreateNew === true ) { //return the second port for the ww side
                return messageChannel.port2;
            }
            
            messagePort.addEventListener("message", function onCloseMessage(event){ //the special message for closing the message port from the other side
                if ( event.data === "_closeMessagePort" ) {
                    messagePort._closed = true;
                    messagePort.close();
                    messagePort.onmessage = null;
                    messagePort.removeListener("message",arguments.callee);
                }
            });
            
            if ( this.mode !== true ) { //on the ww side
                this.sendCommand = commandsListener.sendCommand;
                messagePort.postMessage("create"); //send the "create" message to create the DataConnector on the mt side, if not exists
                this.sendCommand("Peer", "setDataConnectorID", this._thisID); //send the id of the data connector to set it on the mt side
                commandsListener.setCommandsPrefix(this.commandsPrefix + this._thisID); //set the new prefix for a commands listener, after it was sent to the mt side
            }
    } else {
        logger("!!!Not valid message port");    
    }
};

//send all the queued commands
/**
 * Description
 * @method sendQueuedCommands
 * @return 
 */
DataConnectorProto.sendQueuedCommands = function() {
    var queuedCommands = this.queuedCommands;
    if ( queuedCommands.length > 0 ) { //if the queued commands are waiting for sending them to the other side
        for( var i =0, len = queuedCommands.length; i < len; i++ ) {
            var commandsToSend = queuedCommands[i]; //instance of Arguments
            if ( commandsToSend.length > 3 ) {
                this.sendCommand(commandsToSend[0],commandsToSend[1],commandsToSend[2], commandsToSend[3]);     
            } else {
                this.sendCommand(commandsToSend[0],commandsToSend[1],commandsToSend[2]);
            }
        }        
    }  
};

//all methods are divided on the two sides:
//with mt_ prefix - for usage on a main thread side
//with ww_ prefix - for usage on a web worker side

//send the heartbeat message to the server to prevent a timeout for the current connection with the gServer
/**
 * Description
 * @method sendHeartbeatToServer
 * @return 
 */
DataConnectorProto.sendHeartbeatToServer = function(){
    if ( this.isPeerJSConnected() === true ) {
        this.socket.send(this._heartbeatMessagesForServer);
    }
};

/**
 * check if the current connection attempt to the server is overdue (when WebSocket connection is not connected really in connecting state, but thinking that connected)
 * @method checkConnectionAttemptOverdue
 * @return LogicalExpression
 */
DataConnectorProto.checkConnectionAttemptOverdue = function() {
    return this.timestamps.disconnected != null
            && ( getTimestamp() - this.timestamps.disconnected ) > this.moduleSettings.timeIntervalSecondsConnectionAttemptToCSOverdue; //when disconnected from the cs
};

/**
 * check the connection state of the connection to the central server
 * @method checkConnectionToServer
 * @return 
 */
DataConnectorProto.checkConnectionToServer = function(){
    if ( this.destroyed !== true ) {
        if ( this.checkConnectionAttemptOverdue() === true //if the current connection attempt to the cs has overdue 
            || this.isPeerJSConnected() !== true ) { //if not connected to the central server
                var peerJSConnection = this.serverConnection;
                if ( this.timestamps.timestampDisconnectedFromCS != null ) { //if the timestamp is already defined
                    //check for expiring of the connection to the central server
                    if ( ( getTimestamp() - this.timestamps.timestampDisconnectedFromCS ) > this.timeIntervalSecondsDataConnectorNotConnectedConnectionToCSExpired ) {
                        //if the connection is expired
                        if ( peerJSConnection instanceof Peer ) { //if the PeerJS is exists
                            this.reconnectForce();  //reconnect to the cs  
                        } else { //if the PeerJS is not exists
                            this.createConnectionToCS();
                        }
                    }
                } else { //if the timestamp is not defined
                    this.timestamps.timestampDisconnectedFromCS = getTimestamp(); //set the timestamp when DataConnector was disconnected from the central server
                
                    if ( peerJSConnection instanceof Peer 
                        && peerJSConnection.disconnected === true ) { //if disconnected, then reconnect. If not disconnected, may be trying to establish a new connection
                            logger("checkConnectionToServer. Reconnect to the CS"); //can to reconnect
                            this.reconnect();            
                    } else 
                        if ( peerJSConnection instanceof Peer 
                            && this.isWebSocketOpen() === false
                            && peerJSConnection.open === true ) { //if think that connected, but disconnected for really
                                logger("checkConnectionToServer. Disconnect from the CS"); //can to reconnect
                                this.disconnect();        
                        }
                    else 
                        if ( peerJSConnection instanceof Peer === false ) { //check if PeerJS is not exists
                            this.createConnectionToCS();
                        }
                    else 
                        if ( peerJSConnection.socket instanceof Socket === false ) { //check if the WebSocket is not exists
                            this.reconnect();  //reconnect to the cs
                        }
                    
                }
                
        }
    }
    
};

//close a connections, that are not opened or closed befor some timestamp, or that are expired by ping request
/**
 * Description
 * @method closeExpiredDataConnections
 * @return 
 */
DataConnectorProto.closeExpiredDataConnections = function(){
    var cyc = 0;
    var currentList = this.incoming_dataConnections;
    var currentTimestamp = Date.now();
    while ( cyc++ < 2 ) {
        if ( cyc === 2 ) { //the first cycle is for incoming connections and the second is for the reated connection
            currentList = this.created_dataConnections; 
        }
        for( var i =0, len = currentList.length; i < len; i++ ) {
            var connection = currentList[i];
            if ( connection != null && connection.open === true ) {
                if ( connection._pingTimestamp != null //timestam of the connection is unknown
                    && connection._flCloseAfterAsyncOperations !== true
                    && (currentTimestamp - connection._pingTimestamp) > 120000 ) { //more then 120 seconds has passed since the last action through the connection
                        connection.close();        
                } else if ( connection._flCloseAfterAsyncOperations === true
                            && connection.open !== false
                            && connection._timestampCloseAfterAsyncOperations != null //if it is necessary to close the connection
                            && (currentTimestamp - connection._timestampCloseAfterAsyncOperations) > 240000 ) { //the connection still opened for 4 minutes, after it is closed
                                connection.resetNumIncompleteAsyncOperations(); //reset the number of an incompleted async operations to zero
                                connection.close(); //close the connection
                } else if ( connection.open === false ) { //connection not opened
                    connection._pingTimestamp = currentTimestamp; //set the timestamp to close connection if it is not opened   
                } else if ( connection._flCloseAfterAsyncOperations !== true ) { //if not necessary to close the connection after all async operations will have been done
                    connection._pingTimestamp = currentTimestamp; //set ping timestamp for the connection
                    connection.send(this.pingRequest); //send ping message to the peer 
                }
            }
        }
    }
};


/**
 * is connected to the cs
 * @method isPeerJSConnected
 * @return 
 */
DataConnectorProto.isPeerJSConnected = function(){
    var peerJS = this.serverConnection;
    
    if ( peerJS instanceof Peer === false ) {
        return false;    
    } else if (peerJS.disconnected === false
            && typeof(peerJS.id) === "number"
            && peerJS.open === true
            && this.isWebSocketOpen() === true ) { //is the WebSocket connection is open
                return true;    
    } else {
        return false;    
    }
};

//is WebSocket is in open state
/**
 * Description
 * @method isWebSocketOpen
 * @return 
 */
DataConnectorProto.isWebSocketOpen = function(){
    var peerJS = this.serverConnection;
    
    if ( peerJS instanceof Peer === false ) {
        return false;    
    } else if (peerJS.socket instanceof Socket
                && peerJS.socket._wsOpen() === true ) { //is the WebSocekt connection is in OPEN state
                    return true;    
    } else {
        return false;    
    }
};

//force reconnection to the cs
/**
 * Description
 * @method reconnectForce
 * @return 
 */
DataConnectorProto.reconnectForce = function(){
    
    var peerJS = this.serverConnection;
    this.timestamps.timestampDisconnectedFromCS = getTimestamp();
    
    if ( peerJS instanceof Peer 
        && peerJS.disconnected === true ) { //if connected to the cs at least once
            logger("!!!Reconnect to the CS"); //can to reconnect
            this.reconnect();
    } else {
        if ( peerJS.socket instanceof Socket ) {
            this._disconnect(); //close the WebSocket connection forcely
        } else {
            peerJS.disconnected = true;
            this.reconnect();
        }
    }  
};

//reconnect to the cs
/**
 * Description
 * @method reconnect
 * @return 
 */
DataConnectorProto.reconnect = function(){
   logger("!!!On reconnect to the CS"); //can to reconnect
   var peerJS = this.serverConnection;
   if ( this.destroyed !== true ) {
       if ( this.mode === true ) { //on the main thread side
        if ( this.isPeerJSConnected() === true ) { //if we are connected
            if ( this.disconnected === true ) { //if the state of the DataConnector is disconnected, but for really it is open
                this.onPeerOpen(peerJS.id);
            }
        } else { //if we are disconnected
            if ( peerJS instanceof Peer 
                    && peerJS.disconnected === true ) { //if connected to the cs at least once
                        logger("!!!Reconnect to the CS"); //can to reconnect
                        peerJS.reconnect();
            } else {
                //this.serverConnection.disconnected = true; //do the mock disconnection without using of the disconnect() method to avoid emitting some unnecessary events
                this.checkConnectionToServer();
            }
        }
       } else {
            this.sendCommand("Peer", "reconnect"); //send command for the mt side to reconnect to the cs   
       }
   }
};

//change the DataConnector state to disconnected
DataConnectorProto._disconnect = function(flInformOtherSide) {
    this.disconnected = true;
    if ( this.mode === true ) {
        var peerJS = this.serverConnection;
        if ( peerJS instanceof Peer //disconnect from the cs on the main thread side
            && peerJS.disconnected !== true ) { //if not disconnected already
                peerJS.disconnect();
        }
    }
    if ( flInformOtherSide === true ) { //it is necessary to inform the other side
        this.sendCommand("Peer", "disconnected", false); //send event to the other side with flInformOtherSide = false
    }
    logger("!!!Disconnect from the CS");
    this.emit("disconnected");
};

//close DataConnector
//if flInformOtherSide === true then the "close" event will be sent to the other side
/**
 * Description
 * @method disconnect
 * @param {} flInformOtherSide
 * @return 
 */
DataConnectorProto.disconnect = function(flInformOtherSide) {
    if ( this.destroyed !== true ) { //if not destroyed
        flInformOtherSide = flInformOtherSide == null ? true : flInformOtherSide;
        if ( this.mode === true ) { //on the mt side
            var peerJS = this.serverConnection;
            if ( peerJS instanceof Peer ) {        
                if ( this.isPeerJSConnected() === true 
                    && this.disconnected === true ) { //if really connected to the cs, but the data connector has the status = disconnected
                        logger("Change the state to be equal to the state of PeerJS");
                        this.onPeerOpen(peerJS.id); //change this state 
                } else 
                if ( this.disconnected !== true ) {//if necessary to change the state of the DataConnector to the "disconnected"
                    this._disconnect(flInformOtherSide); //if does not in already in the disconnected state
                }
            } else { //if connection to the cs is not exists by any reasons, create it
                this.createConnectionToCS();    
            }
        } else { //on the ww side
            this._disconnect(flInformOtherSide);
        }
    }
};

//set timeout, after that the message port will be closed
/**
 * Description
 * @method beforeClosingMessagePort
 * @return 
 */
DataConnectorProto.beforeClosingMessagePort = function(){
    var _self =this;
    var _messagePort = this.messagePort;
    if ( this.mode === true ) { //on the mt side
        var _timeout = setTimeout(function(){ //after the timeout port will be closed
            _messagePort.postMessage("_closeMessagePort"); //send a message to the port on the other side
            _messagePort._closed = true;
            _messagePort.onmessage = null;
            _messagePort.removeListener("message",arguments.callee);
            _messagePort.close(); //close the message port on this side of the DataConnector   
        }, 30000); //wait for 30 seconds
        //set the listener for message 'create'. This means that need to create a new DataConnector with this port as the default message port
        /**
         * Description
         * @method onmessage
         * @param {} event
         * @return 
         */
        _messagePort.onmessage = function(event){
            var msg = event.data;
            if ( msg === "create" ) { //create a new Data Connector
                logger("create the Data Connector once again");
                _messagePort.onmessage = null;
                clearTimeout(_timeout);  //do not close the message port
                var newDC = new DataConnector(_self.settings, _self.id); //create the new data connector
                newDC.setMessagePort(_messagePort); //set the message port for the new data connector
                _self.emit("newDC", newDC); //emit, that the new DataConnector has been created on the ww side
            }
        };
    }
};

/**
 * destroy connection to the cs
 * if flInformOtherSide === true then the "close" event will be sent to the other side
 * if flDoNotSendMessagesOnBrowserClose, then do not inform the cs and another peers about this closing
 * @method destroy
 * @param {} flInformOtherSide
 * @param {} flDoNotCallOnBrowserClose
 * @return 
 */
DataConnectorProto.destroy = function(flInformOtherSide, flDoNotCallOnBrowserClose) {
   this.destroyed = true; //set flags to disable all event handlers and listeners from the ww side
   this.disconnected = true;
   this.commandsListener.stopped = true; //stop the commands listener
   flInformOtherSide = flInformOtherSide == null ? true : flInformOtherSide;
   if ( flInformOtherSide === true ) { //if necessary to inform the other side about the closing
        this.sendCommand("Peer", "destroyed", false); //send event to the other side with flInformOtherSide = false
   }
   this.emit("close");
   this.removeAllListeners();
    if ( this.mode === true ) { //if executed on the main thread
        if ( this.serverConnection instanceof Peer 
            && this.serverConnection.destroyed === false ) { //remove all listeners and close the server connection
                if ( flDoNotCallOnBrowserClose !== true ) { //do not call the onBrowserClose method
                    this.onBrowserClose();
                }
                this.serverConnection.destroy();
        }
    } else { //on the ww side close all connecions with the peers, on the mt side thay were closed by Peer.js
       //close all the data connections with another peers
        this.closeAllDataConnections(flInformOtherSide);   
   }
   clearTimeout(this.intCloseExpiredDataConnections);
   logger("!!!Destroy the connection to the cs");
   this.beforeClosingMessagePort(); //for the mt side listen for the 'create' event to start over this DataConnector once again
};

/**
 * make new Peer for establish a connection to the central server
 * emit the event createNewConnectionToCS
 * @method createConnectionToCS
 * @return 
 */
DataConnectorProto.createConnectionToCS = function(){
    logger("!!!A new connection to the cs will be created");
    
    const self = this;
    if ( this.serverConnection instanceof Peer ) { //if not desrtroyed before this
        this.serverConnection.removeAllListeners();    
        this.serverConnection.destroy();
    }
    
    window
    .user
    .checkLoggedIn() //check the login status on facebook
    .then(function(res){ //get the access token and user id
        if ( Array.isArray(res) === true ) {
            var authservicename = res[0]; //authentification service name
            var socialUserID = this.socialUserID = res[1];
            var accessToken = res[2]; 
            var settingsPeerJS = self.settingsPeerJS;
            settingsPeerJS.token = accessToken; 
            settingsPeerJS.authservicename = authservicename;
            self.serverConnection = new Peer(socialUserID, settingsPeerJS); //peer.js connection constructructor
            self.socket = self.serverConnection.socket;
            self.setListenersConnectionToCS();
        } else {
            throw new Error("Error when login");
        }
    });
    
    this.timestamps.timestampDisconnectedFromCS = getTimestamp(); //update the timestamp to prevent destoying of the connection to the server
      
};

//son the mt side set the listeners for WebSocket event, that is the connection to the central server
/**
 * Description
 * @method setListenersWebSocket
 * @return 
 */
DataConnectorProto.setListenersWebSocket = function() {
    var _self = this;
    this.socket.on("message", function(data) { //on message from cs through the WebSocket connection
        logger("A message from the socket has came");
        _self.sendCommand("Socket", "event", null, null, ["message",data]); 
    }); 
    this.socket.on("close", function() { //on the WebSocket connection to the CS has closed
        logger("!!!The socket has closed");
        _self.sendCommand("Socket", "event", "close");
    });
};

//set the listeners for an events of the conection to the cs
/**
 * Description
 * @method setListenersConnectionToCS
 * @return 
 */
DataConnectorProto.setListenersConnectionToCS = function(){
    var _self = this;
    
    //connection to the cs closed or disconnected
    /**
     * Description
     * @method onDisconnect
     * @return 
     */
    function onDisconnect() { 
        if ( _self.destroyed !== true ) { //if has not been destroyed before
            var connectionToCS = _self.serverConnection;
            if ( connectionToCS instanceof Peer === true ) {
                _self.timestamps.disconnected = getTimestamp(); //set the timestamp when disconnected from the cs
                if ( connectionToCS.destroyed === true ) { //if destroyed can't to reconnect, create a new one instance of Peer
                    _self.serverConnection = null;
                    //remove listeners for closing events
                    removeAllListeners(); //remove all listeners for the current connection events
                    setTimeout(_self.createConnectionToCS.bind(_self), 100); //create the new connection with the server
                } else { //if disconnected
                    _self.disconnect(true);
                    if ( connectionToCS.disconnected === true ) { //check once again that the connection is closed
                        connectionToCS.removeListener("open", _self.onPeerOpen); //remove all the previos listeners for the open event
                        connectionToCS.once("open", _self.onPeerOpen); //set the listener for open event
                        setTimeout(connectionToCS.reconnect.bind(connectionToCS), 100); //reconnect with the server
                    }
                }
            } else { //if the connection to the main server is absent, then open it
                _self.disconnected = true;
                removeAllListeners(); //remove all listeners for the current connection events
                setTimeout(_self.createConnectionToCS.bind(_self), 100); //create the new connection with the server    
            }
            _self.timestamps.timestampDisconnectedFromCS = getTimestamp(); //set the timestamp of the last disconnection from the cs
        }
    }
    
    //on connection to the cs error
    /**
     * Description
     * @method onError
     * @param {} err
     * @return 
     */
    function onError(err) {
        if ( _self.destroyed === true ) {
            return;    
        }
        _self.emit("error", err);
        logger("!!!PeerJS connection error");
        logger(err);
    }
    
    //remove all listeners for the current connection events
    /**
     * Description
     * @method removeAllListeners
     * @return 
     */
    function removeAllListeners() {
        var connectionToCS = _self.serverConnection;
        
        if ( connectionToCS instanceof Peer === true ) {
            //remove old listeners
            connectionToCS.removeListener("disconnected", onDisconnect);
            connectionToCS.removeListener("close", onDisconnect);
            connectionToCS.removeListener("error", onError); 
            connectionToCS.removeListener("open", _self.onPeerOpen);
            connectionToCS.removeListener("connection", _self.onIncomingDataConnection);
        }
    }
    
    //remove an old and set the new listeners for connection to the cs
    /**
     * Description
     * @method setListeners
     * @return 
     */
    function setListeners(){
        var connectionToCS = _self.serverConnection;
        
        if ( connectionToCS instanceof Peer === true ) {
            //remove old listeners
            removeAllListeners();
            
            //set a new listeners
            connectionToCS.on("disconnected", onDisconnect);
            connectionToCS.once("close", onDisconnect);
            connectionToCS.on("error", onError);
            connectionToCS.once("open", _self.onPeerOpen);
            connectionToCS.on("connection", _self.onIncomingDataConnection);
        }
    } 
    
    setListeners();
};

/**
 * Description
 * @method onPeerOpen
 * @return 
 */
DataConnectorProto.onPeerOpen = function(){
    var connectionToCS = this.serverConnection; //save the current connection to the cs
    setTimeout(
        (function() {
            var dc = this.dc; //reference to the data connector
            if (dc === globalObj._globalDataConnector //if this dc is the current global data connector
                && dc.destroyed !== true
                && dc.serverConnection === connectionToCS 
                && dc.disconnected === true ) { //if disconnected
                    //this.serverConnection.removeListener("open", this.onPeerOpen); //remove the listener for open event
                    logger("!!!A new connection to the cs was established");
                    dc.destroyed    = false;
                    dc.disconnected = false;
                    var args = this.args; //arguments given by the DataConnectorProto.onPeerOpen
                    dc[dc.getMethodByName("onPeerOpen")](args[0],args[1],args[2],args[3]);
            }
        }).bind(
            {
                dc : this,
                args : arguments
            }
        )
        , 50); //whait for a one second to emit the Open event, may the connection to the cs will be disconnected during this time
};

//on connection to the cs opened on the mt side
//inform the ww side
/**
 * Description
 * @method mt_onPeerOpen
 * @param {} userID
 * @return 
 */
DataConnectorProto.mt_onPeerOpen = function(userID) {
    
    this.id = userID;
    this.emit("open", userID);
    this.sendCommand("Peer", "open", userID);
    this.socket = this.serverConnection.socket; //update the connection to the CS
    this.setListenersWebSocket();
    this.timestamps.disconnected = null;
    
    // setTimeout(
    //     (function cls(){ //disconnect from server after 25 seconds
    //         this.flClosed = true;
    //         this.socket.close();
    //         setTimeout(cls.bind(this), 25000);
    //     }).bind(this)
    // , 60000);
    
};

//on message from mt side, that the connection to the cs opened with the userID, given by the cs
/**
 * Description
 * @method ww_onPeerOpen
 * @param {} userID
 * @return 
 */
DataConnectorProto.ww_onPeerOpen = function(userID) {
    this.id = userID;
    
    if ( this.beenConnected !== true ) { //if has never been opened before
        this.beenConnected = true; //set the flag that been connected
        this.socket = new wwSocket(this); //emulation of the WebSocket connection to the server
    } 
    
    logger("Connected to the cs with the id " + userID);
    
    this.emit("open", userID);
};

//return true if connection to the cs has been established
/**
 * Description
 * @method isConnected
 * @return ConditionalExpression
 */
DataConnectorProto.isConnected = function() {
    return (this.mode === true) ? this.serverConnection instanceof Peer === true //on the mt side
                                    && typeof(this.serverConnection.id) === "number"
                                    && this.serverConnection.id !== 0
                                    && this.serverConnection.disconnected !== true
                                    && this.serverConnection.destroyed !== true
                                    && this.disconnected !== true
                                : this.id !== 0 //on the ww side determine by the user id
                                    && this.disconnected !== true //on the ww side determine by the user id
                                    && this.destroyed !== true;
};

//start the connection to the main server
//return a Promise, that is waiting while the connection to the main server will be opened, after that will return the user ID, that was given by the central server
/**
 * Description
 * @method open
 * @return NewExpression
 */
DataConnectorProto.open = function(){
    logger("Trying to open the connection to the cs");    
    var _self = this;
    var peerJS = _self.serverConnection;
    
    if ( _self.mode === true ) { //on the main thread side
        if ( ( peerJS instanceof Peer === false
            || peerJS.destroyed === true ) ) { //if the peer JS is not exists
                _self.createConnectionToCS();
        } else if ( peerJS instanceof Peer
                && peerJS.destroyed === false ) { //if already opened
                    _self.onPeerOpen(); //inform the ww thread about it
                    return;    
        }
    } else { //send the command to open the connection with the cs
        _self.sendCommand("Peer", "open", false); //send event to the mt to open a connection to the CS    
    }
    
    return new Promise(
        function(res, rej) {
            
            /**
             * Description
             * @method onConnect
             * @param {} userID
             * @return 
             */
            function onConnect(userID) { //cs return userID
                //chek if the message port is given
                if ( _self.messagePort instanceof MessagePort ) {
                    _self.removeListener("open", waitConnectionToCS);
                    logger("!!!Connection was opened");
                    res(userID); 
                    
                    if ( _self.mode === true ) { //on the main thread side
                        //start the procedures to control the connection state
                        _self.timestamps.timestampDisconnectedFromCS = getTimestamp(); //set the timestamp to not close the connection by the intCheckConnectionToCS when trying to connect for the first time
                        _self.intCloseExpiredDataConnections = setInterval(_self.closeExpiredDataConnections, _self.moduleSettings.intervalCheckExpiredDataConnections); //each 120 seconds close the expired Data Connections
                        _self.intSendHeartbeatToServer = setInterval(_self.sendHeartbeatToServer, timeIntervals.timeIntervalSecondsSendingHeartbeatMessage * 1000); //send heartbeat messages
                        _self.intCheckConnectionToCS = setInterval(_self.checkConnectionToServer, timeIntervals.timeIntervalMainP2PCheckConnection); //check the connection state to the central server
                    }    
                    
                } else { //wait while the message port will be set
                    _self.on("onSetMessagePort", function(){
                        waitConnectionToCS(userID);    
                    });
                }
            }

            /**
             * Description
             * @method waitConnectionToCS
             * @param {} userID
             * @return 
             */
            function waitConnectionToCS(userID) { //when DataConnector create a new connection to the central server
                if ( _self.isConnected() === false ) {
                    _self.once("open", waitConnectionToCS); //wait until the DataConnector will start a new connction to the central server    
                } else {
                    onConnect(userID);
                }
            }
            
            if ( _self.mode === true ) { //on the main thread side
                if ( _self.isConnected() === true ) { //if already opened with the id
                    onConnect(_self.id);    
                } else { //if waiting for opening of the connection to the central server
                    _self.removeListener("open", waitConnectionToCS);
                    _self.once("open", waitConnectionToCS); //wait until the DataConnector will start a new connction to the central server
                }
            } else {
                _self.removeListener("open", waitConnectionToCS);
            }
        }    
    );    
};

//return the prefix, depending on the side, where the code is executed
//return "mt" or "ww"
/**
 * Description
 * @method getPrefix
 * @return 
 */
DataConnectorProto.getPrefix = function(){
    if ( this.mode === true ) { //send event for ww
        return "mt";    
    } else { //send event for mt
        return "ww";
    }      
};

//return the method with the given name, depending on the side, where the code is executed
/**
 * Description
 * @method getMethodByName
 * @param {} commandName
 * @return BinaryExpression
 */
DataConnectorProto.getMethodByName = function(commandName) {
    return this.getPrefix() + "_" + commandName;    
};

//return data connection from store by it's id and type
/**
 * Description
 * @method getDataConnection
 * @param {} connType
 * @param {} uniqueID
 * @return MemberExpression
 */
DataConnectorProto.getDataConnection = function(connType, uniqueID){
    return this[connType+"_dataConnections"][uniqueID]; //prefix for the store - is the connection type
};

//remove data connection from the store
/**
 * Description
 * @method removeDataConnection
 * @param {} connType
 * @param {} uniqueID
 * @return 
 */
DataConnectorProto.removeDataConnection = function(connType, uniqueID){
    logger("Remove the data connection with type = " + connType + " and id = " + uniqueID);
    this[connType+"_dataConnections"][uniqueID] = null; //prefix for the store - is the connection type
};

//emit the new connection event for other side(ww or main thread)
//for the mt - to create a new connection
//for the ww - about incoming connection
//id = id of the connection
//connectionType = "incoming" or "created"
/**
 * Description
 * @method emitNewConnection
 * @param {} dataConnection
 * @return 
 */
DataConnectorProto.emitNewConnection = function(dataConnection) {
    var opt = {
        _uniqueID : dataConnection["_uniqueID"],
        _type : dataConnection["_type"],
        peer : dataConnection.peer,
        open : dataConnection.open,
        options : {}
    };
    if ( dataConnection.metadata != null ) {
        opt.options.metadata = dataConnection.metadata;
    }
    if ( dataConnection.serialization != null ) {
       opt.options.serialization = dataConnection.serialization; 
    }
    if ( dataConnection["_type"] === "incoming" ) {
        this.emit("connection", dataConnection);    
    } else {
        this.emit("createConnection", dataConnection);    
    }
    this.sendCommand("Peer", "connect", opt); //execute sendCommand method to inform the other side
};

//listener for the onData event of a DataConnection
//send this event to the ww side
/**
 * Description
 * @method mt_dataConnection_onData
 * @param {} data
 * @return 
 */
DataConnectorProto.mt_dataConnection_onData = function(data){
    var dataConnection = this;
    var dataConnector = dataConnection["_referenceToDC"];
    var pongResponse  = dataConnector.pongResponse;
    var pingRequest   = dataConnector.pingRequest;
    logger("Incoming data from the data connection with type = " + dataConnection["_type"] + " and id = " + dataConnection["_uniqueID"]);
    if ( data === pongResponse ) { //unset ping timestamp to not close the data connection by the procedure that is checking of a pings that were expired
        dataConnection._pingTimestamp = null;    
    } else if ( data === pingRequest ) { //send pong response to ping request
        dataConnection.send(pongResponse);
    } else if ( dataConnection["_flNotInformOtherSide"] !== true ) { //if flag that not necessary to inform the other side is not set
        dataConnector.sendCommand("DataConnection", "data", [dataConnection["_type"], dataConnection["_uniqueID"], ["data", data]]);
    }
};

//listener for the onOpen event of a DataConnection
//send this event to the ww side
/**
 * Description
 * @method mt_dataConnection_onOpen
 * @return 
 */
DataConnectorProto.mt_dataConnection_onOpen = function(){
    var dataConnection = this;
    logger("!!!Opened the data connection with type = " + dataConnection["_type"] + " and id = " + dataConnection["_uniqueID"]);
    if ( dataConnection.unactive !== true ) { //if not deactivated
        dataConnection._pingTimestamp = null; //unset timestamp, to not close this connection by the maintaince procedure called "close eexpired data connections"
        dataConnection["_referenceToDC"].sendCommand("DataConnection", "open", [dataConnection["_type"], dataConnection["_uniqueID"],["open"]]);
    }
};

//after when a data connection has emitted the "close" event
//the method is same on the both side
/**
 * Description
 * @method onDataConnectionClosed
 * @return 
 */
DataConnectorProto.onDataConnectionClosed = function() {
    if ( isDataConnection(this) === true ) {
        var dataConnection = this;
        var dataConnector = this["_referenceToDC"];
        logger("!!!On closed the data connection with type = " + dataConnection["_type"] + " and id = " + dataConnection["_uniqueID"]);
        dataConnection._pingTimestamp = null;
        dataConnector.removeDataConnectionFromStore(dataConnection); //delete from the store
        dataConnector.removeListenersForDataConnection(dataConnection);
        if ( dataConnection["_flNotInformOtherSide"] !== true ) { //if the flag that not necessary to inform the other side is not set
            dataConnector.sendCommand("DataConnection", "close", [dataConnection["_type"], dataConnection["_uniqueID"], ["close"]]); //inform the other side about closing the connection
        }
    }
};

//the other side informs about closing of a connection
//args = [0 : _type, 1 : _uniqueID]
/**
 * Description
 * @method dataConnection_close
 * @param {} args
 * @return 
 */
DataConnectorProto.dataConnection_close= function(args){
    var dataConnector, dataConnection;
    if ( Array.isArray(args) === true ) { //if dataConnection is an object with the options of the DataConnection instance
        dataConnector = this;
        dataConnection = dataConnector.getDataConnection(args[0], args[1]); //get DataConnection by type and unique id
    }
    if ( dataConnection != null ) {  //dataConnection was found
        dataConnection["_flNotInformOtherSide"] = true; //the other side is already knows about the closing of the data connection
        logger("!!!Close the data connection with type = " + dataConnection["_type"] + " and id = " + dataConnection["_uniqueID"]);
        dataConnection.close(dataConnector.mode);  //Close forcibly on the mt side, because on the ww side it is already closed
    } else {
        logger(new Error("DataConnection was not found"));
        logger(new Error(args));
    }
};

//listener for events from the mt side
//eventDesc = [0 : _type, 1 : _uniqueID, 2 : event]
//event = [0 : event type, 1 : [arguments]]
/**
 * Description
 * @method ww_dataConnection_emitEvent
 * @param {} eventDesc
 * @return 
 */
DataConnectorProto.ww_dataConnection_emitEvent = function(eventDesc){
    if ( Array.isArray(eventDesc) === true ) {
        var eventType = eventDesc[2][0]; //the type of the event to emit with the data connection
        if ( typeof(eventType) !== "string" ) {
            logger(new Error("Event type is not a string"));
            return;
        }
        var dataConnector = this;
        var dataConnection = dataConnector.getDataConnection(eventDesc[0],eventDesc[1]);
        if ( dataConnection != null ) {
                var eventArguments = eventDesc[2][1];
                logger("The event with the type = " + eventType + " from the the data connection with type = " + dataConnection["_type"] + " and id = " + dataConnection["_uniqueID"]);
                if ( eventType === "data" ) {
                    if ( dataConnection.open === true ) {
                        if (this.parseIncomingDataOnWW === true
                            && typeof(eventArguments) === "string") { //parse incoming data before fire an event
                                if ( JSON.parseAsync !== undefined ) { //if async method is available
                                    dataConnection.increaseNumIncompleteAsyncOperations();
                                    JSON.parseAsync(eventArguments, function(parsedData) {
                                        dataConnection.emit("data", parsedData);
                                        dataConnection.decreaseNumIncompleteAsyncOperations();    
                                    });
                                } else {
                                    dataConnection.emit("data", JSON.parse(eventArguments));    
                                }
                        } else  if (this.parseIncomingDataOnWW !== true
                            && typeof(eventArguments) === "object") {
                                dataConnection.emit("data", eventArguments);
                        }     
                    }
                } else if ( Array.isArray(eventArguments) ) { //if arguments is an Array
                    dataConnection.emit.apply(dataConnection, eventType, eventArguments); //call with all arguments
                } else if ( eventArguments !== undefined ) { //if only the one argument
                    dataConnection.emit(eventType, eventArguments); //emit an event of the given type and the given arguments
                } else { //event without an arguments 
                    dataConnection.emit(eventType);
                }
        } else { //data connection with the type and the unique ID was not found
            logger(new Error("Data connection with type = " + eventDesc[0] + " and unique ID = " + eventDesc[1] + " was not found. For emit the event with the type = " + eventType ));    
        }
    }
};

/**
 * Description
 * @method mt_dataConnection_onError
 * @param {} err
 * @return 
 */
DataConnectorProto.mt_dataConnection_onError = function(err){
    var dataConnection = this;
    logger("Error has been occurred in the data connection with the Peer " + dataConnection.peer );
    logger(err);
};

//send a data throw the data connection
//dataConnection - instance of DataConnection or
//dataConnection(!Array) = [0 : _type, 1 : _uniqueID, 2 : data]
/**
 * Description
 * @method dataConnection_sendData
 * @param {} args
 * @return 
 */
DataConnectorProto.dataConnection_sendData = function(args){
    var dataConnector,dataConnection, data;
    if ( isDataConnection(this) === true ) {
        dataConnection = this;
        dataConnector = dataConnection["_referenceToDC"]; 
        data = args;
    } else if ( Array.isArray(args) === true ) { //if dataConnection is an array : [ 0 - type of data connection, 1 - unique id of the data connection, 2 - data, that need to send by the data connection ]
        dataConnector = this;
        dataConnection = dataConnector.getDataConnection(args[0], args[1]); //get DataConnection by type and unique id
        data = args[2];
    }
    if ( dataConnection != null 
        && dataConnector instanceof DataConnector ) { //dataConnection was found
            logger("Send a data through the data connection with type = " + dataConnection["_type"] + " and id = " + dataConnection["_uniqueID"]);
            dataConnector[dataConnector.getMethodByName("dataConnection_sendData")](dataConnection, data); //exec the method, depending on the execution side
    } else {
        logger(new Error("DataConnection was not found"));    
    }
};

//send a data throw the data connection
/**
 * Description
 * @method mt_dataConnection_sendData
 * @param {} dataConnection
 * @param {} data
 * @return 
 */
DataConnectorProto.mt_dataConnection_sendData = function(dataConnection, data){
    dataConnection.send(data); //send the given data throw the data connection
};

//send a data throw the data connection
//inform the mt side to do this
/**
 * Description
 * @method ww_dataConnection_sendData
 * @param {} dataConnection
 * @param {} data
 * @return 
 */
DataConnectorProto.ww_dataConnection_sendData = function(dataConnection, data){
    var dataConnector = dataConnection["_referenceToDC"];
    if ( this.parseIncomingDataOnWW === true 
        && typeof(data) !== "string") { //need to send stringified data
            if ( JSON.stringifyAsync !== undefined ) { 
                dataConnection.increaseNumIncompleteAsyncOperations(); //increase the num of an async ops
                JSON.stringifyAsync(data, function(data) { 
                    dataConnector.sendCommand("DataConnection", "send", [dataConnection["_type"], dataConnection["_uniqueID"], data]); 
                    dataConnection.decreaseNumIncompleteAsyncOperations(); //decrease the num of an async ops
                });  
            } else {
               dataConnector.sendCommand("DataConnection", "send", [dataConnection["_type"], dataConnection["_uniqueID"], JSON.stringify(data)]);     
            }
    } else { //send the command for sending data throw the data connection to the mt side 
        dataConnector.sendCommand("DataConnection", "send", [dataConnection["_type"], dataConnection["_uniqueID"], data]);
    }
};

//set open to false
/**
 * Description
 * @method dataConnection_deactivate
 * @param {} flNotInformTheOtherSide
 * @return 
 */
DataConnectorProto.dataConnection_deactivate = function(flNotInformTheOtherSide){
    var dataConnection = this;    
    dataConnection.open = false;
    dataConnection.unactive = true;
    logger("Connection with the peer " + dataConnection.peer + " was deactivated" );
    var dataConnector = dataConnection["_referenceToDC"];
    if ( flNotInformTheOtherSide !== true
        && dataConnector instanceof DataConnector ) {
            dataConnector.sendCommand("DataConnection", "deactivate", true); //send this command to the other side
    }
};

//set the listeners for DataConnection
/**
 * Description
 * @method setListenersForDataConnection
 * @return 
 */
DataConnectorProto.setListenersForDataConnection = function() {
    this[this.getMethodByName("setListenersForDataConnection")](arguments[0],arguments[1],arguments[2],arguments[3]);
};

//set the listeners for the DataConnection on the main thread side
/**
 * Description
 * @method mt_setListenersForDataConnection
 * @param {} dataConnection
 * @return 
 */
DataConnectorProto.mt_setListenersForDataConnection = function(dataConnection) {
    dataConnection.on   ("data" , this.mt_dataConnection_onData);    
    dataConnection.on   ("error", this.mt_dataConnection_onError);
    dataConnection.once ("close", this.onDataConnectionClosed);
    dataConnection.once ("deactivate", this.dataConnection_deactivate);
    dataConnection.once("open"  , this.mt_dataConnection_onOpen);
    if ( dataConnection.open === true ) { //already opened
        dataConnection.emit("open");
    }
};

//set the listeners for DataConnection on the ww side
/**
 * Description
 * @method ww_setListenersForDataConnection
 * @param {} dataConnection
 * @return 
 */
DataConnectorProto.ww_setListenersForDataConnection = function(dataConnection) {
    dataConnection.once("deactivate", this.dataConnection_deactivate);
    dataConnection.on("sendData", this.dataConnection_sendData); //send a data throw the data connection  
    dataConnection.on("close"   , this.onDataConnectionClosed); //on data connection emit "close" event
};

//remove the listeners for DataConnection
/**
 * Description
 * @method removeListenersForDataConnection
 * @return 
 */
DataConnectorProto.removeListenersForDataConnection = function() {
    this[this.getMethodByName("removeListenersForDataConnection")](arguments[0],arguments[1],arguments[2],arguments[3]);
};

//remove a listeners for the DataConnection on the main thread side
/**
 * Description
 * @method mt_removeListenersForDataConnection
 * @param {} dataConnection
 * @return 
 */
DataConnectorProto.mt_removeListenersForDataConnection = function(dataConnection) {
    dataConnection.removeListener("data" , this.mt_dataConnection_onData);    
    dataConnection.removeListener("error", this.mt_dataConnection_onError);
    dataConnection.removeListener("close", this.onDataConnectionClosed);
    dataConnection.removeListener("open"  , this.mt_dataConnection_onOpen);
    dataConnection.removeListener("deactivate", this.dataConnection_deactivate);
};

//remove the listeners for DataConnection on the ww side
/**
 * Description
 * @method ww_removeListenersForDataConnection
 * @param {} dataConnection
 * @return 
 */
DataConnectorProto.ww_removeListenersForDataConnection = function(dataConnection) {
    dataConnection.removeListener("sendData", this.dataConnection_sendData); //send a data throw the data connection  
    dataConnection.removeListener("close"   , this.onDataConnectionClosed); //on data connection emit "close" event
    dataConnection.removeListener("deactivate", this.dataConnection_deactivate);
};

/**
 * put the data connection to the store and return the unique id of the connection
 * it is necessary to give the id as the pair id of the connection in the main thread side or ww side
 * @method putDataConnectionToStore
 * @param {} dataConnection
 * @param {} id
 * @return dcID
 */
DataConnectorProto.putDataConnectionToStore = function(dataConnection, id) {
    var storePrefix = dataConnection["_type"]; //the prefix depending on the connection type - incoming from another peer or created on the client side
    
    if ( id == null ) { //if the id for the connection is not given as the argument, create new id for the connection
        var dcID = this[storePrefix + "_idDataConnection"]; //it is the length of the data connection store
        if ( dcID == null
            || dcID > this.maxDataConnections ) {
                this[storePrefix + "_idDataConnection"] = dcID = 0; //reset to zero if more then one  
        } else { //increment the current pointer to id for a data connection
            dcID = this[storePrefix + "_idDataConnection"]++;    
        } 
    } else { //if the id for the connection is given as the argument
       dcID = id; //save under the given id
    }
    var oldConnection = this[storePrefix + "_dataConnections"][dcID];
    if ( oldConnection != null ) { //if old connection is exists under this unique id
        oldConnection.close(); //close it
    }
    this[storePrefix + "_dataConnections"][dcID] = dataConnection;
    dataConnection["_uniqueID"] = dcID; //unique id of the connection
    if ( this.parseIncomingDataOnWW === true ) { //not need to parse json on mt side
        dataConnection["_flDoNotParseJSON"] = true; //set the special flag    
    }
    logger("Put to the store the data connection with type = " + dataConnection["_type"] + " and id = " + dataConnection["_uniqueID"]);
    return dcID; 
};

//remove connection from the store
/**
 * Description
 * @method removeDataConnectionFromStore
 * @param {} dataConnection
 * @return 
 */
DataConnectorProto.removeDataConnectionFromStore = function(dataConnection){
    this.removeDataConnection(dataConnection["_type"], dataConnection["_uniqueID"]);
};

//on incoming data connection from other peer
//on the Web Worker side it is necessary to call this with the argument = id of the data connecction from the main thread
//args - id of the connection or instance of DataConnection PeerJS
/**
 * Description
 * @method onIncomingDataConnection
 * @return 
 */
DataConnectorProto.onIncomingDataConnection = function() {
    if ( this.destroyed === true ) {
        return;    
    }
    logger("An incoming data connection");
    this[this.getMethodByName("onIncomingDataConnection")](arguments[0],arguments[1],arguments[2],arguments[3]);
};

//on incoming DataConnection instance
/**
 * Description
 * @method mt_onIncomingDataConnection
 * @param {} dataConnection
 * @return 
 */
DataConnectorProto.mt_onIncomingDataConnection = function(dataConnection) {
    dataConnection["_type"] = "incoming"; //set the flag that it is the incoming connection
    dataConnection["_referenceToDC"] = this; //reference to the DataConnectors
    this.putDataConnectionToStore(dataConnection);
    logger("!!!Incoming data connection with the peer " + dataConnection.peer + " type " + dataConnection["_type"] + " id = " + dataConnection["_uniqueID"]);
    this.emitNewConnection(dataConnection); //emit the event new connection with the type = "incoming" for the ww side
    this.setListenersForDataConnection(dataConnection);
};
    
//it is necessary to give the id of the connection from the main thread
//settings = { _uniqueID - id of the connection into the store; peer - id of the connected peer; options for Peer.connect = options = {metadata - of the connection; serialization - serialization method and so on}; "_type" - "incoming" or "created" }
/**
 * Description
 * @method ww_onIncomingDataConnection
 * @param {} settings
 * @return dataConnection
 */
DataConnectorProto.ww_onIncomingDataConnection = function(settings) {
    var dataConnection = new WWDataConnection(settings); //create a mock data connection for WebWorker side 
    dataConnection["_referenceToDC"] = this;
    this.putDataConnectionToStore(dataConnection, settings["_uniqueID"]);
    //emit the event "connection" that informs about the new incoming data connection
    this.emit("connection", dataConnection);
    this.setListenersForDataConnection(dataConnection);
    return dataConnection;
};

//create data connection
//on the main thread side it is necessary to call this with the argument = id of the data connecction from the WebWorker
/**
 * Description
 * @method connect
 * @return CallExpression
 */
DataConnectorProto.connect = function() {
    return this[this.getMethodByName("connect")](arguments[0],arguments[1],arguments[2],arguments[3]); 
};

//create data connection on the main thread side and save it into the store, and save the given unique id from the web worker
//settings = { _uniqueID - id of the connection into the store; peer - id of the connected peer; options for Peer.connect = options = {metadata - of the connection; serialization - serialization method and so on}; "_type" - "incoming" or "created" }
/**
 * Description
 * @method mt_connect
 * @param {} settings
 * @return 
 */
DataConnectorProto.mt_connect = function(settings) {
    var peerJS = this.serverConnection;
    if (peerJS instanceof Peer
        && peerJS.disconnected !== true ) {
        
            var dataConnection = peerJS.connect(settings.peer, settings.options); //create an instance of PeerJS DataConnection with peer that has the given id
            if ( dataConnection == null ) {
                throw new Error("Data connection was not created!");    
            }
            dataConnection["_referenceToDC"] = this; //referense to the DataConnector
            dataConnection["_type"] = settings["_type"];
            this.putDataConnectionToStore(dataConnection, dataConnection["_uniqueID"]); //put the connection to the store under the given id
            logger("!!!Try to open the data connection with the peer " + settings.peer + " type " + dataConnection["_type"] + " id = " + dataConnection["_uniqueID"]);
            this.setListenersForDataConnection(dataConnection);
            this.emit("createConnection", dataConnection);
            
            return dataConnection;
    } else {
        return null;    
    }
};

//create data connection on the WebWorker side and save it into the store with the unique id
//id = Peer id
//options = as Peer.connect options 
/**
 * Description
 * @method ww_connect
 * @param {} id
 * @param {} options
 * @return 
 */
DataConnectorProto.ww_connect = function(id, options){
    if ( this.disconnected !== true ) { //if not disconnected from the cs
        var settings = {
            peer : id,
            options : options,
            _type : "created"
        };
        var dataConnection = new WWDataConnection(settings); //create a mock data connection for WebWorker side
        dataConnection["_referenceToDC"] = this; //referense to the DataConnector
        this.putDataConnectionToStore(dataConnection);
        this.emitNewConnection(dataConnection); //emit about creating the connection to the main thread to open it
        this.setListenersForDataConnection(dataConnection);
        return dataConnection;
    } else {
        return null;    
    }
};

//define a handlers for incoming messages from the ww
//structure { type,kind : (name of a handler function for ww) }
//handler function will be executed with the argument = body of the message and with the context. 
DataConnectorProto.mt_incomingCommandHandlers = {
    "Peer" : {
        "open" : "open",
        "reconnect" : "reconnect",
        "connect" :"connect", //on new connection on the other side
        "disconnected" : "disconnect", //on connection to the main server closed
        "destroyed" :"destroy", //on connection to the main server destroyed
        "setDataConnectorID" : "setDataConnectorID" //set the id for the instance of the DataConnector
    },
    "DataConnection" : {
        "close" : "dataConnection_close", //on the ww side - emot an event that the connection was closed
        "send"  : "dataConnection_sendData", //no handler on the ww side
        "deactivate" : "dataConnection_deactivate" //set open to false value
    },
    "Socket" : {
        "send" : "socket.send" //send a data throught WebSocket connection to the CS of the PeerJS/ Not required on the ww side
    }
};

//define a handlers for incoming messages from the mt
//structure { type,kind : (name of a handler function for ww) }
//handler function will be executed with the argument = body of the message and with the context. 
DataConnectorProto.ww_incomingCommandHandlers = {
    "Peer" : {
        "open" : "onPeerOpen",
        "connect" : "onIncomingDataConnection", //on new connection on the other side
        "disconnected" : "disconnect", //on connection to the main server closed
        "destroyed" : "destroy" //on connection to the main server destroyed
    },
    "DataConnection" : {
        "open"  : "ww_dataConnection_emitEvent", //no handler on the mt side. The method ww_dataConnection_emitEvent is exists only on the ww side
        "data"  : "ww_dataConnection_emitEvent", //no handler on the mt side. The method ww_dataConnection_emitEvent is exists only on the ww side
        "close" : "dataConnection_close", //on the ww side - emot an event that the connection was closed
    },
    "Socket" : {
        "event" : "socket.emit" //emit an event by the socket. 
    }
};

//executed if a handler for incoming command has not been found or DataConnector has been destroyed
/**
 * Description
 * @method handlerNoHandlerOrStopped
 * @return 
 */
DataConnectorProto.handlerNoHandlerOrStopped = function(){
    if ( this.destroyed === true ) {
        this.sendCommand("Peer", "destroyed", false); //send event to the other side with flInformOtherSide = false  
    } 
};

/**
 * send a message for all opened DataConnections with the types: "incoming" or "created"
 * @method sendForAllDataConnections
 * @param {} message
 * @return 
 */
DataConnectorProto.sendForAllDataConnections = function(message) {
    var listIncoming = this["incoming_dataConnections"];    
    var listCreated  = this["created_dataConnections"];
    
    var idsIncoming  = Object.keys(listIncoming); //ids of the incoming Data Connections
    var idsCreated   = Object.keys(listCreated);  //ids of the created  Data Connections
    
    var i, len, idConnection, dc;
    
    for ( i = 0, len = idsIncoming.length; i < len; i++ ) {
        idConnection = idsIncoming[i];
        dc = listIncoming[idConnection]; //instance of DataConnection
        if ( isDataConnection(dc) //if the real connection
            && dc.open === true ) { //and open
                dc.send(message); //send the message       
        }
    }
    
    for ( i = 0, len = idsCreated.length; i < len; i++ ) {
        idConnection = idsCreated[i];
        dc = listIncoming[idConnection] //instance of DataConnection
        if ( isDataConnection(dc) //if the real connection
            && dc.open === true ) { //and open
                dc.send(message); //send the message       
        }
    }
    
};

/**
 * close all opened DataConnections with the types: "incoming" or "created"
 * @method closeAllDataConnections
 * @param {} _flInformOtherSide
 * @return 
 */
DataConnectorProto.closeAllDataConnections = function(_flInformOtherSide) {
    var listIncoming = this["incoming_dataConnections"];    
    var listCreated  = this["created_dataConnections"];
    
    var idsIncoming  = Object.keys(listIncoming); //ids of the incoming Data Connections
    var idsCreated   = Object.keys(listCreated);  //ids of the created  Data Connections
    
    var i, len, idConnection, dc;
    
    var flInformOtherSide = _flInformOtherSide == null ? true : _flInformOtherSide;
    
    for ( i = 0, len = idsIncoming.length; i < len; i++ ) {
        idConnection = idsIncoming[i];
        dc = listIncoming[idConnection]; //instance of DataConnection
        if ( isDataConnection(dc) //if the real connection
            && dc.open === true ) { //and open
                if ( flInformOtherSide === false  ) { //not necessary to inform the other side about the closing
                    dc["_flNotInformOtherSide"] = true;    
                }
                dc.close(); //close       
        }
    }
    
    for ( i = 0, len = idsCreated.length; i < len; i++ ) {
        idConnection = idsCreated[i];
        dc = listIncoming[idConnection] //instance of DataConnection
        if ( isDataConnection(dc) //if the real connection
            && dc.open === true ) { //and open
                if ( flInformOtherSide === false  ) { //not necessary to inform the other side about the closing
                    dc["_flNotInformOtherSide"] = true;    
                }
                dc.close(); //close       
        }
    }
    
};

/**
 * when the browser was closed by the user
 * if flDoNotSendInformingMessages === true, then do not send the messages to other peers and the cs about closing
 * @method onBrowserClose
 * @return 
 */
DataConnectorProto.onBrowserClose = function() {
    if ( this.destroyed !== true ) { 
        if ( this.isPeerJSConnected() === true ) { //if not disconnected
            
            this.sendForAllDataConnections(this._messageForELSOnBrowserClosed); //send message for all connected users
            this.sendForAllDataConnections(this._messageForILSOnBrowserClosed); //send message for all connected users
            this.socket._socket.send(this._messageForCSOnBrowserClosed); //send message to the cs

            this.destroy(null, true); //close all data connections (true - do not call onBrowserClose from the destroy method)
        }
    }
};

DataConnector.prototype = DataConnectorProto;

module.exports = {
  DataConnector : DataConnector
};