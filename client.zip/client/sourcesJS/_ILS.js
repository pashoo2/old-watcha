        /*jshint curly:true, debug:true */
        /* global geolib */
        /*global localStorage*/
        "use strict";
        var EventEmitter = require("eventemitter");
        var timestamps = require("timestamps");
        var timeIntervals = require("timeIntervals");
        var validators = require("validatorsILS").validatorsILS;
        var commonlib = require("commonlib");
        var glib = require("glib");
        var logger = require("logger").logger;
        var globalSettings = require("globalSettings");
        logger.namespace = "ILS";
        var libMainP2P = require("libMainP2P");

        if (ExternalLocalServer === undefined) {
            var ExternalLocalServer = require("ExternalLocalServer").ELS;
        }

        //main variables--
        var getCurrentTimestamp = timestamps.getCurrentTimestamp;
        var isValidTimestamp = timestamps.isValidTimestamp;
        var isDataConnection = libMainP2P.isDataConnection;
        var returnMainP2P = libMainP2P.returnMainP2P;
        var setDataConnectionMetadataTimestamp = libMainP2P.setDataConnectionMetadataTimestamp;
        var isPeer = libMainP2P.isPeer;
        var isSocket = libMainP2P.isSocket;
        var isILS = libMainP2P.isILS;
        var isELS = libMainP2P.isELS;
        var isArray = commonlib.isArray;
        var strToInt = commonlib.strToInt;
        var numToStr = commonlib.numToStr;
        var isMainP2P = libMainP2P.isMainP2P;
        var getConnectionTimestamp = libMainP2P.getConnectionTimestamp;
        var uniqueItems = commonlib.uniqueItems; //return new array with the unique items from the giveen
        var mergeUnique = commonlib.mergeUnique;
        var empty_user_id = globalSettings.empty_user_id; //the value, that is representation of an empty id of the user
        var isEmptyLSID = commonlib.isEmptyLSID; //check if the given id is empty
        //--main variables

        var moduleSettings = globalSettings.settingsILS;
        var settingsDebug  = globalSettings.settingsDebug;
        
        /**
         * @constructor
         * @class InnerLocalServer
         * @classdesc use for maintaince of a locations - to watch for the user on this locations, and send them an information about other users, that are placed on a maintained locations
         * @property {object} handledLocations - list of handled locations or only a one location
         * @property {number} handledLocations.locationHash - hash of a location, that is handled by the ils
         * @property {object} ELSConnections - connections to the ls, which are maintained the nearest locations to a handled locations through an ELS connections
         * @property {number} ELSConnections.locationHash - is a location, that is maintained by the local server, and ELS - is a External Local Server instance, that is a connection to the local server
         * @property {ExternalLocalServer} ELSConnections.locationHash.ELS - connection to the nearest ls, which is maintains a nearest location
         * @property {object} ELSConnections.locationHash.userDesc - ocation description with users on the maintained location with hash = locationHash
         * @method InnerLocalServer
         * @param {} mainConnection
         * @param {} cb - function called when the ILS will be started
         * @return 
         */
        function InnerLocalServer(mainConnection, cb) {
            
            if (isMainP2P(mainConnection) === false) {
                return false;
            }
            
            //set the id for this ils
            if ( self.ilsID == null ) { //check the ils id
                this.ilsID = self.ilsID = 0;    
            } else {
                this.ilsID = ++self.ilsID;    
            }
            
            logger("ILS starting with id = " + this.ilsID);
            
            this.g_MainP2P = mainConnection; //reference to MainP2P
            this.ID = mainConnection.getUserID(); //this user ID
            self.handledLocations = this.handledLocations = {}; //self = WorkerGlobalScope
            this.handledLocationsList = []; //list of the maintained locations? for performance it is the array
            this.ELSConnections = {}; //all connections to the els
            this.intCheckingIncomingUsers = setInterval(this.checkIncomingUsers.bind(this), timeIntervals.timeIntervalInnerLocalServerCheckIncomingUsers);
            this.intCheckConnectedUsers = setInterval(this.checkUsers.bind(this), timeIntervals.timeIntervalInnerLocalServerCheckUsers);
            this.intRequestHashesOfUsers = setInterval(this.requestHashesOfUsers.bind(this), timeIntervals.timeIntervalInnerLocalServerRequestUsersLocationsHashes);
            this.intCleanListOfMovedUsers = setInterval(this.cleanListMovedUsers.bind(this), timeIntervals.timeSecondsInnerLocalServerMovedUsersDelay * 1000);
            this.intCreateJSONLocationsDescription = setInterval(this.createJSONLocationsDescription.bind(this), timeIntervals.timeIntervalSecondsCreateJSONLocationsDescription * 1000);
            
            //check overhead for this ls
            this.intcheckOverhead = setInterval(this.checkOverhead.bind(this),  (timeIntervals.timeIntervalSecondCheckOverhead * 1000) );
            this.intCheckMaintainedLocationsOverdue = setInterval(this.checkMaintainedLocationsOverdue.bind(this), timeIntervals.timeIntervalSecondCheckHandlingLocationsOverdue * 1000);
            
            //bind all methods to this context
            this.onMessageFromCS = this.onMessageFromCS.bind(this);
            this.onConnectedToCS = this.onConnectedToCS.bind(this);
            
            this.handlersIncomingMessageFromLS = this.formHandlersIncomingMessageFromLS(this); //form the handlers for incoming messages from another local servers
            this.isValidUserDataConnection = this.isValidUserDataConnection.bind(this);
            
            this.listCallbacksForIncomingMessagesFromCS = {}; // { uniqueID = [timestampSend, Promise] } - list with a promises for messages with the unique id, that are waiting for the messages from the cs
            this.messageUniqueID = 10000; //unique ID for the next sending messages for cs
            
            //on events, fired by main p2p
            mainConnection.on("messageFromCS_CSToILS", this.onMessageFromCS); //message from the cs received
            mainConnection.on("connectedAgain", this.onConnectedToCS); //on connected to the cs once again, send the "pong" message for all handled locations
            
            this.onConnectedToCS(cb);

        }

        /** 
         * inner local server closed
         * @event ilsClosed 
         */
        /** 
         * new location for handling has been added
         * @event ilsNewLocation 
         * @param {String} locationHash  
         */
        /** 
         * new location for handling has been added
         * @event ilsStopLocation
         * @param {String} locationHash
         */

        var ILSProto = Object.create(new EventEmitter());
        ILSProto.constructor = InnerLocalServer;
        
        ILSProto.debugProperties = {
            flNotAllowAnyConnections : false //do not allow any  incoming DataConnections   
        };
        
        //function allow to set a debug property to the given value
        /**
         * Description
         * @method setDebugProperty
         * @param {} propertyName
         * @param {} value
         * @return 
         */
        ILSProto.setDebugProperty = function(propertyName, value){
            if ( commonlib.hasProperty(this.debugProperties, propertyName) === true ) { //if the property with the given name is exists
                this.debugProperties[propertyName] = value;
            }    
        };
        
        /** handledLocation
         * handledLocation.users = [ userID:usrDesc ]
         * usrDesc.dataConnection = DataConnection to user;
         * usrDesc.timestamp = description timestamp;
         * usrDesc.userID    = userID //user ID;
         * usrDesc.location  = {locationHash, timestamp, lat, lng}
         * usrDesc.location.locationHash = user location hash;
         * usrDesc.location.timestamp    = timestamp of a last user location update
         * usrDesc.location.lat = latitude coordinate
         * usrDesc.location.lng = longitude coordinate*/
        
        //check if closed
        /**
         * Description
         * @method isClosed
         * @return LogicalExpression
         */
        ILSProto.isClosed = function() {
            var ils = this;
            return ils.g_flClosedManually === true
                    || ( ils.g_MainP2P instanceof MainP2P === false );    
        };
        
        /**
         * close the ils 
         * @method close
         * @return 
         */
        ILSProto.close = function() {
            var ils = this;
            
            logger("Closing ils with id " + ils.ilsID);
            
            if (ils.intCheckingIncomingUsers != null) {
                clearInterval(ils.intCheckingIncomingUsers);
                ils.intCheckingIncomingUsers = null;
            }

            if (ils.intCheckConnectedUsers != null) {
                clearInterval(ils.intCheckConnectedUsers);
                ils.intCheckConnectedUsers = null;
            }
            if (ils.intRequestHashesOfUsers != null) {
                clearInterval(ils.intRequestHashesOfUsers);
                ils.intRequestHashesOfUsers = null;
            }
            if (ils.intCleanListOfMovedUsers != null) {
                clearInterval(ils.intCleanListOfMovedUsers);
                ils.intCleanListOfMovedUsers = null;
            }
            if (ils.intCreateJSONLocationsDescription != null) {
                clearInterval(ils.createJSONLocationsDescription);
                ils.intCreateJSONLocationsDescription = null;
            }
            if (ils.intCheckHandlingLocationsOverflow != null) {
                clearInterval(ils.intCheckHandlingLocationsOverflow);
                ils.intCheckHandlingLocationsOverflow = null;
            }
            if (ils.intCheckMaintainedLocationsOverdue != null) {
                clearInterval(ils.intCheckMaintainedLocationsOverdue);
                ils.intCheckMaintainedLocationsOverdue = null;
            }            

            ils.stopMaintainceAllLocations(); //stop handling all locations            
            ils.g_flClosedManually = true;
            ils.g_MainP2P = false;
            ils.emit("close");
            ils.removeAllEvListeners();
        };
        
        //stop handling all locations and close all els instances
        /**
         * Description
         * @method stopMaintainceAllLocations
         * @return 
         */
        ILSProto.stopMaintainceAllLocations = function() {
            
            var ils = this;
            var maintainedLocationsList = ils.getListOfMaintainedLocations();
            if ( maintainedLocationsList !== false ) {
                var maintainedLocations = maintainedLocationsList.slice(); //make a copy of the list of the maintained locations, because of the original array will be changed by removing it's elements   
                for (var i = 0, len = maintainedLocations.length; i < len; i++) { //stop maintaince of all locations
                    ils.stopLocationHandling(maintainedLocations[i]);
                }
            }
            
            //close a connections to all the nearest local servers
            var ELSConnectionsDesc = ils.getAllNearestLocationsDesc();
            if ( ELSConnectionsDesc !== false ) {
                var _keys = Object.keys(ELSConnectionsDesc);
                for( i = 0, len = ELSConnectionsDesc.length; i < len; i++ ) {
                    var nearestLocationDesc = ELSConnectionsDesc[_keys[i]];    
                    if ( commonlib.hasProperty(nearestLocationDesc, "ELS") === true ) { //close an ELS connection for a nearest LS if exists
                        ILSProto.closeELS(nearestLocationDesc.ELS);
                    }
                }
            } 
            
        };
                
        //remove all the locations from the local storage
        /**
         * Description
         * @method removeHandledLocationsFromLocalStorage
         * @param {} cb
         * @return 
         */
        ILSProto.removeHandledLocationsFromLocalStorage = function(cb) {
            logger("Remove all the maintained locations from the db");
            localStorage
                .keys( //get list with all keys from the local storage
                    function(err, keys) {
                        if ( err instanceof Error === false
                            || keys != null ) { //if the kyes are absent
                                var i = keys.length;
                                var promisesToDo = [];
                                var ind = 0;
                                while ( i-- ) {
                                    var lh = keys[i];
                                    if ( isNaN(lh) === false ) { //if the key is a location hash
                                        promisesToDo[ind++] = localStorage.removeItem(commonlib.numToStr(lh));
                                        logger("Remove location " + lh + " from the db");
                                        promisesToDo[ind++] = localStorage.removeItem("nearest_" + lh);
                                    }
                                }
                                
                                if ( typeof(cb) === "function" ) { //if the callback is defined
                                    if (promisesToDo.length > 0 ) { //waiting for promises
                                        Promise
                                            .all(promisesToDo)
                                            .then(cb, cb);
                                    } else { //call the callback
                                        cb();    
                                    }
                                }
                                
                        }
                });    
            
        };
        
        //load the list of the handled locations from the local storage
        //cb - callback functiob
        /**
         * Description
         * @method loadHandledLocationsFromLocalStorage
         * @param {} cb
         * @return 
         */
        ILSProto.loadHandledLocationsFromLocalStorage = function(cb){
            localStorage.getItem("timestamp_ClientClosed", 
                function(err, resTimestamp) { //try to get the timestamp when closed
                    
                    if ( err !== null //if an error
                        || resTimestamp === null //or this key is not exists
                        || ( getCurrentTimestamp() - strToInt(resTimestamp) ) > timeIntervals.timeoutLocationHandlingAfterClientDisconnectedFromCS ) { //or too much time
                            cb(null);
                            localStorage.clear();
                    } else {
                        localStorage
                            .keys( //get list with all keys from the local storage
                                function(err, keys) {
                                    
                                    if ( err instanceof Error
                                        || keys == null ) { //if the kyes are absent
                                            cb(null);    
                                    } else {
                                        var i = keys.length;
                                        var values = {};
                                        var promisesToDo = []; //array with promises to do
                                        var ii = 0;
                                        while ( i-- ) {
                                            var lh = keys[i];
                                            if ( isNaN(lh) === false ) { //if the key is a location hash
                                                values[lh] = {}; //put the location hash to the results
                                                promisesToDo[ii++] = localStorage.getItem("nearest_" + lh) //load the nearest users from the db
                                                                           .bind({lh : lh})
                                                                           .then(function(val) {
                                                                                if ( val instanceof Error
                                                                                    || val === null ) { //if error or empty list of the nearest local servers
                                                                                        delete values[this.lh]; //remove the location from the resulted list
                                                                                } else { //put the list with the nearest local servers to the result
                                                                                    values[this.lh] = val;        
                                                                                }
                                                                           })
                                                                           .catch(function(){ //if an error
                                                                                delete values[this.lh]; //remove the location from the resulted list   
                                                                           });
                                            }
                                        }
                                        if ( promisesToDo.length > 0 ) { //if the promises for getting the nearest local servers are exists
                                            Promise
                                                .all(promisesToDo) //get all the nearest local servers
                                                .then(function(){
                                                    cb(values);   //retur the maintained locations with the nearest local servers 
                                                });
                                        } else {
                                            cb(null);
                                        }
                                    }
                                }
                            ); 
                    }
                }
            );
        };
        
        /**
         * remove all the listeners for the ils and events, that are listened by this instance
         * @method removeAllEvListeners
         * @return 
         */
        ILSProto.removeAllEvListeners = function() {
            var ils = this;
            
            var mainConnection = returnMainP2P(ils);
            if ( mainConnection !== null ) {
                mainConnection.removeListener("messageFromCS_CSToILS", this.onMessageFromCS); //message from the cs received
                mainConnection.removeListener("connectedAgain", this.onConnectedToCS); //on connected to the cs once again, send the "pong" message for all handled locations
            }
            
            ils.removeAllListeners();
            
        };

        /**
         * if the ils is open
         * then
         * @method isOpen
         * @return LogicalExpression
         */
        ILSProto.isOpen = function() {
            return isMainP2P(this.g_MainP2P) === true && this.g_flClosedManually !== true;
        };


        /**
         * check timeout of incoming users
         * @method checkIncomingUsers
         * @return 
         */
        ILSProto.checkIncomingUsers = function() {
            var ils = this;
            var maintainedLocations = ils.getListOfMaintainedLocations();
            for (var i = 0, len = maintainedLocations.length; i < len; i++) {
                var incomingUsersList = ils.getIncomingUsersDescription(maintainedLocations[i]);
                if (incomingUsersList === false || commonlib.isEmptyObject(incomingUsersList) === true) {
                    continue;
                }
                var _keys = Object.keys(incomingUsersList); //incoming users ID
                for (var ii = 0, _len = _keys.length; ii < _len; ii++) {
                    var incomingUserID = _keys[ii];
                    var incomingUserDesc = incomingUsersList[incomingUserID]; //description of an incoming user
                    if (typeof(incomingUserDesc.timestamp) !== "number" //there is no timestamp
                        || (getCurrentTimestamp() - incomingUserDesc.timestamp) > timeIntervals.timeIntervalInnerLocalServerCheckIncomingUsers) { //if the user is outdated
                        delete incomingUsersList[incomingUserID]; //remove it's description from the list
                    }
                }
            }
        };



        /**
         * check timeout of users, connected to the ils
         * @method checkUsers
         * @return 
         */
        ILSProto.checkUsers = function() {
            var ils = this;
            var maintainedLocations = ils.getListOfMaintainedLocations(); //list with all the maintained locations
            for (var i = 0, len = maintainedLocations.length; i < len; i++) {
                var locationHash = maintainedLocations[i];
                var usersList = ils.getUsersDescription(locationHash); //description of the users on the maintained location
                if (usersList === false) {
                    continue;
                }
                var _keys = Object.keys(usersList); //an ID of the user on the maintaied location
                for (var ii = 0, _len = _keys.length; ii < _len; ii++) {
                    var userID = _keys[ii];
                    var userDesc = usersList[userID]; //description of the incoming user
                    if (typeof(userDesc.timestamp) !== "number" //there is no timestamp
                        || (getCurrentTimestamp() - userDesc.timestamp) > timeIntervals.timeIntervalInnerLocalServerCheckUsers) { //if the user is outdated
                        ils.closeUserConnection(userID, locationHash);
                    }
                    //check, that the user is not on the several locations simultaneously
                    ils.findOrRemoveUserOnLocations(userID, false, true); //if the user is on the several locations remove him from all the locations and close all the data connections with him
                }
            }
        };
        
        /**
         * add the task for creation the JSON location description
         * the task will be executed when the current iteration of the js code execution will be done
         * @method addTaskMakeJSONLocationDescription
         * @param {} locationHash
         * @return 
         */
        ILSProto.addTaskMakeJSONLocationDescription = function (locationHash) {
            var ils = this;
            var locationsList; //list with the locations that are necessary to create the descriptions for
            if ( isArray(ils.addTaskMakeJSONLocationDescription_listLocations) === false ) {
               ils.addTaskMakeJSONLocationDescription_listLocations = []; 
            }
            locationsList = ils.addTaskMakeJSONLocationDescription_listLocations;
            if ( locationsList.indexOf(locationHash) === -1 ) { //if the given location is not into the list
                locationsList[locationsList.length] = locationHash; //add it to the list   
            }
            
            if ( ils.addTaskMakeJSONLocationDescription_taskInterval == null ) { //if there is no the current running task
                var currentTask = ils.addTaskMakeJSONLocationDescription_taskInterval = setImmediate(function(){ //create it
                    if ( isArray(locationsList) === true //list with the locations
                        && locationsList.length > 0 ) {
                            for( var i = 0, len = locationsList.length; i < len; i++ ) {
                                var locationHash = locationsList[i];
                                ils.createJSONOneLocationDescription(locationHash, true); //create the JSON description without any timesout checkout
                                commonlib.deleteFromArray(locationsList, locationHash); //delete this location from the task list
                            }
                            if ( currentTask === ils.addTaskMakeJSONLocationDescription_taskInterval ) { //if the reference to the current task is not empty
                                clearImmediate(currentTask); //stop the current immidiate
                                ils.addTaskMakeJSONLocationDescription_taskInterval = null; //clear the reference to the current task
                            }
                    }   
                });   //do it on after this iteration of the js code execution will be done
            }
        };

        /**
         * create the JSON descriptions of the specified maintained location
         * @method createJSONOneLocationDescription
         * @param {} ilsMaintainedLocation
         * @param {} flDoNotCheckTimestampLastCreation - if true, then do not check is the last creation of the json description expired or not 
         * @return 
         */
        ILSProto.createJSONOneLocationDescription = function(ilsMaintainedLocation, flDoNotCheckTimestampLastCreation) {
            var ils = this;
            var locationUsers = {}; //description of the users on the maintained location
            var nearestUsers = {}; //users on the nearest locations and the maintained location (the description of all users on the maintained location and the nearest locations)
            var locationDesc = ils.getHandledLocationDescription(ilsMaintainedLocation); //description of the location

            if (locationDesc !== false 
                && flDoNotCheckTimestampLastCreation !== true
                && typeof(locationDesc.timestampLastFormedMessageObjForELS) === "number" 
                && (getCurrentTimestamp() - locationDesc.timestampLastFormedMessageObjForELS) < timeIntervals.timeSecondsBeetweenCreateJSONLocationDescription) {
                    logger("Too little time has passed since the last creation of a JSON location description");
                    return;
            }

            var i, len, _keys, userID, descLocationFromTheList, _location;
            //add the users located on the maintained location to the resulted message for the user
            var usersOnTheLocation = ils.getUsersDescription(ilsMaintainedLocation);
            if (usersOnTheLocation !== false 
                && commonlib.isEmptyObject(usersOnTheLocation) === false) { //users on the maintained location are exists
                    _keys = Object.keys(usersOnTheLocation);
                    for (i = 0, len = _keys.length; i < len; i++) {
                        userID = _keys[i]; //user from the location, that is same to the user location
                        descLocationFromTheList = usersOnTheLocation[userID];
                        _location = descLocationFromTheList.location;
                        if (commonlib.isEmptyObject(descLocationFromTheList) === false) { //if the description of the location is not empty
                            if (locationUsers[userID] === undefined
                                || locationUsers[userID].coordsTimestamp < _location.coordsTimestamp ) {  //put the full description of the user, that is necessary by an ils instances
                                    locationUsers[userID] = ils.getCoordinatesDescription(descLocationFromTheList, true); //with timestamp and numOfMaintainedLocations
                            }
                            if (nearestUsers[userID] === undefined
                                || nearestUsers[userID].coordsTimestamp < _location.coordsTimestamp ) {
                                    nearestUsers[userID] = ils.getCoordinatesDescription(descLocationFromTheList); //put only the user coordinates to the message
                            }
                        }
                    }
            }
            //add descriptions of the users, which are located on the nearest locations
            var nearestLocations = ils.getNearestLocations(ilsMaintainedLocation); //the list of the locations, that are the nearest to the user lcoation
            for (i = 0, len = nearestLocations.length; i < len; i++) { //for each of the nearest location
                var nearestLocationHash = nearestLocations[i];
                var nearestLocationUsers = ils.getUsersOnNearestLocation(nearestLocationHash);
                if (nearestLocationUsers !== false) { //if the location is not empty
                    _keys = Object.keys(nearestLocationUsers); //id of the users, that are located on the location, that is the nearest to the user location
                    for (var ii = 0, _len = _keys.length; ii < _len; ii++) {
                        userID = _keys[ii];
                        descLocationFromTheList = nearestLocationUsers[userID]; //location of the user from the nearest location
                        if (commonlib.isEmptyObject(descLocationFromTheList) === false) { //if the description of the location is not empty
                            if (nearestUsers[userID] === undefined
                                || nearestUsers[userID].coordsTimestamp < _location.coordsTimestamp ) {
                                    nearestUsers[userID] = ils.getCoordinatesDescription(descLocationFromTheList); //put only the user coordinates to the message
                            }
                        }
                    }
                }
            }

            if (Object.keys(nearestUsers).length > 0) { //if the users are exists on the locations (nearest or maintained)
                locationDesc.timestampLastFormedMessageObjForELS = getCurrentTimestamp(); //update the timestamp when the last JSON description has been formed
                //form the message for the users, which are located on this location, that will request the description of this location
                JSON.stringifyAsync(ils.ilsMessageToUsr_LocationDescription(nearestUsers), 
                    function(formedMessageObjForELS) {
                        if (formedMessageObjForELS != null && (formedMessageObjForELS instanceof Error) === false) {
                            if (locationDesc !== false) {
                                locationDesc.formedMessageObjForELS = formedMessageObjForELS;
                                logger("ILS has created the location(hash = " + ilsMaintainedLocation + ") description for ELS");
                            }
                        }
                    },
                    true);

                if (Object.keys(locationUsers).length > 0) { //if users are not absent on the maintained location
                    //form the message for a nearest local servers, that will request the description of this location
                    JSON.stringifyAsync(locationUsers, 
                        function(formedMessageObjForILS) {
                            if (formedMessageObjForILS != null && (formedMessageObjForILS instanceof Error) === false) {
                                if (locationDesc !== false) {
                                    locationDesc.formedMessageObjForILS = formedMessageObjForILS;
                                    logger("ILS has created the location(hash = " + ilsMaintainedLocation + ") description for ILS");
                                }
                            }
                        },
                        true);
                } else if ( locationDesc !== false ) {
                    locationDesc.formedMessageObjForILS = "";    
                }
            } else if ( locationDesc !== false ) {
                locationDesc.formedMessageObjForELS = ""; 
                locationDesc.formedMessageObjForILS = "";
            }
        };


        /**
         * return the JSON description of the users on the maintained location in the format : userID : { locationHash, coordsTimestamp, timestamp, lat, lng }
         * or false if it is absent
         * @method getLocationDescForTheILS
         * @param {} locationHash
         * @return LogicalExpression
         */
        ILSProto.getLocationDescForTheILS = function(locationHash) {
            var ils = this;
            var maintainedLocationDesc = ils.getHandledLocationDescription(locationHash);
            return maintainedLocationDesc !== false 
                    && typeof(maintainedLocationDesc.formedMessageObjForILS) === "string"
                    && maintainedLocationDesc.formedMessageObjForILS !== "" 
                    && maintainedLocationDesc.formedMessageObjForILS;
        };


        /**
         * return the JSON description of the users on the maintained location and the nearest locations in the format : userID : { locationHash, coordsTimestamp, timestamp, lat, lng }
         * or false if it is absent
         * @method getLocationDescForTheELS
         * @param {} locationHash
         * @return res
         */
        ILSProto.getLocationDescForTheELS = function(locationHash) {
            var ils = this;
            var maintainedLocationDesc = ils.getHandledLocationDescription(locationHash);
            var res = (maintainedLocationDesc !== false && commonlib.isEmptyObject(maintainedLocationDesc.formedMessageObjForELS) === false && maintainedLocationDesc.formedMessageObjForELS);
            if (res === false) { //if the description has not been formed
                ils.createJSONOneLocationDescription(locationHash); //start the creation
            }
            return res;
        };


        /**
         * create the JSON with the description of all the maintained locations and all the nearest locations
         * @method createJSONLocationsDescription
         * @return 
         */
        ILSProto.createJSONLocationsDescription = function() {
            var ils = this;

            var allMaintainedLocations = ils.getListOfMaintainedLocations();
            for (var ind = 0, length = allMaintainedLocations.length; ind < length; ind++) {
                ils.createJSONOneLocationDescription(allMaintainedLocations[ind]); //get one of the maintained locations and form the ready messeges with its description for an els and a n ils
            }
        };

        //message request hashes of the users on the maintained locations
        /**
         * Description
         * @method ilsMessageToCS_requestHashesOfUsers
         * @param {} usersOnHandledLocations
         * @return 
         */
        ILSProto.ilsMessageToCS_requestHashesOfUsers = function(usersOnHandledLocations) {
            var res = [];
            //transform object { userID : {userDesc} } into Array[0..N] = { userDesc, userID }
            var usersIDs = Object.keys(usersOnHandledLocations);
            for (var i = 0, len = usersIDs.length; i < len; i++) {
                var userID = usersIDs[i];
                var userLocationDesc = usersOnHandledLocations[userID];
                var obj = {
                    lat: userLocationDesc.lat,
                    lng: userLocationDesc.lng,
                    userID: strToInt(userID) //convert to the integer for the local server
                };
                res.push(obj);
            }
            if (res.length !== 0) {
                return { //message for server
                    kind: "calculateHashesUsersLocations", //kind of the message
                    body: res
                };
            } else {
                return false;
            }
        };

        /**
         * send the message to the cs
         * return true or false
         * @method sendMessageToCS
         * @param {Object} message
         * @param {boolean} flWithoutQueue - send immidiately before any queued messages and do not put this message to the queue
         * @param {boolean} callback - callback for the server responce to this request
         * @return 
         */
        ILSProto.sendMessageToCS = function(message, flWithoutQueue, callback) {
            if (typeof(message) === "object"
                && message !== null) { //mesage is a full object
                    var mainConnection = returnMainP2P(this);
                    var uniqueID;
                    
                    if (isMainP2P(mainConnection) === true) {
                        if (commonlib.hasOwnProperty(message, "type") === false) {
                            message.type = "fromILS";
                        }
                        if (commonlib.hasProperty(message, "kind") === false 
                            || commonlib.hasProperty(message, "body") === false) {
                                logger("The message for the cs has a wrong format");
                                return false;
                        }
                        
                        if ( typeof(callback) === "function" ) { //if the callback function is defined
                            
                            if (this.messageUniqueID == null ) { //if the uniqueID is not defined
                                uniqueID = this.messageUniqueID = 10000;     
                            } else {
                                uniqueID = ++this.messageUniqueID;
                            }
                            
                            //set the listener for te server responce to this message
       			        	mainConnection.once("messageFromCS(" + uniqueID + ")_CSToILS", callback); //on event messageFromCS(uniqueID)_ILS will be fired, callback function will be called
                            
                            this.listCallbacksForIncomingMessagesFromCS[uniqueID] = [getCurrentTimestamp(), callback];  //put into the list with all promises
                        }
                        
                        if ( uniqueID != null ) { //if the uinique id for the message is defined
                            message.uniqueID = uniqueID; //set the uniqueID for this message
                        }
                        
                        mainConnection.sendMessageToCS(message, flWithoutQueue);
                        return true;

                    } else {
                        return false;
                    }
            }
        };


        /**
         * request the hashes of the users, that are located on the maintained locations, by the central server
         * {locationHash:usersOnLocation}
         * locationHash - maintained location hash
         * usersOnLocation - users on the maintained location with hash = locationHash
         * @method requestHashesOfUsers
         * @return 
         */
        ILSProto.requestHashesOfUsers = function() {
            var ils = this;
            var maintainedLocations = ils.getListOfMaintainedLocations();
            var usersOnHandledLocations = {};
            if (Array.isArray(maintainedLocations) !== false) {
                for (var i = 0, len = maintainedLocations.length; i < len; i++) { //send users coordinates, from an each maintained location to the server
                    var locationHash = maintainedLocations[i]; //one of the maintained locations
                    var usersList = ils.getUsersDescription(locationHash);
                    if (usersList !== false) { //if the list of the users on the maintained location is not empty
                        var _keys = Object.keys(usersList); //ID of the users on the maintained location
                        for (var ii = 0, _len = _keys.length; ii < _len; ii++) { //add users from the maintained location to the message
                            var userID = _keys[ii];
                            var usrLocationDesc = usersList[userID].location; //form the description of the user location for sending it
                            var usrCoords = usersOnHandledLocations[userID] = {};
                            usrCoords.lat = usrLocationDesc.lat;
                            usrCoords.lng = usrLocationDesc.lng;
                        }
                    }
                }

                ils.sendMessageToCS(ils.ilsMessageToCS_requestHashesOfUsers(usersOnHandledLocations), true); //form the message with  the users coordinates and send it to the cs for calculation of the hashes
            }
        };


        /**
         * return [locationHash] - array, where items is a hashes of maintained locations
         * return false if there is no maintained locations
         * @method getListOfMaintainedLocations
         * @return 
         */
        ILSProto.getListOfMaintainedLocations = function() {
            var ils = this;
            var list = ils.handledLocationsList;
            
            if ( list.length > 0 ) {
                return list;
            } else {
                return false;
            }

        };
        
        /**
         * return the number of the maintained locations
         * return 0 if there is no maintained locations
         * @method getNumberOfMaintainedLocations
         * @return 
         */
        ILSProto.getNumberOfMaintainedLocations = function() {
            var ils = this;
            var list = ils.getListOfMaintainedLocations();
            if ( isArray(list) === true ) {
                return list.length;    
            } else {
                return 0;    
            }
        };
        
        /**
         * return the number of the maintained users, that are on the maintained locations
         * return 0 if there is no maintained users
         * @method getNumberOfMaintainedUsers
         * @return numOfUsers
         */
        ILSProto.getNumberOfMaintainedUsers = function() {
            var ils = this;
            var list = ils.getListOfMaintainedLocations(); //list with the maintained locations
            var numOfUsers = 0; //the resulted list of the users
            if ( isArray(list) === true ) {
                for( var i = 0, len = list.length; i < len; i++) {
                    var users = ils.getUsersDescription(list[i]); //users on the maintained location
                    if ( typeof(users) === "object"
                        && users !== null ) { //if the users are exists
                            numOfUsers += Object.keys(users).length;  //add the number of the users  
                    }
                }    
            }
            return numOfUsers;
        };

        /**
         * pong message for the cs
         * @method ilsMessageToCS_pong
         * @param {} locationHash  - only the one location or array with a several locations
         * @return ObjectExpression
         */
        ILSProto.ilsMessageToCS_pong = function(locationHash) {
            
            if ( isArray(locationHash) === true ) { //if there is a several locations
                var _locationHash = locationHash.slice();  //copy the existing array             
                var len = _locationHash.length;
                if ( _locationHash.length > 1 ) { //if more than one location
                    for ( var i = 0; i < len; i++ ) { //convert array from a string to an integer
                        var lh = _locationHash[i];
                        _locationHash[i] = strToInt(lh);
                    } 
                    return {
                        kind: "pong",
                        body: uniqueItems(_locationHash) 
                    };    
                } else { //if there is only a one location into the array
                    locationHash = locationHash[0];    
                }  
            }
            
            return {
                kind: "pong",
                body: strToInt(locationHash)
            };    
        };


        /**
         * update the location timestamp. If this location is overdue, then the local server request from the cs is the lcoation maintained by it
         * @method updateLocationTimestamp
         * @param {} locationHash
         * @return 
         */
        ILSProto.updateLocationTimestamp = function(locationHash) {
            var ils = this;
            var locationDesc = ils.getHandledLocationDescription(locationHash);
            if (locationDesc !== false) {
                locationDesc.timestampLastLocationUpdate = getCurrentTimestamp();
            }
        };


        /**
         * on ping, received from the central server
         * @method onCSPing
         * @param {} pingMsg
         * @return 
         */
        ILSProto.onCSPing = function(pingMsg) {
            
            logger("ping onCSPing");
			logger(pingMsg.locationHash);
            
            if (validators.validatorMessageCSPing(pingMsg) === false) {
                logger(validators.validatorMessageCSPing.errors);
            } else {
                var msgTimestamp = pingMsg.timestamp; //timestamp when the message was formed
                var currentTimestamp = getCurrentTimestamp();
                if ( Math.abs(currentTimestamp - msgTimestamp) > timeIntervals.timeoutSecondsInternalLocalServerMessageFormCSPing ) {
                    logger("Expired ping. Message timestamp = " + msgTimestamp + " and the current timestamp = " + currentTimestamp);
                    return; //if the message is overdue
                }
                var ils = this,
                    locationHash = commonlib.numToStr(pingMsg.locationHash), //maintained location from message
                    nearestLocations = pingMsg.nearestLocations, //list of the nearest local servers for the location is absent
                    flFormPongResponse = false; //is necessary to form the pong response for the cs
                if (commonlib.isEmptyObject(nearestLocations) === false //the list of the nearest locations is not empty
                    && ils.isLocationHandled(locationHash) === false) { //if the loction is not handled by the ils
                        //checking the overhead by the number of the maintained users
                        if ( ils.getNumberOfMaintainedUsers() > moduleSettings.maxMaintainedUsers //check if the number of the maintained users are too large 
                              && locationHash !== ils.getUserLocation() ) { //check if this location, that we are trying to add to the list, is the current location
                                flFormPongResponse = false; 
                        } else { //if can to do maintenance of the location
                            ils.addNewLocationForHandling(locationHash, nearestLocations); //add this location for the maintaince
                            flFormPongResponse = true;
                        }
                } else if (ils.isLocationHandled(locationHash) === true) {
                    flFormPongResponse = true;
                }
                if (flFormPongResponse === true) {
                    //form the pong request for the cs
                    ils.updateLocationTimestamp(locationHash); //uodate the timestamp of the location
                    ils.sendMessageToCS(ils.ilsMessageToCS_pong(locationHash));
                }
            }
        };


        /**
         * ils has asked if a location(s) is maintained and the cs was answered that it is
         * @method onLocationsAreMaintained
         * @param {} locationsHashes
         * @return 
         */
        // ILSProto.onLocationsAreMaintained = function(locationsHashes) {
        //     if (validators.validatorMessageCSLocationsAreMaintained(locationsHashes) === false) {
        //         logger(validators.validatorMessageCSLocationsAreMaintained.errors);
        //     } else { //if the message is not valid
        //         var ils = this;
        //         for (var i = 0, len = locationsHashes.length; i < len; i++) {
        //             var locationHash = commonlib.numToStr(locationsHashes[i]);
        //             if (ils.isLocationHandled(locationHash) === true) { //if the location is handled by the ils
        //                 ils.updateLocationTimestamp(locationHash); //uodate the timestamp of the location  
        //             } else { //if it's not maintained, but the cs think that the location is maintained
        //                 ils.sendMessageToCS(ils.ilsMessageToCS_stopLocationsHandling([locationHash])); //send the request for cs to stop maintenance of the location 
        //             }
        //         }
        //     }
        // };
    
    
        /**
         * when connected to the cs, send the pong message with all the handled locations to inform the cs that the ils still can to handle some locations
         * secondsAfterDisconnection - seconds between the disconnection and this connection with the cs
         * secondsAfterDisconnection may be a function, thet will be called when the list with maintained locations will be loaded
         * @method onConnectedToCS
         * @param {} secondsAfterDisconnectionOrCallback
         * @return 
         */
        ILSProto.onConnectedToCS = function(secondsAfterDisconnectionOrCallback){
            var ils = this;            
            
            if ( ils.g_flClosedManually === true ) {
                return;    
            }
            
            var locations;
            var listHandledLoations = ils.getListOfMaintainedLocations(); //all the handled locations
            if ( isArray(listHandledLoations) === true
                || listHandledLoations.length > 0  ) { //if the handled locations are exists (the browser been opened)
                    if ( typeof(secondsAfterDisconnectionOrCallback) !== "number" //if not a number, then may be connected for the first time
                         || secondsAfterDisconnectionOrCallback < timeIntervals.timeoutLocationHandlingAfterClientDisconnectedFromCS ) { //check is too much time was passed after the disconnection
                            logger("Disconnected. Send pong for: ");
                            logger(listHandledLoations);
                            locations = listHandledLoations;
                            ils.sendMessageToCS(ils.ilsMessageToCS_pong(locations), true); //send the message immidiately before and without the messages queue
                    } else { //if maintaince of all locations was expired
                        ils.stopMaintainceAllLocations(); //stop handling of all the locations    
                    }
                    
                    if ( typeof(secondsAfterDisconnectionOrCallback) === "function" ) { //if secondsAfterDisconnectionOrCallback is a function, thern it will be called
                        secondsAfterDisconnectionOrCallback();
                    }
                    
            } else if ( settingsDebug.doNotTakeLocationsFromDBOnLocading !== true ) { //if the browser been closed
                logger("Load locations from the storage");
                ils.loadHandledLocationsFromLocalStorage( //try to load the locations with the nearest local servers from the local storage
                    function(handledLocations) { //handledLocations = { locationHash : newarestLocalServers } 
                        if ( commonlib.isEmptyObject(handledLocations) !== true ) { //if the list is not empty
                            var locations = Object.keys(handledLocations); //list with the locations
                            var len = locations.length;
                            if ( isArray(locations) === true
                                && len > 0 ) { //is the locations were loaded
                                    logger("Loaded list: ");
                                    logger(locations);
                                    
                                    ils.removeHandledLocationsFromLocalStorage(
                                        function() {
                                            for( var i =0; i < len; i++ ) {
                                                var lh = locations[i]; //location hash from the loaded list
                                                var nearestLocalServers = handledLocations[lh]; //the list with the nearest local servers
                                                if ( commonlib.isEmptyObject(nearestLocalServers) === false ) { //if the list with the nearest local servers is not empty
                                                    ils.addNewLocationForHandling(lh, nearestLocalServers); //add this location for handling
                                                } else { //if the nearest locations are unknown
                                                    commonlib.deleteFromArray(locations,lh); //delete this location from the list to does not send pong with this location for the cs
                                                }
                                            }
                                            
                                            //send pong with all the locations to the cs
                                            ils.sendMessageToCS(ils.ilsMessageToCS_pong(locations), true); //send the message immidiately before and without the messages queue                    
                                            
                                            if ( typeof(secondsAfterDisconnectionOrCallback) === "function" ) { //if secondsAfterDisconnectionOrCallback is a function, thern it will be called
                                                setTimeout(secondsAfterDisconnectionOrCallback, 2000); //get some pause before callback
                                            }    
                                        }    
                                    ); //clean the db from all locations
                                    
                            }
                        } else { //remove all locations from the IndexedDB
                            ils.removeHandledLocationsFromLocalStorage(function(){
                                if ( typeof(secondsAfterDisconnectionOrCallback) === "function" ) { //if secondsAfterDisconnectionOrCallback is a function, thern it will be called
                                   secondsAfterDisconnectionOrCallback();
                                }    
                            });
                            
                        }
                        
                    }
                );    
            } else 
                if ( typeof(secondsAfterDisconnectionOrCallback) === "function" ) { //if secondsAfterDisconnectionOrCallback is a function, thern it will be called
                    secondsAfterDisconnectionOrCallback();
                }
        };
        
        //array with the messages kinds, position into the array is the priority for the message with the kind. Higher priority is better
        ILSProto.messagesFromCSPriority = ["calculatedHashesUsersLocations", "locationsAreMaintained", "ping", "stopLocationHandling", "addLocationForHandling"];
        
        /**
         * message from the central server
         * @method onMessageFromCS
         * @param {} messageKind
         * @param {} message
         * @param {} timestamp
         * @return 
         */
        ILSProto.onMessageFromCS = function(messageKind, message, timestamp) {
            var ils = this;
            
            if ( ils.g_flClosedManually === true ) {
                return;    
            }
            
            logger("ILS>onMessageFromCS. Incoming message from the cs with the kind = " + messageKind);
            
            switch (messageKind) {
                case "calculatedHashesUsersLocations": //locations hashes, calculated by the central server
                    ils.onCalculatedHashesUsersLocations(message, timestamp);
                    break;
                case "stopLocationHandling":
                    ils.onStopLocationHandling(message);
                    break;
                case "addLocationForHandling":
                    ils.onAddLocationForHandling(message);
                    break;
                    // case "addUserToLocation": //not used at this time
                    //     ils.onAddUserToLocation(message);
                    //     break;
                    // case "removeUserFromLocation": //not used at this time
                    //     ils.onRemoveUserFromLocation(message);
                    //     break;
                case "ping" :
                    if ( ils.debugProperties.flNotAllowAnyConnections === true ) { //do not respond to the cs ping request if the flag is set
                        break;   
                    }
                    ils.onCSPing(message);
                    break;
                // case "locationsAreMaintained" :
                //     ils.onLocationsAreMaintained(message);
                //     break;
                default :
                    return;
            }
            
            //check the expired messages callbacks and delete the resolved from the list
            ils.checkCSMessagesCallbacks();
            
        };
        
        /**
         * check the expired callbacks for incoming messages and remove it from the list with the false result
         * @method checkCSMessagesCallbacks
         * @return 
         */
        ILSProto.checkCSMessagesCallbacks = function() {
            var ils = this;
            var listWithCallbacks = ils.listCallbacksForIncomingMessagesFromCS; //list of all awaiting callbacks. { messageID : [timestamp, callback] }
            var _keys = Object.keys(listWithCallbacks);
            var currentTimestamp = getCurrentTimestamp();
            for ( var i = 0, len = _keys.length; i < len; i++ ) {
                var messageUniqueID = _keys[i];
                var desc = listWithCallbacks[messageUniqueID];
                if ( typeof(desc[0]) === "number" //check the callback timestamp, may be it was expired
                     && ( desc[0] - currentTimestamp ) > timeIntervals.timeIntervalSecondsAwaitingMessageCallbackExpired ) {
                        //if the promise is expired 
                        var cb = desc[1];
                        if ( typeof(cb) === "function" ) { //if the callback is a function
                            cb(false);    
                        }
                        delete listWithCallbacks[messageUniqueID]; //remove it from the list                            
                }
            }
        };

        //forms a message to the user that his location has changed
        //oldLocationHash - previous user location
        //newLocationHash - location to which the user has moved
        //newLSID - new ID of the ls, which is maintains the new user location
        //calcTimestamp - when the cs has formed new location hash of the user
        /**
         * Description
         * @method ilsMessageToUsr_LocationChanged
         * @param {} oldLocationHash
         * @param {} newLocationHash
         * @param {} newLSID
         * @param {} calcTimestamp
         * @return msg
         */
        ILSProto.ilsMessageToUsr_LocationChanged = function(oldLocationHash, newLocationHash, newLSID, calcTimestamp) {
            var msg = {
                    type: "fromLocalServer",
                    kind: "locationChange",
                    timestamp: getCurrentTimestamp(),
                    body: {
                        newLocationHash: newLocationHash,
                        previousLocationHash: oldLocationHash,
                        newLSID: isEmptyLSID(newLSID) === true ? empty_user_id : newLSID,
                        timestamp: calcTimestamp //calculation timestamp of the location hash
                    }
                };
            return msg;
        };

        //message for nearest ls, that the user go to the location, maintained by the ls
        //users = { userID : {locationHash, timestamp} }
        //locationHash - location, where the user was moved
        //timestamp - time when the user moved to the location
        /**
         * Description
         * @method ilsMessageToLS_UsersMoveToLocation
         * @param {} users
         * @return ObjectExpression
         */
        ILSProto.ilsMessageToLS_UsersMoveToLocation = function(users) {
            return {
                kind: "ilsUsersMovedToLocation",
                body: users //{timestamp: timestamp when the user location hash was calculated by the cs
                    // locationHash: new location hash
                    // previousLocationHash : previous location hash
                    // lat
                    // lng
                    // }
            };
        };
        
        /**
         * add the given user description to the given location
         * @method addUserDescriptionToTheNewLocation
         * @param {} userID
         * @param {} locationHash
         * @param {} userDescription
         * @return 
         */
        ILSProto.addUserDescriptionToTheNewLocation = function(userID, locationHash, userDescription) {
            var ils = this;
            if ( ils.isLocationHandled(locationHash) === true ) { //if the new location is handled by the ils
                    var userDataConnection = userDescription.dataConnection;
                    var usersOnNewLocation = ils.getUsersDescription(locationHash);  //get the list of the users, that are located on the new location
                    usersOnNewLocation[userID] = userDescription; //add the current user's description to the new location description
                    if ( userDescription.location != null ) { //if the location description is defined for this user
                        userDescription.location.locationHash = locationHash; //update the current location hash into the description of the user location
                    }
                    if ( isDataConnection(userDataConnection) === true
                        && userDataConnection.metadata != null ) { //if the data connection has the metadata
                            userDataConnection.metadata.g_locationHash = locationHash; //update the user data connection location hash
                    }
                    //delete from the incoming users list
                    var incomingUsersOnLocation = ils.getIncomingUsersDescription(locationHash);
                    if (incomingUsersOnLocation !== false //try to find the user into the list of an incoming users on the location
                        && commonlib.isEmptyObject(incomingUsersOnLocation) === false 
                        && commonlib.hasProperty(incomingUsersOnLocation, userID) === true) { //if he is on the list of the incoming users
                            delete incomingUsersOnLocation[userID];
                    }
                    //add the task for creation JSON location description
                    ils.addTaskMakeJSONLocationDescription(locationHash);
                    return true;
                } else { //if the new location is not handled by this ls, then close the data connection with the user
                   return false; 
                }    
        };
        
        /**
         * move the user from one maintained location to another and chek locationHash for the user data connection
         * timestsampNewLHCalculated - when the new location hash was calculatd by the cs
         * @method moveUserToAnotherLocation
         * @param {} userID
         * @param {} currentLocationHash
         * @param {} newLocationHash
         * @param {} timestsampNewLHCalculated
         * @return 
         */
        ILSProto.moveUserToAnotherLocation = function(userID, currentLocationHash, newLocationHash, timestsampNewLHCalculated) {
            
            var ils = this;
            var currentUserDescription = ils.getUserDescription( userID, currentLocationHash );
            if ( currentUserDescription !== false ) { //if the description of the user is not empty
                ils.deleteUserFromLocation( userID, currentLocationHash, true ); //do not close the current data connection with the user
                if ( ils.addUserDescriptionToTheNewLocation(userID, newLocationHash, currentUserDescription) !== true //if cant place the current user description to the new user's location
                    && isDataConnection(currentUserDescription.dataConnection) === true ) { //if the user has the data connection
                        ils.closeDataConnection(currentUserDescription.dataConnection); //close it
                } else
                    if ( currentUserDescription.location != null ) { //if the location description is defined for this user
                        currentUserDescription.location.timestamp = typeof(timestsampNewLHCalculated) === "number" ? timestsampNewLHCalculated : getCurrentTimestamp(); //set the given timestamp of the hash calculation or the current timestamp 
                    }
            } else { //if there is no description for this user
                ils.deleteUserFromLocation( userID, currentLocationHash ); //do not close the current data connection with the user    
            }
                
        };
        
        /**
         * user current location has changed. Move the user to the other location
         * movedUsers = { userID : { oldLocationHash, newLocationHash, newLocationLSID } }
         * @method usersLocationsChanged
         * @param {} movedUsers
         * @return 
         */
        ILSProto.usersLocationsChanged = function(movedUsers) {
            var ils = this,
                messagesForLSs = {}; // { locationHash : { userID : {newUserLocationHash, oldLocationHash, newLocationTimestamp, lat, lng, newLocationLSID} } }, els - connection to the local server, that is maintains location = newUserLocationHash
            var _keys = Object.keys(movedUsers); //users that have changed their locations
            for (var i = 0, len = _keys.length; i < len; i++) { //for each user which has changed his location
                var userID = _keys[i], //id of the user that has changed his location
                    usrLocations = movedUsers[userID],
                    currentLocationHash = usrLocations.oldLocationHash, //the current location of the user
                    newLocationHash = usrLocations.newLocationHash, //the new calculated hash for the user location where he has moved
                    newLocationLSID = usrLocations.newLocationLSID, //the new ID of the local server for the new location
                    usrLat = usrLocations.lat, //the user coordinates
                    usrLng = usrLocations.lng,
                    newLocationCalcTimestamp = usrLocations.newLocationTimestamp, //the timestamp of the hash calculation
                    flNewLocationMaintainedByThisLS = ( newLocationLSID === ils.ID && ils.isLocationHandled(newLocationHash) === true ); //flag means that the new location is maintained by this local server
                if (newLocationLSID !== false) { //if the ID is known for the nearest local server, that maintains the new location of the user
                    //put the message for the local server
                    if (commonlib.hasProperty(messagesForLSs, newLocationHash) === false) {
                        var msgForLS = messagesForLSs[newLocationHash] = {}; //there is no messages for this local server
                    } else if ( flNewLocationMaintainedByThisLS === false ) { //if the next local server for the user is differes from this ls
                        msgForLS = messagesForLSs[newLocationHash]; //the messages for this local server are exists already
                    }
                    msgForLS[userID] = { //put the user location descr into the message for the local server
                        timestamp: newLocationCalcTimestamp, //timestamp when the user location hash was calculated by the cs
                        previousLocationHash: currentLocationHash, //the current user location
                        locationHash: newLocationHash, //location, where the user has moved
                        lat: usrLat,
                        lng: usrLng
                    };
                }

                //form the message to the user, that his location has changed
                logger("!!!!the user " + userID + " location was changed from " + currentLocationHash + " to " + newLocationHash);
                var msgToUser = ils.ilsMessageToUsr_LocationChanged(currentLocationHash, newLocationHash, newLocationLSID, newLocationCalcTimestamp);
                var usrDesc = ils.getUserDescription(userID, currentLocationHash);
                var userDataConnection = usrDesc.dataConnection;
                if ( isDataConnection(userDataConnection) === true
                     && userDataConnection.open === true ) { //dataConnection with the user is exists
                        userDataConnection.send(msgToUser); //send the message to the user about this changing of his location
                        if ( flNewLocationMaintainedByThisLS === true ) { //if the new local serveris this local server
                            ils.moveUserToAnotherLocation(userID, currentLocationHash, newLocationHash, newLocationCalcTimestamp);
                        }
                }
                ils.putUserIntoListOfMovedUsers(userID, currentLocationHash); //put the user into the list of the moved users for the current location
                if ( flNewLocationMaintainedByThisLS === false ) { //if the new local server is another local server
                    ils.closeUserConnection(userID, currentLocationHash); //close the connection with the user
                }
            }

            var __keys = Object.keys(messagesForLSs);
            for (var ii = 0, _len = __keys.length; ii < _len; ii++) { //for each of users, that moved on another locations
                newLocationHash = __keys[ii]; //hash of the location where the users have moved
                var nearestLocationDesc = ils.getNearestLSDesc(newLocationHash); //description of the nearest location
                if (nearestLocationDesc !== false 
                    && commonlib.hasProperty(nearestLocationDesc, "ELS") === true 
                    && nearestLocationDesc.ELS.isConnected() === true) { //els connection is exists for the nearest location and opened
                        nearestLocationDesc.ELS.sendMessage(ils.ilsMessageToLS_UsersMoveToLocation(messagesForLSs[newLocationHash])); //send the message with list of the users,that have moved to the location, maintained by the nearest ls
                }
            }

        };
        
        /**
         * message to the central server with the list of the new local servers for the locations
         * @method ilsMessageToCS_newLocalServers
         * @param {} locations = [locationHash], newLS = [lsID], lsID - id of the choosen local server for the location
         * @param {} newLS
         * @return ObjectExpression
         */
        ILSProto.ilsMessageToCS_newLocalServers = function(locations, newLS){
            return {
                kind: "newLocalServers",
                body: {
                    listLocations : locations,
                    listNewLSs : newLS 
                }
            };                
        };

        /**
         * on responce from the cs to the message that the
         * response = { locations, lsID, messagesPings }, where locations[i] => lsID[i] - valid or empty id for the location
         * timestamp - timestamp when the message was formed on the cs
         * messagesPings = Array[pingMessage1...pingMessageN], where pingMessage - ping message for this local server from the cs
         * @method usersLocationsChangedWihtoutLSForLocation_onCSResponce
         * @param {} kind
         * @param {} response
         * @param {} timestamp
         * @return 
         */
        ILSProto.usersLocationsChangedWihtoutLSForLocation_onCSResponce = function(kind, response, timestamp) { //on response from the server. response = { locationHash : lsID }
            
            var movedUsers = this.movedUsers;
            var ils = this.ils;
            var listMovedUsers = {}; //the resulted list of the moved users
            
            if ( typeof(response) === "object"
                && response !== null
                && isArray(response.locations) === true
                && isArray(response.lsID) === true
                && response.locations.length === response.lsID.length ) {
                    
                    var locations = response.locations; //locations from the server responce
                    var localServers = response.lsID; //the valid ls for the locations
                    
                    var i, len;
                    
                    var messagesPings = response.messagesPings; //ping messages for this local server from the cs
                    if ( isArray(messagesPings) === true
                        && messagesPings.length > 0 ) { //process ping messages from the cs before sending messages to the users with the new locations
                            for( i = 0, len = messagesPings.length; i < len; i++ ) {
                                ils.onCSPing(messagesPings[i]); //process each ping message
                            }
                    }
                    
                    for( i = 0, len = locations.length; i < len; i++ ) {
                        var locationHash = numToStr(locations[i]); //location hash from the responce
                        if ( locationHash !== "" ) { //if the location hash  is not empty
                            var newLSID = localServers[i]; //the valid ls id for the location from the cs
                            var __keys = Object.keys(movedUsers); //for each user, changed his location set the new valid local server id to send it for him
                            for( var ii = 0, _len = __keys.length; ii < _len; ii++ ) {
                                var userID = __keys[ii]; //location hash from the responce
                                    var userDesc = movedUsers[userID]; //description of the new user location
                                if ( userDesc.newLocationHash === locationHash ) { //if the new location for the user is equals to the location form the cs
                                    var userLocatonDesc = ils.getUserDescription(userID, userDesc.oldLocationHash); //get the description of the user location
                                    if ( userLocatonDesc !== false //check if the user still is on the maintained location
                                        && ( userLocatonDesc.location.timestamp < timestamp ) ) { //check if the user coordinates was calculated before this message has come
                                            //if the user is on the location, it is necessary to move him
                                            userDesc.newLocationLSID = newLSID; //set the new valid ls ID (that has gotten from the cs)
                                            listMovedUsers[userID] = userDesc;  
                                    }
                                }
                            }
                        }
                    }
            } else {
                logger(new Error("Wrong message from the cs"));    
            }
            
            ils.usersLocationsChanged(listMovedUsers); //send the messages that the locations changed to the users
                
        };
        
        /**
         * user current location has changed, but id of the local server is unknown. Choose the new ls for each location, claim the choosen local server from the cs, then move the user to the other location with the new choosen local server
         * @method usersLocationsChangedWihtoutLSForLocation
         * @param {} movedUsers = { userID : { oldLocationHash, newLocationHash, newLocationLSID } }
         * @param {} listOfLocations
         * @return 
         */
        ILSProto.usersLocationsChangedWihtoutLSForLocation = function(movedUsers, listOfLocations) {
            
            var locations = Object.keys(listOfLocations); //locations hashes
            var len = locations.length; 
            if ( len === 0 ) { //do nothing if the list is empty
                return;    
            }
            
            var ils = this;
            var locationsForLS = []; //[locationHash] - list with the loations. locationsForLS[i] is location for newLSForLocations[i]
            var newLSForLocations = []; //[lsID] - list with the chosen lcoal servers for locations
            var ind = 0;
            
            for ( var i = 0; i < len; i++ ) {
                var locationHash = locations[i];
                var listOfUsers = listOfLocations[locationHash]; //id of the users, that have changed their location
                
                if ( listOfUsers.length === 1 ) { //only the one user is on the location
                   newLSID = listOfUsers[0]; 
                   
                } else { //it is necesary to choose the local server from several users
                    var usersDescriptions = {}; //{userID : userDesc}, where the userDesc - is the description of the current user location
                    for( var ii = 0, _len = listOfUsers.length; ii < _len; ii++  ) {
                        var userID = listOfUsers[ii];
                        usersDescriptions[userID] = ils.getUserDescription(userID, movedUsers[userID].oldLocationHash);  //get the description of the user current location 
                    }
                    
                    var newLSID = ils.chooseNewLSForLocation(locationHash, [], usersDescriptions ); //choose the new local server for the location
                    if ( isEmptyLSID(newLSID) === true ) { //if the new ls was not choosed
                        newLSID = listOfUsers[0]; //choose the first user from the list
                    }
                    
                }
                
                locationsForLS[ind] = strToInt(locationHash);
                newLSForLocations[ind++] = strToInt(newLSID); //set the new ls id for the location
                
            }
                        
            ils.sendMessageToCS( //send chosen local servers to the cs
                ils.ilsMessageToCS_newLocalServers(locationsForLS, newLSForLocations),
                undefined,
                this.usersLocationsChangedWihtoutLSForLocation_onCSResponce
                    .bind(
                        {
                            movedUsers : movedUsers,
                            ils : this
                        }
                    )
            );
            
        };

        /**
         * on incoming calculated hashes for the current locations of hte users
         * {locationHash:{users, timestamp}}
         * locationHashILS - maintained by the ils location
         * timestamp - time, when the hashes have been calculated
         * users = { id:{locationHash, timestamp} }
         * locationHash - calculated hash of a user location, must be equal to locationHashILS, otherwise that means, the user was moved
         * @method onCalculatedHashesUsersLocations
         * @param {} message
         * @param {} msgTimestamp
         * @return 
         */
        ILSProto.onCalculatedHashesUsersLocations = function(message, msgTimestamp) {
            if (validators.validatorMessageCSCalculatedHashesUsersLocations(message) === false) {
                logger(validators.validatorMessageCSCalculatedHashesUsersLocations.errors);
                return;
            }
            var ils = this;
            var listMaintainedLocations = ils.getListOfMaintainedLocations();
            
            var usersChangedLocationsWithLSID = {}; //list of the users that have changed their location and the ls for this new locations are known. userID : newLocationDescription {}
            var usersChangedLocationsWithoutLSID = {}; //list of the users that have changed their location and the ls for this new locations are unknown. userID : newLocationDescription {}
            var listForUser; //usersChangedLocationsWithLSID or usersChangedLocationsWithoutLSID 
            var locationsWithoutLS = {}; // list of a hashes of the locations without the local server and users on this locations {locationHash : [userID]} 
            
            for (var i = 0, len = listMaintainedLocations.length; i < len; i++) { //for each of the maintained locations
                var ilsMaintainedLocationHash = listMaintainedLocations[i]; //the hash of the maintained lcoation
                var usersOnMaintainedLocationDesc = ils.getUsersDescription(ilsMaintainedLocationHash); //description of the users on the maintained location
                if (usersOnMaintainedLocationDesc !== false) { //there is no users on the location
                    var _keys = Object.keys(message); //users from the message
                    for (var ii = 0, _len = _keys.length; ii < _len; ii++) {
                        var userIDFromMessage = _keys[ii]; //the user ID from the message
                        if (commonlib.hasProperty(usersOnMaintainedLocationDesc, userIDFromMessage) === true) { //if the user with the ID from the message was found on the location
                            var currentUserDesc = usersOnMaintainedLocationDesc[userIDFromMessage]; //description of the user location
                            if ( commonlib.hasProperty(currentUserDesc, "location") === true //description of the user location
                                 && commonlib.hasProperty(currentUserDesc.location, "timestamp") //timestamp when the location hash of the user location was calculated
                                 && currentUserDesc.location.timestamp < msgTimestamp ) { //the timestmp of the incoming location hash calculation is newer then the current
                                    var newUserLocationHash = commonlib.numToStr(message[userIDFromMessage]); //new calculated hash for the user location
                                    //newUserLocationHash must be converted from string to integer by the message validator
                                    if (newUserLocationHash !== ilsMaintainedLocationHash) { //user location hash has changed
                                        
                                        //check for the new ls id
                                        var newLocationLSID = ils.getNearestLSID(newUserLocationHash);
                                        
                                        if ( newLocationLSID === false ) { //if the local server for the location is absent
                                            listForUser = usersChangedLocationsWithoutLSID;
                                            if ( isArray(locationsWithoutLS[newUserLocationHash]) === false ) { //if there is no user on theis location without the local server
                                                locationsWithoutLS[newUserLocationHash] = [userIDFromMessage];    
                                            } else { //add the user on the location without the local server
                                               locationsWithoutLS[newUserLocationHash][locationsWithoutLS[newUserLocationHash].length] = userIDFromMessage;
                                            }
                                        } else {
                                            listForUser = usersChangedLocationsWithLSID;
                                        }
                                        
                                        listForUser[userIDFromMessage] = { //add the user to the list of the users, that have change their locations
                                            oldLocationHash: ilsMaintainedLocationHash,
                                            newLocationHash: newUserLocationHash,
                                            newLocationTimestamp: msgTimestamp,
                                            newLocationLSID: strToInt(newLocationLSID),
                                            lat: currentUserDesc.location.lat,
                                            lng: currentUserDesc.location.lng
                                        };
                                        
                                    } else {
                                        currentUserDesc.location.timestamp = msgTimestamp; //when the last hash calculation has been    
                                    }
                            }
                        }
                    }
                }
            }

            //send the messages to the users and the nearest locatl servers about the users, that have changed their locations
            ils.usersLocationsChanged(usersChangedLocationsWithLSID); //move the user to another nearest local server for the further handling
            ils.usersLocationsChangedWihtoutLSForLocation(usersChangedLocationsWithoutLSID, locationsWithoutLS); //choose the new local server for the locations without it and send ids of them to the central server to claim that
        };


        /**
         * message "stop location handling" from the cs
         * message format: Array[locationHash] or [[locationHash, newLSID]], where newLSID - new id of the local server for this location
         * @method onStopLocationHandling
         * @param {} message
         * @return 
         */
        ILSProto.onStopLocationHandling = function(message) {
            if ( validators.validatorMessageCSStopLocationHandling(message) === false ) {
                logger(validators.validatorMessageCSStopLocationHandling.errors);    
            } else {
                var ils = this;
                var locationsHashes = message.locations; //locations to stop
                var newLSIDs = message.newLSID; //list of id of the valid local server for the locations

                for (var i = 0, len = locationsHashes.length; i < len; i++) {
                    ils.stopLocationHandling(locationsHashes[i], typeof(newLSIDs[i]) === "number" ? newLSIDs[i] : empty_user_id, true); //stop handling the location
                }
            }
        };


        /**
         * update the current list of the nearest local servers with the new list  - newNearestLocalServers
         * ils.handledLocations[locationHash].nearestLS - array with the list of the nearest ls for the hadled by the ils location (maintainedLocationHash)
         * newNearestLocalServersDesc - nearest location to the maintained location (locationHash). { nearestLocationHash : { localServerID, timestamp } }
         * or newNearestLocalServersDesc - array [nearestLocationHash]
         * @method updateNearestLSs
         * @param {} maintainedLocationHash
         * @param {} newNearestLocalServersDesc
         * @return 
         */
        ILSProto.updateNearestLSs = function(maintainedLocationHash, newNearestLocalServersDesc) {
            if (commonlib.isEmptyObject(newNearestLocalServersDesc) === true) { //if the list of the nearest local servers is is empty
                return;
            }
            var ils = this;
            var listNearestLocations = ils.getNearestLocations(maintainedLocationHash);
            if (listNearestLocations === false) { //may be location is not maintained
                return false;
            }
            //at first - we exclude from the list the locations, that are already maintained by a local servers
            //at second - we start an ELS for all the locations with the server ID
            //at third - we collect all the locations without the local server and we start the one ELS instance for all the locations without a local server
            var listNewLocationsWithoutID = []; //list with a new locations which will be handled by the new ELS, that is combine all the new given locations, that have an unknown id of the local server 
            if (commonlib.isEmptyObject(newNearestLocalServersDesc) === false) { //if it is an objcet with the id of the nearest local server
                var _keys = Object.keys(newNearestLocalServersDesc);
                for (var i = 0, len = _keys.length; i < len; i++) {
                    var newNearestLocationHash = _keys[i]; //hash of the nearest location from the incoming list
                    var lsID = newNearestLocalServersDesc[newNearestLocationHash].localServerID;
                    if (listNearestLocations.indexOf(newNearestLocationHash) === -1) { //if the location is absent into the current list
                        listNearestLocations[listNearestLocations.length] = newNearestLocationHash; //add it to the list and create an els connection for it
                    }
                    var connectionsToTheNearestLSs = ils.getNearestLSDesc(newNearestLocationHash); //description of the connection to the nearest local server
                    if (connectionsToTheNearestLSs === false 
                        || commonlib.hasProperty(connectionsToTheNearestLSs, "ELS") === false 
                        || connectionsToTheNearestLSs.ELS === null) { //if the connection to the nearest local server is absent
                            //ELS connection is absent for the nearest location
                            if ( isEmptyLSID(lsID) === true ) { //if the given location is not maintained by any local server
                                listNewLocationsWithoutID[listNewLocationsWithoutID.length] = newNearestLocationHash; //add the new location to start it with the new ELS, that is combine all the new given locations, that have an unknown id of the local server 
                            } else {
                                ils.connectToELS(newNearestLocationHash, lsID); //connect to the new ls    
                            }
                    } else { //ELS connection is exists for the nearest location
                        var elsConnection = connectionsToTheNearestLSs.ELS;
                        if ( elsConnection.elsPeerID !== lsID //the current els has the ls id, that is not equals to the given id of the local server from the incoming message for this nearest location
                             && (
                                 (typeof(elsConnection.timestamp) === "number" 
                                    && elsConnection.timestamp < newNearestLocalServersDesc[newNearestLocationHash].timestamp) //the given id of the ls is newer then the id of the existing els
                                 || typeof(elsConnection.timestamp) !== "number" //if the timestamp for the current els connection is absent
                                )
                            ) { //incoming id of the local server is not empty? but the current is empty
                                ils.connectToELS(newNearestLocationHash, lsID); //connect to the new ls
                        }
                    }
                }
            }

            if (listNewLocationsWithoutID.length > 0) {
                //start the ELS for handling the new given locations with unknown id of a service local server
                ils.connectToELS(listNewLocationsWithoutID, empty_user_id);
            }
        };


        /**
         * add new location for handling
         * locationHash - hash of the location for handling
         * nearestLocalServers = { locationHash:{localServerID,timestamp} } - object with a local serevers IDs, nearest to the location
         * locationHash - hash of a location, that is handled by the local server peer
         * localServerID - local server peer ID
         * timestamp - timestamp when the list of nearest local servers has been formed
         * flDoNotUpdateTheDatabase - if true, then do not update locations into the IndexedDB
         * return false, if location not added
         * @method addNewLocationForHandling
         * @param {} locationHash
         * @param {} nearestLocalServers
         * @param {} flDoNotUpdateTheDatabase
         * @return 
         */
        ILSProto.addNewLocationForHandling = function(locationHash, nearestLocalServers, flDoNotUpdateTheDatabase) {
            var ils = this;
            var handledLocationsList = ils.getListOfMaintainedLocations(); //number of maintained locations
            var numHandledLoations = 0;
            
            locationHash = commonlib.numToStr(locationHash); //convert to string
            
            if (handledLocationsList === false) {
                ils.handledLocations = {};
            } else {
                numHandledLoations = handledLocationsList.length;
            }
            
            if (numHandledLoations === 0 
                || ils.isLocationHandled(locationHash) === false) { //location is not already handled by the ils
                    //the location with hash = locationHash is still not maintained by the ils
                    var newMaintainedLocationDesc = ils.handledLocations[locationHash] = {}; //add this location to the list ogf maintained locations
                    
                    self.handledLocations = ils.handledLocations; //self = global scope(window or worker global context)
                    
                    var _locationHash = commonlib.numToStr(locationHash);
                    if ( ils.handledLocationsList.indexOf(_locationHash) === -1 ) { //if there is no this location into the list of the maintained locations
                        ils.handledLocationsList[numHandledLoations] = _locationHash; //add to the handled list
                        if ( flDoNotUpdateTheDatabase !== true ) { //if the flag is not set
                            localStorage.setItem(locationHash, getCurrentTimestamp()); //save in the local storage
                            localStorage.setItem("nearest_" + locationHash, nearestLocalServers); //save in the local storage the list with the nearest local servers
                        }
                    }
                    
                    newMaintainedLocationDesc.users = {}; //users on the location and it's data connections
                    newMaintainedLocationDesc.incomingUsers = {}; //users, that came on the maintained by the ils location, but not connected to the ils yet
                    newMaintainedLocationDesc.movedUsers = {}; //users, that have moved from the location recently
                    newMaintainedLocationDesc.nearestLS = []; //nearest local servers
                    newMaintainedLocationDesc.timestampWhenAdded = getCurrentTimestamp(); //time when the location was added for maintenance
                    
                    ils.updateNearestLSs(locationHash, nearestLocalServers); //update the list of the nearest local servers and connect to each of the nearest local server
                    
                    ils.emit("ilsNewLocation", locationHash); //emit the event that a new location was added for handling
                    ils.createJSONOneLocationDescription(locationHash); //conver the description of the new location into the JSON string format
                    ils.updateLocationTimestamp(locationHash); //update the timestamp of the new location. The timestamp is for checking if handling of a location has expired
                    
                    logger("!!!Add location " + locationHash + " for handling ");
            } else {
                logger("!!!Location " + locationHash + " already maintained ");
            }
        };


        /**
         * return the current user location
         * @method getUserLocation
         * @return Literal
         */
        ILSProto.getUserLocation = function() {
            var mainP2P = returnMainP2P(this);
            if (isMainP2P(mainP2P) === true) {
                return mainP2P.getUserLocation();
            }
            return null;
        };


        /**
         * try to choose a new ls for the location, passing through the 5 following stages:
         * 1) choose a users, that are not the known local servers
         * 2) calculate a value of the coefficient for each chosed user
         * 3) choose the user with the maximum value of the coefficient, that is not not beyond the bounds. If a value is negative, then the user is approaching to the center, otherwise - removing from the center
         * But in both variants(negative or positive - removing or approching) the larger value by it's module is better, because of the user will be approached or removed from the center for a long time. It's better when the local server(user) will staying on the location for a long time
         * 4) if there is no chosed ls, then choose between the users, that are known local servers if they are exists
         * 5) if there is no chosed ls, then return empty_user_id 
         * listNewLSs - array[userID1,...,userIDN] - id of the users, which are choosed as the ls for a locations, that ils want to stop, before
         * @method chooseNewLSForLocation
         * @param {} locationHash
         * @param {} listNewLSs
         * @param {} usersDescriptions
         * @return empty_user_id
         */
        ILSProto.chooseNewLSForLocation = function(locationHash, listNewLSs, usersDescriptions) {
            
            var ils = this;
            var flParamUsersDescriptions = (usersDescriptions != null); //if the parametr is defined
            var usersDesc = (flParamUsersDescriptions === false) ? ils.getUsersDescription(locationHash) : usersDescriptions; //decription of a users, which are located on the maintained location location
            if (usersDesc !== false) {
                var usersIDs = commonlib.deleteFromArray(Object.keys(usersDesc), ils.ID); //the list of the users id, which are located on the maintained location, exclude the current user
                
                if ( usersIDs.length === 0 ) { //if there is no users on the maintained location
                    return empty_user_id;    
                } else if (usersIDs.length === 1) { //if only one user is on the location
                    return usersIDs[0]; //return his id as an id of the local server for the location  
                }
                
                var nearestLocalServers = ils.getListOfAllNearestLSs(); //list of an id's of the known nearest local servers
                var usersIDsNotNearestLSs = []; //id's of the users, which are not the known local servers for a nearest locations
                var usersIDsNearestLSs = []; //id's of the users, which are the known local servers for a nearest locations
                var _usersDescForCalculation = {}; //description of the user for a further calculations : { numberOfMaintainedLocations : { latitude, longitude, averageSpeed, lastSpeed, distanceToCenter, coefficient } }
                var usersCoordinates = []; // Array({latitude:1, longitude:1}...{latitude:N, longitude:N}) -  array of the current coordinates of a users on the location
                var i, len, userID, userDesc;

                //1) distribute the users by the groups : local servers and not lcoal servers
                //2) get coordinates of the users to calculate the geographical center
                
                var minimumNumberOfMaintainedLocations = 1000; //the minimum number of maintained locations from all of the given users
                
                for (i = 0, len = usersIDs.length; i < len; i++) {
                    userID = usersIDs[i];
                    if ( ( listNewLSs == null //if the list is empty
                             || listNewLSs.indexOf(userID) === -1) //if this user had not been chosen as the ls for a location before
                        && ( nearestLocalServers === false
                             || nearestLocalServers.indexOf(userID) === -1) //if the user is not in the list of all known local servers
                    ) { 
                        usersIDsNotNearestLSs[usersIDsNotNearestLSs.length] = userID; //put into the list of a users, which are not the known local servers for the nearest locations
                    } else { //to the list of the nearest local servers
                        usersIDsNearestLSs[usersIDsNearestLSs.length] = userID;
                    }
                    userDesc = (flParamUsersDescriptions === false) ? ils.getUserDescription(userID, locationHash) : usersDescriptions[userID];
                    if (userDesc !== false) {
                        var userLocation = userDesc.location; //coordinates of the user
                        //the current coords
                        var numOfMaintainedLocations = userDesc.numOfMaintainedLocations; //number of the maintained locations by the user
                        
                        if ( minimumNumberOfMaintainedLocations > numOfMaintainedLocations ) { //choose the minimum number of the maintained locations for the list of the users
                            minimumNumberOfMaintainedLocations = numOfMaintainedLocations;    
                        }
                        
                        var usersDescForCalculation; //_usersDescForCalculation but with considering of the numOfMaintainedLocations
                        if ( _usersDescForCalculation[numOfMaintainedLocations] === undefined ) { //if absent
                           usersDescForCalculation = _usersDescForCalculation[numOfMaintainedLocations] = {}; 
                        } else {
                           usersDescForCalculation = _usersDescForCalculation[numOfMaintainedLocations]; 
                        }
                        
                        var currLat  = userLocation.lat;
                        var currLng  = userLocation.lng;
                        var firstLat = userDesc.firstLat;
                        var firstLng = userDesc.firstLng;
                        var diffLastAndFirstAppeal = userDesc.timestampLastAppeal - userDesc.timestamp; //a difference between the timestamp when the user was placed on the current location and the timestamp of the last incoming description of thee user's coordinates
                        //calculate the average speed as coordinates changing for all the time when the user is located on the location to the time when he is staying on this location
                        var averageSpeedGradusPerSec = commonlib.round(Math.sqrt(Math.pow((currLat - firstLat), 2) + Math.pow((currLng - firstLng), 2)) / diffLastAndFirstAppeal, 6); //the average speed of the user in gradus per second
                        usersDescForCalculation[userID] = { //description of the user for a further calculations
                            lat: currLat, //the current value of the lat coordinate
                            firstLat: firstLat, //a value of the lat coord, when the user has been placed on the location
                            lng: currLng, //the current value of the lng coordinate
                            firstLng: firstLng, //a value of the lng coord, when the user has been placed on the location
                            averageSpeedGradusPerSec: averageSpeedGradusPerSec, //the value of the average speed in gradus per second
                            timeOnLocation: getCurrentTimestamp() - userDesc.timestamp, // а time interval that the user has spent on the location
                            coefficient: 0 //a value of the coefficient
                        };
                        usersCoordinates[usersCoordinates.length] = {
                            lat: currLat,
                            lng: currLng
                        };
                    }
                }
                
                usersDescForCalculation = _usersDescForCalculation[minimumNumberOfMaintainedLocations]; //choose the list of the users, that have the minimum number of the maintained locations
                
                var coordsCenter = glib.getCenterOfLocation(usersCoordinates); // the geographical center of all points, that are a coordinates of a users on the location
                var coefficient;
                var maxCoefficient;
                var userIDWithMaxCoefficient = false;
                //calculate the distance to the center and a value of the coefficient for the users, that are not the known local servers
                for (i = 0, len = usersIDsNotNearestLSs.length; i < len; i++) {
                    userID = usersIDsNotNearestLSs[i];
                    if (commonlib.hasProperty(usersDescForCalculation, userID) === true) {
                        userDesc = usersDescForCalculation[userID];
                        coefficient = glib.calculateValueCoefficientNewLSForLocation(userDesc, coordsCenter); //calculate a value of the coefficient for the user
                        //chose the max value of the coefficient
                        if (maxCoefficient === undefined || (typeof(coefficient) === "number" && maxCoefficient < coefficient)) {
                            maxCoefficient = coefficient;
                            userIDWithMaxCoefficient = userID;
                        }
                    }
                }
                if (maxCoefficient == null) { //if was not chosen
                    //try to chose ls from the users that are known ls
                    maxCoefficient = undefined;
                    for (i = 0, len = usersIDsNearestLSs.length; i < len; i++) {
                        userID = usersIDsNearestLSs[i];
                        if (commonlib.hasProperty(usersDescForCalculation, userID) === true) {
                            userDesc = usersDescForCalculation[userID];
                            coefficient = glib.calculateValueCoefficientNewLSForLocation(userDesc, coordsCenter); //calculate a value of the coefficient for the user
                            //chose the max value of the coefficient
                            if (maxCoefficient === undefined || (typeof(coefficient) === "number" && maxCoefficient < coefficient)) {
                                maxCoefficient = coefficient;
                                userIDWithMaxCoefficient = userID;
                            }
                        }
                    }
                    if (maxCoefficient != null) { //the user was choosed
                        return userIDWithMaxCoefficient;
                    } else { //the ls for the location can't be defined
                        return empty_user_id;
                    }
                } else { //if the user was chosen
                    return userIDWithMaxCoefficient;
                }
            }
            return empty_user_id;
        };

        
        /**
         * message to the cs to stop maintaince of the specefied location(s) and set the new chosen ls(s) for them
         * @method ilsMessageToCS_stopLocationsHandling
         * @param {} locationsToStopMaintaince
         * @param {} chosenLSID
         * @param {} flForceClosing - if true, then send the mesage with Force flag
         * @return 
         */
        ILSProto.ilsMessageToCS_stopLocationsHandling = function(locationsToStopMaintaince, chosenLSID, flForceClosing) {
            var listLocations = Array.isArray(locationsToStopMaintaince) === true ? commonlib.convertArrayStringValuesToIntegers(locationsToStopMaintaince) : [commonlib.strToInt(locationsToStopMaintaince)];
            if (listLocations.length > 0) {
                var ils = this;
                var listNewLSs = []; //the new ls for the locations

                //choose a user as the ls for the locations, maintenance of which wanted to stop
                for (var i = 0, len = listLocations.length; i < len; i++) {
                    var newLSID = ( chosenLSID == null ) ? ils.chooseNewLSForLocation(listLocations[0], listNewLSs) : chosenLSID; //if the local server is given as the argument
                    listNewLSs[i] = isEmptyLSID(newLSID) === true ? empty_user_id : commonlib.strToInt(newLSID);
                }

                //the format : listLocations[i] = hash of the location to stop, listNewLSs[i] = chosed new ls id
                var msg = {
                    kind: "stopLocationsHandling",
                    body: {
                        listLocations: listLocations,
                        listNewLSs: listNewLSs //convert id of a new ls to integers
                    }
                };
                
                if ( flForceClosing === true ) { //set the Force flag
                    msg.body.flForce = true;    
                }
                
                return msg;
            }
        };

        /**
         * check if a number of the maintained locations is too large
         * @method checkOverhead
         * @return 
         */
        ILSProto.checkOverhead = function() {
            var ils = this;
            
            if ( ils.timestamp_lastCheckOverhead !== undefined
                && ( getCurrentTimestamp() - ils.timestamp_lastCheckOverhead ) < timeIntervals.timeIntervalSecondsBetweenTwoOverheadCheckILS ) { //too little time has passed
                    return;   
            }
            
            //check the number of the maintained locations
            var maintainedLocations = ils.getListOfMaintainedLocations();
            if (maintainedLocations !== false) {
                var numOfMaintainedLocations = maintainedLocations.length;
                var minMaintainedLocations = moduleSettings.minMaintainedLocations;
                var maxMaintainedLocations = moduleSettings.maxMaintainedLocations;
                if (numOfMaintainedLocations > maxMaintainedLocations //if maintained more then the minimum number of maintained locations
                    || ils.getNumberOfMaintainedUsers() > moduleSettings.maxMaintainedUsers) { //and the number of the users on the location uis too large for handling
                        //get the location on wich the user is located. Maintaince of this location can't be stopped                   
                        var locationHashCurrentUser = ils.getUserLocation();
                        var locationsHashesToStop = [];
                        var lengthLocationsHashesToStop = 0;
                        var currentTimestamp = getCurrentTimestamp();
                        
                        ils.timestamp_lastCheckOverhead = currentTimestamp;
                        
                        for (var i = 0; i < numOfMaintainedLocations && lengthLocationsHashesToStop < (numOfMaintainedLocations - minMaintainedLocations) ; i++) { //go from the first added lmaintained location to the last and chose any location that approach to the following conditions
                            var locationHashMaintained = maintainedLocations[i];
                            if (locationHashMaintained !== locationHashCurrentUser 
                                && locationsHashesToStop.indexOf(locationHashMaintained) === -1) { //if this maintained location is not the current user and not in the stopping list already
                                    var locationDesc = ils.getHandledLocationDescription(locationHashMaintained);
                                    if ((currentTimestamp - locationDesc.timestampWhenAdded) >= timeIntervals.timeSecondsStopLocationMaintaince) { //if enough time has passed for ability to stop maintenance
                                        locationsHashesToStop[lengthLocationsHashesToStop++] = locationHashMaintained; //request to the cs to stop its maintenance
                                    }
                            }
                        }
                        
                        if (lengthLocationsHashesToStop > 0) { //if exist locations which maintenance can be stopped
                            ils.sendMessageToCS(ils.ilsMessageToCS_stopLocationsHandling(locationsHashesToStop));
                        }
                }
            }
        };


        //message to the cs to check if the location is maintained by this ils
        /**
         * Description
         * @method ilsMessageToCS_isLocationMaintained
         * @param {} maintainedLocationHash
         * @return ObjectExpression
         */
        ILSProto.ilsMessageToCS_isLocationMaintained = function(maintainedLocationHash) {
            return {
                kind: "isLocationMaintained",
                body: Array.isArray(maintainedLocationHash) === true ? commonlib.convertArrayStringValuesToIntegers(maintainedLocationHash) : [commonlib.strToInt(maintainedLocationHash)]
            };
        };


        /**
         * check if a maintained location is overdue
         * @method checkMaintainedLocationsOverdue
         * @return 
         */
        ILSProto.checkMaintainedLocationsOverdue = function() {
            var ils = this;
            //check the number of the maintained locations
            var maintainedLocations = ils.getListOfMaintainedLocations();
            var locationsForChecking = []; //list of a location to check if are maintained by ils
            if (maintainedLocations !== false) {
                var currentTimestamp = getCurrentTimestamp();
                for (var i = 0, len = maintainedLocations.length; i < len; i++) {
                    var maintainedLocationHash = maintainedLocations[i];
                    var locationDesc = ils.getHandledLocationDescription(maintainedLocationHash);
                    //!!!if (locationDesc !== false 
                    //    && (currentTimestamp - locationDesc.timestampLastLocationUpdate) > timeIntervals.timeIntervalSecondCheckHandlingLocationsOverdue ) { //if the location is overdue
                            //send a request to the cs if the location is maintained by the ls
                            locationsForChecking[locationsForChecking.length] = maintainedLocationHash;
                            ils.updateLocationTimestamp(maintainedLocationHash); //update the timestamp of the location
                   // }
                }
                if (locationsForChecking.length > 0) {
                    ils.sendMessageToCS(ils.ilsMessageToCS_isLocationMaintained(locationsForChecking));
                }
            }
        };


        /**
         * add location for handling
         * message format : { locationHash, nearestLocalServers }
         * locationHash - hash of the location for handling
         * nearestLocalServers = { locationHash:localServerID } - object with a local serevers IDs, nearest to the location
         * locationHash - hash of a location, that is handled by the local server peer
         * localServerID - local server peer ID
         * return false, if location not added
         * @method onAddLocationForHandling
         * @param {} message
         * @return 
         */
        ILSProto.onAddLocationForHandling = function(message) {
            if (validators.validatorMessageCSAddLocationForHandling(message) !== false) {
                var ils = this;
                ils.checkOverhead(); //check if a number of the maintained locations is too large
                ils.addNewLocationForHandling(message.locationHash, message.nearestLocalServers); //add location for handling
                ils.sendMessageToCS(ils.ilsMessageToCS_pong(message.locationHash)); //send the pong responce to validate that the location was added for handling by the ils
            } else {
                logger(validators.validatorMessageCSAddLocationForHandling.errors);
            }
        };


        /**
         * return list of the users, that has moved from the maintained location
         * @method getListOfMovedUsers
         * @param {} locationHash
         * @return 
         */
        ILSProto.getListOfMovedUsers = function(locationHash) {
            var ils = this;
            var locationDesc = ils.getHandledLocationDescription(locationHash);
            if ( locationDesc === false
                || isArray(locationDesc.listMovedUsers) === false ) {
                    return false;    
            } else {
                return locationDesc.listMovedUsers;
            }
        };

        /**
         * clean the list of the users, that have moved from one of the maintained locations
         * @method cleanListMovedUsers
         * @return 
         */
        ILSProto.cleanListMovedUsers = function() {
            var ils = this;
            var listMaintainedLocations = ils.getListOfMaintainedLocations();
            for (var i = 0, len = listMaintainedLocations.length; i < len; i++) {
                var _listMovedUsers = ils.getListOfMovedUsers(listMaintainedLocations[i]);
                if (_listMovedUsers !== false) {
                    //the list of the moved users is exists
                    var _keys = Object.keys(_listMovedUsers); //id of the recently moved users from the maintained location
                    for (var ii = 0; ii < _keys.length; ii++) {
                        var userID = _keys[ii]; //moved user id
                        var movedUserTimestamp = _listMovedUsers[userID];
                        if (typeof(movedUserTimestamp) === "number" //there is no timestamp for the user
                            || (movedUserTimestamp - getCurrentTimestamp()) > timeIntervals.timeSecondsInnerLocalServerMovedUsersDelay) { //passed more than the delay time
                            delete _listMovedUsers[userID]; //delete the user from the list
                        }
                    }
                }
            }
        };


        /**
         * check is user recently moved from the location
         * return true if moved recently or false
         * @method isUserIntoListOfMovedUsers
         * @param {} userID
         * @param {} ilsMaintainedLocationHash
         * @return LogicalExpression
         */
        ILSProto.isUserIntoListOfMovedUsers = function(userID, ilsMaintainedLocationHash) {
            var ils = this;
            if (ils.isLocationHandled(ilsMaintainedLocationHash) === false) {
                return false;
            }
            var locationDesc = ils.getHandledLocationDescription(ilsMaintainedLocationHash);
            return commonlib.isEmptyObject(locationDesc.listMovedUsers) === false //some of the users is into the list
                && commonlib.hasProperty(locationDesc.listMovedUsers, userID) === true; //the user is into the list 
        };


        /**
         * add user on to the maintained location
         * message format:
         * {locationHash, userID, timestamp, previousLocationHash}
         * !!!!DEPRECATED
         * @method onAddUserToLocation
         * @param {} message
         * @return 
         */
        ILSProto.onAddUserToLocation = function(message) {
            var ils = this,
                userID = message.userID,
                ilsMaintainedLocationHash = message.locationHash = message.locationHash.trim();
            if (ilsMaintainedLocationHash == null || userID == null //user ID is not specified
                || ils.isLocationHandled(ilsMaintainedLocationHash) == false) { //location is not maintained by the ils
                    return;
            }
            if (ils.isUserIntoListOfMovedUsers(userID, ilsMaintainedLocationHash) == true) { //user moved from this location recently
                return;
            }

            //try to find more newer user description than timestamp into the message from cs
            var res = ils.findOrRemoveUserOnLocations(userID, false, false, message.timestamp);
            if (res === true) { //found more newer user description on the maintained and nearest locations
                return;
            } else
            if (Array.isArray(res) === true && res.length > 0) { //if the result is the list of a locations, where the user was found
                ils.deleteUsersFromLocations(userID, res); //delete from the locations    
            }

            //add the user into the list of incoming users of the maintained location
            ils.addUserIntoIncomingList(userID, ilsMaintainedLocationHash);

        };


        /**
         * put the user into list of the moved users from the location
         * @method putUserIntoListOfMovedUsers
         * @param {} userID
         * @param {} locationHash
         * @return 
         */
        ILSProto.putUserIntoListOfMovedUsers = function(userID, locationHash) {
            var ils = this;
            var listMovedUsers = ils.getListOfMovedUsers(locationHash);
            if (listMovedUsers === false) { //if the list is absent
                var locationDesc = ils.getHandledLocationDescription(locationHash);
                if (locationDesc !== false) {
                    listMovedUsers = locationDesc.movedUsers = {}; //create it for the maintained location
                } else {
                    listMovedUsers = false;
                }
            }
            if (listMovedUsers !== false) {
                listMovedUsers[userID] = getCurrentTimestamp();
            }
        };


        /**
         * server whants to remove user from location
         * {locationHash,userID,timestamp}
         * @method onRemoveUserFromLocation
         * @param {} message
         * @return 
         */
        ILSProto.onRemoveUserFromLocation = function(message) {
            var ils = this,
                userID = message.userID,
                ilsMaintainedLocationHash = message.locationHash;
            if (ilsMaintainedLocationHash == null || userID == null //user ID is not specified
                || ils.isLocationHandled(ilsMaintainedLocationHash) == false) { //location is not maintained by the ils
                return;
            }
            ils.closeUserConnection(userID, ilsMaintainedLocationHash); //remove user from the location and close connection with him
        };


        /**
         * close els and create a new connection to the local server by previous connection(els)
         * @method reconnectToELS
         * @param {} els
         * @return 
         */
        ILSProto.reconnectToELS = function(els) {
            var ils = this;
            if (ils.isValidELS(els) === false) {
                return;
            }
            var elsPeerID = els.elsPeerID; //id of the nearest local server id
            ils.closeELS(els); //close the previous connection
            ils.connectToELS(els.locationHash, elsPeerID); //create the new connection
        };


        /**
         * when External Local Server instance closed
         * @method onELSClosed
         * @param {} reason
         * @return 
         */
        ILSProto.onELSClosed = function(reason) {
            var els = this,
                ils = els.getILS(els); //get the ils instance
            if (ils.isValidELS(els) === true) { //if it is the valid els, then it's necessary to reconnect to the local server
                ils.reconnectToELS(els);
            } else { //close the connection to the els and remove all the descriptions because the els is not valid
                ils.closeELS(els);
            }
            if (reason != null) {
                logger("The els connection to the nearest ls has closed because of the reason with the code = " + reason);
            }
        };


        /**
         * close els instance, without handling any event, while closing
         * @method closeELS
         * @param {} els
         * @return 
         */
        ILSProto.closeELS = function(els) {
            var ils = this;
            els.g_flClosedManually = true;
            ils.removeELSListeners();
            var allValidNearestLocationsToAllMaintainedLocation = ils.getAllValidNearestLocations(); //get all the valid nearest locations
            if (ils.isValidELS(els, true) === true) { //check the els and it's locations
                var elsLocations = els.getELSLocations(els);
                var allNearestLocationsDesc = ils.getAllNearestLocationsDesc(); //get all descriptions of all the nearest locations
                for (var i = 0, len = elsLocations.length; i < len; i++) {
                    var nearestLocationHash = elsLocations[i]; //for each of the nearest locations that are maintained by the els
                    if (commonlib.hasProperty(allNearestLocationsDesc, nearestLocationHash) === true) { //if the nearest location has a description into the list of the nearest locations
                        var nearestLocationDesc = allNearestLocationsDesc[nearestLocationHash];
                        if (commonlib.hasProperty(allValidNearestLocationsToAllMaintainedLocation, nearestLocationHash) === false) {
                            //if the els location is not the valid location, that is the nearest location to all the maintained locations
                            if (nearestLocationDesc.ELS !== els && isELS(nearestLocationDesc.ELS) === true) { //if the els from the nearest location description equals to the closing els
                                nearestLocationDesc.ELS.removeELSLocation(nearestLocationHash); //remove the nearest location from the list of the locations, that are maintained by the els
                            }
                            delete allNearestLocationsDesc[nearestLocationHash]; //delete the description of this location
                        } else {
                            //if the els location is valid, but necessary to reset the ELS reference
                            if (nearestLocationDesc.ELS === els) { //if the els from the nearest location description equals to the closing els
                                nearestLocationDesc.ELS = null; //reset the reference to the ELS instance into the list of the nearest locations
                            }
                        }
                    }
                }
            }

            logger("ELS with id = '" + els.elsPeerID + "' has been closed by ILS");
            els.close(); //close the els connection to the nearest local server
        };


        /**
         * return true if location is handled by the ils
         * @method isLocationHandled
         * @param {} locationHash
         * @return LogicalExpression
         */
        ILSProto.isLocationHandled = function(locationHash) {
            var ils = this;
            var listOfMaintainedLocations = ils.getListOfMaintainedLocations(); //all the maintained locations
            return listOfMaintainedLocations !== false 
                && listOfMaintainedLocations.indexOf(commonlib.numToStr(locationHash)) !== -1;
        };


        /**
         * return handled by the ils location description by locationHash
         * return false if error
         * @method getHandledLocationDescription
         * @param {} locationHash
         * @return 
         */
        ILSProto.getHandledLocationDescription = function(locationHash) {
            var ils = this;
            if ( ils.isLocationHandled(locationHash) === true  ) {
                var locationDesc = ils.handledLocations[locationHash];
                return locationDesc != null
                    && locationDesc;
            } else {
                return false;    
            }
        };


        /**
         * return all the locations, that are the nearest to the handled location
         * return false if an error
         * @method getNearestLocations
         * @param {} locationHash
         * @return 
         */
        ILSProto.getNearestLocations = function(locationHash) {
            var ils = this;
            var locationDesc = ils.getHandledLocationDescription(locationHash);
            if (locationDesc !== false) {
                if (Array.isArray(locationDesc.nearestLocations) === false) {
                    locationDesc.nearestLocations = []; //if the list is empty
                }
                return locationDesc.nearestLocations;
            } else {
                return false;
            }
        };


        /**
         * return the list with the descriptions of all the nearest locations for all the locations handled by the ils 
         * { lsID : null, 
         * ELS  : null,
         * locationDesc : {} }
         * return false if the list is empty
         * @method getAllNearestLocationsDesc
         * @return LogicalExpression
         */
        ILSProto.getAllNearestLocationsDesc = function() {
            var ils = this;
            return commonlib.hasProperty(ils, "ELSConnections") === true
                    && commonlib.isEmptyObject(ils.ELSConnections) === false 
                    && ils.ELSConnections;
        };
        
        /**
         * delete the nearest location description
         * @method delNearestLocationDesc
         * @param {} locationHash
         * @return 
         */
        ILSProto.delNearestLocationDesc = function(locationHash) {
            var ils = this;
            if ( commonlib.hasProperty(ils, "ELSConnections") === true
                && typeof(ils.ELSConnections) === "object" ) {
                    delete ils.ELSConnections[locationHash];        
            }
        };

        /**
         * return a list of an id's of all known nearest local servers
         * @method getListOfAllNearestLSs
         * @return 
         */
        ILSProto.getListOfAllNearestLSs = function() {
            var ils = this;
            var descNearestLSs = ils.getAllNearestLocationsDesc(); //get the description of an els connections to the nearest lss
            if (descNearestLSs === false) {
                var IDLSs = []; //list of an id of the nearest local servers
                var numIDLSs = 0;
                var _keys = Object.keys(descNearestLSs);
                for (var i = 0, len = _keys.length; i < len; i++) {
                    var descNearestLS = descNearestLSs[_keys]; //get a description of a nearest local server
                    var lsID = descNearestLS.lsID;
                    if (lsID != null && IDLSs.indexOf(lsID) === -1) { //if not into the list already
                        IDLSs[numIDLSs++] = lsID;
                    }
                }
                return IDLSs.length > 0 && IDLSs;
            } else {
                return false;
            }
        };


        /**
         * return the list with the descriptions of all the nearest locations for all the locations handled by the ils 
         * @method getAllNearestLocationsList
         * @return LogicalExpression
         */
        ILSProto.getAllNearestLocationsList = function() {
            var ils = this;
            var allNearestLocationsDesc = ils.getAllNearestLocationsDesc();
            return allNearestLocationsDesc !== false
                    && Object.keys(allNearestLocationsDesc);
        };


        /**
         * return an array with the nearest locations, that are the nearest to all the maintained locations, excepting excepted location
         * exceptedLocationHash - maintained location, locations that are the nearest to this location will be excepted
         * return false if the list is empty or other errors
         * @method getAllValidNearestLocations
         * @param {} exceptedLocationHash
         * @return 
         */
        ILSProto.getAllValidNearestLocations = function(exceptedLocationHash) {
            var ils = this;
            exceptedLocationHash = exceptedLocationHash;
            var allMaintainedLocations = ils.getListOfMaintainedLocations(); //the list of all the maintaied locations
            if (Array.isArray(allMaintainedLocations) === true) {
                var allValidNearestLocations = []; //resulting array
                for (var i = 0, len = allMaintainedLocations.length; i < len; i++) {
                    var maintainedLocationHash = allMaintainedLocations[i]; //one of the maintained locations
                    if (exceptedLocationHash == null
                        || maintainedLocationHash !== exceptedLocationHash) { //if this location must be excepted
                            var allNearestLocationsToMaintainedLocation = ils.getNearestLocations(maintainedLocationHash); //get all the locations that arte the nearest to the maintained location
                            if (Array.isArray(allNearestLocationsToMaintainedLocation) === true) {
                                mergeUnique(allValidNearestLocations, allNearestLocationsToMaintainedLocation);
                            }
                    }
                }
                if ( allValidNearestLocations.length !== 0 ) {
                    return allValidNearestLocations;   
                } else {
                    return false;
                }
            } else {
                return false;
            }
        };


        /**
         * return description of the nearest ls by the ils maintained location hash and it's nearest location hash
         * return { ELS, locationDesc, lsID }
         * return false if an error
         * @method getNearestLSDesc
         * @param {} elsLocationHash
         * @param {} flDoNotCheckForLocality - do not check if the given location is maintained by this ils or an external(local or not)
         * @return 
         */
        ILSProto.getNearestLSDesc = function(elsLocationHash, flDoNotCheckForLocality) {
            var ils = this;
            
            if ( flDoNotCheckForLocality !== true
                && ils.isLocationHandled(elsLocationHash) === true ) { //this location is handled by this ils
                    return {
                        ELS : null,
                        lsID : ils.ID,
                        locationDesc : ils.getHandledLocationDescription(elsLocationHash)
                    };
            } else {
                var nearestLSs = ils.getAllNearestLocationsDesc();
                if ( nearestLSs !== false
                    && typeof(nearestLSs[elsLocationHash]) === "object" ) {
                        return nearestLSs[elsLocationHash];
                } else {
                    return false;    
                }
            }
        };


        /**
         * clean the list of all the nearest locations to the maintained locations
         * @method cleanAllNearestLocationsDesc
         * @return 
         */
        ILSProto.cleanAllNearestLocationsDesc = function() {
            var ils = this;
            var nearestLocations = ils.getAllNearestLocationsDesc();
            var _keys = Object.keys(nearestLocations);
            for (var i = 0, len = _keys.length; i < len; i++) { //close all the els from the list
                var nearestLocationDesc = nearestLocations[_keys[i]];
                if (commonlib.hasProperty(nearestLocationDesc, "ELS") === true && isELS(nearestLocationDesc.ELS) === true) {
                    ils.closeELS(nearestLocationDesc.ELS);
                }
            }
            ils.ELSConnections = {}; //delete the descriptions of all the nearest locations
        };


        /**
         * return ID of the nearest local server
         * return false
         * @method getNearestLSID
         * @param {} locationHash
         * @return 
         */
        ILSProto.getNearestLSID = function(locationHash) {
            var ils = this;
            
            if ( ils.isLocationHandled(locationHash) === true ) { //if the location is handled by this ils
                return ils.ID;  //return id of this ILS  
            } else {
                var nearestLocationDesc = ils.getNearestLSDesc(locationHash);
                return nearestLocationDesc !== false 
                    && ((commonlib.hasProperty(nearestLocationDesc, "ELS") === true && commonlib.hasProperty(nearestLocationDesc.ELS, "elsPeerID") === true && nearestLocationDesc.ELS.elsPeerID) || (commonlib.hasProperty(nearestLocationDesc, "ELS") === false //if ELS is absent
                    && typeof(nearestLocationDesc.lsID) === "number" //if els is absent, but lsID is given by the central server
                    && nearestLocationDesc.lsID !== empty_user_id
                    && nearestLocationDesc.lsID));
            }
        };


        /**
         * return users from the nearest ls by the location hash, that is nearest location to one of the maintained locations
         * return { ELS, locationDesc }
         * return false if an error
         * @method getUsersOnNearestLocation
         * @param {} elsLocationHash
         * @return 
         */
        ILSProto.getUsersOnNearestLocation = function(elsLocationHash) {
            var ils = this;
            
            //check if this location is maintained by this ils
            if ( ils.isLocationHandled(elsLocationHash) === true ) {
                return ils.getUsersOnLocation(elsLocationHash);  //return the users on the maintained location  
            } else {            
                var nearestLocationDesc = ils.getNearestLSDesc(elsLocationHash);
                return nearestLocationDesc !== false 
                        && commonlib.hasProperty(nearestLocationDesc, "locationDesc") === true 
                        && commonlib.hasProperty(nearestLocationDesc.locationDesc, "users") === true
                        && nearestLocationDesc.locationDesc.users;
            }
        };


        /**
         * return users from the maintained location or one of the nearest locations by the location hash
         * return { ELS, locationDesc }
         * return false if an error
         * @method getUsersOnLocation
         * @param {} locationHash
         * @return 
         */
        ILSProto.getUsersOnLocation = function(locationHash) {
            var ils = this;
            if (ils.isLocationHandled(locationHash) === true) { //if requested location is the maintained location
                return ils.getUsersDescription(locationHash);
            } else { //if it is the nearest location to one of the maintained locations
                return ils.getUsersOnNearestLocation(locationHash);
            }
        };



        /**
         * users and it's data connections description, which are on the handled location
         * return false if the location is not handled or there is no users description
         * @method getUsersDescription
         * @param {} locationHash
         * @return LogicalExpression
         */
        ILSProto.getUsersDescription = function(locationHash) {
            var ils = this;
            var locationDesc = ils.getHandledLocationDescription(locationHash);
            return locationDesc !== false
                    && commonlib.hasProperty(locationDesc, "users") === true
                    && locationDesc.users;
        };


        /**
         * /return the user description from the list of the users on the maintained location
         * return false if the location is not handled or there is no user description
         * @method getUserDescription
         * @param {} userID
         * @param {} locationHash
         * @return LogicalExpression
         */
        ILSProto.getUserDescription = function(userID, locationHash) {
            var ils = this;
            var usersDesc = ils.getUsersDescription(locationHash); //description of the users, that are located on the location where the user is placed
            return usersDesc !== false
                    && commonlib.hasProperty(usersDesc, userID) === true
                    && usersDesc[userID];
        };


        /**
         * incoming users, which are move on the maintained location
         * return false if the location is not maintained or there is no incoming users
         * @method getIncomingUsersDescription
         * @param {} locationHash
         * @return LogicalExpression
         */
        ILSProto.getIncomingUsersDescription = function(locationHash) {
            var ils = this;
            var locationDesc = ils.getHandledLocationDescription(locationHash);
            return locationDesc !== false && commonlib.hasProperty(locationDesc, "incomingUsers") === true && locationDesc.incomingUsers;
        };


        /**
         * return all the maintained locations, that are the nearest to the given nearest locations
         * return false if the list is empty
         * nearestLocationsHashes - must be an array with integers
         * @method getILSLocationsNearestToTheLocation
         * @param {} nearestLocationsHashes
         * @return LogicalExpression
         */
        ILSProto.getILSLocationsNearestToTheLocation = function(nearestLocationsHashes) {
            var ils = this;
            var allMaintainedLocations = ils.getListOfMaintainedLocations();
            var res = [];
            if (typeof(nearestLocationsHashes) === "number") { //only the one location
                nearestLocationsHashes = [nearestLocationsHashes];
            }
            for (var ii = 0; ii < nearestLocationsHashes.length; ii++) {
                for (var i = 0, len = allMaintainedLocations.length; i < len; i++) {
                    var maintainedLocationHash = allMaintainedLocations[i];
                    var locationsNearestToTheMaintained = ils.getNearestLocations(maintainedLocationHash); //get the list of all the locations, nearest to one of the maintained
                    if (Array.isArray(locationsNearestToTheMaintained) === true && locationsNearestToTheMaintained.indexOf(nearestLocationsHashes[ii]) !== -1) { //if the nearest location from the corresponding argument was found into the list of the nearest locations to the maintained location
                        if (res.indexOf(maintainedLocationHash) === -1) { //prevent a duplicates in the result array
                            res.push(maintainedLocationHash); //if found that the location  from the given list is the nearest to the maintained location
                        }
                    }
                }
            }
            return res.length > 0 && res;
        };


        /**
         * return the locations from the given list that are the valid nearest locations to the maintained locations
         * locationsHashes - array with the locations hashes
         * @method getOnlyNearestLocations
         * @param {} locationsHashes
         * @return res
         */
        ILSProto.getOnlyNearestLocations = function(locationsHashes) {
            var ils = this;
            var listValidNearestLocations = ils.getAllValidNearestLocations();
            if (listValidNearestLocations === false) {
                return []; //nearest locations are absent
            }
            var res = []; //the result array with the valid nearest locations from the given list
            for (var i = 0, len = locationsHashes.length; i < len; i++) {
                var locationHash = locationsHashes[i];
                if (listValidNearestLocations.indexOf(locationHash) !== -1 //if the location from the list is the valid nearest location
                    && res.indexOf(locationHash) === -1) { //avoid any duplicates in the result
                    res.push(locationHash);
                }
            }
            return res;
        };


        /**
         * is external local server instance an active current connection to the nearest ls
         * flDontClose == false, then the unvalid els will not be closed
         * return true or false
         * @method isValidELS
         * @param {} els
         * @param {} flDontClose
         * @return LogicalExpression
         */
        ILSProto.isValidELS = function(els, flDontClose) {
            var ils = this,
                elsLocationsList = els.getELSLocations(); //locations maintained by the els
            if (elsLocationsList === false 
                || elsLocationsList.length === 0) { //the list of the els locations is empty
                    if (flDontClose !== true) {
                        ils.closeELS(els); //close the els
                    }
                    return false;
            }
            //check all the els locations
            var allNearestLocationsDesc = ils.getAllNearestLocationsDesc(); //all the opened descriptions of the nearest locations
            for (var i = 0, len = elsLocationsList.length; i < len; i++) {
                var nearestLocationHashMaintainedByELS = elsLocationsList[i]; //the location, that is maintained by the els
                if (commonlib.hasProperty(allNearestLocationsDesc, nearestLocationHashMaintainedByELS) === true) { //description for the els location is exists into the list of the nearest locations description
                    var nearestLocationDesc = allNearestLocationsDesc[nearestLocationHashMaintainedByELS]; //the description of the els location into the list of the locartions, that are the nearedst to the locations, that are handled by the ils
                    if (commonlib.hasProperty(nearestLocationDesc, "ELS") === true) {
                        if (nearestLocationDesc.ELS === els) { //if the valid ELS connection from the list of the descriptions is equals to the given els
                            continue;
                        }
                    }
                }
                //if there is no description of the els location into the list of the nearest locations
                els.removeELSLocation(nearestLocationHashMaintainedByELS); //remove the location, maintained by the els, from the list of els locations
            }
            var elsLocations = els.getELSLocations(); //locations, that are handled by the ils
            return elsLocations !== false 
                    && elsLocations.length > 0; //if exists at least the one location, that is maintained by the els
        };


        /**
         * return locationHash of the maintained location by the els(ExternalLocalServer instance)
         * els represents connection to the ls, which handle location, that is nearest to the maintained location
         * return locationsHashes or false
         * @method returnILSHandledLocationsByELS
         * @param {} els
         * @return LogicalExpression
         */
        ILSProto.returnILSHandledLocationsByELS = function(els) {
            var ils = els.getILS();
            if (ils === false || ils.isValidELS(els) === false) { //check the els and it's locations
                return false;
            }
            var elsLocations = els.getELSLocations(); //locations, that are maintained by the els
            return Array.isArray(elsLocations) === true && elsLocations.length !== 0 && ils.getILSLocationsNearestToTheLocation(elsLocations);
        };

        // depecated //check is ELS ID is into the list of the nearest local servers
        // //false if an error
        // ILSProto.isValidELSID = function (elsID, elsHandledLocationHash) {
        //     if ( elsID == null || elsID === 0 ) {
        //         return false;    
        //     }
        //     var ils = this,
        //         nearestLSDesc = ils.getNearestLSDesc(elsHandledLocationHash); //description of the nearest local server by the location, maintained by the ils and the nearest location to it, that is maintained by the els
        //     if( nearestLSDesc !== false
        //         && nearestLSDesc.ELS instanceof ExternalLocalServer === true ) { //if the nearest location description has an instance of the ELS
        //             var els = nearestLSDesc.ELS;
        //             return els.isValidELS(els) === true
        //                     && els.elsPeerID === elsID; //given nearest ls (els) id is not equal to the els ID
        //     } else if ( commonlib.hasProperty(nearestLSDesc, "lsID") === true ) { //if the nearest location description has an id of the local server, but not an instance of the ELS 
        //         return nearestLSDesc.lsID === elsID;
        //     }
        //     return false;
        // };


        /**
         * return ELS instance by the local server ID
         * return ELS instance if found
         * return false if not found
         * @method getELSByID
         * @param {} lsID
         * @return Literal
         */
        ILSProto.getELSByID = function(lsID) {
            var ils = this;
            lsID = commonlib.strToInt(lsID);
            var allNearestLSs = ils.getAllNearestLocationsDesc(); //for description of all the nearest local servers
            var _keys = Object.keys(allNearestLSs);
            for (var i = 0, len = _keys.length; i < len; i++) {
                var nearestLocationHash = _keys[i];
                var lsDesc = allNearestLSs[nearestLocationHash];
                if (commonlib.hasProperty(lsDesc, "ELS") && lsDesc.ELS.elsPeerID === lsID //if found ELS with ID that is equals to the given ID
                    && lsDesc.ELS.isClosed() === false) { //not closed
                    return lsDesc.ELS;
                }
            }
            return false;
        };


        /**
         * set an empty description for he given location into the list of the nearest locations
         * @method setEmptyNearestLocationDesc
         * @param {} nearestLocationHash
         * @param {} lsID
         * @return emptyDesc
         */
        ILSProto.setEmptyNearestLocationDesc = function(nearestLocationHash, lsID) {
            var ils = this;
            
            var emptyDesc = { 
                    lsID : lsID === undefined ? null : lsID,
                    ELS  : null,
                    locationDesc: {}
            };
            
            var descNearestLocalServers = ils.ELSConnections;
            
            if ( isArray(nearestLocationHash) === true ) { //if there is a several locations
                for ( var i = 0, len = nearestLocationHash.length; i < len; i++ ) {
                    descNearestLocalServers[nearestLocationHash[i]] = emptyDesc;   
                } 
            } else { //if only the one location
                descNearestLocalServers[nearestLocationHash] = emptyDesc;
            }
            
            return emptyDesc;
        };
        
        /**
         * set empty list with the users for the nearest location
         * @method setEmptyUsersOnNearestLocation
         * @param {} nearestLocationHash
         * @param {} lsID
         * @return 
         */
        ILSProto.setEmptyUsersOnNearestLocation = function(nearestLocationHash, lsID){
            var ils = this;
            var descNearestLocalServer;
            if ( isArray(nearestLocationHash) === true ) { //if there is a several locations
                for ( var i = 0, len = nearestLocationHash.length; i < len; i++ ) {
                    descNearestLocalServer = ils.getNearestLSDesc(nearestLocationHash[i]);
                    if ( descNearestLocalServer !== false ) {
                        descNearestLocalServer.locationDesc = {};    
                    }   
                } 
            } else { //if only the one location
                descNearestLocalServer = ils.getNearestLSDesc(nearestLocationHash);
                if ( descNearestLocalServer !== false ) {
                    descNearestLocalServer.locationDesc = {};    
                }
            }    
        }


        /**
         * set the id of the nearest local server for all the locations from the given list
         * lsID may be the ID of the nearest local server or the instance of the ExternalLocalServer
         * if found an ELS, that is already connected and with the id, that is not equals to the given lsID, then the corresponding nearest location will be removed from the list of the founded ELS locations, and this location will be included to the same list for the new ELS
         * @method setLSForNearestLocations
         * @param {} elsLocationsHashes
         * @param {} lsID
         * @return 
         */
        ILSProto.setLSForNearestLocations = function(elsLocationsHashes, lsID) {
            if (lsID == null) {
                return;
            }
            var ils = this;
            var _ELS;
            var flELS = isELS(lsID); //flag means, that by the argument, called "lsID", an instance of the External Local Server is given
            if (typeof(elsLocationsHashes) === "string") { //if only the one location
                elsLocationsHashes = [elsLocationsHashes];
            }
            if (flELS === true) { //if the ELS instance was given instead of id of a local server
                _ELS = lsID; //set the ELS variable (connection to the local server)
                for (var i = 0; i < elsLocationsHashes.length; i++) {
                    var elsLocationHash = elsLocationsHashes[i];
                    if (_ELS.isELSLocationIntoList(elsLocationHash) === false) { //if the location is not maintained by the ELS, remove it from the list of the given els locations
                        elsLocationsHashes.splice(i, 1); //delete the location from the given list
                        i--;
                    }
                }
            } else { //if lsID is not an instance of ELS, convert to a number
                lsID = commonlib.strToInt(lsID);
            }
            for (var ii = 0, len = elsLocationsHashes.length; ii < len; ii++) {
                var nearestLocationHash = elsLocationsHashes[ii];
                var nearestLocationDesc = ils.getNearestLSDesc(nearestLocationHash, true); //get the description of the nearest location (do not check if it is the locally maintained location)
                if (nearestLocationDesc === false) { //the description of the nearest location is empty
                    nearestLocationDesc = ils.setEmptyNearestLocationDesc(nearestLocationHash); //set the empty description of the location
                } else 
                    if (commonlib.hasProperty(nearestLocationDesc, "ELS") === true) {
                        var elsForLocation = nearestLocationDesc.ELS;
                        if ((isELS(elsForLocation) === true) && ((flELS === true && elsForLocation !== _ELS) //if the ELS connection to the neatest local server is differ from the given ELS
                            || (flELS === false && elsForLocation.elsPeerID !== lsID))) { //if the ID of the neatest local server is differ from the given lsID
                                elsForLocation.removeELSLocation(nearestLocationHash); //delete the location from the list of the nearest locations, that are handled by the els
                                nearestLocationDesc.ELS = null; //drop this ELS as ELS, that handles the location description
                        }
                    }
                if (flELS === true) {
                    nearestLocationDesc.lsID = _ELS.elsPeerID; //if the lsID is the instance of the els
                    nearestLocationDesc.ELS = _ELS;
                } else {
                    nearestLocationDesc.lsID = lsID; //if the lsID is the ID of the local server   
                }
            }
        };


        /**
         * create new instance of External Local Server for messaging with the neartest ls and information exchange about a location, nearest to the handled location
         * locationHash - nearest location to the location, maintained by the ls
         * lsID - nearest ls ID or instance of DataConnection or instance of ExternalLocalServer, if the connection was already created
         * flRequestValidIDFromCS - if true, then call the 'getELSPeerID' method of the els instance to get the valid id for the locations
         * return ELS instance
         * return false if an error
         * @method connectToELS
         * @param {} elsLocationsHashes
         * @param {} lsID
         * @param {} flRequestValidIDFromCS
         * @return 
         */
        ILSProto.connectToELS = function(elsLocationsHashes, lsID, flRequestValidIDFromCS) {
            var ils = this;
            var flEmptyLS;
            
            if ( lsID === ils.ID ) { //if it is the local connection (it is not necessary to create ELS for this type)
                ils.setLSForNearestLocations(elsLocationsHashes, lsID); //set the empty ELS for this locations
                return false;    
            }
            
            var flDataConnection = isDataConnection(lsID);
            if (typeof(elsLocationsHashes) === "string") { //if there is only the one location
                elsLocationsHashes = [elsLocationsHashes];
            }
            if (flDataConnection !== true
                && isELS(lsID) === true) { //it is not necessary to create a new one instance of the ELS
                    connToLS = lsID; //set lsID as the els connection
                    connToLS.addELSLocations(elsLocationsHashes); //add els locations to the list of the locations, that are handled by the els
                    ils.setLSForNearestLocations(elsLocationsHashes, connToLS);
                    flEmptyLS = isEmptyLSID(connToLS.elsPeerID) === true;
            } else { //if the ID of the nearest local server is given as the argument or the data connection with the ls is given as the argument. lsID may be empty, then it will be requested by the ELS from the central server
                var connToLS;
                if (flDataConnection === true) { //if the lsID argument is a data connection to the nearest local server
                    //try to find the els instance by the id of the data connection
                    connToLS = ils.getELSByID(lsID.peer);
                    flEmptyLS = isEmptyLSID(connToLS.elsPeerID) === true;    
                } else { //try to find an existing els connection with the given local server id
                    flEmptyLS = isEmptyLSID(lsID) === true;
                    connToLS = ils.getELSByID( flEmptyLS !== true ? lsID : empty_user_id);
                }
                if (isELS(connToLS) === false) { //if there is no existing ELS connection, create it
                    connToLS = new ExternalLocalServer(ils.g_MainP2P, elsLocationsHashes, 2, lsID, ils, ( flRequestValidIDFromCS === true ? false : true ) ); //create the ELS by the local server ID               
                } else { //add the locations for handling for existing ELS connection
                    
                    if ( flDataConnection === true //if the data connection was given
                        && connToLS.setDataConnection(lsID) === false ) { //set the incoming connection as the main connection for ELS
                            lsID.close(); //close the incoming connection if not valid
                            return false;
                    }
                    
                    connToLS.addELSLocations(elsLocationsHashes, flRequestValidIDFromCS === true); //add els locations to the list of the locations, that are handled by the els    
                    
                }
                ils.setLSForNearestLocations(elsLocationsHashes, connToLS); //set the ELS connection for all listed the nearest locations

            }
            
            if ( flEmptyLS === true ) { //if there is no local server for this location(s)
                ils.setEmptyUsersOnNearestLocation(elsLocationsHashes); //set empty descriptions for the locations
            }
            
            if (isELS(connToLS) === true) {
                ils.setELSListeners(connToLS);
                return connToLS;
            } else {
                return false;
            }
        };


        /**
         * set the listeners for the els instance
         * @method setELSListeners
         * @param {} els
         * @return 
         */
        ILSProto.setELSListeners = function(els) {
            var ils = this;
            ils.removeELSListeners(els); //remove all the previous listeners, before add the 
            if (isELS(els) === true) {
                els.on("newLocalServer", ils.onNewLSID); //on new local server ID
                els.once("externalLocalServerOpened", ils.onELSOpen); //connection opened
                els.on("incomingMessageForILS", ils.onIncomingMessageFromLS); //on message from the ls
                els.once("externalLocalServerClosed", ils.onELSClosed); //conection to the ls has closed
            }
        };


        /**
         * remove the listeners for the els instance
         * @method removeELSListeners
         * @param {} els
         * @return 
         */
        ILSProto.removeELSListeners = function(els) {
            var ils = this;
            if (isELS(els) === true) {
                els.removeListener("newLocalServer", ils.onNewLSID); //on new local server ID
                els.removeListener("externalLocalServerOpened", ils.onELSOpen); //connection opened
                els.removeListener("incomingMessageForILS", ils.onIncomingMessageFromLS); //on message from the ls
                els.removeListener("externalLocalServerClosed", ils.onELSClosed); //conection to the ls has closed
            }
        };


        /**
         * on new ID of the local server
         * listNewLSID = { locationHash : newLSID } - the list was formed by the els and includes only the local servers, which have an id, that is differ from the id of the els
         * it is necessary to establish a connections with the new local servers for the nearest locations, that were being handled by the els, and now the other local servers handles this locations
         * @method onNewLSID
         * @param {} listNewLSID
         * @return 
         */
        ILSProto.onNewLSID = function(listNewLSID) {
            var els = this,
                ils = els.getILS(els);
            ils.connectToNearestLSs(listNewLSID);
        };


        /**
         * when a nearest ls open
         * @method onELSOpen
         * @return 
         */
        ILSProto.onELSOpen = function() {
            var els = this,
                ils = els.getILS(els);
            if (ils === false 
                || ils.isValidELS(els) === false) { //is not the valid instance of ELS
                    ils.closeELS(els);
            }
        };


        /**
         * establish new connections to the local servers with id from the given list
         * listLSIDForLocations = { locationHash : newLSID }
         * @method connectToNearestLSs
         * @param {} listLSIDForLocations
         * @return 
         */
        ILSProto.connectToNearestLSs = function(listLSIDForLocations) {
            var ils = this;
            var listLocationsWithoutLS = []; //list of the locations without a service local servers
            var validNearestLocations = ils.getOnlyNearestLocations(Object.keys(listLSIDForLocations)); //get only the valid nearest locations from the given list
            for (var i = 0, len = validNearestLocations.length; i < len; i++) {
                var validNearestLocationHash = validNearestLocations[i];
                var lsID = listLSIDForLocations[validNearestLocationHash];
                if (isEmptyLSID(lsID) === true) { //if a local server for the location is absent for now 
                    listLocationsWithoutLS[listLocationsWithoutLS.length] = validNearestLocationHash;
                } else {
                    //need to establish the new connection to the local server
                    //or if an els already the instance of the ELS, add the location for the maintaince by the els connection
                    ils.connectToELS(validNearestLocationHash, lsID);
                }
            }
            if (listLocationsWithoutLS.length > 0) {
                //create a new ELS for locations with an unknown id of a service local server
                ils.connectToELS(listLocationsWithoutLS, null);
            }
        };
        
        /**
         * form the message with the new local server ID for the location
         * @method ilsMessageToNearestLS_newLSID
         * @param {} lsID
         * @param {} locationHash
         * @return ObjectExpression
         */
        ILSProto.ilsMessageToNearestLS_newLSID = function(lsID, locationHash) {
            return {
                type: "toILS",
                kind: "ilsNewLSID",
                body: {
                    locationHash : numToStr(locationHash), //must be a string
                    lsID : lsID
                },
                timestamp: getCurrentTimestamp()
            };
        };
        
        /**
         * form and send a message with the new LS ID for the maintained location
         * @method sendMessageWithNewLSIDForAllNearestLS
         * @param {} locationHash
         * @param {} lsID
         * @return 
         */
        ILSProto.sendMessageWithNewLSIDForAllNearestLS = function(locationHash, lsID) {
            var ils = this;
            ils.sendToAllNearestLSForMaintainedLocation(locationHash, ils.ilsMessageToNearestLS_newLSID(lsID, locationHash));
        };
        
        /**
         * local server give us id of the new local server for the location, which is now the LS instead of itself
         * @method onLSNewLSID
         * @param {} els
         * @param {} msgBody
         * @param {} timestamp
         * @return 
         */
        ILSProto.onLSNewLSID = function(els, msgBody, timestamp) {
            var ils = els.getILS();
            var newLSID      = commonlib.strToInt(msgBody.lsID); //new ls id 
            var locationHash = msgBody.locationHash; //location hash for the new id
    
            if ( els.isELSLocationIntoList(locationHash) !== false //check if the location hash is into the list of the locations, maintained by the ils
                && els.checkTimestampLSID(timestamp) === true ) { //and the timestamp is newer then the timestamp of the current ls id
                    ils.connectToELS( locationHash, newLSID, true ); //try to connect to the with the new ls and request the valid ls id for this location
            }
        };       
          
        /**
         * on message from the nearest local server, that he has logged out
         * @method onLSClosed
         * @param {} els
         * @param {} msgBody
         * @param {} timestamp
         * @return 
         */
        ILSProto.onLSClosed = function(els, msgBody, timestamp) {
            els.setUntrusted(); //set that the current ls is untrusted (the valid id must be requested form the cs)
            els.getELSPeerID(); //disconnect from the current ls
        };
            
        /**
         * return the description of a messages handlers, comming from th nearest ls
         * @method formHandlersIncomingMessageFromLS
         * @param {} ils
         * @return ObjectExpression
         */
        ILSProto.formHandlersIncomingMessageFromLS = function(ils) {
            return {
                "ilsGetLocationsDescription": { //request of the nearest to the els maintained locations description
                    validator: validators.validatorILSIncomingRequestGetLocationsDescriptions,
                    handler: ils.onLSRequestLocationsDescription
                },
                "ilsLocationsDescription": { //on incoming nearest location description
                    validator: validators.validatorMessageILSIncomingMessageLocationDescription,
                    handler: ils.onLocationsDescription
                },
                "ilsUsersMovedToLocation": { //user move to the maintained location
                    validator: validators.validatorMessageILSUserCame,
                    handler: ils.onUserCame
                },
                "ilsUserCameToNearestLocation": { //user came to the nearest location
                    validator: validators.validatorMessageILSUserCameToNearestLocation,
                    handler: ils.onUserCameToNearestLocation
                },
                "ilsSendMessageToTheUser" : { //send the message to the user on the maintained location or one of the nearest locations
                    validator: validators.validatorMessageILSSendMessageToUser,
                    handler: ils.onSendMessageToUser    
                },
                "ilsNewLSID" : { //send the message to the user on the maintained location or one of the nearest locations
                    validator: validators.validatorMessageILSNewLSID,
                    handler: ils.onLSNewLSID  
                },
                "out" : {
                    validator: validators.validatorMessageILSOut,
                    handler: ils.onLSClosed  //the nearest local server has logged out  
                }
            };
        };


        /**
         * incoming message from a nearest ls
         * @method onIncomingMessageFromLS
         * @param {} incomingMessage
         * @return 
         */
        ILSProto.onIncomingMessageFromLS = function(incomingMessage) {
            var els = this,
                ils = els.getILS();
            if (ils === false //not valid els
                || ils.isValidELS(els) == false) {
                    ils.closeELS(els);
                    return;
            }
            var res = validators.validatorMessageILSMain(incomingMessage);
            if (res === false) { //message not valid
                return;
            }
            var msgKind = incomingMessage.kind,
                msgBody = incomingMessage.body,
                msgDesc = ils.handlersIncomingMessageFromLS[msgKind];
            
            logger("ILS>onIncomingMessageFromLS. Incoming message with the kind: " + msgKind);    
                
            if (msgDesc != null) {
                if (msgDesc.validator(msgBody) !== false) {
                    msgDesc.handler(els, msgBody, incomingMessage.timestamp);
                } else {
                    logger("onIncomingMessageFromLS. Error:");
                    logger(msgDesc.validator.errors);
                }
            }
        };


        /**
         * delete user from all the given locations or from the only one location
         * @method deleteUsersFromLocations
         * @param {} users
         * @param {} locations
         * @return 
         */
        ILSProto.deleteUsersFromLocations = function(users, locations) {
            var ils = this;
            if (typeof(locations) === "number" || typeof(locations) === "string") {
                locations = locations[locations];
            }
            if (typeof(users) === "number") {
                users = users[users];
            }

            for (var i = 0, len = locations.length; i < len; i++) { //for all the given locations
                for (var ii = 0, _len = users.length; ii < _len; ii++) { //for all the given users
                    ils.deleteUserFromLocation(users[ii], locations[i]);
                }
            }
        };


        /**
         * delete user from the location
         * @method deleteUserFromLocation
         * @param {} userID
         * @param {} locationHash
         * @param {} flDoNotCloseUserConnection - do not close the user connection
         * @return 
         */
        ILSProto.deleteUserFromLocation = function(userID, locationHash, flDoNotCloseUserConnection) {
            var ils = this;
            if (ils.isLocationHandled(locationHash) === true) { //if the location is maintained by the ils, need to close connection with the user
                var incomingUsersOnLocation = ils.getIncomingUsersDescription(locationHash);
                if (incomingUsersOnLocation !== false //try to find the user into the list of an incoming users on the location
                    && commonlib.isEmptyObject(incomingUsersOnLocation) === false 
                    && commonlib.hasProperty(incomingUsersOnLocation, userID) === true) { //if he is on the list of the incoming users
                        delete incomingUsersOnLocation[userID];
                } 
                ils.closeUserConnection(userID, locationHash, flDoNotCloseUserConnection); //if he is on the maintained location
            } else { //if the locationHash is the nearest location
                var usersOnNearestLS = ils.getUsersOnNearestLocation(locationHash);
                if (usersOnNearestLS !== false //description for the location is exists
                    && commonlib.isEmptyObject(usersOnNearestLS) === false && commonlib.hasProperty(usersOnNearestLS, userID) === true) { //user is on the location
                    delete usersOnNearestLS[userID];
                }
            }
        };


        /**
         * find the user on the maintained locations and its nearest locations
         * flDeleteUserFromLocations - if true, then the user will be removed from all of the locations, where he was found
         * flDeleteUserFromLocationsIfFoundedOnMoreThanOne - if true, then user will be removed from the locations, if he was found on more than one location
         * return array of the locations hashes where is the user located
         * givenTimestamp is not null - check if exists the timestamp of the user loctaion, that is bigger than the givenTimestamp
         * if the givenTimestamp is not null, then return true if found, and listWithTheLocations if not found
         * @method findOrRemoveUserOnLocations
         * @param {} userID
         * @param {} flDeleteUserFromLocations
         * @param {} flDeleteUserFromLocationsIfFoundOnMoreThanOne
         * @param {} givenTimestamp
         * @return foundedOnLocations
         */
        ILSProto.findOrRemoveUserOnLocations = function(userID, flDeleteUserFromLocations, flDeleteUserFromLocationsIfFoundOnMoreThanOne, givenTimestamp) {
            var ils = this,
                foundedOnLocations = []; //the result list of the locations where the user was found

            var flCheckTimestamp = typeof(givenTimestamp) === "number"; //need to check the timestamp of the hash calculation of the user location

            //put the location, were the user was found into the result array
            //locationHash - location where the user was found
            //process the result according to the given flags
            function _putIntoResult(locationHash) {
                if (foundedOnLocations.indexOf(locationHash) === -1) {
                    foundedOnLocations.push(locationHash);
                }
                var len = foundedOnLocations.length;
                if (flDeleteUserFromLocations === true) { //if necessary to delete the user from all the locations where he was found
                    ils.deleteUserFromLocation(userID, locationHash);
                } else if (len > 1 //user found on more than one location
                    && flDeleteUserFromLocationsIfFoundOnMoreThanOne === true) { //if need to check thaty the user is located to the several locations simultaneously
                    ils.deleteUserFromLocation(userID, locationHash);
                    if (len === 2) { //if the user is located on 2 locations at the same time, need to delete the user from the previous location, where he was found, too
                        ils.deleteUserFromLocation(userID, foundedOnLocations[0]);
                    }
                }
            }

            var maintainedLocations = ils.getListOfMaintainedLocations(); //list of all the maintained locations
            for (var i = 0, len = maintainedLocations.length; i < len; i++) {
                var locationHash = maintainedLocations[i];
                var usrDesc = ils.getUserDescription(userID, locationHash); //description of the users on the maintained location
                if (usrDesc !== false) { //if user is on the location
                    if (flCheckTimestamp === true) { //check the timestamp when the central server has calculated the hash of the user location
                        if (commonlib.hasProperty(usrDesc, "location") === true
                            && typeof(usrDesc.location.timestamp) === "number" //timestamp when the hash of the user location has been calculated by the cs
                            && usrDesc.location.timestamp > givenTimestamp) { //calculation into the list is newer then the given timestamp
                                return true;
                        }
                    }
                    _putIntoResult(locationHash);
                }

                var incomingUsers = ils.getIncomingUsersDescription(locationHash); //description of all the incoming users to the maintained location
                if (incomingUsers !== false 
                    && commonlib.hasProperty(incomingUsers, userID) === true) { //if the user was found on the location
                        if (flCheckTimestamp === true) {
                            var incomingListTimestamp = incomingUsers[userID]; //timestamp, when the user has been moved to the location by another inner local server
                            if (typeof(incomingListTimestamp) === "number" //check timestamp of the user into the list of incoming users
                                && incomingListTimestamp > givenTimestamp) { //timestamp when the user came on to the location
                                    return true;
                            }
                        }
                        _putIntoResult(locationHash);
                }
            }

            var nearestLocations = ils.getAllNearestLocationsDesc();
            if (nearestLocations !== false) { //nearest locations are absent
                var _keys = Object.keys(nearestLocations);
                for (var ii = 0, _len = _keys.length; ii < _len; ii++) {
                    var nearestLocationHash = _keys[ii];
                    var usersOnNearestLocation = ils.getUsersOnNearestLocation(nearestLocationHash); //users on the nearest location
                    if (usersOnNearestLocation !== false 
                        && commonlib.hasProperty(usersOnNearestLocation, userID) === true) { //user was found on the nearest location
                            if (flCheckTimestamp === true) { //try to find the location with a timestamp, that is bigger than the given
                                usrDesc = usersOnNearestLocation[userID];
                                if (typeof(usrDesc.timestamp) === "number" && usrDesc.timestamp > givenTimestamp) { //timestamp when the user was placed on the nearest location
                                    return true;
                                }
                            }
                            _putIntoResult(nearestLocationHash);
                    }
                }
            }

            return foundedOnLocations;
        };


        /**
         * user has came to the nearest location, needed to check whether he located to any other locations and remove him from the locations where he was detected
         * @method onUserCameToNearestLocation
         * @param {} els
         * @param {} incomingMessage
         * @return 
         */
        ILSProto.onUserCameToNearestLocation = function(els, incomingMessage) {
            var ils = els.getILS();
            var _keys = Object.keys(incomingMessage); //{ userID : userLocationDesc }
            for (var i = 0, len = _keys.length; i < len; i++) {
                var userID = _keys[i]; //ID of the user, which has moved
                var userNewLocation = incomingMessage[userID]; //userLocationDesc = { lat, lng, timestamp, locationHash, previousLocationHash }
                var newUserLocationHash = userNewLocation.locationHash; //the new location where the user has moved
                var previousUserLocation = userNewLocation.previousLocationHash; //the previous location from where the user has moved
                if (els.isELSLocationIntoList(newUserLocationHash) === false //the location from the message is not maintained by the els
                    || ils.isUserOnTheLocation(userID, newUserLocationHash) === true //if the user is not on the els location
                    || ils.isUserOnTheLocation(userID, previousUserLocation) === false) { //check if the user has been on the previous location
                    continue;
                }

                //remove the user from all the known locations and try to find the user on another locations,on to where he has moved later than according to this message
                ils.findOrRemoveUserOnLocations(userID, true, false, userNewLocation.timestamp); //try to found location where is the user calculated location hash is newer than that from the incoming message
            }
        };

        //message from the nearest ls, that the user came to the nearest location
        //delete this user from all the locations
        /**
         * Description
         * @method ilsMessageToNearestLS_userCameToLocation
         * @param {} message
         * @param {} userID
         * @param {} userLocation
         * @return 
         */
        ILSProto.ilsMessageToNearestLS_userCameToLocation = function(message, userID, userLocation) {
            if (message == null) { // message is empty for now
                return {
                    type: "toILS",
                    kind: "ilsUserCameToNearestLocation",
                    body: {
                        userID: {
                            timestamp: userLocation.timestamp, //when the user change the location
                            previousLocationHash: userLocation.previousLocationHash, //from where the user has moved
                            locationHash: userLocation.locationHash, //location, where the user has moved
                            lat: userLocation.lat,
                            lng: userLocation.lng
                        }
                    },
                    timestamp: getCurrentTimestamp()
                };
            } else if (commonlib.isEmptyObject(message.body) === false) { //if the message is not empty
                message.body[userID] = { //add the next user location to the message
                    timestamp: userLocation.timestamp, //when the user change the location
                    previousLocationHash: userLocation.previousLocationHash, //from where the user has moved
                    locationHash: userLocation.locationHash, //location, where the user has moved
                    lat: userLocation.lat,
                    lng: userLocation.lng
                };
            }
        };

        /**
         * the other local server wants this local server send the message to the user
         * @method onSendMessageToUser
         * @param {} els
         * @param {} msgBody
         * @param {} timestamp
         * @return 
         */
        ILSProto.onSendMessageToUser = function(els, msgBody, timestamp) {
            var ils = els.getILS();
            ils.sendToUser(msgBody.locationHash, msgBody.to, msgBody.message); //send the message to the user
        };
        
        /**
         * message from the nearest ls, that the user moved from it's location to the location, maintained by this ls(ils)
         * incomingUsersDescription = { userID : {locationHash, timestamp} }
         * locationHash - location, where the user was moved
         * timestamp - time when the user moved to the location
         * @method onUserCame
         * @param {} els
         * @param {} incomingUsersDescription
         * @return 
         */
        ILSProto.onUserCame = function(els, incomingUsersDescription) {
            var ils = els.getILS();
            var users = Object.keys(incomingUsersDescription);
            var msgToNearestLSs; // message for the nearest local servers that the user has come to the location, maintained by this local server
            for (var i = 0, len = users.length; i < len; i++) { //for each of the moved users
                var userID = users[i],
                    userLocationDesc = incomingUsersDescription[userID],
                    elsMaintainedLocation = userLocationDesc.previousLocationHash, //from which location the user has gone
                    ilsMaintainedLocation = userLocationDesc.locationHash, //on which location the user has came
                    actionTimestamp = userLocationDesc.timestamp; //when the hash of the user location was calculated
                if (els.isELSLocationIntoList(elsMaintainedLocation) === false //the location from which the user has gone is not maintained by this nearest local server
                    || ils.isLocationHandled(ilsMaintainedLocation) === false) { //the location where the user has moved does not maintained by this ls    
                    continue;
                }
                var usersOnTheELSLocation = ils.getUsersOnNearestLocation(elsMaintainedLocation);
                if (commonlib.hasProperty(usersOnTheELSLocation, userID) === false) { //user has not been located on the location, from which had moved, according to the incoming message
                    continue;
                }

                //find the user on the all known locations - maintained and the nearest to the maintained and try to found the user with the newer timestamp of the user location hash on the all known locations
                //remove the user from all the locations
                var res = ils.findOrRemoveUserOnLocations(userID, true, false, actionTimestamp);
                if (res === true) { //if found the user with the newer timestamp of his location on the another location
                    continue;
                }

                //add the user to the list of incoming users on the maintained location
                if (ils.addUserIntoIncomingList(userID, ilsMaintainedLocation, actionTimestamp) === false) {
                    return false;
                }

                //add to the message that the user came to this location for all the nearest local servers
                msgToNearestLSs = ils.ilsMessageToNearestLS_userCameToLocation(msgToNearestLSs, userID, userLocationDesc);
            }
            //send the message that the users has come to the locations, maintained by the ils
            ils.sendToAllNearestLS(msgToNearestLSs);
        };
        
        /**
         * send the message to the nearest local server    
         * @method sendToTheNearestLS
         * @param {} nearestLocationHash
         * @param {} message
         * @return 
         */
        ILSProto.sendToTheNearestLS = function(nearestLocationHash, message) {
            var ils = this;
            var nearestLSDesc = ils.getNearestLSDesc(nearestLocationHash);
            if ( nearestLSDesc !== false //find an ELS instance
                 && commonlib.hasProperty(nearestLSDesc, "ELS") === true ) {
                    if ( message.type == null ) {
                        message.type === "toLocalServer"    
                    }
                    nearestLSDesc.ELS.sendMessage(message); //send the message for the nearest ls throw the els instance         
            }    
        };
        
        /**
         * send the message to all the local servers, that are the nearest to the give maintained location
         * @method sendToAllNearestLSForMaintainedLocation
         * @param {} maintaiedLocationHash
         * @param {} message
         * @return 
         */
        ILSProto.sendToAllNearestLSForMaintainedLocation = function(maintaiedLocationHash, message) {
            var ils = this;
            var listNearestLocations = ils.getNearestLocations( maintaiedLocationHash );  //list with the nearest locations, to the maintained location
            if (listNearestLocations === false) {
                logger("!!!Nearest locations for maintained location " + maintaiedLocationHash + " are absent");
            } else {
                for (var i = 0, len = listNearestLocations.length; i < len; i++) { //for each of the nearest locations
                    ils.sendToTheNearestLS(listNearestLocations[i], message);
                }    
            }
        };
        
        /**
         * send the message to all the nearest for the maintained location local servers
         * @method sendToAllNearestLS
         * @param {} message
         * @return 
         */
        ILSProto.sendToAllNearestLS = function(message) {
            var ils = this;
            var _nearestLocations = ils.getAllNearestLocationsList(); //get all the nearesr local servers for the maintained location
            if (_nearestLocations === false) {
                logger("!!!Nearest locations are absent");
            } else {
                for (var i = 0, len = _nearestLocations.length; i < len; i++) { //for each of the nearest locations
                    ils.sendToTheNearestLS(_nearestLocations[i], message);
                }
            }
        };


        /**
         * add user to the list of incoming users to the maintained location(ilsMaintainedLocation)
         * return false if an error
         * @method addUserIntoIncomingList
         * @param {} incomingUserID
         * @param {} ilsMaintainedLocation
         * @param {} actionTimestamp
         * @return 
         */
        ILSProto.addUserIntoIncomingList = function(incomingUserID, ilsMaintainedLocation, actionTimestamp) {
            var ils = this,
                maintainedLocationIncomingUsers = ils.getIncomingUsersDescription(ilsMaintainedLocation);
            if (maintainedLocationIncomingUsers === false) { //if the list of an incoming users was not found for the maintained location, create the list manually
                var locationDesc = ils.getHandledLocationDescription(ilsMaintainedLocation);
                if (locationDesc === false) {
                    return false;
                }
                maintainedLocationIncomingUsers = locationDesc.incomingUsers = {};
            }
            maintainedLocationIncomingUsers[incomingUserID] = actionTimestamp || getCurrentTimestamp();
        };


        /**
         * parse incoming description of the nearest location, which is into the JSON format, validate and save the description as the users o
         * @method onIncomingLocationDescription
         * @param {} incomingDescription
         * @param {} nearestLocationDesc
         * @return 
         */
        ILSProto.onIncomingLocationDescription = function(incomingDescription, nearestLocationDesc) {
            //parse JSON string, which contains the description of the nearest location
            JSON.parseAsync(incomingDescription, function(incomingNearestLocationDesc) {
                if (incomingNearestLocationDesc != null && incomingNearestLocationDesc instanceof Error === false) {
                    if (validators.validatorMessageILSIncomingMessageLocationDescription_eachLocation(incomingNearestLocationDesc) !== false) { //if the message is valid
                        nearestLocationDesc.users = incomingNearestLocationDesc; //add users from the incoming message directly
                    } else {
                        logger("ILSProto.onIncomingLocationDescription. Invalid nearest location description");
                        logger(validators.validatorMessageILSIncomingMessageLocationDescription_eachLocation.errors);
                    }
                }
            });
        };


        /**
         * location description from the nearest ls has come
         * locationDescription = { userID : { lat, lng, timestamp, locationHash } }
         * return false, if location description is not valid
         * @method onLocationsDescription
         * @param {} els
         * @param {} incomingLocationsDescription
         * @param {} timestamp
         * @return 
         */
        ILSProto.onLocationsDescription = function(els, incomingLocationsDescription, timestamp) {
            var ils = els.getILS();
            if (ils.isValidELS(els) === false) {
                return;
            }
            var elsLocations = els.getELSLocations(); //get the nearest locations, that are handled by the els
            for (var i = 0, len = elsLocations.length; i < len; i++) { //for ah of the handled nearest location
                var elsLocationHash = elsLocations[i];
                if (commonlib.hasProperty(incomingLocationsDescription, elsLocationHash) === true) { //if the incoming description of the nearest locations contains the els location
                    var nearestLocation = ils.getNearestLSDesc(elsLocationHash); //get the description of the els location
                    if (nearestLocation !== false) {
                        if (commonlib.hasProperty(nearestLocation, "locationDesc") === false) {
                            var nearestLocationDesc = nearestLocation.locationDesc = {}; //if there is no description for the users on the els location
                        } else {
                            nearestLocationDesc = nearestLocation.locationDesc;
                            if (nearestLocationDesc.timestamp > timestamp) { //if the current description of the nearest location is newer then the incoming
                                continue;
                            }
                        }
                        nearestLocationDesc.timestamp = timestamp; //timestamp, when the description was formed
                        //parse the incoming description and save the result as users, that are located on the nearest location
                        ils.onIncomingLocationDescription(incomingLocationsDescription[elsLocationHash], nearestLocationDesc);
                    }
                }
            }
            els.updateTimestamp(); //update timestamp of the els
        };

        //form the message with the description of the requested location
        //resulted message : { ilsLocation : { userID : { lat, lng, locationHash, timestamp } } }
        /**
         * Description
         * @method ilsMessageToNearestLS_locationDescription
         * @param {} els
         * @param {} ilsLocationsHashes
         * @return 
         */
        ILSProto.ilsMessageToNearestLS_locationDescription = function(els, ilsLocationsHashes) {
            var ils = this;
            if (typeof(ilsLocationsHashes) === "number" || typeof(ilsLocationsHashes) === "string") {
                ilsLocationsHashes = [ilsLocationsHashes];
            }

            var message = {
                kind: "ilsLocationsDescription",
                body: {}
            };
            
            var flDescriptionsExists = false; //falg means, that the description of any of the requested locations is exists
            for (var i = 0, len = ilsLocationsHashes.length; i < len; i++) { //for each of the maintained locations, that are nearest to the els
                var ilsLocationHash = ilsLocationsHashes[i];
                var locationDesc = ils.getLocationDescForTheILS(ilsLocationHash); // description of the users on the maintained location for the nearest local server { userID : { lat, lng, locationHash, timestamp } }
                if (locationDesc != false) { //if the description is exists
                    message.body[ilsLocationHash] = locationDesc; //put the stringified location description nto the message
                    flDescriptionsExists = true;
                } else { //if the description is absent, make it
                    ils.createJSONOneLocationDescription(ilsLocationsHashes);
                }
            }
            
            if ( flDescriptionsExists === true ) { //send the descriptions of all the maintained locations, that are nearest to the els
                els.sendMessage(message);
            }
        };


        /**
         * nearest ls has requested the description of the locations(listed into the locations list), that is maintained by the ils
         * @method onLSRequestLocationsDescription
         * @param {} els
         * @param {} locationsList
         * @return 
         */
        ILSProto.onLSRequestLocationsDescription = function(els, locationsList) {
            var ils = els.getILS();
            if (ils === false) {
                ils.closeELS(els);
                return;
            }
            var ilsLocationsHashes = ils.returnILSHandledLocationsByELS(els); //all the location, maintained by the ils, that are the nearest to the nearest ls (connection to which is handled by the els)
            ils.ilsMessageToNearestLS_locationDescription(els, ilsLocationsHashes); //send the location description to ls
        };


        /**
         * is the user(with usrID) is on the location(locationHash)
         * return 1 if user is on to the location
         * return 2 if the user is into the list of incoming users
         * return false if there is no with the ID on the location
         * @method isUserOnTheMaintainedLocation
         * @param {} userID
         * @param {} locationHash
         * @return LogicalExpression
         */
        ILSProto.isUserOnTheMaintainedLocation = function(userID, locationHash) {
            var ils = this;
            if (ils.isLocationHandled(locationHash) === false) {
                return false;
            }
            var userDesc = ils.getUserDescription(userID, locationHash),
                incomingUsersDesc = ils.getIncomingUsersDescription(locationHash);
            return (userDesc !== false && 1) || (incomingUsersDesc !== false && commonlib.hasProperty(incomingUsersDesc, userID) === true && 2) //user is into the list of incoming users
                || false;
        };


        /**
         * check if the user is located on the location with the given hash(incoming list, maintaind location or the nearest location)
         * @method isUserOnTheNearestLocation
         * @param {} userID
         * @param {} locationHash
         * @return LogicalExpression
         */
        ILSProto.isUserOnTheNearestLocation = function(userID, locationHash) {
            var ils = this;
            var usersOnTheNearestLocation = ils.getUsersOnNearestLocation(locationHash);
            return usersOnTheNearestLocation !== false //if the nearest location with the given hash is exists
                && commonlib.hasProperty(usersOnTheNearestLocation, userID); //is the user is located on the nearest location

        };


        /**
         * check if the user is located on the location (incoming list, maintaind location or the nearest location) with the given hash
         * @method isUserOnTheLocation
         * @param {} userID
         * @param {} locationHash
         * @return LogicalExpression
         */
        ILSProto.isUserOnTheLocation = function(userID, locationHash) {
            var ils = this;
            return (ils.isLocationHandled(locationHash) === true && ils.isUserOnTheMaintainedLocation(userID, locationHash) !== false) //check if the user is on the  maintained location
                || ils.isUserOnTheNearestLocation(userID, locationHash) === true; //check if the user is on the nearest location
        };


        /**
         * add user on the location, that is maintained by the ils
         * and user location description with the current coordinates
         * return false if the user can not be added on to the location
         * @method addUserOnLocation
         * @param {} dataConnection
         * @return Literal
         */
        ILSProto.addUserOnLocation = function(dataConnection) {

            if (dataConnection.open === false) { //if the data connection was closed while removing user from all locations
                return false;
            }

            var ils = this,
                userID = dataConnection.peer,
                usrLocationDescByDataConnection = ils.getUserCoordsDescriptionByUserIncomingDataConnection(dataConnection, true);
            if (usrLocationDescByDataConnection === false) {
                return false; //it is not valid location description
            }
            var ilsMaintainedLocation = usrLocationDescByDataConnection.locationHash; //location where the user is located, according to the metadata of the incoming connection

            var usersDesc = ils.getUsersDescription(ilsMaintainedLocation); //all the users description on the maintained location
            if (usersDesc === false) {
                return false;
            }
            
            var currentUserDesc;
            if (commonlib.hasProperty(usersDesc, userID) === false) { //if the user is not on the location

                //compare timestamp of the incoming connection and all a timestamps of this user in all the locations
                if (ils.findOrRemoveUserOnLocations(userID, false, true, usrLocationDescByDataConnection.timestamp) === true
                    && ils.isValidUserDataConnection(dataConnection, true) !== true ) { //this connection is not valid, this means this is connection to the user, that is located on a maintained location
                        return false; //found more newer user description on the maintained and nearest locations
                }

                currentUserDesc = usersDesc[userID] = {}; //create the new description for the user
                if (ils.isUserIntoListOfMovedUsers(userID, ilsMaintainedLocation) === false) { //if the user has not mogo out from the location at the nearest time
                    ils.updateLocationTimestamp(ilsMaintainedLocation); //update the timestamp of the location, because of it is the new user
                }
                
            } else { //user is already on the location
                currentUserDesc = usersDesc[userID]; //current description  of the user on the maintained location
                //check timestamp of the incoming and the current calculations of the user's location hash
                if (commonlib.hasProperty(currentUserDesc, "location") 
                    && typeof(currentUserDesc.location.timestamp) === "number" 
                    && currentUserDesc.location.timestamp > usrLocationDescByDataConnection.timestamp) { //if the current user hash calculation formed by the cs is newer than the incoming
                        return false;
                } else //if the incoming connection is more newer
                    if (isDataConnection(currentUserDesc.dataConnection) === true) {
                        if ( currentUserDesc.dataConnection !== dataConnection ) { //the current data connection with the user is not equals to this incoming data connection
                            ils.closeDataConnection(currentUserDesc.dataConnection, true); //close the previous user connection    
                        } else {
                            return true;//the current data connection with the user is equals to this incoming data connection
                        }   
                    }
            }

            //delete from incoming users
            var incomingUsersDesc = ils.getIncomingUsersDescription(ilsMaintainedLocation);
            if (commonlib.hasProperty(incomingUsersDesc, userID) === true) { //user is into the list of incoming users
                delete incomingUsersDesc[userID];
            }

            //update the properties of the user
            currentUserDesc.dataConnection = dataConnection;
            currentUserDesc.description = usrLocationDescByDataConnection.description; //compressed JSON string with the user description (tags, status, name e.t.c.)
            currentUserDesc.timestamp = usrLocationDescByDataConnection.timestamp; //when the user was placed on the location
            currentUserDesc.userID = userID;
            currentUserDesc.prevLat = usrLocationDescByDataConnection.lat; //the previous value of the lat coord
            currentUserDesc.prevLng = usrLocationDescByDataConnection.lng; //the previous value of the lng coord
            currentUserDesc.firstLat = usrLocationDescByDataConnection.lat; //a value of the lat coord, when the user has been placed on the location
            currentUserDesc.firstLng = usrLocationDescByDataConnection.lng; //a value of the lng coord, when the user has been placed on the location
            currentUserDesc.timestampLastAppeal = usrLocationDescByDataConnection.timestamp; //the timestamp of tha last appeal of the user to the ls
            currentUserDesc.numOfMaintainedLocations = usrLocationDescByDataConnection.numOfMaintainedLocations; //the number of the locations, that are maintained by the user as local server
            currentUserDesc.location = { //user location description
                locationHash: ilsMaintainedLocation, //calculated by the cs location hash
                timestamp: typeof(usrLocationDescByDataConnection.timestamp) === "number" ? usrLocationDescByDataConnection.timestamp : 0, //timestamp when the user location hash was calculated by the central server
                lng: usrLocationDescByDataConnection.lng,
                lat: usrLocationDescByDataConnection.lat,
                coordsTimestamp: usrLocationDescByDataConnection.coordsTimestamp
            };

            //create the new JSON location description
            ils.addTaskMakeJSONLocationDescription(ilsMaintainedLocation);

            return true;
        };
        
        /**
         * send the given message to the user on the maintained location
         * retrun true if the message was sent
         * @method sendToUserOnMaintainedLocation
         * @param {} userID
         * @param {} locationHash
         * @param {} message
         * @return res
         */
        ILSProto.sendToUserOnMaintainedLocation = function(userID, locationHash, message) {
            var ils = this;
            var res = false;
            var userDesc = ils.getUserDescription(userID, locationHash);
            if ( userDesc !== false ) { //if the user is not on the maintained location
                var dc = userDesc.dataConnection;
                if ( isDataConnection(dc) === true
                    && dc.open === true ) {
                        dc.send(message);
                        res = true;        
                } else { //if the Data Connection was found
                    logger("Data connection with the user " + userID + " is absent or closed");
                }
            } else {
                logger("Tthe user " + userID + " is absent on the maintained locations");     
            } 
            return res;
        };
        
        /**
         * send the message to the user on the maintained location or on the nearest locations to the maintained location
         * @method sendToUser
         * @param {} locationHash
         * @param {} userID
         * @param {} message
         * @return 
         */
        ILSProto.sendToUser = function(locationHash, userID, message) {
            var ils = this;
            var locatonDesc = ils.getHandledLocationDescription(locationHash); //get
            if ( locatonDesc.users[userID] == null ) { //if the user was not found on the maintained location
                //try to find the user on the nearest locations
                var neartestLocationsList = locatonDesc.nearestLocations; //locations, that are the nearest to the maintained location
                for( var i = 0, len = neartestLocationsList.length; i < len; i++ ) {
                    var nearestLocationHash = neartestLocationsList[i]; //hash of the nearest location
                    var usersOnLocation = ils.getUsersOnNearestLocation(nearestLocationHash);
                    if ( usersOnLocation[userID] != null ) { //if the user is on this nearest location
                        if ( ils.isLocationHandled(nearestLocationHash) !== true ) { //if the location maintained by the other local server
                            var msgForLS = { //message for the local server, to resend msg for the user, located on the location, maintained by the user
                                kind : "ilsSendMessageToTheUser",
                                body : {
                                    locationHash : nearestLocationHash,
                                    to : userID
                                }    
                            };
                            if ( typeof(message) === "string" ) {
                                msgForLS.message = message;
                                ils.sendToTheNearestLS(nearestLocationHash, msgForLS); //get the description of the nearest ls
                            } else {
                                JSON.stringifyAsync(message, function(strMsg) { //convert the message object to the string
                                    msgForLS.message = strMsg;
                                    ils.sendToTheNearestLS(nearestLocationHash, msgForLS); //get the description of the nearest ls
                                });    
                            }
                        } else { //if the location is maintained by this local server
                            ils.sendToUserOnMaintainedLocation(userID, nearestLocationHash, message);  //send to the user, located on the maintained location
                        }
                    }
                }
            } else { //send to the user from the maintained location
               ils.sendToUserOnMaintainedLocation(userID, locationHash, message);     
            } 
            
        };
        
        /**
         * send offer of the user for creating messagiung channel to another user
         * @method onSendOffer
         * @param {} dataConnection
         * @param {} body
         * @param {} timestamp
         * @return 
         */
        ILSProto.onSendOffer = function(dataConnection, body, timestamp) {
    
            if (validators.validatorIncomingUserOfferForMessagingWithAnotherUser(body) === false) { //validate user description
                logger("ILSProto.onSendOffer. Offer is not valid");
                logger(validators.validatorIncomingUserOfferForMessagingWithAnotherUser.errors);
                return false;
            }
            
            var ils = this;
            var userLocationDesc = ils.getUserCoordsDescriptionByUserIncomingDataConnection(dataConnection); //description of the user location
            var locationHash     = userLocationDesc.locationHash; //location hash where is the caller located 
            var calleeUserID     = body.to; //id of the user, who is the callee side
            
            var msg = { //message for the callee
                type: "fromLocalServer",
                kind: "offerSDP",
                timestamp: getCurrentTimestamp(),
                body: {
                    from  : dataConnection.peer,
                    offer : body.offer
                }
            };
            
            ils.sendToUser(locationHash, calleeUserID, msg);
        
        };
        
        /**
         * send answer of the user to the offer of another user
         * @method onSendAnswer
         * @param {} dataConnection
         * @param {} body
         * @param {} timestamp
         * @return 
         */
        ILSProto.onSendAnswer = function(dataConnection, body, timestamp) {
           
           if (validators.validatorIncomingUserAnswerForMessagingWithAnotherUser(body) === false) { //validate user description
                logger("ILSProto.onSendAnswer. Answer is not valid");
                logger(validators.validatorIncomingUserAnswerForMessagingWithAnotherUser.errors);
                return false;
            }
            var ils = this;
            var userLocationDesc = ils.getUserCoordsDescriptionByUserIncomingDataConnection(dataConnection); //description of the user location
            var locationHash     = userLocationDesc.locationHash; //location hash where is the callee located 
            var callerUserID = body.to; //id of the user, who is the callee side
            
            var msg = { //message for the callee
                type: "fromLocalServer",
                kind: "answerSDP",
                timestamp: getCurrentTimestamp(),
                body: {
                    from  : dataConnection.peer,
                    answer : body.answer
                }
            };
            
            ils.sendToUser(locationHash, callerUserID, msg);

        };

        /**
         * incoming message from a user, that is placed on the maintained location
         * @method onIncomingDataFromUser
         * @param {} incomingData
         * @return 
         */
        ILSProto.onIncomingDataFromUser = function(incomingData) {
            var dataConnection = this,
                ils = dataConnection.g_getILS();

            if (ils === false
                || ils.g_flClosedManually === true
                || ils.isValidUserDataConnection(dataConnection) !== true) {
                    return;
            }
            
            var res = validators.validatorIncomingMessageFromUser(incomingData);
            if (res === false) { //message not valid
                logger("ILSProto.onIncomingDataFromUser. Incoming data not valid.");
                logger(validators.validatorIncomingMessageFromUser.errors);
                return;
            }
            logger("Incoming data from user to ILS with the kind = " + incomingData.kind);
            switch (incomingData.kind) {
                case "userDescription": //incoming userDescription means, that user has requested the description of the location where he is located from the ils
                    if (ils.onUserDescription(dataConnection, incomingData.body, incomingData.timestamp) !== false) {
                        ils.sendLocationDescToUser(dataConnection);
                    }
                    break;
                case "sendOffer"  :
                    ils.onSendOffer(dataConnection, incomingData.body, incomingData.timestamp);
                    break;
                case "sendAnswer" :
                    ils.onSendAnswer(dataConnection, incomingData.body, incomingData.timestamp);
                    break;
            }
        };


        /**
         * incoming user description and at the same time it is a request of the maintained location description
         * messageTimestamp - timestamp when the message was sent
         * @method onUserDescription
         * @param {} dataConnection
         * @param {} incomingUsrDesc
         * @param {} messageTimestamp
         * @return 
         */
        ILSProto.onUserDescription = function(dataConnection, incomingUsrDesc, messageTimestamp) {
            if (validators.validatorIncomingUserDescription(incomingUsrDesc) === false) { //validate user description
                logger("ILSProto.onUserDescription. User description is not valid");
                logger(validators.validatorIncomingUserDescription.errors);
                return false;
            }
            var ils = this,
                usrDescFromList = ils.getUserDescByDataConnection(dataConnection); //get the description of the user from the list of maintained locations
            var coordsTimestamp = incomingUsrDesc.coordsTimestamp; //timestamp when user get the coordinates
            var userLocationDesc = commonlib.hasProperty(usrDescFromList, "location") === true ? usrDescFromList.location : false;
            if (usrDescFromList === false 
                || (userLocationDesc === true && commonlib.hasProperty(userLocationDesc, "coordsTimestamp") === true && userLocationDesc.coordsTimestamp > coordsTimestamp ) //if the timestamp from the list, that shows when the user coordinates was formed, is newer than the incoming timestamp
            ) { //if the current user location description is newer than the time when the incoming  coordinates of the user has been received on the client side
                return false;
            } else if (userLocationDesc === false) { //if description of the user coordinates is absent into the list of the users descriptions
                userLocationDesc = usrDescFromList.location = {};
            }

            //upadate the user's speed
            usrDescFromList.timestampLastAppeal = messageTimestamp; //update the timestamp when the last message from the client was received

            var prevLat = userLocationDesc.lat, //the current coords
                prevLng = userLocationDesc.lng,
                newLat = incomingUsrDesc.lat, //an incoming coords
                newLng = incomingUsrDesc.lng;
            
            usrDescFromList.numOfMaintainedLocations = incomingUsrDesc.numOfMaintainedLocations; //the number of the locations, that are maintained by the user as the local server
            usrDescFromList.currSpeedMetersPerSec =
                        geolib.getSpeed( //get the user speed by the previous coordinates from the list and the new coordinates from the description in meters per hour
                            {
                                lat: prevLat,
                                lng: prevLng,
                                time: userLocationDesc.coordsTimestamp * 1000 //when the previous coordinates were received by the user geolocation methods
                            }, {
                                lat: newLat,
                                lng: newLng,
                                time: coordsTimestamp * 1000  //when the current coordinates were received by the user geolocation methods
                            }
                        ) * 0.2778; //convert from kilometers per hour to meters per second

            usrDescFromList.prevLat = prevLat; //the previous value of the lat coord
            usrDescFromList.prevLng = prevLng; //the previous value of the lng coord
            usrDescFromList.description = incomingUsrDesc.description; //add compressed JSON string with the user description
            
            //update users's coordinates in the the user description into the description of the users, that are located on the maintained location
            userLocationDesc.lat = incomingUsrDesc.lat;
            userLocationDesc.lng = incomingUsrDesc.lng;
            userLocationDesc.coordsTimestamp = coordsTimestamp; //when this coordinates was formed by the user

        };

        //outcoming message with location description for user
        //locationsDesc = { user : { location, timestamp, userID } }
        //location = { locationHash, lat, lng, timestamp }
        /**
         * Description
         * @method ilsMessageToUsr_LocationDescription
         * @param {} descUsersOnLocations
         * @return ObjectExpression
         */
        ILSProto.ilsMessageToUsr_LocationDescription = function(descUsersOnLocations) {
            return {
                type: "fromLocalServer",
                kind: "locationDescription",
                timestamp: getCurrentTimestamp(),
                body: {
                    locationDescription: descUsersOnLocations,
                    timestampDescFormed: getCurrentTimestamp()
                }
            };
        };


        /**
         * return only coordinates of the user from the source
         * if flWOTimestampAndNum = true, then add the numOfMaintainedLocations and the timestamp when the location hash was calculated 
         * @method getCoordinatesDescription
         * @param {} source
         * @return ObjectExpression
         */
        ILSProto.getCoordinatesDescription = function(source, flTimestampAndNum) {
            
            var _location; //source for description of the user coordinates
            if ( source.location != null ) {
               _location = source.location; 
            } else {
                _location = source;    
            }
            
            var resObj = { //put as decription ony the coordinates
                    lat: _location.lat,
                    lng: _location.lng,
                    coordsTimestamp: _location.coordsTimestamp, //when this coordinates was formed by the user
                    description : source.description
                };
            if ( flTimestampAndNum === true ) {
                resObj.numOfMaintainedLocations = source.numOfMaintainedLocations; //number of locations, maintained by the user
                resObj.timestamp = _location.timestamp; //timestamp when the location hash was calculated for the user
            }
            return resObj;
        };


        /**
         * send location description to the user
         * usrDesc - users description from the list
         * send the message in the format: { userOnNearestLocation : { lat, lng, timestamp } }
         * @method sendLocationDescToUser
         * @param {} dataConnection
         * @return 
         */
        ILSProto.sendLocationDescToUser = function(dataConnection) {
            if (isDataConnection(dataConnection) === true && dataConnection.open === true) { //if the data connection is open
                var ils = this;
                var userCords = ils.getUserCoordsDescriptionByUserIncomingDataConnection(dataConnection);
                if (userCords === false) {
                    return false;
                }
                var ilsMaintainedLocation = userCords.locationHash; //location where the user is placed
                var locationsDescMessageForUser = ils.getLocationDescForTheELS(ilsMaintainedLocation); //description of maintained location and of all the neaarest locations to the maintained location
                if (locationsDescMessageForUser !== false) {
                    //message with the descriptions of the maintained location and all nearest locations to it
                    dataConnection.send(locationsDescMessageForUser); //send a message with the locations description
                }
            }
        };

        //mesage for all the users that the ils has closed
        /**
         * Description
         * @method ilsMessageToUsr_ServerClosed
         * @return ObjectExpression
         */
        ILSProto.ilsMessageToUsr_ServerClosed = function() {
            return {
                timestamp: getCurrentTimestamp(),
                type: "fromLocalServer",
                kind: "serverClosed"
            };
        };


        /**
         * flDoNotCallCloseUserConnection = true, then don't call the "closeUserConnection" procedure
         * @method closeDataConnection
         * @param {} dataConnection
         * @param {} flDoNotCallCloseUserConnection
         * @return 
         */
        ILSProto.closeDataConnection = function(dataConnection, flDoNotCallCloseUserConnection) {
            if (isDataConnection(dataConnection) === false 
                || dataConnection.g_flClosedManually === true) { //if already has been closed
                    return; //is not te instance of the DataConnection
            }

            logger("!!!Close the data connection with peer " + dataConnection.peer);

            if (typeof(dataConnection.g_getILS) === "function") {
                var ils = dataConnection.g_getILS();
                ils.removeUserDataConnectionEventListeners(dataConnection);
                if (flDoNotCallCloseUserConnection !== true) { 
                     var usrLocationDesc = ils.getUserDescByDataConnection(dataConnection);
                    if ( usrLocationDesc !== false
                        && usrLocationDesc.dataConnection === dataConnection //if it is the current user's data connection
                        && commonlib.hasProperty(usrLocationDesc, "location") === true) { //delete the user from the maintained location
                            ils.closeUserConnection(dataConnection.peer, usrLocationDesc.location.locationHash);
                    }
                }
            }
            if ( dataConnection.g_flClosedManually !== true ) {
                dataConnection.g_flClosedManually = true; //set the flag that this connection has closed
                setImmediate(
                    function(){ //close the data connection
                        dataConnection.close(); //close connection    
                    }
                );
            }
        };


        /**
         * close user's connection to the ils. user is on the locationHash
         * @method closeUserConnection
         * @param {} usrID
         * @param {} locationHash
         * @param {} flDoNotCloseUserConnection - do not close the user connection
         * @return 
         */
        ILSProto.closeUserConnection = function(usrID, locationHash, flDoNotCloseUserConnection) {
            var ils = this;
            var usersDesc = ils.getUsersDescription(locationHash); //all connected users description
            if (commonlib.hasProperty(usersDesc, usrID) === true) { //the user is absent on the location
                var usrDesc = usersDesc[usrID]; //user description
                delete usersDesc[usrID]; //delete the user description from the list of users on the location
                //not used -- usrDesc.dataConnection.send(ils.ilsMessageToUsr_ServerClosed);  //send a message that the local server closed

                if ( flDoNotCloseUserConnection !== true ) {
                    var dataConnection = usrDesc.dataConnection;
                    logger("!!!Close the data connection with peer " + usrID + " on the location hash " + locationHash);
                    ils.closeDataConnection(dataConnection, true); //close the connection with the user
                }
                
                ils.putUserIntoListOfMovedUsers(usrID, locationHash);
                ils.addTaskMakeJSONLocationDescription(locationHash); //create the new JSON location description(without this user)

            }
        };

        /**
         * outgoing message that the location maintaince was stopped by the ls
         * @method ilsMessageToUsr_locationMaintainceStopped
         * @param {string} locationHash hash of the location, maintenance of which is stopping
         * @param {} newLSID
         * @return msg
         */
        ILSProto.ilsMessageToUsr_locationMaintainceStopped = function(locationHash, newLSID) {
            var msg = {
                type: "fromLocalServer",
                kind: "locationMaintainceStopped",
                timestamp: getCurrentTimestamp(),
                body: {
                    locationHash : commonlib.numToStr(locationHash)    
                }
            };
            if ( isEmptyLSID(newLSID) === false ) {
                msg.body.idNewLS = commonlib.strToInt(newLSID);
            }
            return msg;
        };


        /**
         * send the message to the user that the ils stop maintaince of the location and the new ls id if exists
         * @method sendMessageToUsersLocationMaintainceStopped
         * @param {} locationHash
         * @param {} newLSID
         * @return 
         */
        ILSProto.sendMessageToUsersLocationMaintainceStopped = function(locationHash, newLSID) {
            var ils = this;
            ils.sendToAllUsersOnLocation(locationHash, ils.ilsMessageToUsr_locationMaintainceStopped(locationHash, newLSID));
        };
        
        /**
         * close all the connections with the user on the maintained location
         * @method sendToAllUsersOnLocation
         * @param {} locationHash
         * @param {} message
         * @return 
         */
        ILSProto.sendToAllUsersOnLocation = function(locationHash, message) {
            var ils = this;
            var _keys = Object.keys(ils.getUsersOnLocation(locationHash)); //get the ID of the users, that are located on the maintained location
            for (var i = 0, len = _keys.length; i < len; i++) { //for each user on the location
                ils.sendToUser(locationHash, _keys[i], message); //send to the user from the location
            }
        };
        
        /**
         * close all the connections with the user on the maintained location
         * @method closeConnectionsWithAllUsersOnLocation
         * @param {} locationHash
         * @return 
         */
        ILSProto.closeConnectionsWithAllUsersOnLocation = function(locationHash) {
            var ils = this; 
            var _keys = Object.keys(ils.getUsersOnLocation(locationHash)); //get the ID of the users, that are located on the maintained location
            for (var i = 0, len = _keys.length; i < len; i++) { //for each user on the location
                 ils.closeUserConnection(_keys[i], locationHash); //close the connection with the user from the location
            }
        };

        /**
         * stop handling the location with the hash = locationHash
         * newLSID - new id of a local server, that now maintaince the location
         * close connections to els
         * close connections users, on the location and send the newLSID if it is exists
         * flCommandFromCS - if it is command, that received from the central server
         * @method stopLocationHandling
         * @param {} _locationHash
         * @param {} _newLSID
         * @param {} flCommandFromCS
         * @return 
         */
        ILSProto.stopLocationHandling = function( _locationHash, _newLSID, flCommandFromCS) {
            var ils = this;
            var locationHash = numToStr(_locationHash); //convert to string
            if (ils.isLocationHandled(locationHash) === true ) { //if the location is handled by the ils
                
                var newLSID;
                
                if ( flCommandFromCS !== true //if it is not the command from the central server
                    && commonlib.isEmptyLSID(_newLSID) === true ) { //and the new ls id is empty
                        newLSID = ils.chooseNewLSForLocation(locationHash);  //choose the ID for the new local server
                } else { //if the id is given
                    newLSID = _newLSID;    
                }
            
                ils.emit("ilsCloseLocation", locationHash); //emit event, before the other actions
                
                //send messages to the local servers and the user
                ils.sendMessageWithNewLSIDForAllNearestLS(locationHash, newLSID); //send the message to all the nearest local servers, about the new id of the local server
                ils.sendMessageToUsersLocationMaintainceStopped(locationHash, newLSID); //send a message to the users, that the location maintaince is stopped
                                     
                setTimeout(function() { //waiting for some time to allow for the message to reach the users 
                    //after sending messages to the local servers send the messages to the users on the location
                                       
                    //close connections to all of the nearest local servers, that are not the nearest to the other maintained locations
                    var nearestLocations = ils.getNearestLocations(locationHash); //list(array) of the locations, that are the nearest to the maintained location(location hash)
                    //it is necessary to exclude the nearest locations, that are the nearest to the other maintained locations
                    var allValidNearestLocationsToMaintainedLocations = ils.getAllValidNearestLocations(locationHash); //get all the valid nearest locations, excepted the locations, that are the nearest only to the location hash, and not the nearest to the other maintained locations
                    if (Array.isArray(allValidNearestLocationsToMaintainedLocations) === false) {
                        //if the nearest locations to all the maintained locations are absent
                        ils.cleanAllNearestLocationsDesc(); // clean all the nearest locations
                    } else if (nearestLocations !== false) {
                        var allNearestLocationsDesc = ils.getAllNearestLocationsDesc(); //get a descriptions of all the nearest locations
                        for (var i = 0, len = nearestLocations.length; i < len; i++) { //for each the nearest location to the closing location
                            var nearestLocationHashForClosingLocation = nearestLocations[i];
                            if (allValidNearestLocationsToMaintainedLocations.indexOf(nearestLocationHashForClosingLocation) === -1) {
                                //if the nearest location was became not valid after the location maintenance was stopped (it is not the nearest to the others processed locations, excepted the closed location)
                                if (commonlib.hasProperty(allNearestLocationsDesc, nearestLocationHashForClosingLocation) === true) { //if the nearest location description is exists into the list of the nearest locations descriptions
                                    var nearestLocationDesc = allNearestLocationsDesc[nearestLocationHashForClosingLocation]; //description of the one of the nearest locations
                                    if (commonlib.hasProperty(nearestLocationDesc, "ELS") === true) { //check if exists an ELS, that is handling this nearest location
                                        var els = nearestLocationDesc.ELS; //els connection to the nearest ls
                                        if ( isELS(els) === true ) { //remove the location from the list of the locations, that are maintained by the els
                                            els.removeELSLocation(nearestLocationHashForClosingLocation); //remove the nearest location from the list of the els locations
                                            //the els will close itself if there is no locations for handling
                                        }
                                    }
                                    ils.delNearestLocationDesc[nearestLocationHashForClosingLocation]; //delete the description of this nearest location
                                }
                            }
                        }
                    }
                    
                    if (flCommandFromCS !== true) { //it is necessary to inform the cs that the maintaince of the location was stopped
                        ils.sendMessageToCS(ils.ilsMessageToCS_stopLocationsHandling(locationHash, newLSID, true)); //send the message to the cs with flag, that location maintaince was stopped independently from the cs 
                    }
                    
                    ils.closeConnectionsWithAllUsersOnLocation(locationHash); //close the connections to all of the users, that are located on the closing location
                    //delete the closing location from the list of the maintained locations
                    delete ils.handledLocations[locationHash];
                    localStorage.removeItem(locationHash); //remove from the local storage
                    commonlib.deleteFromArray(ils.handledLocationsList, locationHash);
                
                }, timeIntervals.timeIntervalILSAfterStopLocationHandlingToDisconnectAll);
            }
        };

        /**
         * return true if the maintained location is nearest to the one of the locations
         * otherwise return false
         * @method isMaintainedLocationIsNearestToLocations
         * @param {} maintainedLocationHash
         * @param {} locationsHashes
         * @return Literal
         */
        ILSProto.isMaintainedLocationIsNearestToLocations = function(maintainedLocationHash, locationsHashes) {
            var ils = this;
            if (ils.isLocationHandled(maintainedLocationHash) === false) {
                return false;
            }
            var nearestLocationsToTheMaintained = ils.getNearestLocations(maintainedLocationHash); //list of all the locations, that are the nearest to the maintained
            if (nearestLocationsToTheMaintained === false) {
                return false;
            }
            if (typeof(locationsHashes) === "number" || typeof(locationsHashes) === "string") { //if the only one location
                locationsHashes = [locationsHashes];
            } else if (Array.isArray(locationsHashes) === false || locationsHashes.length === 0) {
                return false;
            }
            for (var i = 0, len = locationsHashes.length; i < len; i++) { //check all the given location if it is the nearest to the maintained
                var locationHash = locationsHashes[i]; //the checking location
                if (nearestLocationsToTheMaintained.indexOf(locationHash) !== -1) {
                    return true; //if one of the given locations is the nearest
                }
            }
            return false;
        };


        /**
         * get opened data connection with the local server by the local server ID
         * return false if it's not found
         * @method getOpenedELSByID
         * @param {} peerID
         * @return Literal
         */
        ILSProto.getOpenedELSByID = function(peerID) {
            var ils = this;
            peerID = commonlib.strToInt(peerID);
            var nearestLocationsDesc = ils.getAllNearestLocationsDesc(); //all nearet lcoations
            if (nearestLocationsDesc === false) {
                return false;
            }
            var _keys = Object.keys(nearestLocationsDesc);
            for (var i = 0, len = _keys.len; i < len; i++) {
                var nearestLocationDesc = nearestLocationsDesc[_keys[i]]; //description of the nearest location
                if (commonlib.hasProperty(nearestLocationDesc, "ELS") === true) //if ELS is exists for this location
                    var els = nearestLocationDesc.ELS;
                if (els.elsPeerID === peerID //els id is equal to the given id
                    && nearestLocationDesc.ELS.isConnected() === true) { //if ELS is open
                    return nearestLocationDesc.ELS; //return as the result
                }
            }
            return false; //not found
        };


        /**
         * get the lcoations, that are maintained by the local server with the given ID
         * return an arraywith the location hashes
         * or false if there is no locations with the lsID
         * @method getAllNearestLocationsByLSID
         * @param {} lsID
         * @return LogicalExpression
         */
        ILSProto.getAllNearestLocationsByLSID = function(lsID) {
            var ils = this;
            var nearestLocations = ils.getAllNearestLocationsDesc();
            var res = [];
            lsID = commonlib.strToInt(lsID);
            var _keys = Object.keys(nearestLocations);
            for (var i = 0, len = _keys.length; i < len; i++) {
                var nearestLocationHash = _keys[i];
                if (commonlib.hasProperty(nearestLocations[nearestLocationHash], "ELS") === true //if the location have els connection
                    && nearestLocations[nearestLocationHash].ELS.elsPeerID === lsID) { //and the id of the local server equals to the given id
                    return nearestLocations[nearestLocationHash].ELS.getELSLocations(); //get the list from the inner list of the els       
                } else if (nearestLocations[nearestLocationHash].lsID === lsID) { //or the ls id from the list of the nearest locations(that was given by the central server) is equal to the given
                    res.push(nearestLocationHash); //put the location to the list of the results
                }
            }
            return res.length > 0 && res;
        };

        /**
         * returns the list with all the valid nearest locations by metadata of the given data connection
         * retrun false if there is no valid locations
         * @method getListOfTheValidNearestLocationsByDataConnectionMetadata
         * @param {} dataConnection
         * @return Literal
         */
        ILSProto.getListOfTheValidNearestLocationsByDataConnectionMetadata = function(dataConnection) {
            if ( isDataConnection(dataConnection) === true ) {
                    
                    var ils = this;
                    var locationsFromConnection = dataConnection.metadata.g_locationHash; //get the nearest locations by the metadata of the data connection
                    if ( isArray(locationsFromConnection) === true 
                         && locationsFromConnection.length > 0 ) { //the list with the nearest locations is not empty
                        
                            var validNearestLocations = ils.getAllNearestLocationsList();
                            if ( validNearestLocations === false ) {
                                return false;    
                            }
                            
                            var validIncomingNearestLocations = []; //the formed list with the valid nearest locations, that are maintained by the data connection
                            var lsID = dataConnection.peer; //id of the local server by the incoming data connection
                            for( var i = 0, len = locationsFromConnection.length; i < len; i++ ) {
                                var nearesLocationHash = locationsFromConnection[i];
                                var validLSID = ils.getNearestLSID(nearesLocationHash);
                                if ( validNearestLocations.indexOf(nearesLocationHash) !== -1 //if the location from data connection is the valid
                                    && ( validLSID === lsID //if the local server id are equals
                                        || validLSID === false )  //or the valid id is empty
                                ) {  
                                    validIncomingNearestLocations[validIncomingNearestLocations.length] = nearesLocationHash; //put it to the resulted list
                                }
                            }
                            if ( validIncomingNearestLocations.length > 0 ) { //if the valid locations are exists
                                dataConnection.metadata.g_locationHash = validIncomingNearestLocations; //set the valid list instead of the given into the metadata of the data connection
                                return validIncomingNearestLocations;    
                            }
                            
                    }
                    
            }
            return false;    
        };
        
        /**
         * data connection from the other local server to the ils
         * @method onDataConnectionLSToLS
         * @param {} dataConnection
         * @return 
         */
        ILSProto.onDataConnectionLSToLS = function(dataConnection) {
            var ils = this;
            var res = validators.validatorILSIncomingNearestLSDataConnection(dataConnection);
            if (res === false) { //the metadata or the properties of the connection is not valid
                logger(validators.validatorILSIncomingNearestLSDataConnection.errors);
                dataConnection.close();
            } else {
                //try to find an opened connection with s ls, which have this id
                var peerID = dataConnection.peer;
                var els = ils.getOpenedELSByID(peerID); //get the ELS, that is connected, by the id
                if (els === false) { //if an opened connection with this ls was not found
                    var nearestLocations = ils.getAllNearestLocationsByLSID(peerID); //get all nearest locations hashes, that are maintained by the local server with the dataConnection ID
                    var flRequestTheValidIdFromCS = false; //flag means that it is necessary to request the valid id for the nearest locations from the list
                    if (nearestLocations === false 
                        || nearestLocations.length === 0) { //if there is no els locations for connection with this ls
                            
                            //get list of the locations from the metadata of the incoming data connection
                            nearestLocations = ils.getListOfTheValidNearestLocationsByDataConnectionMetadata(dataConnection);
                            if ( isArray(nearestLocations) === false ) { //if the nearest locations are exist for this data connection
                                dataConnection.close();
                                return;
                            }
                            
                            flRequestTheValidIdFromCS = true; //request the valid ls id from the cs
                    }
                }
                 
                ils.connectToELS(nearestLocations, dataConnection, flRequestTheValidIdFromCS); //add connection to the list and set the events handlers    
            }
        };


        /**
         * return user description object from the list of users on the maintained location by a data connection to the user
         * return false if an error
         * @method getUserDescByDataConnection
         * @param {} dataConnection
         * @return LogicalExpression
         */
        ILSProto.getUserDescByDataConnection = function(dataConnection) {
            var ils = dataConnection.g_getILS();
            if (ils === false) {
                return false;
            }
            var userLocationDesc = ils.getUserCoordsDescriptionByUserIncomingDataConnection(dataConnection);
            return userLocationDesc !== false 
                    && ils.getUserDescription(dataConnection.peer, userLocationDesc.locationHash); //description of the users, that are located on the location where the user is placed
        };


        /**
         * check is connection with a user is opened and equal to the connection from the list of the users on the mantained location
         * return false if it is not valid connection
         * flNewConnection - set to true if it is the new incoming connection
         * @method isValidUserDataConnection
         * @param {} dataConnection
         * @param {} flNewConnection
         * @return Literal
         */
        ILSProto.isValidUserDataConnection = function(dataConnection, flNewConnection) {
            
            if (isDataConnection(dataConnection) === false
                || dataConnection.open === false) {
                    ils.closeDataConnection(dataConnection);
                    return false;
            }

            var ils = this; //associated ILS instance to the dataConnection

            if (commonlib.hasProperty(dataConnection, "g_flChecked") === false) { //if the metadata of the data connection was already validated
                if (typeof(dataConnection.peer) !== "number" || commonlib.hasProperty(dataConnection, "g_getILS") === false //function for getting ILS instance if absent
                    || commonlib.hasProperty(dataConnection, "metadata") === false //connection metadata is absent or empty
                    || commonlib.isEmptyObject(dataConnection.metadata) === true
                ) {
                    ils.closeDataConnection(dataConnection);
                    return false;
                }
                if (commonlib.hasProperty(dataConnection, "g_flCheckedMetadata") === false //if the metadata has not been checked, check it
                    && validators.validatorIncomingUserConnectionMetadata(dataConnection.metadata) === false) { //not valid metadata
                        ils.closeDataConnection(dataConnection);
                        return false;
                } else {
                    dataConnection.g_flChecked = true; //flag that the connection is valid
                }
            }
            var usrDesc = ils.getUserDescByDataConnection(dataConnection); //description of the user from the list of the ils
            if ( usrDesc !== false //if the current user descripton is already exists
                 && ( dataConnection.open === false
                        || (commonlib.hasProperty(usrDesc, "dataConnection") === true 
                            && usrDesc.dataConnection !== dataConnection) 
                    )
                ) { //data connection from the description of the users on the maintained location is not equals to the given data connection) {
                    if ( usrDesc!== false ) {
                        if ( usrDesc.dataConnection.metadata.g_timestamp > dataConnection.metadata.g_timestamp ) { //if the timestamp when the data connection was created for existing connection is newer then for the incoming connection
                            ils.closeDataConnection(dataConnection);
                            return false;
                        } else { //if the current data connection is absent for the user
                            if ( isDataConnection(usrDesc.dataConnection) === true ) { //close the current data connection and replace by the incoming for the user description
                                usrDesc.dataConnection = null; //drop the current data connection into the user description
                                ils.closeDataConnection(usrDesc.dataConnection, true); //close the current main data connection
                            }
                            usrDesc.dataConnection = dataConnection; //set the incoming connection as the main data connection for the user
                            return true;    
                        }
                    } else {
                        ils.closeDataConnection(dataConnection);
                        return false;    
                    }
                    
            } else 
                if ( usrDesc !== false
                     && (
                         commonlib.hasProperty(usrDesc, "dataConnection") === false //there is no dataConnection to the user into the current description of the maintained location
                         || ( dataConnection.open === false //the connection is not open
                             && usrDesc.dataConnection === dataConnection )
                        )   
                    ) { //user connection from the list is equal to the dataConnection
                            var userLocation = ils.getUserCoordsDescriptionByUserIncomingDataConnection(dataConnection);
                            if (userLocation === false) { //user loction hash is absent
                                ils.closeDataConnection(dataConnection);
                                return false;
                            }
                            var usersOnTheLocation = ils.getUsersDescription(userLocation.locationHash); //hash of the location where the user is located
                            delete usersOnTheLocation[dataConnection.peer]; //delete the description of the user from the list
                            ils.closeDataConnection(dataConnection);
                            return false;
                    }
            else 
                if ( flNewConnection !== true //if it is not new data connection
                    && usrDesc === false ) { //and the description for the user by this connection is absent
                        ils.closeDataConnection(dataConnection);
                        return false;        
                }
            return true;
        };


        /**
         * get location, that is maintained by the ils, by user data connection
         * return false if there is no valid user location description
         * return { locationHash, lat, lng }
         * if flCleanUnnecessary = true, delete unnecessary data from the connection metadata
         * @method getUserCoordsDescriptionByUserIncomingDataConnection
         * @param {} dataConnection
         * @return LogicalExpression
         */
        ILSProto.getUserCoordsDescriptionByUserIncomingDataConnection = function(dataConnection, flCleanUnnecessary) {
            var ils = this;
            var res = false; //the default value is false
            if (commonlib.hasProperty(dataConnection, "metadata") === false) { //there is no metadata
                return false;
            }
            var connMetadata = dataConnection.metadata;
            var userLocationHash = connMetadata.g_locationHash = connMetadata.g_locationHash.trim(); //hash of the location, on which the user is located
            if ( ils.isLocationHandled(userLocationHash) !== false ) { //if the user location is not maintained by the ils
                res = {
                    description : connMetadata.g_description,
                    locationHash: userLocationHash,
                    lat: connMetadata.g_lat, //latitude coordinate
                    lng: connMetadata.g_lng, //longitude coordinate
                    numOfMaintainedLocations : connMetadata.g_numOfMaintainedLocations, //number of the maintained locations
                    timestamp: connMetadata.g_timestampHashCalculation, //when the hash was calculated by the cs
                    coordsTimestamp: connMetadata.g_timestampCoords //when the coordinates were formed by the client
                };
                
                if ( flCleanUnnecessary === true ) {
                    delete connMetadata.g_description; //delete descripton string, because it is unnecessary information   
                }
            }
            
            return res;
        };


        /**
         * if necessary for monitoring to the user, to check if he is cheating
         * @method monitorUser
         * @param {} userID
         * @return 
         */
        ILSProto.monitorUser = function(userID) {};


        /**
         * incoming data connection from the peer on the maintained by the ils location
         * @method onDataConnectionPeerToLS
         * @param {} dataConnection
         * @return 
         */
        ILSProto.onDataConnectionPeerToLS = function(dataConnection) {
            var ils = this;
            if (dataConnection.open !== true 
                || validators.validatorIncomingUserConnectionMetadata(dataConnection.metadata) === false) {
                    logger(validators.validatorIncomingUserConnectionMetadata.errors);
                    ils.closeDataConnection(dataConnection);
                    return false;
            } else { //set the flag that the metadata of this connection is valid
                dataConnection.g_flCheckedMetadata = true;
            }
            var userID = dataConnection.peer;
            var usrLocationDesc = ils.getUserCoordsDescriptionByUserIncomingDataConnection(dataConnection);
            if (isEmptyLSID(userID) === true
                || usrLocationDesc === false ) {
                    dataConnection.close();
                    return;
            }
            var userLocationHash = usrLocationDesc.locationHash;
            var resUsr = ils.isUserOnTheMaintainedLocation(userID, userLocationHash); //try to find a user with this ID into the list of an incoming users and the list of a users, that are located on the location
            if (resUsr === false) {
                //user is not into the list of incoming users or on the location
                //it is fishily
                ils.monitorUser(userID); //we will monitor the user
            }
            ils.addReferenceToILSForDataConnection(dataConnection); // add the reference to the ils for the data connection
            if (ils.addUserOnLocation(dataConnection) !== true) { //add user on the location
                ils.closeDataConnection(dataConnection); //if something wrong, delete the user from the location and close this connection
            } else { //if the user was placed on the location
                logger("!!!Add the peer " + userID + " on the location hash = " + userLocationHash);
                ils.addUserDataConnectionEventListeners(dataConnection); //add handlers for the dataConnection events
            }
        };


        /**
         * add event listeners for the connected peer data connection
         * @method addUserDataConnectionEventListeners
         * @param {} dataConnection
         * @return 
         */
        ILSProto.addUserDataConnectionEventListeners = function(dataConnection) {
            var ils = this;
            ils.removeUserDataConnectionEventListeners(dataConnection); //remove the previous listeners
            dataConnection.on("data", ils.onIncomingDataFromUser);
            dataConnection.once("close", ils.onUserConnectionClose);
        };


        /**
         * remove event listeners for the connected peer data connection
         * @method removeUserDataConnectionEventListeners
         * @param {} dataConnection
         * @return 
         */
        ILSProto.removeUserDataConnectionEventListeners = function(dataConnection) {
            var ils = this;
            if (isDataConnection(dataConnection) === true) {
                dataConnection.removeListener("data", ils.onIncomingDataFromUser);
                dataConnection.removeListener("close", ils.onUserConnectionClose);
            }
        };


        /**
         * on connection with the user closed
         * @method onUserConnectionClose
         * @return 
         */
        ILSProto.onUserConnectionClose = function() {
            var dataConnection = this;
            if (dataConnection.g_getILS) {
                var ils = dataConnection.g_getILS();
                if (ils !== false) { //there is no ILS that is associated with the connection
                    ils.closeDataConnection(dataConnection); //if the data connection is not valid it will be closed
                }
            } else {
                dataConnection.removeAllListeners();
            }
        };


        /**
         * add a reference to the ils instance for data connection with the user
         * @method addReferenceToILSForDataConnection
         * @param {} dataConnection
         * @return 
         */
        ILSProto.addReferenceToILSForDataConnection = function(dataConnection) {
            var ils = this;
            dataConnection.g_innerLocalServer = ils;
            dataConnection.g_getILS = ils.getILSByDataConnection; // function for getting ils by the data connection
        };


        /**
         * get ils instance by the data connection
         * if dataConnection is empty, then use this
         * @method getILSByDataConnection
         * @param {} dataConnection
         * @return LogicalExpression
         */
        ILSProto.getILSByDataConnection = function(dataConnection) {
            if (dataConnection == null) { //if the dataConnection is not given thru the arguments
                dataConnection = this; //then this function is called as the method of the instance of the DataConnection  
            }
            return commonlib.hasProperty(dataConnection, "g_innerLocalServer") === true 
                    && isILS(dataConnection.g_innerLocalServer) === true
                    && dataConnection.g_innerLocalServer;
        };


        /**
         * incoming data connection to the ils
         * g_locationHash - location, that is maintained by the ils
         * g_ilsHandledLocation - loaction, that is maintained by the local server, that created this connection
         * @method onDataConnection
         * @param {} dataConnection
         * @return 
         */
        ILSProto.onDataConnection = function(dataConnection) {
            var ils = this;
            
            //!DEBUG
            if ( ils.debugProperties.flNotAllowAnyConnections === true ) { //if flag that do not allow any incoming data connections
                dataConnection.close();
                return;    
            }
            
            if (ils.g_flClosedManually === true //ils closed
                || dataConnection.open === false 
                || commonlib.hasProperty(dataConnection, "peer") === false 
                || commonlib.hasProperty(dataConnection, "metadata") === false 
                || commonlib.hasProperty(dataConnection.metadata, "g_connType") === false) {
                    ils.closeDataConnection(dataConnection);
                    return;
            }

            var connType = dataConnection.metadata.g_connType; //type of this data connection
            switch (connType) {
                case "LSToLS": //connection from the othrer local server
                    ils.onDataConnectionLSToLS(dataConnection);
                    break;
                case "ELS":
                    ils.onDataConnectionPeerToLS(dataConnection);
                    break;
                default: //an unknown type of the incoming data connection
                    ils.closeDataConnection(dataConnection);
            }
        };

        InnerLocalServer.prototype = ILSProto;

        module.exports = {
            ILS: InnerLocalServer
        };