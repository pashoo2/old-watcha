/*global L*/
/*global $*/
/*global FB*/
/*global GumWrapper*/

/*
    special html tags:
    1) data-ui-userproperty="propertyName" - field for the user property with the name = propertyName
    1) data-onstage - show introjs tooltips and hints on this stages
*/

/*
    fuctions for working with the user interface
    mainMap - instance of Map Leaflet.js
*/

var EventEmitter = require("eventemitter");
var commonlib = require("commonlib");
var MainMap = require("MainMap");

var logger = require("logger").logger;
    logger.namespace = "interface";

/*
    show the correspondance between a page name and it's DOM id
    { page name : DOM ID }
*/
var correspondencePageNameDOMId = {
    "loading"     : "page_onLoading",
    "main"        : "page_main",
    "listusers"   : "page_users",
    "aboutuser"   : "page_about",
    "lookingtags" : "page_lookingtags"
};

/*
    settings with the correspondence : value name - field DOM id
*/
var correspondenceValueNameDOMId = {
    "latitude": "lt", //the current lattitude 
    "longitude": "ln", //the current longitude
    "locationhash": "lh", //the current location hash
    "localserverid": "ls", //id of the local server for the current loation hash
    "connectedtolocalserverid": "cls" //id of the local server to which the user is connected
};

var storage = { //settings for the storage
        keyNameListAvailableTagsForUser : "_listAvailableTagsForUser",
        keyNameListChosenTagsUser   : "_listAvailableTagsForUser"
    };

/**
 * Description
 * @method UserInterface
 * @return 
 */
function UserInterface() {

    var _self = this;
    //bind the current object to hte methods
    _self.onUserPropertyChanged     = this.onUserPropertyChanged.bind(this);
    _self.setFlags(); //set the flags
    _self.setScreenSettings(); //screen settings
    _self.setInterfaceLanguage();
    
    //bind the context
    this.chatButton = this.chatButton.bind(this);
    
}

/*
    events:
    removeUser(userID) - remove the user from the interface
    showUser(nUser) - show the neighbor user nuser instanceof NeighborUser
*/
var UserInterfaceProto = Object.create(new EventEmitter());

UserInterfaceProto.settings = {
    correspondencePageNameDOMId  : correspondencePageNameDOMId,
    correspondenceValueNameDOMId : correspondenceValueNameDOMId,
    storage : storage
};

UserInterfaceProto.setInterfaceLanguage = function() {
    var userLanguage = commonlib.getBrowserLanguage();
    if ( userLanguage == null ) {
        userLanguage = "en"; //use English as the default language    
    }
    
    this.userLanguage = userLanguage; //set the language as the property
};

UserInterfaceProto.getInterfacePlugins = function() {
    const ip = this.interfacePlugins;
    if ( ip == null ) {
        return this.interfacePlugins = window.interfacePlugins; //plugins to work with the interface;    
    } else {
        return ip;    
    }
};

UserInterfaceProto.getIntegrationPlugins = function() {
    const ip = this.integrationPlugins;
    if ( ip == null ) {
        return this.integrationPlugins = window._integrationPlugins; //plugins to work with the interface;    
    } else {
        return ip;    
    }
};

/*
    set screen settings cache
*/
UserInterfaceProto.setScreenSettings = function(){
    var uiDoc = $(window.document);
    this.screen = {
        width  : uiDoc.width(),
        height : uiDoc.height()    
    };    
};

/**
 * sert listeners for events fired by elements on the page
 * page = jquery ui or id
 * @method setListenersForPageElements
 * @param {} page
 * @return 
 */
UserInterfaceProto.setListenersForPageElements = function(page) {
    $(page)
        .find('[data-ui-userproperty]') //set listeners for elements, that represents the user properties
        .on('change', this.onUserPropertyChanged);  
};

/*
    return the page id by it's name or false
*/
UserInterfaceProto.getPageIDByName = function(pageName) {
    if ( typeof(pageName) === "string" ) {
        var _pageName = pageName.trim().toLowerCase();
        var pageID  = this.settings.correspondencePageNameDOMId[_pageName];
        if ( typeof(pageID) === "string" ) {
            return pageID;
        }
    }
    
    return false;
};

/*
    on page created in the DOM
*/
UserInterfaceProto.onPageLoadedDynamically = function(page) {
   this.setListenersForPageElements(page); 
};

/**
 * page changing from the current to the target by it's name and option correspondencePageNameDOMId
 * @method showPage
 * @param {} pageName
 * @return 
 */
UserInterfaceProto.showPage = function(pageName, cb) {
    var userInterface = this;
    var pageID  = this.getPageIDByName(pageName);
    var flCallback = typeof(cb) !== "function";
    if ( pageID === false ) {
        pageID = pageName.startsWith("#") === true ? pageName : ( "#" + pageName );    
    }
    var ip = this.getInterfacePlugins();
    var ipPages = ip.pages;
    
    if ( flCallback !== true ) { //if callback is not defined, set as a cb the promise standard function
        cb = function(res, rej) {
            res();    
        };    
    }
    
    var uiPage = ip.main.getUIElement(pageID);
    if ( uiPage == null
        || uiPage.length === 0 ) {
            ipPages.loadDynamicPage(pageID, function(){ userInterface.showPage(pageID, cb); }, true); //load the page if it is absent in the DOM   
    } else {
        ipPages.changeToTargetPage(pageID, cb);
    }
    
    if ( flCallback !== true ) { //if a callback is not defined, return Promise
        return new Promise(cb);    
    }
};
/*
---------interfacePlugins*/


/**
 * set main flags, defines perform direction    
 * @method setFlags
 * @return 
 */
UserInterfaceProto.setFlags = function(){
    var flags = this.flags = this.getInterfacePlugins().flags; //set the flags for the interface plugins module and this object
    flags.allowPagesSwiping = false;
};

/**
 * show the given value in the corresponding field into the user interface
 * @method showValue
 * @param {} name
 * @param {} value
 * @return 
 */
UserInterfaceProto.showValue = function(name, value) {
    var valueName = name.trim().toLowerCase();
    var fieldID   = this.settings.correspondenceValueNameDOMId[valueName];
    var ip = this.getInterfacePlugins();
    
    if ( fieldID == null ) { //if the global id for the property is not defined
        var currentPage = this.getActivePage(); //show it on the current page
        ip.main.showValue(currentPage.find('[data-ui-userproperty="' + valueName + '"]'), value);
    } else { //shw global user property
        if ( value != null ) { //if the value is given
            ip.main.showValue(fieldID, value);
        } else { //if necessary to get it from the storage
            window.user.getDataValue(
                name, 
                function(value) {
                    ip.main.showValue(fieldID, value);    
                }
            );    
        }
    }
};

/*
    get the jq ui equals to the current page
*/
UserInterfaceProto.getActivePage = function() {
    var ip = this.getInterfacePlugins();
    var generalPagesContainer = this.generalPagesContainer;
    if ( generalPagesContainer == null ) {
        generalPagesContainer = this.generalPagesContainer = $(ip.options.generalPagesContainerSelector);
    }
    return generalPagesContainer.pagecontainer( "getActivePage" );
};

/*
    emit the event on the active page
*/
UserInterfaceProto.fireOnActivePage = function(){
    this.getInterfacePlugins().fireOnPage(this.getActivePage(), arguments) 
};

/**
 * show the given value in the corresponding field into the user interface
 * @method getValue
 * @param {} name
 * @param {} value
 * @return 
 */
UserInterfaceProto.getValue = function(name, value) {
    var ip = this.getInterfacePlugins();
    
    var valueName = name.trim().toLowerCase();
    var currentPage = this.getActivePage();
    var field       = currentPage.find('[data-ui-userproperty="' + valueName + '"]');
    ip.main.getValue(field, value);
};

/**
 * must be called when the user has been connected to the cs
 * @method onUserConnected
 * @return 
 */
UserInterfaceProto.onUserConnected = function(flNewcomer) {
    this.mainMap = new MainMap(L); //create the main map object, and get it Leaflet.js object and MapQuest object for Leaflet.js
    this.setListenersForUserEvents(); //set the listeners for the events from the user
    this.flags.allowPagesSwiping = false; //set the flag to allow swipe a pages for the user
    
    this.showPage("main"); //change the current page to the main
    this.getIntegrationPlugins().getPlugin("swipingMenu").show();
    
    if ( flNewcomer === true ) {
        this.startTour();
    }
    
};

/*
    on page sucessfully loaded on the user main screen
*/
UserInterfaceProto.onPageShown = window.interfacePlugins.main.onPageShown;

/**
 * on value changed in the interface field with the user property
 * @method onUserPropertyChanged
 * @param {} e
 * @return 
 */
UserInterfaceProto.onUserPropertyChanged = function(e) {
    var _uiTextInput = $(e.target);
    var propertyName = _uiTextInput.attr("data-ui-userproperty"); 
    var val = _uiTextInput.val();
    if ( typeof(propertyName) !== "string" ) { //try get the parent element
        _uiTextInput = _uiTextInput.closest("[data-ui-userproperty]");
        propertyName = _uiTextInput.attr("data-ui-userproperty");
    }
    if ( typeof(propertyName) === "string" ) {
        window.user.saveDataValue(propertyName.trim().toLowerCase(), val); //save the value
    }
    
};

/*
    load JSON file with available tags for the user
*/
UserInterfaceProto.loadAvailTags = function loadAvailTags(callbackOnLoad) {
    
    var localforage = window.localforage;
    var logger = window.logger;
    var _key = this.settings.storage.keyNameListAvailableTagsForUser; 
    if (localforage === undefined) {
        logger(new Error("The local forage is unavailable"));
    }
    else {
        localforage.getItem(_key, //try to read the list from the storage 
            function (err, res) {
                if (err != null
                    || res == null) { //if the list is empty
                        $.ajax({ //load it dynamically
                            url: "./src/availTags.json",
                            dataType: "text",
                            error: function (jqXHR, textStatus, err) { //if an error
                                logger("!!!Can't load the tags list");
                                logger(err);
                            }
                        })
                        .done(function (data) {
                            if (typeof (data) === "string" && data.trim().length > 0) {

                                var successCallback;

                                if (typeof (callbackOnLoad) === "function") { //if callback is defined
                                    successCallback =
                                        function (err) {
                                            if ( !(err instanceof Error) ) {
                                                JSON.parseAsync(data, callbackOnLoad);    
                                            } else {
                                                logger("!!!Can't load the tags list");
                                                logger(err);
                                                callbackOnLoad(err);    
                                            }
                                        };
                                }
                                else { //if not defined
                                    successCallback = undefined;
                                }

                                localforage.setItem(_key, data,
                                    successCallback
                                );
                            }
                            else {
                                logger("!!!Can't load the tags list");
                                if (typeof (callbackOnLoad) === "function") {
                                    callbackOnLoad();
                                }
                            }
                        });
                }
                else {
                    if (typeof (callbackOnLoad) === "function") { //if callback is defined
                        if (typeof (res) === "string") { //if necessary to parse
                            JSON.parseAsync(res, callbackOnLoad);
                        } else { // if already an object
                            callbackOnLoad(res);
                        }
                    }
                }

            }
        );
    }
};

/*
    befor the panel myTags will be opened
*/
UserInterfaceProto.loadMyTagsLookingTags = function loadMyTagsLookingTags(flLookingTags, listviewTarget, listviewAvailableTags) {
    var _interface = this;
    var user = window.user;
    var interfacePlugins = this.getInterfacePlugins();
    var listsMethods = interfacePlugins.listviews;
    if ( typeof(user) === "object" ) {
        user.getTags( flLookingTags === true, //load tags
            function (tagsUser) { //tags, chosen by the user
                _interface.loadAvailTags(function(tags) { //get tags, available for users
                    if ( typeof(tags) === "object"
                         && tags != null
                         && !(tags instanceof Error) ) {
                            
                            var i, len;
                             
                            if ( Array.isArray(tagsUser) === true
                                && tagsUser.length > 0 ) {
                                    
                                    var tagsUserDesc = {}; //{tagName : image}
                                    
                                    //filter the available tags by tags, choosed by the user
                                    for( i =0, len = tagsUser.length; i < len; i++ ) {
                                        var tagName = tagsUser[i]; //name of the chosen tag
                                        var imageForTag = tags[tagName]; //image for the chosen tag
                                    
                                        if ( typeof(imageForTag) === "string" ) { //if this tag is already into the list of the chosen tags
                                            tagsUserDesc[tagName] = imageForTag; //set the image for the chosen tag
                                            delete tags[tagsUser[i]]; 
                                        }   
                                    }
                                    
                                    listsMethods.clearListview(listviewTarget, false, true); //clean the listview without updating it
                                    listsMethods.appendListToListview(listviewTarget, tagsUserDesc);
                            } else { //if the chosen tags are absent
                                listsMethods.clearListview(listviewTarget, true, true); //clean the listview with updating it 
                            }
                            
                            if ( tags != null ) { //if have an elements to add them into the list
                                listsMethods.clearListview(listviewAvailableTags, false, true); //clean and do not update
                                listsMethods.appendListToListview(listviewAvailableTags, tags);            
                            } else { //the list  must be empty
                                listsMethods.clearListview(listviewAvailableTags, true, true); //update the listview   
                            }
                    }
                });
            }
        );    
    } else {
        window.logger("!!!Can't read the chosen tags because the global variable User is not defined");    
    }
            
};

/*
    save looking tags from the given listview(listviewTarget)
*/
UserInterfaceProto.saveLookingTags = function(flLookingTags, listviewTarget) {
    var user = window.user; //user global
    if ( typeof(user) === "object" ) { //save the list with chosen tags
        user.saveTags( 
            flLookingTags === true, 
            this.getInterfacePlugins().listviews.getListviewItems(listviewTarget, true) //get the chosen items and expect the disabled elements
        );
    }  
};

/*
    set listeners for the user events
*/
UserInterfaceProto.setListenersForUserEvents = function() {
    var user = window.user;
    user.on("neighborusergone", this.onNeighborUserGone.bind(this)); //necessary to remove a neighbor user from the interface
    user.on("neighboruser", this.onNeighborUser.bind(this)); //necessary to add a neighbor user to the interface
    user.on("neighborusercard", this.onNeighborUserShowCard.bind(this)); //necessary to remove a neighbor user from the interface
    user.on("neighboruserconnectionstatechanged", this.onConnectionWithNUStateChange.bind(this)); //messaging connection state changed
};

/*
  show the popup with the neighbor user description  
*/
UserInterfaceProto.onNeighborUserShowCard = function(nUser) {
    var htmlRepresentation = nUser.showDesc(true); //html without a chat button
    $.prompt(
        htmlRepresentation,
        {
        	buttons: { 
        	    "Chat" : nUser.id,
        	    "Close" : false
        	},
        	focus: 1,
        	submit: this.chatButton
        }
    );
    $(".jqistates").enhanceWithin();
    
};

UserInterfaceProto.chatButton = function(e,v,m,f){
    if ( typeof(v) === "number" ) { //if "chat"
        this.chatWith(v);
    }
};

/*
    necessary to show a neighbor user in the interface
    nUser - instanceof NeighborUser
*/
UserInterfaceProto.onNeighborUser = function(nUser) {
    this.emit("showUser", nUser);
};

/*
    necessary to remove neighbor user from the interface
*/
UserInterfaceProto.onNeighborUserGone = function(userID) {
    this.closeChatWith(userID);
    this.emit("removeUser", userID);
};

/*
    if the state of a messaging connection with a neighbor user has changed 
    flDisabled = true, if connection was closed
*/
UserInterfaceProto.onConnectionWithNUStateChange = function(nUserID, newState, flDisabled) {
    const chatbox = window.chatbox;
    if ( flDisabled === true ) { //if connection has closed, loch the send button
        chatbox.lockSendButton(nUserID,  typeof(newState) === "string" ? newState : "Connection was closed"); //disable Send button while connection with the neighbor user not started    
    } else 
        if (newState === "open") { //if a connection has been opened
            chatbox.unlockSendButton(nUserID); //unlock the Send button in Chatbox
        } else 
            if ( typeof(newState) === "string" ) { //if it is only necessary to show the current connection state
                chatbox.setStateText(nUserID, newState); //disable Send button while connection with the neighbor user not started    
            }
};

/*
    highlight an interface fields that are containing the user properties
    reason - reason why the effect is necessary
    flStopPrev - if true, then stop the effect for all nodes which are currently highlighted
*/
UserInterfaceProto.highlightUserProperties = function(props, reason, flStopPrev) {
    const UI = this;
    
    if ( Array.isArray(props) === true
        && props.length > 0 ) {
            const len = props.length;
            var resSelector = '';
            for ( var i = 0; i < len; i++ ) {
                var propName = props[i];
                if ( typeof( propName ) === "string" ) {
                    resSelector = resSelector + '[data-ui-userproperty="' + propName.trim().toLowerCase() + '"],';
                }
            }
            
            if ( resSelector.endsWith(",") === true ) { //remove the "," at the end of the selector string
                resSelector = resSelector.substr(0, resSelector.length-1);    
            }
            
            this.getInterfacePlugins().interface.highlightUI($(resSelector), typeof(reason) === "string" ? reason : "default", "default", flStopPrev); //highlight the given ui elements, reason - as a name of the effect 
    } else if ( props == null ) {
        this.getInterfacePlugins().interface.highlightUI(null, typeof(reason) === "string" ? reason : "default", "default", flStopPrev); //highlight the given ui elements, reason - as a name of the effect 
    }    
};

/*
    open chat page with the user
*/
UserInterfaceProto.chatWith = function(nUserID){
    
    this.setListenersForChatbox();
    const user = window.user;
    const chatbox = window.chatbox;
    
    user
        .loadMessagesHistoryWithNeighborUser(nUserID)
        .then(function(res){
            if ( Array.isArray(res) === true ) { //if the messages history was loaded successfully
                chatbox.showMessages(res, nUserID); 
            } else { //if an error, then show the empty list
                chatbox.showMessages([], nUserID);    
            }
            
            chatbox.lockSendButton(nUserID, "Connecting..."); //disable Send button while connection with the neighbor user not started
            
            user
                .connectWith(nUserID) //connect to the neighbor user
                .then(function(res){
                    debugger;
                    if ( res instanceof Error ) {
                        throw res;    
                    } else if ( res !== true ) {
                        throw new Error("An error has occurred");    
                    } else {
                        chatbox.unlockSendButton(nUserID); //enable Send button when connected to the neighbor user
                    }
                })
                .catch(function(e){
                    debugger;
                    logger(e);
                    if ( chatbox.isSendButtonLocked() === false ) { //if not already locked
                        chatbox.lockSendButton(nUserID, "The user locks your request for messaging or other error has occurred"); //disable Send button because of not connected    
                    }
                });
            
        });    
};

/*
    show the videostream provided by the neighbor user
*/
UserInterfaceProto.showVideoStream = function(nUserID){
    window.user.showNeighborUserVideoStream(nUserID);
};

/*
    close chatbox with the user and clear the messages list
*/
UserInterfaceProto.closeChatWith = function(nUserID){
    window.chatbox.close(nUserID);   
};

/*
    show messagge in the chatbox
*/
UserInterfaceProto.showChatMessage = function(userID, message){
    var _message;
    if ( message instanceof Error ) {
        _message = message;
    } else {    
        _message = ( typeof(message) === "string" ) ? commonlib.getMessageDescriptionObj(userID, message) : message; 
    }
    
    this.setListenersForChatbox();
    window.chatbox.showMessage( _message, userID);
    
};

/*
    interface signals that user wants to send a message
*/
UserInterfaceProto.onSendMessage = function(userID, message){
    window.user.sendTo(userID, message);
};

/*
    set listeners for chat events    
*/
UserInterfaceProto.setListenersForChatbox = function() {
    if ( this.flListenersWasSet !== true ) { //if the listeners were not set before
        this.flListenersWasSet = true;
        window.chatbox.on("send", this.onSendMessage); //send message to the neighbor user
    }
};

/*
    show the state of the connection to the central server
*/
UserInterfaceProto.showConnectionState = function(state) {
    $("#ConnectionState").text(state + "...");
};

/*
    show the login dialog
*/
UserInterfaceProto.chooseLogInService = function(){
    return new Promise(
        function(res, rej) {
            $.prompt("Choose service to login: ", 
                {
                	title: "You are necessary to auth this app through one of the services to continue",
                	buttons: { "Facebook" : 'facebook', "Windows Live!" : 'windows', "Google Plus": "google", "Close" : false },
                	submit: 
                    	function(e,v,m,f){
                            if ( typeof(v) === 'string' ) { //if login was chosen
                                res(v); //login through the chosen service
                            } else { //denied
                                rej(new Error('User cancelled login or did not fully authorize.'));
                            }	
                        }
                }
            );
        }
    );
};

/*
    show an error message for the user
*/
UserInterfaceProto.showError = function(message){
    var msg = "";
    if ( typeof(message) === "string" ) {
        msg = message;
    } else
        if ( ( message instanceof Error ) === true ) {
            msg = message.message;    
        }
        
    if ( msg.length > 0 ) { //if the message is not empty
        $.prompt(msg, {title: "Error!",buttons: { "Ok" : true }}); //show popup with the message  
    }
};

/*
    show social profiles with links on the screen
*/
UserInterfaceProto.showSocialProfiles = function(ui, socialProfiles) {
   $.prototype.showSocialProfiles(socialProfiles); 
};

UserInterfaceProto.videoTranslation = {
    
    setListenersOnStopVideoStreming : function() {
        
        var videoTranslation = window.interface.videoTranslation;
        var currentStream = videoTranslation.getActiveVideoStream();
    	if ( currentStream !== false ) { //stop the current videostream
            function onMediaStreamClose(){
                var timeoutToClose = setTimeout(
                    function(){
                        currentStream.removeEventListener("active", onStreamRestore);
                        currentStream.removeEventListener("inactive", onMediaStreamClose);
                        currentStream.removeEventListener("removetrack", onMediaStreamClose);
                        videoTranslation.stopVideo();
                    }
                    ,10000); //waiting for 5 seconds and close the connection
                                        
                    function onStreamRestore(){ //if the stream restore
                        clearInterval(timeoutToClose); //do not close the connection   
                    }
                                
                    currentStream.addEventListener("active", onStreamRestore);
            }
            
            console.log("currentStream");                      
            console.trace();
            
            //set listeners for close events
            currentStream.addEventListener("inactive", onMediaStreamClose);
            currentStream.addEventListener("removetrack", onMediaStreamClose);
    	}
    },
    
    stopVideo : function() {
        var videoTranslation = window.interface.videoTranslation;
        var currentStream = videoTranslation.getActiveVideoStream();
    	if ( currentStream !== false ) { //stop the current videostream
    	    commonlib.closeMediaStream(currentStream);
    		videoTranslation.currentStream = null;  //clear the current stream   
    	}
    		                
    	var currentTranslationHash = videoTranslation.currentTranslationHash; 
    	if ( typeof(currentTranslationHash) === "string" ) { //if the hash of the current video stream is not empty
            window.interface.emit("stopVideoTranslation", videoTranslation.currentTranslationHash ); //emit the event that the user stop translation
        	videoTranslation.currentTranslationHash = null;
    	}  
    	
    	$("#videoTranslationBox").attr("src", "").empty().remove();
    	$.prompt.close();
    	$('[name="jqi_state0_buttonClose"]').click();
    	$('.jqibox').remove();
    	videoTranslation.videoTranslationBox = null;
    	
    },
    
    /*
        return text with the description of the video stream
    */
    getBroadcastDescription : function() {
        return $("#videoTranslationBox_broadcastDescription").val();    
    },
    
    /*
        show the popup with the video from the camera,
        stream - watching stream,
        state - show this string in the popup
        description - description of the video
    */
    showCameraPopup : function(stream, state, description) {
        
        var UI = window.interface;
        
        var width  = UI.screen.width / 2,
            height = UI.screen.height / 2;
        
        /*
            set the current videostream
        */
        var videoTranslation = UI.videoTranslation;
        if ( videoTranslation.currentStream != null ) {
            videoTranslation.stopVideo();
        }
        
        videoTranslation.currentTranslationHash = null;
        videoTranslation.currentStream = stream; //set the new stream
        
        if ( videoTranslation.videoTranslationBox != null ) {
            $(videoTranslation.videoTranslationBox).remove();   
        }
        
        var flInnerBroadcast = videoTranslation.flInnerBroadcast = ( stream == null && typeof(state) !== "string" ); //if this is the video stream provided by this user camera
        
        //html for video box
        var htmlCode = '<video id="videoTranslationBox" style="marign:0px; border:0px; overflow: hidden; max-width:'+width+'px; max-height:'+height+'px;"></video>\
                <p><label for="videoTranslationBox_broadcastDescription">Description:</label></p>\
                <p><textarea';
        htmlCode += ( ( flInnerBroadcast !== true ) ? 'disabled="disabled" class="disabled"' : '' );
        htmlCode += ' id="videoTranslationBox_broadcastDescription" style="width:100%"> ';
        htmlCode += ( ( flInnerBroadcast === true ) ? 'Type your video broadcasting description on here...' : ( typeof(description) === "string" ? commonlib.clearBannedWords(description) : "" ) );
        htmlCode += '</textarea></p>';
        htmlCode += '<label id="videoTranslationBox_currentState"> State: ' + ( typeof(state) !== "string" ? "" : state ) + '</label>';
        
        debugger;
        videoTranslation.videoTranslationBox = $.prompt(
            htmlCode,
            {
            	buttons: flInnerBroadcast === true ? { "Start broadcasting" : true, "Close" : false } : { "Close" : false },
            	focus: 1,
            	submit:
            	    function(e,v,m,f) {
    		            if ( v === true ) { //start video streaming

        		            if ( videoTranslation.currentStream == null ) { //if we start the camera
        		                var gum = new GumWrapper({video: 'videoTranslationBox'});
        		                gum.play(
        		                    function(stream) {
        		                      if ( ( stream instanceof Error ) === false ) { //if can to get the camera screen
        		                        
        		                        if ( window.videostreams == null ) {
        		                            window.videostreams = [];
        		                        }
        		                        window.videostreams[window.videostreams.length] = stream;
        		                        
        		                        videoTranslation.currentStream = stream;
        		                        videoTranslation.currentTranslationHash = commonlib.generateHash(8); //set the unique hash for the string        
        		                        videoTranslation.setListenersOnStopVideoStreming(); //if the video translation will be stopped
        		                      }
        		                    }
        		                );
        		                       		                
        		            }
        		            e.preventDefault();
    		            } else { //close the video broadcast
    		                videoTranslation.stopVideo();
    		            }
            	    },
            	persistent : false
            }
        );
        
        //if a MediaStream was given
        if ( stream instanceof MediaStream ) {
            videoTranslation.showVideoStream(stream);
        }
        
    },
    
    /*
        check if the hash of the current translation is equals to the given hash
    */
    isActiveTranslation : function(hash) {
        var videoTranslation = window.interface.videoTranslation;
        return videoTranslation.currentTranslationHash === hash;
    },
    
    /*
        return the active videostream or false if not exists
    */
    getActiveVideoStream : function() {
        var videoTranslation = window.interface.videoTranslation;
        var currentStream = videoTranslation.currentStream;
        if ( videoTranslation.currentStream != null
            && currentStream.active === true) { //if in active state
                return videoTranslation.currentStream; //stop the current stream
        } else {
            return false;    
        }
    },
    
    /*
        return the hash string of the currently watching video stream
    */
    getCurrentStreamHash : function() {
        var videoTranslation = window.interface.videoTranslation;
        if ( videoTranslation.getActiveVideoStream() !== false
            && typeof(videoTranslation.currentTranslationHash) === "string"
            && videoTranslation.currentTranslationHash.length > 0) {
                return videoTranslation.currentTranslationHash;
        } else {
            return false;    
        }
    },
    
    /*
        show the connection state for the broadcast
    */
    showVideoConnectionState : function(msg) {
        
        var videoTranslation = window.interface.videoTranslation;
        var videoTranslationBox = videoTranslation.videoTranslationBox;
        
        if ( videoTranslationBox != null ) {
            var stateString = (typeof(msg) === "string" && msg.length > 0) ? ("State: " + msg) : ""; //state to show for the user
            videoTranslationBox.find("#videoTranslationBox_currentState").text(stateString);
        }
        
    },
    
    showVideoStream : function(stream) {
        
        var videoTranslation = window.interface.videoTranslation;
        
        if ( stream instanceof MediaStream ) { //ifa strem is given
            videoTranslation.currentStream = stream;
            var video = document.getElementById( "videoTranslationBox");
            if (video.mozSrcObject !== undefined) {
                video.mozSrcObject = stream;
            } else {
                video.src = (window.URL && window.URL.createObjectURL(stream)) || stream;
            }
            video.play(); 
        }
    }
    
};

/*
    show the hints and intro for the user on the page
    page - page ID(current by default)
    stage - stage number (1 by default)
*/
UserInterfaceProto.startTour = function(){
    const pageName = this.getInterfacePlugins().pages.getCurrentPageName();
    this.getIntegrationPlugins().getPlugin("guidesteps").startTour( typeof(pageName) !== "string" ? "map" : pageName , this.userLanguage);
};

UserInterface.prototype = UserInterfaceProto;


module.exports = {
    UserInterface : UserInterface
};