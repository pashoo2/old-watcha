/*global localforage*/
/*global localStorage*/
/*global $*/
//Event Emitter
//creates and handles the conection with the appWorker ( that handles MainP2P, ELS, ILS), and start the appWorker in another thread

//required modules
var EventEmitter = require("eventemitter");
var getCurrentTimestamp = require("timestamps").getCurrentTimestamp;
var CommandsListener = require("CommandsListener").CommandsListener; //listen commands from the appWorker
var DataConnector = require("DataConnector").DataConnector; //for using Peer.js in a thread(with worker)

//settings
var settingsGlobal = require("globalSettings"); //global settings for the app
var settingsModule = settingsGlobal.settingsConnectorWithAppWorker; //settings exclusevly for this module
var settingsConnectors = settingsGlobal.settingsConnectors; //settings that must be the same for both connectors
var pathToAppWorker = settingsGlobal.path.appWorker; //path to appWorker.js

//object for start and control the connection with the app worker(gClient)
//emit an events, if the messages received from gClient
//user - the main object for interaction with the user
//listHandlersCommandsForUserFromMainP2P = { "commandFromAppWorker" : "handlerNameMethodUser" } - define a handlers = methods of the instance of the User for a commands from the appWorker. When the command "commandFromAppWorker" will come, than the method of the user will be called - user["handlerNameMethodUser"]
/**
 * Description
 * @method ConnectorAppWorker
 * @param {} user
 * @param {} listHandlersCommandsForUserFromMainP2P
 * @return 
 */
function ConnectorAppWorker(user, listHandlersCommandsForUserFromMainP2P) {

    if( window.Worker === undefined ) {
        throw new Error("Workers does not supported by your browser");
    }
    
    var appWorker = new Worker(pathToAppWorker); //create the appWorker thread;
    this.appWorker = appWorker;
    
    this.listHandlersCommandsForUserFromMainP2P = listHandlersCommandsForUserFromMainP2P;
    this.setHandlersCommandsUserMethods(listHandlersCommandsForUserFromMainP2P); //set a methods of the user as handlers for a incoming commands from the appWorker
    
    //create listener of the commands from the appWorker
    this.commandsPrefix = settingsConnectors.prefixCommandsListener; //get the prefix for a commands from the module settings
    var commandsListener = new CommandsListener(this, appWorker, this.listCommandsHandlers, this.commandsPrefix); //create the object of the listener
    this.commandsListener   = commandsListener;
    this.sendCommand        = commandsListener.sendCommand; //send commands throug this.appWorker and to the appWorker thread
    
    this.dataConnector = null;
    
    //set listener for events from the appWorker
    // if ( appWorker.addEventListener ) { //if it has addEventListener method
    //     appWorker.addEventListener("error",   this.onAppWorkerError);
    // } else {
    //     appWorker.onerror   = this.onAppWorkerError;
    // }
    appWorker.onerror   = this.onAppWorkerError;
    
    this.user = user;
    
    //bind the context
    this.sendToMainP2P = this.sendToMainP2P.bind(this);
    
    $(window).unload(this.onWindowClosed); //on window closing
    
    localforage.config(settingsGlobal.localforage); //configure the localforage library, that used within the appWorker
    this.loadFromLocalStorageToIndexedDB(); //load all values from the local storage to the indexed db with local forage library
    
}

var ConnectorAppWorkerProto = Object.create(new EventEmitter());

//set user methods as a handlers for a commands from the appWorker and the mainP2P
//listHandlersCommandsForUserFromMainP2P = { "commandFromAppWorker" : "handlerNameMethodUser" } - define a handlers = methods of the instance of the User for a commands from the appWorker. When the command "commandFromAppWorker" will come, than the method of the user will be called - user["handlerNameMethodUser"]
/**
 * Description
 * @method setHandlersCommandsUserMethods
 * @param {} listHandlersCommandsForUserFromMainP2P
 * @return 
 */
ConnectorAppWorkerProto.setHandlersCommandsUserMethods = function(listHandlersCommandsForUserFromMainP2P){
    var commandsHandlersUser = this.listCommandsHandlers["User"] = {}; //add a handlers for a commands from appWorker for the user to the list of all handlers
    var commandsAppWorker = Object.keys(listHandlersCommandsForUserFromMainP2P); //list of the listened commands by the user from the appWorker
    var propertyNameUser = "user."; //name of the property of the ConnectorAppWorker, that contains instance of User 
    for ( var i =0, len = commandsAppWorker.length; i < len; i++ ) {
        var commandAppWorker = commandsAppWorker[i]; //listened command from the appWorker by the user
        commandsHandlersUser[commandAppWorker] = propertyNameUser + listHandlersCommandsForUserFromMainP2P[commandAppWorker]; //handlers will be called as ConnectorAppWorker[propertyNameUser][listHandlersCommandsForUserFromMainP2P[commandAppWorker]]
    }
};

//on error in the appWorker
/**
 * Description
 * @method onAppWorkerError
 * @return 
 */
ConnectorAppWorkerProto.onAppWorkerError = function() {
    console.log("appWorker error:");
    if ( arguments.length === 1
        && arguments[0].stack != null ) {
            logger(arguments[0]);
    }
    console.log(arguments);
};

//define handlers for a messages from the worker
//structure for object: {messageType:{ messageKind : functionHandler }}
//messageType = type of a message
//messageKind = kind of a message
//functionHandler = name of the method of the ConnectorAppWorkerProto
ConnectorAppWorkerProto.listCommandsHandlers = {
    "Main" : {
        "Log" : logger.bind(logger)    
    }
};

//send any to the MainP2P
//commandName - a command or an event name for the instanceof MainP2P
//args - arguments for the command
/**
 * Description
 * @method sendToMainP2P
 * @param {} commandName
 * @param {} args
 * @return 
 */
ConnectorAppWorkerProto.sendToMainP2P = function(commandName, args) {
    this.sendCommand("MainP2P", "data", commandName, null, args);    
};

//start appWorker
/**
 * Description
 * @method start
 * @param {} userID
 * @return 
 */
ConnectorAppWorkerProto.start = function(userID, accessToken) {
    var worker = this.appWorker;
    
    if ( worker instanceof Worker ) { //check if the worker is exists
        //create a port for JSON shared worker to send it to the appWorker
        JSON._startWorker();
        var messagePortJSON = JSON._createNewMessagePort(); //create the message port
        var _self = this;
        
        if ( messagePortJSON instanceof MessagePort ) {
            this.sendCommand("Settings", "JSONMessagePort", messagePortJSON, messagePortJSON); //send mesage to set the JSON shared worker port to the appWorker
        }
        
        //create the DataConnector
        var settingsP2P = settingsGlobal.settingsP2P;
        var settingsForDataConnector = { //settings for DataConnector
            maxDataConnections : settingsP2P.maxDataConnections, //the maximum number for connections
            settingsPeerJS : settingsP2P.settingsPeerJS    
        };
        var dataConnector = new DataConnector(settingsForDataConnector, userID, accessToken); //send the message to start the connection to the cs with the given user id = userID
        this.dataConnector = dataConnector;
        dataConnector.on("newDC", function onNewDC(dataConnector){ //if the new instance has been created by the appWorker
            _self.dataConnector = dataConnector; //set this new instance as default
            dataConnector.on("newDC", onNewDC);
        });
        var messagePortDC = dataConnector.setMessagePort(); //create message channel for DataConnector and port for the DataConnector, that works in the appWorker
        //send the message port to the appWorker
        this.sendCommand("Settings", "DataConnectorMessagePort", messagePortDC, messagePortDC); //post the message to set the DataConnector port   
       
        //send the list of a handlers(methods of the user) for an events(commands) from mainP2P
        this.sendCommand("Settings", "ListHandlersUserFromMainP2P", this.listHandlersCommandsForUserFromMainP2P);
        debugger;
        this.sendCommand("Main", "start", [userID, accessToken]); //send the message to start MainP2P, ILS, ELS instances for handling the user location
    
    }    
};

//on window closed
/**
 * Description
 * @method onWindowClosed
 * @return 
 */
ConnectorAppWorkerProto.onWindowClosed = function(){

    localStorage.setItem("timestamp_ClientClosed", require("timestamps").getCurrentTimestamp());  //set the timestamp when the window was closed  
    
};

//load all the items from the local storage to the IndexedDB using localforage library
/**
 * Description
 * @method loadFromLocalStorageToIndexedDB
 * @return 
 */
ConnectorAppWorkerProto.loadFromLocalStorageToIndexedDB = function(){
    
    var _keys = Object.keys(localStorage);
    
    for( var i =0, len = _keys.length; i < len; i++ ) {
        var key = _keys[i];
        localforage.setItem(key, localStorage.getItem(key)); //load this item to the IndexedDB
    }
        
};

ConnectorAppWorker.prototype = ConnectorAppWorkerProto;

module.exports = {
    ConnectorAppWorker : ConnectorAppWorker
};