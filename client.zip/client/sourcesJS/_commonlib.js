/*global moment*/
/*global localforage*/
/*global S*/ //string.js

var globalSettings = require("globalSettings");
var empty_user_id = globalSettings.empty_user_id; //the value, that is representation of an empty id of the user

function isWorkerContext() {
    return typeof importScripts === 'function';    
}

/**
 * Description
 * @method isEmptyObject
 * @param {} obj
 * @return Literal
 */
function isEmptyObject(obj) {
    if ( typeof(obj) != "object" ) {
        return !obj;
    }
    for (var k in obj) {
        return false;
    }
    return true;
}

/**
 * Description
 * @method hasProperty
 * @param {} obj
 * @param {} propName
 * @return LogicalExpression
 */
function hasProperty(obj, propName) {
    return obj != null
            && obj[propName] != null;
}

/**
 * Description
 * @method strToInt
 * @param {} str
 * @return CallExpression
 */
function strToInt(str) {
    return parseInt(str, 10);
}

/**
 * Description
 * @method numToStr
 * @param {} num
 * @return BinaryExpression
 */
function numToStr(num) {
    return num+'';
}

//get string with the length as fillNum and zero filled prefix
/**
 * Description
 * @method getFStr
 * @param {} int
 * @param {} fillNum
 * @return CallExpression
 */
function getFStr(int, fillNum) {
    return ("00000000000000000000000000" + int).substr(-fillNum);
}

//convert array values from strings to integers
/**
 * Description
 * @method convertArrayStringValuesToIntegers
 * @param {} array
 * @return res
 */
function convertArrayStringValuesToIntegers(array){
    var res = [];
    for( var i = 0, len = array.length; i < len; i++ ) {
        res[res.length] = strToInt(array[i]);    
    }
    return res;
}

//return Array [method, context] or property of the given object by comma - separeted name. context = context fo the function execution
//if not found return false
/**
 * Description
 * @method getObjectPropertyByCommaSeparatedName
 * @param {} object
 * @param {} dottedString
 * @return LogicalExpression
 */
function getObjectPropertyByCommaSeparatedName(object, dottedString) {
    var context, methodName;
    var val = dottedString.split(".").reduce(function(previousValue, currentValue){
        if ( previousValue == null ) { //method has not been found
            return null;
        }
        if ( currentValue == null ) { //the current property name if empty
            return previousValue;
        } else {
            if ( previousValue[currentValue] !== undefined ) { //method or property has been found
                context = previousValue;
                methodName = currentValue;
                return previousValue[currentValue];    
            } else { //method or property has not been found
                context = null;
                methodName  = null;
                return null; //stop execution
            } 
        }   
    }, object);
    
    return val != false
        && [context, methodName];
}

/**
 * call the given method of an object context[methodName] or function func with the argument, that are defined by the array = arrayArguments
 * or may be call as function, arrayArguments, then the given function will be called with the given arguments
 * @method callFunctionWithArguments
 * @param {} context
 * @param {} methodName
 * @param {} arrayArguments
 * @return 
 */
function callFunctionWithArguments(context, methodName, arrayArguments) { //or function, arrayArguments
    if ( arguments.length === 3 ) { //if a method call with the given arguments
        if (typeof(methodName) === "string"
            && typeof(context[methodName]) === "function"
            && isArray(arrayArguments) === true ) {  
                switch( arrayArguments.length ) {
                    case 0:
                        return (context[methodName])();
                    case 1:
                        context[methodName](arrayArguments[0]);
                        break;
                    case 2:
                        context[methodName](arrayArguments[0],arrayArguments[1]);
                        break;
                    case 3:
                        context[methodName](arrayArguments[0],arrayArguments[1],arrayArguments[2]);
                        break;
                    case 4:
                        context[methodName](arrayArguments[0],arrayArguments[1],arrayArguments[2],arrayArguments[3]);
                        break;
                    case 5:
                        context[methodName](arrayArguments[0],arrayArguments[1],arrayArguments[2],arrayArguments[3],arrayArguments[4]);
                        break;
                    case 6:
                        context[methodName](arrayArguments[0],arrayArguments[1],arrayArguments[2],arrayArguments[3],arrayArguments[4],arrayArguments[5]);
                        break;
                    case 7:
                        context[methodName](arrayArguments[0],arrayArguments[1],arrayArguments[2],arrayArguments[3],arrayArguments[4],arrayArguments[5],arrayArguments[6]);
                        break;
                    case 8:
                        context[methodName](arrayArguments[0],arrayArguments[1],arrayArguments[2],arrayArguments[3],arrayArguments[4],arrayArguments[5],arrayArguments[6],arrayArguments[7]);
                        break;
                    case 9:
                        context[methodName](arrayArguments[0],arrayArguments[1],arrayArguments[2],arrayArguments[3],arrayArguments[4],arrayArguments[5],arrayArguments[6],arrayArguments[7],arrayArguments[8]);
                        break;
                    default: break;
                }
        }
    } else if ( arguments.length === 2 ) { //if a function call with the given arguments
        var func = context;
        arrayArguments = methodName;
        if (typeof(func) === "function"
            && isArray(arrayArguments) === true ) {  
                switch( arrayArguments.length ) {
                    case 1:
                        func(arrayArguments[0]);
                        break;
                    case 2:
                       func(arrayArguments[0],arrayArguments[1]);
                        break;
                    case 3:
                        func(arrayArguments[0],arrayArguments[1],arrayArguments[2]);
                        break;
                    case 4:
                        func(arrayArguments[0],arrayArguments[1],arrayArguments[2],arrayArguments[3]);
                        break;
                    case 5:
                        func(arrayArguments[0],arrayArguments[1],arrayArguments[2],arrayArguments[3],arrayArguments[4]);
                        break;
                    case 6:
                        func(arrayArguments[0],arrayArguments[1],arrayArguments[2],arrayArguments[3],arrayArguments[4],arrayArguments[5]);
                        break;
                    case 7:
                        func(arrayArguments[0],arrayArguments[1],arrayArguments[2],arrayArguments[3],arrayArguments[4],arrayArguments[5],arrayArguments[6]);
                        break;
                    case 8:
                        func(arrayArguments[0],arrayArguments[1],arrayArguments[2],arrayArguments[3],arrayArguments[4],arrayArguments[5],arrayArguments[6],arrayArguments[7]);
                        break;
                    case 9:
                        func(arrayArguments[0],arrayArguments[1],arrayArguments[2],arrayArguments[3],arrayArguments[4],arrayArguments[5],arrayArguments[6],arrayArguments[7],arrayArguments[8]);
                        break;
                    default: break;
                }
        }
    }
}

/**
 * Description
 * @method extend
 * @param {} origin
 * @param {} add
 * @return origin
 */
function extend(origin, add) {
  // Don't do anything if add isn't an object
  if (!add || typeof add !== 'object') return origin;

  var keys = Object.keys(add);
  var i = keys.length;
  while (i--) {
    origin[keys[i]] = add[keys[i]];
  }
  return origin;
}

/**
 * Description
 * @method deleteFromArray
 * @param {} array
 * @param {} value
 * @return array
 */
function deleteFromArray(array, value) {
  if ( isArray(array) === true ) {
      var numFound = array.indexOf(value);
        if ( numFound !== -1 ) {
            array.splice(numFound, 1);    
        }
  }
  return array;
}

//check if the variable is an array
/**
 * Description
 * @method isArray
 * @param {} _variable
 * @return LogicalExpression
 */
function isArray(_variable){
    return typeof(_variable) === "object"
        && _variable.constructor != null
        && _variable.constructor.name === "Array";
}

/**
 * Description
 * @method round
 * @param {} float
 * @param {} precission
 * @return BinaryExpression
 */
function round(float, precission) {
    var factor = Math.pow(10, precission);
    return Math.round(float * factor) / factor;
}

/**
 * Description
 * @method randomInteger
 * @param {} min
 * @param {} max
 * @return rand
 */
function randomInteger(min, max) {
    var rand = min - 0.5 + Math.random() * (max - min + 1);
    rand = Math.round(rand);
    return rand;
 }
 
 /**
 * return array only with the unique items
 * @method uniqueItems
 * @param {} arr
 * @return a
 */
function uniqueItems(arr) {
    var a = [];
    for (var i=0, l=arr.length; i<l; i++)
        if (a.indexOf(arr[i]) === -1)
            a.push(arr[i]);
    return a;
}

//function compare that A is bigger then B
/**
 * Description
 * @method compareBHigherThenA
 * @param {} A
 * @param {} B
 * @return BinaryExpression
 */
function compareBHigherThenA(A,B){
    return B - A;    
}

//return false if the given user id is empty
/**
 * Description
 * @method isEmptyLSID
 * @param {} lsID
 * @return LogicalExpression
 */
function isEmptyLSID(lsID){
    return typeof(lsID) !== "number"
            || lsID === empty_user_id;    
}

/**
 * check if the given string is empty (return true or false)
 * @method isEmptyString
 * @param {} str
 * @return ConditionalExpression
 */
function isEmptyString(str) {
   return this.s === null || this.s === undefined ? true : /^[\s\xa0]*$/.test(this.s); 
}

/**
 * merge two arrays into the one
 * only unique items will be put in the destination array
 * @method mergeUnique
 * @param {} arrayDest
 * @param {} arrayContributor
 * @return 
 */
function mergeUnique(arrayDest, arrayContributor) {
    var lenDest = arrayDest.length;
    var lenContributor = arrayContributor.length;
    if ( typeof(lenDest) !== "number"
        || typeof(lenContributor) !== "number" ) {
            console.log("Common.mergeUnique: ERROR. One of the arguments is not an array");
            return [];        
    }
    var i = 0;
    while( i < lenContributor ) {
        var el = arrayContributor[i];
        if ( arrayDest.indexOf(el) === -1 ) {
            arrayDest[lenDest] = arrayContributor[i];    
            lenDest++;
        }
        i++;    
    }  
}

/*
    return the unique elements from the arraySource wich are absent in the arr
*/
function returnUniqueElements(arraySource, arr) {
    const length = arraySource.length;
    var res = [];
    var ind = 0;
    for( var i = 0; i < length; i++) {
        var el = arraySource[i];
        if ( arr.indexOf(el) === -1 ) {
            res[ind] = el;     
        }    
    }
    return res;
}

/**
 * clean the string from the banned words, html keywords and special keywords
 * @method clearBannedWords
 * @param {} string
 * @return string
 */
var clearBannedWords; 
 
var escapeHTML = (function escapeHTML(str) {
    return encodeURI(str).replace(this.exp, '&#34');
}).bind({exp : new RegExp('[<>"]', "g")});
 
if ( isWorkerContext() === true ) {
    clearBannedWords = (function(str) {
        if ( typeof(str) === "string" ) {
            return this.escapeHTML(str);    
        }
    }).bind({escapeHTML:escapeHTML});
} else { 
    clearBannedWords = (function clearBannedWords(str) {
        if ( typeof(str) === "string" ) {
            var result;
            var bannedWordsExp = this.bannedWordsExp;
            if ( bannedWordsExp == null ) {
                    var BannedWordsList = window._gBannedWordsList;
                    if ( Array.isArray(BannedWordsList) === true ) {
                        this.bannedWordsExp = new RegExp(BannedWordsList.join("|"), "gi"); //make the regular expression to filter strings from a banned words    
                    }
                    result = this.escapeHTML(str);
            } else {
                result = this.escapeHTML(str).replace(bannedWordsExp, "***");    
            }
            return result;
        } else {
            return result;    
        }
    }).bind({escapeHTML:escapeHTML});
}

var isEmptyValue = (function isEmptyValue(val) {
    
    var _type = typeof(val);
    var res;
    switch( _type ) {
        case "object" :
           res = this.isEmptyObject(val);
           break;
        case "string" :
           res = val.trim() === "";
           break;
        case "number" :
            res === 0;
            break;
    }
    
    return res;
        
}).bind({
    isEmptyObject : isEmptyObject     
});

/*
    if withoutEmptyValues = true, then 
*/
var cleanObjectBannedWords = (function _cleanObjectBannedWords(obj, withoutEmptyValues) {
    
    if ( typeof(obj) === "object"
        && obj !== null ) { //if an object was given
            var resObj = isArray(obj) === true ? [] : {};  
            var _keys = Object.keys(obj);
            var flArray = (obj instanceof Array);
            var ind = 0;
            var flEmpty = withoutEmptyValues === true; //flag that the object is fully empty
            
            for ( var i = 0, len = _keys.length; i < len; i++ ) {
                var propName = _keys[i];
                var propValue = this.clearBannedWords(obj[propName]); //clean the property value
                var clearName;
                if ( flArray !== true ) {
                    clearName = this.clearBannedWords(propName).trim(); //if keys is a string clear the property name    
                }
                if (flArray === true //if an array was given for cleaning
                    || clearName !== "" ) { //if the property name is not a banned word
                            
                        if ( withoutEmptyValues !== true //not necessary to check if empty
                            || this.isEmptyValue(propValue) !== true ) { //if necessary to check if the property is empty
                                
                                if ( flArray === true ) {
                                    clearName = ind++;  //if an array was given, then set the current index 
                                }
                                
                                if ( typeof(propValue) === "object" ) {
                                    resObj[clearName] = cleanObjectBannedWords.call(this, propValue, withoutEmptyValues);    
                                    flEmpty = false;
                                } else if ( typeof(propValue) === "string" ) {
                                    resObj[clearName] = cleanObjectBannedWords.call(this, propValue, withoutEmptyValues);
                                    flEmpty = false;
                                } else {
                                    resObj[clearName] = propValue;    
                                    flEmpty = false;
                                }
                                
                        }
                }
            }
            
            if ( flEmpty === false ) {
                return resObj;
            } else {
                return null;    
            }
    } else {
        var res = this.clearBannedWords.call(this, obj); 
        return this.isEmptyValue(res) === true ? null : res;    
    }

}).bind({
        clearBannedWords : clearBannedWords,
        isEmptyValue : isEmptyValue
    });

/**
 * arguments - url parts
 * @method resolvePath
 * @return path
 */
function resolvePath(){
    var path = "";
    
    for( var i =0, len = arguments.length; i < len; i++ ) {
        if ( typeof(arguments[i]) === "string" ) {
            var urlPart = arguments[i].trim();
            if ( path.endsWith("/") === true ) { //if the path is ends with "/"
                if ( urlPart.charAt(0) === "/" ) { //if the next url part begins with "/"
                    path = path + urlPart.substr(1); //get the url part without "/"
                } else {
                    path = path + urlPart;    
                }
            } else { //if the part does not ends with the "/"
                if ( urlPart.charAt(0) === "/" ) { //if the next url part begins with "/"
                    path = path + urlPart;
                } else {
                    path = path + "/" + urlPart; //add "/" as the url divider   
                }
            }
        }
    }
    
    return path;
}

/**
 * save js object to the storage
 * obj - object to save, key - key name, cb - callback function
 * cb(true) - if all is ok
 * cb(false) - in case of an error
 * @method saveObjLocalForage
 * @param {} obj
 * @param {} key
 * @param {} cb
 * @return 
 */
function saveObjLocalForage(obj, key, cb) {
    if ( obj != null ) {
        if ( typeof(cb) === "function" ) { //if the callback is defined
            if ( typeof(obj) === "object" ) { //stringify the given object
                JSON.stringifyAsync(obj, 
                  function(res) {
                    if ( typeof(res) === "string" ) { //if the list has loaded
                        localforage.setItem(key, res); //save to the storage
                        if ( typeof(cb) === "function" ) {
                            cb(true);    
                        }
                    } else {
                        if ( typeof(cb) === "function" ) {
                            cb(false);    
                        }    
                    }
                  }
                );
            } else { //the given object is a string
                localforage.setItem(key, obj, cb);    
            }
        } else { //if the callback is not defined, return Promise
            if ( typeof(obj) === "object" ) { //stringify the object
                return JSON.stringifyAsync(obj)
                        .then(function(res){ //string
                            return localforage.setItem(key, res);
                        });
            } else { //if object is a string
                return localforage.setItem(key, obj);    
            }     
        }
    }
}

/**
 * Description
 * @method errPromise
 * @param {} e
 * @return 
 */
function errPromise(e){
    console.stack(e);    
}

/**
 * return js object from the storage
 * key - key name, cb - callback function
 * @method getObjLocalForage
 * @param {} key
 * @param {} cb
 * @return 
 */
function getObjLocalForage(key, cb) {
    
    if ( typeof(cb) === "function" ) {
        return  localforage.getItem(key, 
              function(err, result) { //load from the storage
                if ( typeof(result) === "string"
                    && !( err instanceof Error ) ) { //if the list has loaded
                        JSON.parseAsync(result, cb); //return the result to the callback function    
                } else
                    cb(null);
              }
            );
    } else { //return Promise if the callback is not defined
        return localforage
                .getItem(key)
                .then(
                    function( result ) {
                        if ( typeof(result) === "string" ) {
                            return JSON.parseAsync(result); //return Promise 
                        } else {
                            return result;
                        }
                    }
                )
                .catch(errPromise);    
    }    
}

/*
    return object with a message description  
*/
function getMessageDescriptionObj(from, text, fromName) {
    if ( typeof(text) === "string" ) {
        return { //make the message description object
            message : text,
            date    : Date.now(), //current date
            type    : true, //incoming
            from    : from,
            fromName : fromName
        }; 
    } else {
        return null;
    }
}

/*
    return a text from an object with a message description  
*/
function getMessageTextFromDescriptionObj(msgObj) {
    return msgObj.message;
}

/*
    return a text from an object with a message description  
*/
function getMessageHeadFromDescriptionObj(msgObj) {
    return msgObj.date;
}

/*
    return id of the user, from wich this message 
    return name - id
*/
function getMessageUserFromDescriptionObj(msgObj) {
    var moment = window.moment; //Moment.js
    return ( moment == null ? msgObj.date +"(utc)" : moment.utc(msgObj.date).local().format("YY-MM-DD HH:mm") ) + " " + ( msgObj.fromName == null ? "" : msgObj.fromName ) + " - " + msgObj.from;
}

var ALPHABET = '23456789_' + 'abdegjkmnpqrvwxyz' + 'abdegjkmnpqrvwxyz'.toUpperCase();
var ALPHABET_LENGTH = ALPHABET.length;
function generateHash(len) {
  var rtn = '';
  for (var i = 0; i < len; i++) {
    rtn += ALPHABET.charAt(Math.floor(Math.random() * ALPHABET_LENGTH));
  }
  return rtn;
}

/*
    close the media stream
*/
function closeMediaStream(stream) {
    var activeTracks, i, len, track; 
    
    activeTracks = stream.getVideoTracks(); //get all video tracks from the stream
    for ( i =0, len = activeTracks.length; i < len; i++ ) {
        track = activeTracks[i]; //video track
    	stream.removeTrack(track); //stop it
    }
    activeTracks = stream.getAudioTracks(); //get all video tracks from the stream
    for ( i =0, len = activeTracks.length; i < len; i++ ) {
        track = activeTracks[i]; //video track
    	stream.removeTrack(track); //stop it
    } 
}

/*
    return a string with the language name, like "en", "ru"
    if the language is not detected return null
*/
function getBrowserLanguage() {
    const nav= window.navigator;
    const lang = typeof(nav.language) === "string" ? nav.language : nav.userLanguage; //browser language
    var res;
    
    if ( typeof(lang) === "string" ) { //if a language was detected
        const indLangSubclass = lang.indexOf("-"); //if language contains a subclass like en-us
        if ( indLangSubclass !== -1 ) {
            res = lang.substr(0, indLangSubclass).toLowerCase().trim();  //get only the base language
        } else {
            res = lang.toLowerCase().trim();    
        }
    } else {
        res = null;    
    }
  
    return res; //return the language in the lower case
  
}

module.exports = {
    isEmptyObject : isEmptyObject,
    round    : round,
    strToInt : strToInt,
    numToStr : numToStr,
    getFStr  : getFStr,
    hasProperty : hasProperty,
    convertArrayStringValuesToIntegers : convertArrayStringValuesToIntegers,
    getObjectPropertyByCommaSeparatedName : getObjectPropertyByCommaSeparatedName,
    callFunctionWithArguments : callFunctionWithArguments,
    extend : extend,
    deleteFromArray : deleteFromArray,
    isArray : isArray,
    randomInteger : randomInteger,
    uniqueItems : uniqueItems,
    compareBHigherThenA : compareBHigherThenA,
    isEmptyString : isEmptyString,
    isEmptyLSID : isEmptyLSID,
    mergeUnique : mergeUnique,
    clearBannedWords : clearBannedWords,
    resolvePath : resolvePath,
    saveObjLocalForage : saveObjLocalForage,
    getObjLocalForage  : getObjLocalForage,
    getMessageDescriptionObj : getMessageDescriptionObj,
    getMessageTextFromDescriptionObj : getMessageTextFromDescriptionObj,
    getMessageHeadFromDescriptionObj : getMessageHeadFromDescriptionObj,
    getMessageUserFromDescriptionObj : getMessageUserFromDescriptionObj,
    generateHash : generateHash,
    closeMediaStream : closeMediaStream, 
    isWorkerContext : isWorkerContext,
    cleanObjectBannedWords : cleanObjectBannedWords,
    isEmptyValue : isEmptyValue,
    returnUniqueElements : returnUniqueElements,
    getBrowserLanguage : getBrowserLanguage
};