/*global Ajv*/
"use strict";

//incoming message from the central server with a several messages
var Validator = Ajv;
var validator = (Validator()).compile;
var patterns = require("mainpatterns"); //main patterns for schemas

var schemas = {
    "userCoordsDescriptionString" : { //description of the user and his coordinates
        "type" : "object",
        "required" : ["lat", "lng", "coordsTimestamp", "description"],
        "properties" : {
            "lat" : patterns.optVS_latitude, //the current coordinates
            "lng" : patterns.optVS_longitude,
            "coordsTimestamp" : patterns.optVS_timestamp, //timestamp when the coordinates were formed by the user
            "description" : patterns.optVS_stringCompressedUserDescription
        }
    },
    "userDescription" : { //a description of the user
        "type" : "object",
        "additionalProperties": false,
        "required" : ["gender", "name"],
        "properties" : {
            "name"   : patterns.optVS_textField,
            "gender" : {
                "anyOf" : [patterns.optVS_gender, patterns.optVS_emptyString]    
            },
            "chosentags" :  //short keywords, which are chosen by the user, which allows to find him by other users
                {
                    "type"  : "array",
                    "maxItems" : 20,
                    "items" : patterns.optVS_textField
                },
            "sociallinks" : //short keywords, which are chosen by the user, which allows to find him by other users
                {
                    "type"  : "object",
                    "additionalProperties" : false,
                    "maxProperties" : 20,
                    "patternProperties": {
                        "^[A-Za-z][A-Za-z0-9]{0,20}[A-Za-z]$" : patterns.optVS_textField
                    }
                },
            "age"    : patterns.optVS_age,
            "phone"  : patterns.optVS_phone,
            "email"  : patterns.optVS_email,
            "status" : patterns.optVS_textField,
            "photo"  : patterns.optVS_uri,
            "videostream" : patterns.optVS_videostreamhash, //if user have an active videostream
            "videostreamdescription" : patterns.optVS_videostreamdescription, //if user have an active videostream
            "locationmethod" : patterns.optVS_locationMethod //manual or automatic
        }
    }
};

var validators = {
	validatorUserCoordsTimestamp : validator(schemas.userCoordsDescriptionString),
	validatorUserDescription : validator(schemas.userDescription)
};

module.exports = validators;