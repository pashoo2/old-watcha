        var settings = {
            timeUTCMillisecondsDifference : 0, //diffrernce between UTC time on the central server and the clisent
            delimetrCurrentTimestamp : 1000,
            lowerBoundValidTimestampSeconds : 60
        }
		
        //return timetamp by Date.now() in seconds
        //noinspection NestedFunctionJS
        /**
         * Description
         * @method getCurrentTimestamp
         * @return CallExpression
         */
        function getCurrentTimestamp() {
            return Math.ceil((Date.now() + settings.timeUTCMillisecondsDifference) / settings.delimetrCurrentTimestamp);
        }
        
        /**
         * Description
         * @method addSecondsToTimestamp
         * @param {} timestamp
         * @param {} seconds
         * @return 
         */
        function addSecondsToTimestamp(timestamp,seconds) {
            if ( settings.delimetrCurrentTimestamp === 1000 ) {
                return timestamp + seconds;    
            } else {
                return timestamp + ( seconds * 1000 / settings.delimetrCurrentTimestamp)
            }
        }
        
        //return timetamp by Date.now() in seconds
        //noinspection NestedFunctionJS
        /**
         * Description
         * @method setClientServerUTCTimeDifference
         * @param {} difference
         * @return 
         */
        function setClientServerUTCTimeDifference(difference) {
            settings.timeUTCMillisecondsDifference = difference;
        }
        
        //check whether is the timestamp valid
        //return true or false
        /**
         * Description
         * @method isValidTimestamp
         * @param {} timestamp
         * @return BinaryExpression
         */
        function isValidTimestamp(timestamp) {
            return Math.abs(getCurrentTimestamp() - timestamp) > settings.lowerBoundValidTimestampSeconds;
        }
        
        module.exports = {
        	 getCurrentTimestamp : getCurrentTimestamp,
        	 setClientServerUTCTimeDifference : setClientServerUTCTimeDifference,
        	 isValidTimestamp	 : isValidTimestamp,
        	 addSecondsToTimestamp : addSecondsToTimestamp
        }
        
        