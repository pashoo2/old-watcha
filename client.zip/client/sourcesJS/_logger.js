/*global $*/

var globalSettings = require("globalSettings");
var flEnabled = (globalSettings.debug === true);
var loggerSettings = globalSettings.logger;
    
var context_showLog = {
    _self : self,
    ENVIRONMENT_IS_WORKER : typeof importScripts === 'function',
    ENVIRONMENT_IS_WEB : typeof window === 'object'
};
    
const showLog = (function showLog(text) {
    if ( this.ENVIRONMENT_IS_WEB === true ) {  
        if (this.div != null 
            || this._self.$ !== undefined ) { //check for jquery
                if ( this.div == null ) {
                    var _div = this.div = this._self.$(".data-ui-output-console-log");
                    _div.click(function(){
                        $(this).scrollTop($(this).offset().top);    
                    });
                }
                this.div.append("<p>" + (new Date()).toLocaleString() + " : " + text + "</p>");
        }
    } else 
        if ( this.ENVIRONMENT_IS_WORKER === true ) {
            this._self.connectorWithMainThread.sendCommand("Main", "Log", text);    
        }
}).bind(context_showLog);

var context_customconsolelog = {
    showLog : showLog,
    console : console,
    originLog : console.log
};    
/*set the alternative console.log*/
if ( typeof(console.log) === "function"
    && console.log.name !== "customconsolelog" ) { //if still has not been replaced
        console.log = (function customconsolelog(){
            var text;
            var val = arguments[0];
            if ( val instanceof Error ) {
                text = val.message;
            } else {
                text = val;
            }
              
            this.showLog(text);
            this.originLog.apply(this.console, arguments);
        }).bind(context_customconsolelog);
}

//"!!!" - it is mark for a warning message

if ( flEnabled === true ) {
    module.exports = {
        /**
         * Description
         * @method logger
         * @return FunctionExpression
         */
        get logger() {
            return function Logger(text) {               
                
                if ( text instanceof Error ) {
                    Raven.captureException(text);
                }
                
                if ( flEnabled === true ) { //if the value of the debug flag is true
                    var thisFunc = arguments.callee; //reference to the function representation as an object 
                    var showOnlyErrors   = (loggerSettings.showOnlyErrors === true || thisFunc.showOnlyErrors === true); 
                    var showOnlyWarnings = (loggerSettings.showOnlyWarnings === true || thisFunc.showOnlyWarnings === true); 
                    if ( ( showOnlyErrors === true || showOnlyWarnings === true )
                        && ( ( showOnlyErrors === true && text instanceof Error === false ) || showOnlyErrors   === false )
                        && ( ( showOnlyWarnings === true && typeof(text) === "string" && text.indexOf("!!!") === -1 ) || showOnlyWarnings === false ) //!!! - mark for a warning message
                    ) { //if it is necessary to show only an errors or warnings, but it is not an error or warning
                        return;
                    }
                    if ( thisFunc.namespace != null ) { //if a module name was defined
                        if ( typeof(text) === "string" ) {
                            console.trace(thisFunc.namespace + ": " + text); 
                            showLog(thisFunc.namespace + ": " + text);
                        } else { //if text not a string, then divide the message by two: the first shows a module name, and the second - an object's structure
                            console.trace(thisFunc.namespace + ": ");
                            console.log(text);
                        }
                    } else if ( text != null ) { //if a module name was not defined
                        console.trace(text);
                    }
                }
            };         
        }
    };
} else {
    module.exports = {
        get logger () {
            return function(){};    
        }
    };
}