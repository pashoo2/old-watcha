//incoming message from the central server with a several messages
var Validator = Ajv;
var validator = (Validator()).compile;
var patterns = require("mainpatterns");

var globalSettings = require("globalSettings");

var validMessagesKinds = ["out", "ilsNewLSID", "ilsServerClosed", "ilsSendMessageToTheUser", "ilsGetLocationsDescription", "ilsUserMoveToLocation", "ilsLocationsDescription", "ilsUserCameToNearestLocation"];
var validMessagesKindsFromELS = ["userDescription","sendOffer","sendAnswer"];

//patterns for an inner purposes of this module
var localPatterns =  {
    //user location with a timestamp, when the location hash was calculated by the cs
    optVS_userLocationWithTimestamp : patterns.extendSchemaProperties(patterns.optVS_userLocation, {timestamp : patterns.optVS_timestamp}),
    //user location with timestamp and the previous location
    optVS_userLocationWithTimestampAndPrevious : patterns.extendSchemaProperties(patterns.optVS_userLocation, {timestamp : patterns.optVS_timestamp, previousLocationHash : patterns.optVS_locationHash}),
    //with a timestamp when the coordinates was formed
    optVS_userLocationWithCoordsTimestamp : patterns.extendSchemaProperties(patterns.optVS_userLocation, {coordsTimestamp : patterns.optVS_timestamp}),
    //user location with a timestamp, when the location hash was calculated by the cs and timestamp when the coordinates was formed 
    optVS_userLocationWithTimestampAndCoordsTimestamp : patterns.extendSchemaProperties(patterns.optVS_userLocation, {timestamp : patterns.optVS_timestamp, coordsTimestamp : patterns.optVS_timestamp}),
    //user location with a timestamp, when the location hash was calculated by the cs and timestamp when the coordinates was formed, not necessary to receive a location hash of the user, with the number of tthe locations, that are handled by the user
    optVS_userLocationWithTimestampAndCoordsTimestamp_withoutLocationHash : 
        patterns.extendSchemaProperties(
            patterns.optVS_userLocation_withoutLocationHash,
            {   timestamp : patterns.optVS_timestamp,
                coordsTimestamp : patterns.optVS_timestamp,
                numOfMaintainedLocations : patterns.optVS_positive_integer }
        ),
    optVS_descriptionNearestLocations : { //the description of the nearest locations
        type: "object",
        maxProperties : 10,
        patternProperties : {
            [patterns.patternPropertyLocationHash] : {
                type: "object",
                additionalProperties : false,
                properties: {  //this properties may absent (were not included to required), if a local server for the nearest location is absent
                    localServerID: patterns.optVS_userID_orEmpty,
                    timestamp: patterns.optVS_timestamp
                }
            }
        }
    }
};

var schemas = {
    //when the central server has calculated the location hash of the users locations, that were requested by the ils
    //validation schema for an incoming message, from the cs, that contains calculated hashes of users locations, which are on the maintained locations
    vSchemaMessageFromCS_CalculatedHashesUsersLocations : {
        type: "object",
        patternProperties : { //property name is the user ID
            [patterns.patternPropertyUserID]: patterns.optVS_locationHash //value of the property is the hash of the user location
        }
    },
    vSchemaMessageFromCS_LocationsAreMaintained : { //server send that the locations are maintained by ils
        type : "array",
        additionalItems : false,
        items : patterns.optVS_locationHash
    },
    vSchemaMessageFromCS_Ping : {
        type : "object",
        additionalProperties : false,
        requiredProperties : ["locationHash", "timestamp", "nearestLocations"],
        properties : {
            locationHash : patterns.optVS_locationHash,
            timestamp : patterns.optVS_timestamp,
            nearestLocations : localPatterns.optVS_descriptionNearestLocations
        }
    },
    //message from the central server, to add the user location
    vSchemaMessageFromCS_AddLocationForHandling : {
            type: "object",
            additionalProperties : false,
            required : ["locationHash", "nearestLocalServers"],
            properties: {
                locationHash: patterns.optVS_locationHash,
                nearestLocalServers: localPatterns.optVS_descriptionNearestLocations
            }
    },
    //message from the central server, to stop handling of the locations
    vSchemaMessageFromCS_StopLocationHandling : {
        type: "object",
        additionalProperties : false,
        required : ["locations"],
        properties : {
            locations : {
                type : "array",
                additionalItems : false,
                items : patterns.optVS_locationHash
            },
            newLSID : {
                type : "array",
                additionalItems : false,
                items : patterns.optVS_userID_orEmpty,
                minItems : 0
            }
        }       
    },
    //schema for validation of an incoming from another ls
    vSchemaIncomingMainMessageFromLS : {
        type: "object",
        additionalProperties : false,
        required : ["type","kind","body","timestamp"],
        properties: {
            type: {"enum": ["toILS"]},
            kind: {"enum": validMessagesKinds},
            body: {
                anyOf : [
                    { type:"object",
                      maxProperties : 100,
                      minProperties : 1
                    },
                    { type:"array",
                      maxItems : 100,
                      minItems : 1
                    },
                    {type:"number"}
                ]
            },
            timestamp: patterns.optVS_timestamp
        }
    },
    //message from the nearest ls, that the user moved from it's location to the location, maintained by the ils
    vSchemaIncomingMessageUserCame : {
        type: "object",
        additionalProperties : false,
        patternProperties : {
           [patterns.patternPropertyUserID] : localPatterns.optVS_userLocationWithTimestampAndPrevious
        }
    },
    //message from the nearest local server that the user has came to the location, maintained by the nearest ls
    vSchemaIncomingMessageUserCameToNearestLocation : {
        type: "object",
        additionalProperties : false,
        patternProperties : {
           [patterns.patternPropertyUserID] : localPatterns.optVS_userLocationWithTimestampAndPrevious
        }  
    },
    
    //validation schema for messages from the local server with the location description, that is maintained by the nearest ls and the nearest to the maintained location by the ils
    //locationHash : { userID : { lat, lng, locationHash, timestamp } }
    vSchemaILSIncomingMessageLocationDescription_mainSchema : {
        type: "object",
        additionalProperties : false,
        patternProperties : {
            [patterns.patternPropertyLocationHash] : {
                type : "string",
                minLength : 5
            }
        }
    },
    //in the validation schema, that is described above, items of an arrays is a strings in the JSON format
    //after parsing it wit the JSON.parse, an items must be conform to this schema
    vSchemaILSIncomingMessageLocationDescription_eachLocation : {
        type    : "object",
        additionalProperties : false,
        patternProperties : {
            [patterns.patternPropertyUserID] : localPatterns.optVS_userLocationWithTimestampAndCoordsTimestamp_withoutLocationHash //user description, which is on this location
        }
    },    
    
    //validation schema for metadata of an incoming connection of the user
    vSchemaILSIncomingUserConnectionMetadata : {
        type    : "object",
		required : ["g_locationHash","g_lat","g_lng","g_timestamp","g_connType"],
        properties: {  //user description, which is on this location
            g_locationHash	: patterns.optVS_locationHash_string,
            g_lat			: patterns.optVS_latitude, //latitude coordinate
            g_lng			: patterns.optVS_longitude,  //longitude coordinate
			g_timestamp 	: patterns.optVS_timestamp, //when the connection was created
			g_timestampCoords : patterns.optVS_timestamp, //when coordinates has been formed by a client
			g_timestampHashCalculation : patterns.optVS_timestamp, //when the hash of the location has been calculated by the cs
			g_numOfMaintainedLocations : patterns.optVS_positive_integer, //number of the maintained locations
			g_connType      : { enum:["ELS"] }, //the type of the connection
			g_description   : patterns.optVS_stringCompressedUserDescription
        }
    },
    vSchemaILSIncomingMessageFromUser : {
        type: "object",
        required : ["type","kind","body","timestamp"],
        additionalProperties : false,
        properties: {
            type: {"enum": ["toLocalServer"]},
            kind: {"enum": validMessagesKindsFromELS},
            body: {
                type: "object",
                maxProperties : 10,
            },
            timestamp: patterns.optVS_timestamp
        }
    },
    //incoming description of the user location. timestamp as a property is a time when the user's coordinates was received
    vSchemaIncomingUserDescription : localPatterns.optVS_userLocationWithTimestampAndCoordsTimestamp_withoutLocationHash,
    //dataConnection with the nearest local server
    vSchemaILSIncomingNearestLSDataConnection : {
        type : "object",
        required : ["peer","metadata"],
        additionalProperties : true,
        properties : {
            peer : patterns.optVS_userID,
            metadata : {
                type : "object",
                additionalProperties : true,
                maxProperties: 20,
                required : ["g_connType", "g_timestamp", "g_locationHash"],
                properties : {
                    g_connType : {"enum":["LSToLS"]}, //location that is maintained by the ils, to which is ELS connected
                    g_locationHash : patterns.optVS_listWithLocations, //list with the locations, that are maintained by the ils
                    g_timestamp : patterns.optVS_timestamp
                }
            }
        }
    },
    vSchemaILSIncomingRequestGetLocationsDescriptions : {
        type : "array",
        additionalItems : false,
        items : patterns.optVS_locationHash_string
    },
    vSchemaILSIncomingUserOfferForMessagingWithAnotherUser : {  //offer for anpther user to create a RTCDataChannel with him
        type : "object", 
        additionalProperties : false,
        requiredProperties : ["to", "offer"],
        properties : {
            to : patterns.optVS_userID,
            offer  : patterns.offerSDP
        }
    },
    vSchemaILSIncomingUserAnswerForMessagingWithAnotherUser : {  //answer for the user to his offer 
        type : "object", 
        additionalProperties : false,
        requiredProperties : ["to", "answer"],
        properties : {
            to :  patterns.optVS_userID,
            answer  : {
                anyOf : [
                    patterns.offerSDP,
                    {"enum": [globalSettings.neighborUser.messageMessagingDenied]}
                ]
            }
        }
    },
    vSchemaILSFromLSSendMessageToUser : {
        type : "object", 
        additionalProperties : false,
        requiredProperties : ["to", "locationHash", "message"],
        properties   : {
            to           : patterns.optVS_userID,
            locationHash : patterns.optVS_locationHash, 
            message  : {
                type : "string",
                minLength : 2,
                maxLength : 1024
            }
        }    
    },
    vSchemaILSFromLSNewLSID : { //new local server id for the location
        type : "object", 
        additionalProperties : false,
        requiredProperties : ["locationHash", "lsID"],
        properties : {
            locationHash : patterns.optVS_locationHash_string,
            lsID         : patterns.optVS_userID_orEmpty
        }
    },
    vSchemaILSFromLSOut : {
        type : "object", 
        additionalProperties : false,
        properties : {
            out : {
                enum : [1]    
            }    
        }    
    }
};

var validators = {
	validatorMessageCSAddLocationForHandling : validator(schemas.vSchemaMessageFromCS_AddLocationForHandling),
	validatorMessageILSMain : validator(schemas.vSchemaIncomingMainMessageFromLS),
	validatorMessageILSUserCame : validator(schemas.vSchemaIncomingMessageUserCame),
    validatorMessageILSUserCameToNearestLocation : validator(schemas.vSchemaIncomingMessageUserCameToNearestLocation),
	validatorMessageILSIncomingMessageLocationDescription : validator(schemas.vSchemaILSIncomingMessageLocationDescription_mainSchema),
	validatorMessageILSIncomingMessageLocationDescription_eachLocation : validator(schemas.vSchemaILSIncomingMessageLocationDescription_eachLocation),
	validatorMessageCSCalculatedHashesUsersLocations : validator(schemas.vSchemaMessageFromCS_CalculatedHashesUsersLocations),
	validatorMessageCSLocationsAreMaintained: validator(schemas.vSchemaMessageFromCS_LocationsAreMaintained),
	validatorMessageCSPing: validator(schemas.vSchemaMessageFromCS_Ping),
	validatorMessageCSStopLocationHandling : validator(schemas.vSchemaMessageFromCS_StopLocationHandling),
	validatorIncomingUserConnectionMetadata : validator(schemas.vSchemaILSIncomingUserConnectionMetadata),
    validatorIncomingMessageFromUser : validator(schemas.vSchemaILSIncomingMessageFromUser),
    validatorIncomingUserDescription : validator(schemas.vSchemaIncomingUserDescription),
    validatorILSIncomingNearestLSDataConnection : validator(schemas.vSchemaILSIncomingNearestLSDataConnection),
    validatorILSIncomingRequestGetLocationsDescriptions : validator(schemas.vSchemaILSIncomingRequestGetLocationsDescriptions),
    validatorIncomingUserOfferForMessagingWithAnotherUser : validator(schemas.vSchemaILSIncomingUserOfferForMessagingWithAnotherUser),
    validatorIncomingUserAnswerForMessagingWithAnotherUser : validator(schemas.vSchemaILSIncomingUserAnswerForMessagingWithAnotherUser),
    validatorMessageILSSendMessageToUser : validator(schemas.vSchemaILSFromLSSendMessageToUser),
    validatorMessageILSNewLSID : validator(schemas.vSchemaILSFromLSNewLSID),
    validatorMessageILSOut : validator(schemas.vSchemaILSFromLSOut)
};

module.exports = {
    validatorsILS : validators    
};