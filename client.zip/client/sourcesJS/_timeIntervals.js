module.exports = {
    timeIntervalMainP2POutstanding : 60000,
    timeIntervalMillisecondsUserUpdatePositionOnTheMap : 5000, //interval in millisecond to update the user location on the main map by the current coordinates
    timeIntervalSecondsUserOverdueGetCoordinatesForOthers : 2, //define when the last attemp to get the coordinates has been overdue, and we can do a second attempt
    timeIntervalMainP2PCheckExternalLocalServer : 180000, //180000
    timeIntervalMillisecondsDisconnectFromCSAfterLastDisconnection : 60000, //close the connection to the cs after some seconds, if a new connection will not be opened. This means that the WebSocket connection to the cs has reached timeout
    timeIntervalMainP2PCheckConnection : 3000, //one time per 3 seconds connection to the cs will been checked. For the Data Connector and the MainP2P
    timeIntervalMainP2PCheckConnectionFirstTime :60000, //1 minutes for the first connection to the cs
    timeoutSecondsMainP2PPeerDataConnection : 180, //180,
    timeIntervalExternalLocalServerGetLocationDescription : 10000,//default:30000, //interval in milliseconds to request the current location description from the nearest ls
    timeIntervalExternalLocalServerCheckConnection : 3000, //interval for checking the connection state by ELS
    timeoutSecondsIntervalExternalLocalServerMainConnection : 300,//default:60, //timeout when a connection to the ls becomes overdued
    timeoutToReconnectSecondsIntervalExternalLocalServerMainConnection : 100,
    timeoutSecondsIntervalExternalLocalServerLastConnectionTimeout : 60,
	timeoutSecondsExternalLocalServerIDRequestTimeout : 60,
	timeoutSecondsExternalLocalServerChooseAnotherLocalServerRequest : 10,
	timeoutSecondsExternalLocalServerLastConnectionAttempt : 4, //minimal interval between two attempts to connect to the local server
	timeoutSecondsExternalLocalServerBetweenConnectionAndMessageFromLS : 10, //interval between the connection creation and receiveing a first message from the local server
	timeoutSecondsLocationDescriptionBecomeUnvalid : 15, //after this time the current location description will be invalid
	timeIntervalUpdateUTCMillisecondsDiffirence : 10000, //time interval between attempts to update the time difference between the server and the client, if the previous attempt failed
	timeIntervalInnerLocalServerCheckNearestLocalServers : 30000,  //check a connections to all the nearest local servers and request the list of the local servers from the central server
    timeIntervalInnerLocalServerUpdateLocationDescriptionFromMainServer : 60000, //60000;
    timeIntervalSecondsInnerLocalServerBetweenIncomingData : 2, //minimal time interval beetween two user's connections
    timeIntervalInnerLocalServerCheckIncomingUsers : 60000,
    timeIntervalInnerLocalServerCheckUsers : 60000,
    timeIntervalInnerLocalServerRequestUsersLocationsHashes : 30000, //request users hashes, that are placed on the handled locations
    timeIntervalInnerLocalServerNearestLocationOutdated : 120000,
    timeSecondsInnerLocalServerMovedUsersDelay : 60, //user can moved between the location only one time per one minute. According to this time ils cleans the list of the users, that have moved from the maintained locations recently
    timeIntervalInnerLocalServerMovedUsersCheckingList : 30000,
    timeoutSecondsInternalLocalServerMessageFormCSPing : 40, //after that time a ping message from the central server is considered to be overdued
    timeIntervalSecondsAwaitingNewLSIDIfItISAbsentFoNow : 60, //wait this interval in seconds for another attempt to request new ls id from the cs, because of it is absent for a now
    timeoutBeforeConnectingToLocalServerWhenLocationOrServerIDChanged : 1000, //delay before connecting to the ils
    timeIntervalMillisecondsReconnectToCS : 20000,  //if a connection to the cs was closed because of an error, the client will try to reconnect after this time
    timeIntervalSecondsCreateJSONLocationsDescription : 10, //how often it is necessary to create JSON descriptions of the mainteinaed locations and the nearest locations
    timeSecondsBeetweenCreateJSONLocationDescription : 5, //the minimal time beetween the two creations of the JSOn location description
    timeSecondsProlongAwaitingNewID : 5, //time interval beetwenn the last two requests to get the is of a local server for the ELS locations
    timeIntervalSecondCheckOverhead : 60, //default: 60. time interval for checking is too much locations are maintained by the ils
    timeSecondsStopLocationMaintaince : 60, //a time between when a location was added for maintenance and the current time, after when it has passed maintenance of a location can be stopped
    timeSecondsLocationOverdue : 60, //default : 180. a time beetween the last action that confirms, that the location is maintained by ils, and the current timestamp
    timeIntervalSecondCheckHandlingLocationsOverdue : 40, //default : 60. ils checks if the maintained locations are overdue, send the request to the cs if the overdued location are maintained by the ls
    timeSecondsSinceLastNewUserWasFoundOnLocationOutdated : 300, //default : 300. Time since an els was found by a location description that a new user was appeared on the location
    timeMillisecondsSinceLastRequestUserCoordinatesOutdated : 1000, //if this time has passed since the last request of the user coordinates, then it is overdue
    timeSecondsCSConnectionOutstandingBetweenLastOutgoingAndLastIncomingMessageFromCS : 100, //default: 25 //it is necessary to reconnect with the cs, if the interval beetween the last outgoing and the last incoming messages is more then the value of this option
    timeIntervalSecondsSendingHeartbeatMessage : 15, //interval for sending the heartbeat message to the gServer
    timeIntervalSecondsDataConnectorNotConnectedConnectionToCSExpired : 15, //dafault:15 //if the connection to the central server is not in connected state for this time interval, then it is necessary to recconect to it
    timeIntervalSecondsAwaitingMessageCallbackExpired : 15, //when the waiting callback for the outcoming message with the unique id, that is not receive the answer from the cs will be expired
    timeIntervalExternalLocalServerBetweenReconnections : 3, //minimal interval between the two reconnections to the ls
    timeoutLocationHandlingAfterClientDisconnectedFromCS : 60, //default : 60. time in seconds after location handling will be expired, after the client was disconnected from the cs
    timeIntervalSecondsBetweenTwoOverheadCheckILS : 30, //the minimal interval between two checkings for the ils overhead,
    timeIntervalAfterChooseNewLSBeforeGetLSID : 6000, //time interval after a message for chosing a new ls was sent to the cs to request the new id of the ls
    timeIntervalAfterChooseNewLSBeforeTryToConnect : 8000, //time interval after a message for chosing a new ls was sent to the cs to connect with the new ls
    timeIntervalSecondsConnectionAttemptToCSOverdue : 10000, //time interval after the last disconnection when the connection to the cs becomes overdue(when the WebSocket connection to the cs trying to connect with the cs, but idle for really)
    timeIntervalILSAfterStopLocationHandlingToDisconnectAll : 1000 //time between the commend to stop location handling and disconnection from all the connected ELS and ILS (nearest to this lcoation)
};