//get string with the length as fillNum and zero filled prefix
/**
 * Description
 * @method getFStr
 * @param {} int
 * @param {} fillNum
 * @return CallExpression
 */
function getFStr(int, fillNum) {
    return ("00000000000000000000000000" + int).substr(-fillNum);
}

function _toInt(str) {
    return (str.toFixed !== undefined) ? str : ( (str+0) / 10 );    
}

//return shape hash depending on longitude and latitude
/**
 * Description
 * @method locationHash
 * @param {} longitude
 * @param {} latitude
 * @return CallExpression
 */
function locationHash( longitude, latitude )
{
    var latLon = quarterNumbers( longitude, latitude );
    return hashOfTheSquare(latLon[0], latLon[1]);
}

/**
 * Description
 * @method quarterNumbers
 * @param {} longitude
 * @param {} latitude
 * @return ArrayExpression
 */
function quarterNumbers( longitude, latitude ) {
    return [Math.ceil( longitude * 556.6) , (Math.ceil( latitude * 556.6))];
}

/**
 * return hash representation of the longitude and latitude:
 * prefix + longitude + latitude
 * prefix - depends on octothorpes of the longitude and latitude. Prefix is a one symbol
 * longitude - amplified to 6 symbols length longitudeShapeNum
 * latitude - amplified to 5 symbols length latitudeShapeNum
 * @method hashOfTheSquare
 * @param {} _longitudeShapeNum
 * @param {} _latitudeShapeNum
 * @return CallExpression
 */
function hashOfTheSquare(_longitudeShapeNum, _latitudeShapeNum)
{
    var prefix = "1"; //by default
    var octothorpeLon = _longitudeShapeNum < 0;
    var octothorpeLat = _latitudeShapeNum  < 0;
    if ( octothorpeLon === true && octothorpeLat === true ) { //get abs and prefix
        prefix = "2";
        _longitudeShapeNum = - _longitudeShapeNum;
        _latitudeShapeNum  = - _latitudeShapeNum;
    } else if ( octothorpeLon === true && octothorpeLat === false ) {
        _longitudeShapeNum = - _longitudeShapeNum;
        prefix = "3";
    } else if ( octothorpeLon === false && octothorpeLat === true ) {
        prefix = "4";
        _latitudeShapeNum = - _latitudeShapeNum;
    }
    return _toInt(prefix + getFStr(_longitudeShapeNum,6) + getFStr(_latitudeShapeNum,5));
}

module.exports = locationHash;