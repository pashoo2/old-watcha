//incoming message from the central server with a several messages

var Validator = Ajv;
var validator = (Validator()).compile;
var patterns = require("mainpatterns");

var schemas = {		
		vSchemaIncomingMessageFromCS_severalMessages : {
            type: "object",
            additionalProperties : false,
			required : ["_flFromCS", "_flSeveralMessages", "_messages"],
            properties: {
                _flFromCS: {"enum": [true]}, //flag that the message if for this application
                _flSeveralMessages: {"enum": [true]}, //flag indicates that there are a several messages into the message
                _messages: {
                    type: "array",
					additionalItems : false,
                    items:{
                            type: "object",
							additionalProperties : false,
							required : ["type", "kind", "body", "timestamp"],
                            properties: {
                                type: {type: "string", minLength:4, maxLength:30},
                                kind: {type: "string", minLength:4, maxLength:30},
                                uniqueID : {type:"number", minimum : 1, maximum : 1000000}, //an id of the message, which has been sent to the central server, and to which the central server has sent this message as the responce
                                body: {
									oneOf:[
										{type:"object", maxProperties: 150, minProperties: 1},
										{type:"number"},
										{type:"array", maxItems : 150, minItems : 1}
									]
								},
								timestamp : patterns.optVS_messageTimestamp
                            }
                    }
                }
            }
        },
		//incoming message from the central server
        vSchemaIncomingMessageFromCS_main : {
            type: "object",
            additionalProperties : false,
			required : ["_flFromCS","_flSeveralMessages","type","kind","body","timestamp"],
            properties: {
                _flFromCS: {"enum": [true]}, //flag that the message if for this application
                _flSeveralMessages: {"enum": [false]},
                type: {type: "string", minLength:4, maxLength:30},
                kind: {type: "string", minLength:4, maxLength:30},
                uniqueID : { //unique id of the incoming answer, that must be equal to the outcoming id of the sent request
                    anyOf : [
                        {type:"number", minimum : 1, maximum : 1000000},
                        {type:"string", minLength : 1, maxLength : 7}
                    ]
                }, //an id of the message, which has been sent to the central server, and to which the central server has sent this message as the responce
                body: {
					oneOf:[
						{type:"object", maxProperties: 50, minProperties: 1},
						{type:"number"},
						{
						    type:"array",
						    minItems: 1,
						    maxItems: 50,
						}
					]
				},
				timestamp : patterns.optVS_messageTimestamp
            }
        },
		//schema for peer-to-peer messages validation
		vSchemaIncomingMessageFromPeer_textMessage : {
            type: "object",
			additionalProperties : false,
			required : ["type","text","timestamp"],
			properties: {
                type: {
                	"enum": ["toPeer"]
                },
                text: 	   patterns.optVS_textMessage,
                timestamp: patterns.optVS_timestamp
            }
        }
};

var validators = {
	validatorIncomingMessageFromCS_main : validator(schemas.vSchemaIncomingMessageFromCS_main),  	
	validatorIncomingMessageFromCS_severalMessages : validator(schemas.vSchemaIncomingMessageFromCS_severalMessages),
	validatorIncomingMessageFromCS_textMessage : validator(schemas.vSchemaIncomingMessageFromPeer_textMessage),
};

module.exports = {
    validatorsMainPeer : validators    
};
