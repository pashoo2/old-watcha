require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"globalSettings":[function(require,module,exports){
/*global $*/
//all global settings for the client side
var _self = self || window;

var timestamps = require("timestamps");
var getCurrentTimestamp = timestamps.getCurrentTimestamp;

var prefixMessagesForGServer = "#&!^@",
    webSocketHeartbeatMessage = "$@!";

module.exports = {
	empty_user_id : 0, //the value, that is representation of an empty id of the user
	protocol :  (_self != null && _self.location != null && _self.location.protocol.indexOf("https") !== -1 ? "https" : "http"), //using protocol
    prefixMessagesForGServer : prefixMessagesForGServer, //prefix for all messages, that are for the gServer
    heartbeatMessagesForGServer : webSocketHeartbeatMessage, //ping/pong message for gServer, to prevent a connection timeout
    debug : true, //developer mode on = true, off = false or property is absents
    settingsDebug : { //settings for debugging
    	spottingMethod : "gps", //method to fix the user coordinates "gps" - by navigator.geolocation, "marker" - by leaflet marker position, "txtInputFields" - by text input fields from the main window, with id = 'lt' for lattitude, and 'ln' - longitude
    	randomLocationChangingMeters : 0, //if > 0, then the user location will be changed from 0 to this value each time when the user's coordinates will be requested
    	directionAngle : 0, //integer - angel between the current location and direction of moving. may get the 'random' value
    	doNotTakeLocationsFromDBOnLocading : true //if necessary to load all the locations, that was maintained before the client has closed
    },
    settingsMainPeer : { //settings for the main peer module
    },
	settingsP2P : { //settings for P2P functions
		maxDataConnections : 1000, //max DataConnections with other users
	    settingsPeerJS : { //settings for PeerJS
			    host : (self.LocalStart === true ? "127.0.0.1" : "watchasn.com"),
			    port : (self.LocalStart === true ? 80 : 8321),
			    path : "/",
			    key  : "peerjs",
			    secure : true,
			    turn : false,
			    debug : false
		}	
	},
	settingsConnectors : { //settings for both listeners - _connectorWithAppWorker and _connectorWithMainThread, must be equal for the both connectors 
		prefixCommandsListener : "_CAP" //prefix for commands, that are sending form the main thread to the AppWorkerConnector
	},
	settingsConnectorWithMainThread : {
	},
	settingsConnectorWithAppWorker : {
	},
	path : { //path to module
		appWorker : "/appWorker.js"	
	},
	logger : {
		showOnlyErrors : false,
		showOnlyWarnings : false
	},
	localforage : {
	    driver      : _self.localforage != null ? localforage.INDEXEDDB : undefined, // Force INDEXEDDB;
	    name        : 'gClient1.1',
	    storeName   : 'gClient1.1' // Should be alphanumeric, with underscores.
	},
	settingsMap : {
		mainMapID : "mainMap", //id of the DOM element, that will be contain the main map
		useAdditionalLayers : false, //it is necessary to use an additional layers
		delimetrToWindowSize : 2, //windth and height of the main map are defined accordingly as window.windth/delimetrToWindowSize and window.height/delimetrToWindowSize	
		intervalMillisecondsUpdateTheMap : 3000, //time interval, defines how often it is necessary to get the user coordinates and update the view of the main map
		defaultDuration : 2000, //default duration for MovingMarker, defines the time to move the marker to the new position
		settingsLeafletMap : { //options for Leaflet.map() http://leafletjs.com/reference.html#map-options
			zoom : 10,
			dragging: true,
			touchZoom: true,
			zoomControl:false,
			tap: true,
			inertiaDeceleration: 3000,
			inertiaMaxSpeed: 1500
		},
		tileOptionsDefault : {
			force_http: true,
			maxZoom: 17,
			unloadInvisibleTiles : true,
			updateWhenIdle : false
		},
	    settingsMarkerUser : { //setting for the Leaflet.js marker, representing the current user
            draggable : false,
            zIndexOffset : 100,
            riseOnHover : true,
            clickable : true
        },
        geocoders : {
        	mapbox : "pk.eyJ1IjoiZ2FwcCIsImEiOiJjaXQ5cnN5MXcwMDNrMnRxZDE2dWY0anczIn0.q_jnsGabsl7dwJ8SoHqkpg",
        	mapzen : "mapzen-rrQ3BzQ",
        	nominatim : null
        },
	    settingsMarkerAnotherUser : {} //setting for a Leaflet.js marker, representing another users
	},
	settingsILS : {
		minMaintainedLocations : 1, //The number of the minimum number of the maintained locations
		maxMaintainedLocations : 3, //The number of the maximum number of the maintained locations
		maxMaintainedUsers : 10, //deafault: 200. The maximum number of the users, that are located on the maintained locations
	},
	positionWatcher : {
		flUseGetCurrentPosition : false, //use Geolocation.getCurrentPosition() instead of Geolocation.watchPosition()
		watchingTimeout : 60000, //if errors were returned by Geolocation.watchPosition(), then after this time Geolocation.watchPosition() will be started once again
		optionsForGeolocation : {  //options for receiving the current coordinates
		  enableHighAccuracy : false, // like to receive the best possible results
		  timeout : 60000,   //time (in milliseconds) the device is allowed to take in order to return a position
		  maximumAge : Infinity     //in milliseconds of a possible cached position that is acceptable to return
		}	
	},
	glib : {
		locationHashCenterPointCalculation : { //options for the calculation of a center for location hash by the coordinates of the users, which are placed on this location
			minApropriateCoordDiff		: 25,
			locationRadiusFromCenter	: 25 //the radious from the center point as the bound of a location in degrees
		}
	},
	neighborUser : {
		keyMessagesHistory : "neighborUsersMessagesHistory",
		messageMessagingDenied : "__blocked__"
	},
	predefinedMessages : { //a predefined messages
		forCSOnOut : prefixMessagesForGServer + JSON.stringify({ //when the user has closed the browser
			type : "_gServer",
			timestamp : getCurrentTimestamp(), //random timestamp
			body : {
				type : "main",
				kind : "out",
				body : {},
				timestamp : getCurrentTimestamp()
			}
		}),
		forELSOnOut : JSON.stringify({ //notify about browser closing as ILS for ELS
			type : "fromLocalServer",
			kind : "out",
			body : {out:1},
			timestamp : getCurrentTimestamp()
		}),
		forILSOnOut : JSON.stringify({ //notify about browser closing as ILS for ILS
			type : "toILS",
			kind : "out",
			body : {out:1},
			timestamp : getCurrentTimestamp()
		})
	}
};
},{"timestamps":undefined}]},{},[]);
