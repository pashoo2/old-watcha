require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"ConnectorWithMainThread":[function(require,module,exports){
//Event Emitter
//handles the conection with the main thread

//required modules
var logger = require("logger").logger;
logger.namespace = "ConnectorWithMainThread";
var EventEmitter = require("eventemitter");
var CommandListener = require("CommandsListener").CommandsListener;
var EventHandler = require("CommandsListener").EventHandler;
var getCurrentTimestamp = require("timestamps").getCurrentTimestamp;

//settings
var settingsGlobal = require("globalSettings"); //global settings for the app
var settingsModule = settingsGlobal.settingsConnectorWithAppWorker; //settings exclusevly for this module
var settingsConnectors = settingsGlobal.settingsConnectors; //settings that must be the same for both connectors

//object for handling messages for and from the gClient
//commandsEmitter - object which emit a commands through the onmessage, and realize postMessage method to send commands to the emitter
//EventEmitter
//listHandlersMainP2P - handlers for messages form mainP2P object. The structure must be the same as for EventHandler 
/**
 * Description
 * @method ConnectorWithMainThread
 * @param {} commandsEmitter
 * @param {} mainP2P
 * @return 
 */
function ConnectorWithMainThread(commandsEmitter, mainP2P) {
    
    this.commandsEmitter = commandsEmitter; //set a reference to the global context
    
    //set a listeners for an events from the mainP2P
    this.mainP2P = mainP2P;
    this.mainP2PIncomingDataEmitter = mainP2P.incomingDataEmitter; //connector must emit an events throug this emmitter for sending a commands to the mainP2P
    this.mainP2POutcomingDataEmitter = mainP2P.outcomingDataEmitter;//connector must handle an events throug this emmitter for receiving a data from the mainP2P
  
    //handlers for an events form MainP2
    this.listHandlersUserMainP2P = null;
    this.eventsHandlerFromMainP2P =  null;
    
    //create listener of the commands from the main thread
    this.commandsPrefix = settingsConnectors.prefixCommandsListener; //get the prefix for a commands from the module settings
    var commandsListener = new CommandListener(this, commandsEmitter, this.listCommandsHandlers, this.commandsPrefix); //create the object of the listener
    this.commandsListener   = commandsListener;
    this.sendCommand        = commandsListener.sendCommand; //send commands throug this.workerGlobalContext and to the main thread

}

var ConnectorWithMainThreadProto = Object.create(new EventEmitter());


//set message port of the JSON shared worker, that execute JSON metods in a child thread
/**
 * Description
 * @method setJSONMessagePort
 * @param {} messagePort
 * @return 
 */
ConnectorWithMainThreadProto.setJSONMessagePort = function(messagePort){
    if ( JSON._setMessagePort !== undefined ) { //if the JSON method for setting a message port is available
        JSON._setMessagePort(messagePort);    
    }   
};

//set message port of the JSON shared worker, that execute JSON metods in a child thread
/**
 * Description
 * @method setDataConnectorMessagePort
 * @param {} messagePort
 * @return 
 */
ConnectorWithMainThreadProto.setDataConnectorMessagePort = function(messagePort) {
    if ( this.mainP2P.setPeerJSMessagePort != null ) { //if the JSON method for setting a message port is available
        this.mainP2P.setPeerJSMessagePort(messagePort);    
    }   
};

//set the handlers for the commands froRm the mainP2P to the User
//list will be transform into the fromat for EventHandler
//after an event has came from the mainP2P, the command will be sent to the mainThread. Main thread will call the method of the user object
//listHandlersUserFromMainP2P = { "eventName" : "commandForUser" }
/**
 * Description
 * @method setHandlersUserFromMainP2P
 * @param {} listHandlersUserFromMainP2P
 * @return 
 */
ConnectorWithMainThreadProto.setHandlersUserFromMainP2P = function(listHandlersUserFromMainP2P) {
    //handlers for an events form MainP2
    var thisListHandlersUserMainP2P =  this.listHandlersUserMainP2P = {}; //the list of the handlers for the ConnectorWithMainThread
    //form the handlers for the events 
    var eventsNames = Object.keys(listHandlersUserFromMainP2P); //list of an events from the incoming list
    for( var i = 0, len = eventsNames.length; i < len; i++ ) {
        var eventName = eventsNames[i]; //the name of a handled event
        //form the handler description in the format : ["methodToSendMessageToTheMainThread","typeOfTheMessageForTheUser", "kindOfTheMessageForTheUser"]
        thisListHandlersUserMainP2P[eventName] = ["sendCommand", "User", eventName]; //after an event has came from mainP2P the method sendCommand of the ConnectorWithMainThread will be called with the kind of the message = User, type = listHandlersUserFromMainP2P[_event], and an arguments from the emitted event
    }
    //set the listenerf from the mainP2P, that will be emitted through the instance of EventEmitter from the property of the ConnectorWithMainThread, with the name =  "mainP2POutcomingDataEmitter"
    this.eventsHandlerMainP2P = new EventHandler(this, this.mainP2POutcomingDataEmitter, thisListHandlersUserMainP2P); //set handlers for events from the MainP2P according to the list with an events hadlers this.handlersMainP2P
       
};

/**
 * command from the main thread to close this worker
 * @method closeWorker
 * @return 
 */
ConnectorWithMainThreadProto.closeWorker = function() {    
};


//define the handlers for a messages from the main thread
//structure for object: {messageType:{ messageKind : functionHandler }}
//messageType = type of a message
//messageKind = kind of a message
//functionHandler = function (messageBody){...}
ConnectorWithMainThreadProto.listCommandsHandlers = {
    "Main" : {
        "start" : "mainP2P.connect", //start connection of the client to the central server by calling MainP2P.connect(). Body = userID
        "close" : "closeWorker" //close the web worker
    },
    "Settings" : {
        "JSONMessagePort" : "setJSONMessagePort",  //message port of the json shared worker is received. This is message only for the ww side  
        "DataConnectorMessagePort" : "setDataConnectorMessagePort", //message port for connection the two sides of the data connector
        "ListHandlersUserFromMainP2P" : "setHandlersUserFromMainP2P"
    },
    "MainP2P" : {
        "data" : "mainP2PIncomingDataEmitter.emit" //emit an event throug the emitter of the mainP2P, that emits commands for the mainP2P    
    },
    "Debug" : { //commands for debugging must be sent as debugCommand("Debug", "ILS", "methodName", null, [arguments])
        "ILS" : "mainP2P.innerLocalServer",
        "ELS" : "mainP2P.externalLocalServer"
    }
};

ConnectorWithMainThread.prototype = ConnectorWithMainThreadProto;

module.exports = {
    ConnectorWithMainThread : ConnectorWithMainThread    
};
},{"CommandsListener":undefined,"eventemitter":undefined,"globalSettings":undefined,"logger":undefined,"timestamps":undefined}]},{},[]);
