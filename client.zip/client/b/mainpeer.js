require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"mainpeer":[function(require,module,exports){
		var EventEmitter = require("eventemitter");
		var timestamps = require("timestamps");
		var logger = require("logger").logger;
		logger.namespace = "mainPeer";
		var timeIntervals = require("timeIntervals");
		var validators = require("validatorsMainPeer").validatorsMainPeer;
		var commonlib = require("commonlib");
		var ExternalLocalServer = require("ExternalLocalServer").ELS;
		var InnerLocalServer = require("InnerLocalServer").ILS;
		var libMainP2P = require("libMainP2P");
		var EventHandler = require("CommandsListener").EventHandler;
		var Peer = require("DataConnector").DataConnector;
		var settings = require("globalSettings");
		
		//main variables--
		var globalObj;
		try{
			globalObj = self; //set the reference to the global object
		} catch(e){
			globalObj = window.self;
		}
		var getTimestamp = timestamps.getCurrentTimestamp;
		var isValidTimestamp = timestamps.isValidTimestamp;
		var isDataConnection = libMainP2P.isDataConnection;
		var returnMainP2P = libMainP2P.returnMainP2P;
		var setDataConnectionMetadataTimestamp = libMainP2P.setDataConnectionMetadataTimestamp;
		var isPeer = libMainP2P.isPeer;
		var isSocket = libMainP2P.isSocket;
		var isILS = libMainP2P.isILS;
		var isELS = libMainP2P.isELS;
		var getConnectionTimestamp = libMainP2P.getConnectionTimestamp;
		var csMaxTimeout = timeIntervals.timeSecondsCSConnectionOutstandingBetweenLastOutgoingAndLastIncomingMessageFromCS; //it is necessary to reconnect with the cs, if the interval beetween the last outgoing and the last incoming messages is more then the value of this option 
		var moduleSettings = settings.settingsMainPeer; //settings for this module
		
		//--main variables        

		/**
		 * @constructor
		 * @class MainP2P
		 * @classdesc handle connection to the cs, starting ILS, ELS for location handling constructor and messaging with the User object
		 * @method MainP2P
		 * @return 
		 */
		function MainP2P() {
		    this.myID = null;
		    this.myLocationHash = null;
		    this.currentUniqueID = 0; //the current value for identifying an ils and els instances
		    this.g_flClosedManually = false; //means that the connection to the main server closed manually
		    this.peerConnections = {}; //list of a connections with another users (peers): { userID : { p2p : dataConnection, ILS : dataConnection, NT : dataConnection } } - "p2p" - talkie connection with the User ID, or with the local server - "ELS", or no-typed connection ( unknown type, will be another type) - "NT"
		    this.innerLocalServer = null; //peer is not in the inner local server mode
		    this.externalLocalServer = null; //peer is not connected to a local server
		    this.mainServer = null;
		    //handle an events from the connector with the main thread. Handlers are defined by the list = this.listHandlersEvents
		    this.eventsHandlerMainP2P = new EventHandler(this, this.incomingDataEmitter, this.listHandlersEvents);

		    //bind the handlers to this context
		    this.intCheckConnectionState = this.intCheckConnectionState.bind(this);
		    this.onOpen = this.onOpen.bind(this);
		    this.outstanding = this.outstanding.bind(this);
		    this.onELSClosed = this.onELSClosed.bind(this);
		    this.onNewUserLocation = this.onNewUserLocation.bind(this);
			
			//set some flags to determine the state
			this.flELSMustBeOpened = false; //set the flag that the els must be opened			
			this.flILSMustBeOpened = false; //set the flag that the els must be opened
		    this.mainServerBeenOpened = false;
		    
		    this.timestampLastIncomingFromCS = getTimestamp(); //timestamp when the last message from the cs has came
		    this.timestampLastOutcomingCS = 0; //timestamp when the last unanswered message for the cs was sent.
		    
		    this.sendAnswer = this.sendAnswer.bind(this);
		    this.sendOffer  = this.sendOffer.bind(this);
		    		    
		}

		var MainP2PProto = Object.create(new EventEmitter());
		MainP2PProto.constructor = MainP2P;

		//SERVICE METHODS
		
		
		/** 
         * main connection instance has opened
         * @event mainServerOpened
        */
        
        /** 
         * the main server has closed
         * @event mainServerClosed
        */
        
        /** 
         * change the working mode of the main connection to innerServer or inner server mode was closed
         * @event mainServerModeChanged
        */
        
        /** 
         * try to create a new instance of External local server
         * @event elsOpen
        */
        
        /**
         * on connected to the cs once again
         *@event connectedAgain 
         */
        
        /** 
         * incoming message from the cs, messageType - type of the message. messageKind = unknown, if an unknown type of the message
         * @event messageFromCS(uniqueID)_[messageType]
         * @property messageKind kind of the message
         * @property messageBody body of the message
         * @property uniqueID uniqueID of the message, if exists
        */
        
        /** 
         * when a message from a peer has been received
         * @event messageP2P
         * @property messageText   text from the message
         * @property messageObject full object
        */
        
        /** 
         * on incoming description of the user location in format : { userID : { lat, lng, coordsTimestamp } }
         * @event locationDescription
        */
		
		/**
		 * set the message port for the Data Connector instance on the ww(thet has started in a WebWorker) side to connect with DataConnector on the main thread side
		 * @method setPeerJSMessagePort
		 * @param {} messagePort
		 * @return 
		 */
		MainP2PProto.setPeerJSMessagePort = function(messagePort) {
		    var self = returnMainP2P(this);
		    self.messagePortPeerJS = messagePort;
		    if (isPeer(self.mainServer) === true) { //if PeerJS instance is already exists
		        self.mainServer.setMessagePort(messagePort);
		    }
		};

		MainP2PProto.incomingDataEmitter = Object.create(new EventEmitter()); //emit an events received from the main thread trough the connector with the main thread
		
		//emitted events:
		//"userCooredinates" - received the user coordinates 
		MainP2PProto.outcomingDataEmitter = Object.create(new EventEmitter()); //emit an events as the commands for commander or for the main thread
		/*emitted events:
		"userCooredinates" - request of the user coordinates
		"connectionCSState"(state string) - send the state of the current connection to the central server
		"connect"(userID) - will emit when the connection to cs will has been established with the given userID
		*/
		
		//list of a handlers for an events from the connector with the main thread
		MainP2PProto.listHandlersEvents = {
			"sendOffer"    : "sendOffer",	//on send offer for another user
			"sendAnswer"   : "sendAnswer",  //on send answer on offer from another user
			"browserClose" : "browserClose" //on browser close
		};

		//MESSAGING WITH MAIN THREAD

		/**
		 * Description
		 * @method getUserCoordinates
		 * @param {} callback
		 * @param {} flImmidiate
		 * @return 
		 */
		MainP2PProto.getUserCoordinates = function(callback, flImmidiate) {
		    var self = returnMainP2P(this);
		    self.outcomingDataEmitter.emit("connectionCSState", "Get the current coordinates");
		    if ( flImmidiate === true
		    	|| self.incomingDataEmitter.listeners("getCoordinates").indexOf(callback) === -1 ) { //if the callback was not found into the list of the listeners for the event "getCoordinates"
			        if (self.outcomingDataEmitter.emit("getCoordinates") !== false) { //send the command to get the current user coordinates
			            self.incomingDataEmitter.once("getCoordinates", callback); //when the user coordinates will be received, the callback will be called    
			        } else { //if can't to get the user's coordinates
				    	callback(false);	
				    }
		    }
		};
		
		/**
		 * Description
		 * @method getUserDescription
		 * @param {} callback
		 * @param {} flImmidiate
		 * @return 
		 */
		MainP2PProto.getUserDescription = function(callback, flImmidiate) {
		    var self = returnMainP2P(this);
		    if ( flImmidiate === true
		    	|| self.incomingDataEmitter.listeners("getDescription").indexOf(callback) === -1 ) { //if the callback was not found into the list of the listeners for the event "getDescription"
			        if (self.outcomingDataEmitter.emit("getDescription") !== false) { //send the command to get the current user coordinates
			            self.incomingDataEmitter.once("getDescription", callback); //when the user coordinates will be received, the callback will be called    
			        } else { //if can't to get the user's coordinates
				    	callback(false);	
				    }
		    }
		};

		//CENTRAL SERVER CONNECTION 


		/**
		 * form a message from the peer to the cs. Add the required headers to a message
		 * message - message for the cs
		 * @method formMessageForCS
		 * @param {} message
		 * @return ObjectExpression
		 */
		MainP2PProto.formMessageForCS = function(message) {

		    //check the required properties
		    if (commonlib.hasProperty(message, "type") === false || commonlib.hasProperty(message, "kind") === false || commonlib.hasProperty(message, "body") === false || commonlib.isEmptyObject(message.body) === true) {
		        logger("One or more required properties are absent in the body of the message for the cs");
		        return null;
		    }

		    return { //message header
		        type: "_gServer",
		        body: message,
		        timestamp: getTimestamp()
		    };
		};


		/**
		 * check if the method self.mainServer.socket.send is available
		 * return true or false
		 * @method checkMethodSocketSend
		 * @return LogicalExpression
		 */
		MainP2PProto.checkMethodSocketSend = function() {
		    var self = returnMainP2P(this);
		    return isPeer(self.mainServer) === true //not connected to the central server
		        && isSocket(self.mainServer.socket) === true; //no soket instance
		};


		/**
		 * put the message for the central server to the queue
		 * @method putMessageForCSToQueue
		 * @param {} message
		 * @return 
		 */
		MainP2PProto.putMessageForCSToQueue = function(message) {
		    var self = returnMainP2P(this);

		    if (self.isConnected() === true) { //check the connection to the central server
		        if (message !== null) { //if the message is valid
		            try { //try to send it to the cs
		                var connectionToCS = self.mainServer.socket;
		                connectionToCS.send(message); //send the message to the cs
		                return;
		            } catch (e) {
		                logger(e);
		            }
		        }
		    }

		    if (commonlib.hasProperty(self, "queueMessagesToCS") === false) {
		        self.queueMessagesToCS = []; //new queue for the messages, that cannot be sent
		    }
		    self.queueMessagesToCS.push(message); //put the message to the queue
		    self.removeListener("mainServerOpened", self.sendMessageToCS); //remove the listener if exists
		    self.once("mainServerOpened", self.sendMessageToCS); //when a connection to the cs will be opened, send a messages from the queue   
		};


		/**
		 * uppate the timestamp when the oldest outcoming message has gone to the central server
		 * @param
		 * @method updateTimestampLastOutgoingMessageForCS
		 * @return 
		 */
		MainP2PProto.updateTimestampLastOutgoingMessageForCS = function() {
			this.timestampLastOutcomingCS = getTimestamp(); //timestamp when the last message was sent to the cs	
		};

		/**
		 * send a message to the central server
		 * return false if error
		 * @method sendMessageToCS
		 * @param {} message - message to send
		 * @param {} flWithoutQueue - do not put the message to the queue and send it immidiately
		 * @return 
		 */
		MainP2PProto.sendMessageToCS = function(message, flWithoutQueue) {
		    var self = returnMainP2P(this);
		    if (self.checkMethodSocketSend() === true) { //check socket.send method. It is for sending a messages to the cs
		        if (self.isConnected() === false) { //not connected to the cs
		            if ( flWithoutQueue !== true ) {
		            	self.putMessageForCSToQueue(message);
		            }
		        } else {
		        	
		            var connectionToCS = self.mainServer.socket;
					
		            if (flWithoutQueue !== true
		            	&& Array.isArray(self.queueMessagesToCS) === true 
		            	&& self.queueMessagesToCS.length > 0) { //send all of the queued messages
			                var messagesQueue = self.queueMessagesToCS;
			                var indexLastSent; //index of the last message that was sent to the cs
			                for (var i = 0, len = messagesQueue.length; i < len; i++) {
			                    var messageForCS = self.formMessageForCS(messagesQueue[i]);
			                    if (self.isConnected() === true) { //check the connection to the central server
			                        if (messageForCS !== null) { //if the message is valid
			                            try {
			                                connectionToCS.send(messageForCS); //send the message to the cs
			                                self.updateTimestampLastOutgoingMessageForCS();
			                            } catch (e) {
			                                break; //can't send the message, may be connection is closed    
			                            }
			                        }
			                        indexLastSent = i;
			                    } else { //stop sending
			                        break;
			                    }
			                }
			                //delete messages that have been sent to the cs from the queue
			                if (indexLastSent != null) { //some messages have been sent
			                    if (indexLastSent === messagesQueue.length) { //all have been sent
			                        self.queueMessagesToCS = []; //delete all messages from the queue    
			                    } else { //delete only a messages that have been sent
			                        messagesQueue.splice(0, indexLastSent + 1);
			                    }
			                }
	
			                if (message != null) { //if the current message is not empty send it to the cs
			                    self.sendMessageToCS.call(self, message); //it is necessary to check the connection satatus
			                }

		            } else if (message != null) { //if the messages queue is empty and the current message is not empty
		                messageForCS = self.formMessageForCS(message); //add headers
		                if (messageForCS != null) { //the resulted message is not empty
		                    try {
		                        connectionToCS.send(messageForCS); //send the message to the cs
		                        self.updateTimestampLastOutgoingMessageForCS();
		                        logger("Mesage with the kind " + message.kind + " was sent to the central server.");
		                    } catch (e) { //can't send the message, may be connection to the cs is closed
		                        logger(e);
		                        if ( flWithoutQueue !== true ) { //do not put to the queue
		                        	self.putMessageForCSToQueue(message); //put the message to the queue, if the connection to the cs is really closed   
		                        }
		                    }
		                }
		            }

		        }
		    }
		};

		//request the difference between the server time and the time at the client
		/**
		 * Description
		 * @method messageForCS_updateUTCMillisecondsDiffirence
		 * @param {} clientDate
		 * @return ObjectExpression
		 */
		MainP2PProto.messageForCS_updateUTCMillisecondsDiffirence = function(clientDate) {
		    return {
		        type: "main",
		        kind: "getTimeUTCDifference",
		        body: clientDate
		    };
		};


		/**
		 * message from the cs with a number of milliseconds from 01.01.2010
		 * return false if the message is not valid
		 * @method onTimeUTCDifference
		 * @param {} _dates
		 * @param {} callback
		 * @return 
		 */
		MainP2PProto.onTimeUTCDifference = function(_dates, callback) {
		    var self = returnMainP2P(this);
		    self.outcomingDataEmitter.emit("connectionCSState", "Time offset was set");
		    var clReceivingDate = Date.now(); //time when the client has received the server's response to his request
		    var clSendingDate = Date.parse(_dates.cDate); //when the client has sent the request
		    var srvSendingDate = Date.parse(_dates.sDate); //when the server has sent the responce and calculate the value of diff1
		    var diff1 = _dates.difference; //time between sending the client's request and receiving it on the server, calculated with the value of time offset
		    var diff2 = clReceivingDate - srvSendingDate; //time between sending the server's response and receiving it on the client, calculated with the value of time offset
		    var generalDiff = clReceivingDate - clSendingDate; //time between sending the client's request and receiving the server's responce without the value of time offset
		    var offset = (diff2 + diff1 - generalDiff) / 2; //calculated offset. Client time = server time - offset. Timestamp = client time + offset
		    timestamps.setClientServerUTCTimeDifference(Math.floor(offset)); //set the value of the variable with the time difference in milliseconds
		    if (typeof(callback) === "function") {
		        callback.apply(self); //callback with the resulted offset
		    }
		    logger("The time difference with the cs was set");
		    callback = null;
		};


		/**
		 * send the request for updating the time difference between the central server and the client
		 * @method sendUpdateUTCMillisecondsDiffirence
		 * @return 
		 */
		MainP2PProto.sendUpdateUTCMillisecondsDiffirence = function() {
		    var self = returnMainP2P(this);
		    if (self.isConnected() === true) { //check if connected to the cs
		        var currentDate = new Date();
		        var milliseconds = Date.UTC(currentDate.getUTCFullYear(), currentDate.getUTCMonth(), currentDate.getUTCDate(), currentDate.getUTCHours(), currentDate.getUTCMinutes(), currentDate.getUTCSeconds(), currentDate.getUTCMilliseconds());
		        self.outcomingDataEmitter.emit("connectionCSState", "Request information");
		        self.sendMessageToCS(
		        	self.messageForCS_updateUTCMillisecondsDiffirence({ //form the message
			            cDate: currentDate.toISOString(), //and the current date in the string format
			            cMilliseconds: milliseconds //send to the server number of the milliseconds beetween 01.01.1970 00:00:00 and the current date
			        }), true
		        ); //send the message with request to get difference(true - this message must be sent immidiately, without queue)
		    }
		};


		/**
		 * set the variable "timeUTCMillisecondsDifference" value. Difference in time between the central server and the client
		 * if callback, then calback(timeDifference)
		 * @method updateUTCMillisecondsDiffirence
		 * @param {} _callback
		 * @return 
		 */
		MainP2PProto.updateUTCMillisecondsDiffirence = function(_callback) {
		    var self = returnMainP2P(this);
		    //trying to update the time difference
		    clearInterval(self.intTrySendingUpdateUTCMillisecondsDiffirence);
		    self.sendUpdateUTCMillisecondsDiffirence();
		    self.intTrySendingUpdateUTCMillisecondsDiffirence = setInterval(self.sendUpdateUTCMillisecondsDiffirence.bind(self), timeIntervals.timeIntervalUpdateUTCMillisecondsDiffirence);
		    self.once("messageFromCS_timeUTCDifference", function() { //on incoming message from the cs with the time difference on the client and the cs
		        clearInterval(self.intTrySendingUpdateUTCMillisecondsDiffirence); //no longer need to update the time difference
		        self.onTimeUTCDifference.call(self, arguments[1], _callback);
		        _callback = null;
		    });
		};

		
		/*
			priority of incoming messages from the cs for a messages kinds
		*/
		MainP2PProto.messegaesPriorityToILS = InnerLocalServer.prototype.messagesFromCSPriority;
		MainP2PProto.messegaesPriorityToELS = ExternalLocalServer.prototype.messagesFromCSPriority;
		
		/**
		 * handle an incoming messages from cs
		 * @method onMessageFromCS
		 * @param {} data
		 * @return 
		 */
		MainP2PProto.onMessageFromCS = function(data) {
			
			// try{
			// 	if (data.kind.indexOf("ping") >= 0) {
			// 		console.log("onMessageFromCS ping");
			// 		console.log(data.body);
			// 	}
			// } catch(e){}
			
		    if (commonlib.hasProperty(data, "_flFromCS") === true) {
		        var self = returnMainP2P(this);
		        
		        self.timestampLastIncomingFromCS = getTimestamp(); //timestamp when the last message from the cs has came
		        
		        var res, flSeveralMessages, vFunc;
		        if (commonlib.hasProperty(data, "_flSeveralMessages") === true 
		        	&& data["_flSeveralMessages"] === true) { //there are several messages into this one
		            vFunc = validators.validatorIncomingMessageFromCS_severalMessages;
		            res = vFunc(data);
		            flSeveralMessages = true;
		        } else { //if only the one message
		            vFunc = validators.validatorIncomingMessageFromCS_main;
		            res = vFunc(data);
		        }
		        if (res === false) { //unknown message format
		            self.emit("messageFromCS_unknown", data); //emit the special event "messageFromCS_unknown"
		            logger("Unknown format of the incoming message from the central server");
		            logger("Incoming message :");
		            logger(data);
		            logger("Error : " + vFunc.errors);
		            return;
		        }

		        var postfixForEvent; //this incoming message is response of the central server to the client request with the ID = uniqueIDOfTheMessage

		        if (flSeveralMessages !== true) { //if only the on message
		            logger("Incoming message form cs with the kind = " + data.kind);
		            postfixForEvent = data.uniqueID != null ? "(" + data.uniqueID + ")" : "";
       				self.emit("messageFromCS" + postfixForEvent + "_" + data.type, data.kind, data.body, data.timestamp); //fire event messageFromCS(uniqueID)_typeFromMessage
		        } else { //if there are several messages
		            var messages = data["_messages"];
		            var messagesIndexes = Object.keys(messages);

		            //sorting messages - messages, that fired firstly - no type, secondly - to ils, thirdly - to els
		            var sortedMessages = {
		                another: [], //no-typed
		                toILS: [], //messages for ils
		                toELS: [] //messages for els
		            };

		            for (var i = 0, len = messagesIndexes.length; i < len; i++) { //for an each message
		                var msg = messages[messagesIndexes[i]]; //get the one message from the list of incoming messages
		                var msgType = (msg.type + "");
		                if (msgType.indexOf("ELS") !== -1) { //message for ELS
		                    sortedMessages.toELS[sortedMessages.another.length] = msg;
		                } else if (msgType.indexOf("ILS") !== -1) { //message for ILS
		                    sortedMessages.toILS[sortedMessages.another.length] = msg;
		                } else { //message with no type
		                    sortedMessages.another[sortedMessages.another.length] = msg;
		                }
		            }

		            //fire a no-typed messages
		            var ind = 0;
		            while (ind++ < 3) { //for 3 types of a messages : another(non-typed), toILS, toELS
		                var messagesType;
		                var flUseUniqueID = true; //is necessary to use unique id from the message, when the event will be fired
		                if (ind === 1) { //first messages = no-typed
		                    messagesType = "another";
		                    flUseUniqueID = false;
		                } else if (ind === 2) { //second messages = for ILS
		                    messagesType = "toILS";
		                } else { //first messages = for ELS
		                    messagesType = "toELS";
		                }
		                
		                var messagesToFire = sortedMessages[messagesType]; //list of a messages with the given type
		                var messagesByPriorities = {}; //list with the messages { priority : [message1, ... , messageN] } - messages, sorted by priorities
		                var priorities = []; //list with the priorities
		                for (i = 0, len = messagesToFire.length; i < len; i++) {
		                    msg = messagesToFire[i];
		                    
		                    var msgKind = msg.kind;
		                    var msgPriority = -1; //The default priority for a messages. Higher priority is better
		                    
		                    if ( messagesType === "toILS" ) {
		                    	msgPriority = this.messegaesPriorityToILS.indexOf(msgKind);	
		                    } else if ( messagesType === "toELS" ) {
		                    	msgPriority = this.messegaesPriorityToELS.indexOf(msgKind);	
		                    }
		                    
		                    msgPriority = msgPriority + 1; //increase the message priority to start it from 0		                    
		                    priorities[priorities.length] = msgPriority; //add the message priority to the list of all priorities
		                    
		                    if ( messagesByPriorities[msgPriority] === undefined ) { //if the messages with this priority are absent
		                    	messagesByPriorities[msgPriority] = [msg];	
		                    } else { //add the message to the list
		                    	messagesByPriorities[messagesByPriorities[msgPriority].length] = msg;	
		                    }
		                    		                    
		                }
		                
		                priorities.sort(commonlib.compareBHigherThenA); //sort the messages priorities from N to 0 (in reverse order)
		                for (i = 0, len = priorities.length; i < len; i++) { //emit messages by it order
		                	var messagesWithPriority = messagesByPriorities[priorities[i]];
		                	for (var ii = 0, len1 = messagesWithPriority.length; ii < len1; ii++) {
			                	msg = messagesWithPriority[ii]; //chose a messages with the priority
			                    msgKind = msg.kind; //message kind
			                	postfixForEvent = (flUseUniqueID !== false && msg.uniqueID != null) ? "(" + msg.uniqueID + ")" : ""; //postfix for the firing event by the message unique id
			                    logger("Incoming message form cs with the kind = " + msgKind);
			                 	self.emit("messageFromCS" + postfixForEvent + "_" + msg.type, msgKind, msg.body, data.timestamp); //emit the event, according to the message type
		              		}
		                }
		        	}
		    	}

			}
		};
		
		/**
		 * Description
		 * @method removeEventListeners
		 * @param {} mainServer
		 * @return 
		 */
		MainP2PProto.removeEventListeners = function(mainServer) {
		    var self = returnMainP2P(this);
		    var _server = mainServer || self.mainServer;
		    if (_server != null && _server.removeListener) {
		        _server.removeListener("connection", self.onDataConnection);
		        _server.removeListener("error", self.onConnectionToMainServerError);
		        _server.removeListener("disconnected", self.onConnectionToMainServerDisconnected);
		        _server.removeListener("close", self.onConnectionToMainServerClosed);
		        _server.removeListener("open", self.onConnectionToMainServerOpenAgain);
		    }
		};


		/**
		 * fired, when the connection to the cs will be opened again
		 * @method onConnectionToMainServerOpenAgain
		 * @return 
		 */
		MainP2PProto.onConnectionToMainServerOpenAgain = function() {
		    var self = returnMainP2P(this);
		    if (self.intReconnectToCS != null) { //timeout to recconnect to the cs
		        self.intReconnectToCS = null;
		        clearTimeout(self.intReconnectToCS);
		    }
		    logger("Connection to the cs opened again");
			self.outcomingDataEmitter.emit("connectionCSState", "Connection to the server was opened again");
		    if (isILS(self.innerLocalServer) == false) { //if the ils was closed
		        self.startInnerLocalServer();
		    }
		    
		    setTimeout(
		    	function() { //emit connectedAgain after the pause
		    		if ( self.mainServer.disconnected !== true ) { //if not disconnected since 1 second after the repeated connection
		    			var timeAfterDisconnection = ( self.timestampDisconnection != null ) ? ( getTimestamp() - self.timestampDisconnection ) : 0; //calculate the time passed after the disconnection
			    		self.timestampDisconnection = null; //reset the timestamp when the disconnection has been
			    		self.emit("connectedAgain", timeAfterDisconnection); //first - emit the event to allow make some reaction for els and ils
						self.sendMessageToCS(); //send the queued messages to the central server if exists
		    		}
		    	}
		    	, 1000);
		};


		/**
		 * set the listeners for the events of the connection with the cs
		 * @method setEventListeners
		 * @param {} mainServer
		 * @return 
		 */
		MainP2PProto.setEventListeners = function(mainServer) {
		    var self = returnMainP2P(this);
		    var _server = mainServer || self.mainServer;

		    if (self.checkMethodSocketSend() === false) { //function for sending messages to the sentral server is absent
		        throw new Error("mainServer in not an instance of Peer or mainServer.socket is not an instance of Socket or method mainServer.socket.send is absent");
		    }

		    //clean the list of an old event listeners
		    self.removeEventListeners(mainServer);

		    //set the new listener
		    _server.on("connection", self.onDataConnection, self);
		    _server.on("error", self.onConnectionToMainServerError, self);
		    _server.on("disconnected", self.onConnectionToMainServerDisconnected, self);
		    _server.once("close", self.onConnectionToMainServerClosed, self); //when connection to the main server has closed manually
		    _server.once("open", self.onConnectionToMainServerOpenAgain, self);

		    //set the event listener for an icoming messages from the cs
		    _server.socket.removeListener("message", self.onMessageFromCS, self);
		    _server.socket.on("message", self.onMessageFromCS, self);
		};


		/**
		 * connect to the central server
		 * @method connect
		 * @return 
		 */
		MainP2PProto.connect = function(args) {
		    var self = returnMainP2P(this);
		    self.outcomingDataEmitter.emit("connectionCSState", "Connecting to the central server");
		    if (self.isConnected() === false 
		    	&& self.g_flClosedManually === false) {
			        //if MainP2P instance is not closed manually
			        var peerJS = self.mainServer;
			        logger("connecting to the server");
			        if (isPeer(peerJS) === true 
			        	&& peerJS.disconnected === true //if peerJS connection is disconnected
			            && self.mainServerBeenOpened === true) {
			            	peerJS.reconnect(); //try to reconnect
			        } else if (self.mainServerBeenOpened === false) { //create the new connection with the PeerJS
			            //!!!!self.mainServer = new Peer({key: 'yrw76owxr2uik9'}); //peer.js connection constructructor
			            if (isPeer(self.mainServer) === true) { //close the previous instance of the PeerJS
			                peerJS.removeAllListeners();
			                peerJS.destroy(); //destroy the previous connection
			                self.mainServer = null;
			            }
			            if ( Array.isArray(args) === true ) {
			            	var userID		= args[0]; 
			            	var acessToken	= args[1];
			            }
			            peerJS = self.mainServer = new Peer(self.messagePortPeerJS);
			            //set interval to check if the main connection is established
			            self.clearIntervals();
			            self.intCheckConnection = setInterval(self.intCheckConnectionState, timeIntervals.timeIntervalMainP2PCheckConnectionFirstTime); //check the first connection to the central server
			            peerJS.g_MainP2P = self;
			        } else {
			            return;
			        }
			        //set listeners to the open and disconnected events
			        peerJS.removeListener("open", self.onConnectionToMainServerEstablished);
			        peerJS.removeListener("disconnected", self.intCheckConnectionState);
			        peerJS.once("open", self.onConnectionToMainServerEstablished);
			        peerJS.once("disconnected", self.intCheckConnectionState);
		    }
		};
		
		/**
		 * reconnect to the central server
		 * @method reconnect
		 * @return 
		 */
		MainP2PProto.reconnect = function() {
			 var self = returnMainP2P(this);
			 self.outcomingDataEmitter.emit("connectionCSState", "Reconnect to the central server");
			 logger("Reconnect to the cs");
			 self.mainServer.disconnect();
			 if ( self.mainServer.listeners('disconnected', true) !== true ) { //if there is no listeners for a disconnected event
			 	self.setTimeout(self.intCheckConnectionState, timeIntervals.timeIntervalMainP2PCheckConnectionFirstTime); //call the method for checking the connection ( with the cs) state manually after 100 milliseconds	
			 }
		};


		/**
		 * check if the client is connected to the cs
		 * @method intCheckConnectionState
		 * @return 
		 */
		MainP2PProto.intCheckConnectionState = function() {
		    var self = returnMainP2P(this);
		    if (this.g_flClosedManually === true) {
		        return;
		    }
		    var flDisconnected = (self.isConnected() === false);
		    
		    if ( flDisconnected === false //if not disconnected
				&& self.timestampLastOutcomingCS !== 0 ) { //then check the timeout of the last outcoming message
			    	if ( (self.timestampLastOutcomingCS - self.timestampLastIncomingFromCS) > csMaxTimeout ) { //if too much time has come since the last incoming message from the cs
						self.timestampLastIncomingFromCS = getTimestamp() + 10; //add the additional ten seconds for establish the new connection to the central server
						self.mainServer.reconnect(); //try to reconnect to the main server
				        logger("intCheckConnectionState. Reconnecting to the cs by timeout");				    							
			    	}
			}
				
			//check the current state of the els
			var els = self.externalLocalServer;
			if (self.flELSMustBeOpened === true //flag means the ELS must be opened
				&& (isELS(els) === false
					|| els.isClosed() === true) ) { //if closed
						self.closeELS(); //close the previous ELS
					    if (self.g_flClosedManually === false) { //if the main connection was not closed
				        self.connectToELS(); //start the ELS again    
					    }	
			}
			
			//check the current state of the ils
			var ils = self.innerLocalServer;
			if ( self.flILSMustBeOpened === true //flag means the ILS must be opened
				 && (isILS(ils) === false
					|| ils.isClosed() === true) ) { //if closed
						self.closeInnerLocalServer(); //close the previous
					    self.startInnerLocalServer();	
			}
		};


		/**
		 * is connection to main server opened
		 * return true if connected to the main server
		 * @method isConnected
		 * @return 
		 */
		MainP2PProto.isConnected = function() {
		    var self = returnMainP2P(this);
		    if ( typeof(self.myID) === "number" 
		    	&& self.g_flClosedManually !== true
		    	&& isPeer(self.mainServer) === true
		    	&& self.mainServer.destroyed !== true ) { //the connection to the main server is active 
		    		return true;
		    } else {
		    	return false;
		    }
		};


		/**
		 * when the connection to the central server had established and the id was received
		 * @method onConnectionToMainServerEstablished
		 * @param {} id
		 * @return 
		 */
		MainP2PProto.onConnectionToMainServerEstablished = function(id) {
		    logger("connected with ID = " + id);
		    var self = returnMainP2P(this);
		    self.outcomingDataEmitter.emit("connectionCSState", "Get the user id from the central server");
		    var peerJS = self.mainServer;
		    self.mainServerBeenOpened = true; //flag means that the main server already has been opened at least a once
		    peerJS.removeListener("open", self.onConnectionToMainServerEstablished);
		    peerJS.removeListener("disconnected", self.intCheckConnectionState); //remove the listener for the "disconnected" event
		    self.clearIntervals(); //clear the previous interval
		    self.intOutstanding = setInterval(self.outstanding, timeIntervals.timeIntervalMainP2POutstanding);
		    self.intCheckConnection = setInterval(self.intCheckConnectionState, timeIntervals.timeIntervalMainP2PCheckConnection);
		    self.setEventListeners();
		    self.myID = id; //id of the user
		    self.updateUTCMillisecondsDiffirence(self.onOpen); //update difference between time on the server and client
		};
		
		/**
		 * return the id of the user
		 * @method getUserID
		 * @return MemberExpression
		 */
		MainP2PProto.getUserID = function() {
			return returnMainP2P(this).myID;
		};


		/**
		 * on connection to the cs is opened and the time difference is considered
		 * @method onOpen
		 * @return 
		 */
		MainP2PProto.onOpen = function() {
		    var self = returnMainP2P(this);
		    self.emit("mainServerOpened");
		    if (self.intOutstanding == null) { //start the outstanding procedure
				
		    }
		    self.outcomingDataEmitter.emit("connectionCSState", "Connected the central server");
		    
		    self.startInnerLocalServer(
		    	function(){ //executed after the ILS will be opened
			    	self.connectToELS(); //connect to external local server
				    self.outcomingDataEmitter.emit("onConnectedToCS", self.myID); //emit the event that we have connected to the cs
				    logger("MainP2P opened");		
		    	}
		    ); //start the inner local server before starting ELS
		};


		/**
		 * close MainP2P instance, all connections, els and ils
		 * @method close
		 * @return 
		 */
		MainP2PProto.close = function() {
		    var self = returnMainP2P(this);
		    self.g_flClosedManually = true;
		    logger("Closing MainP2P");
		    if (self.mainServer != null && isPeer(self.mainServer) === true) {
		        self.mainServer.destroy(); //destroy the connection to the cs
		    }
		    self.onConnectionToMainServerDisconnected();
		};


		/**
		 * when connection to the main server has closed manually
		 * @method onConnectionToMainServerClosed
		 * @return 
		 */
		MainP2PProto.onConnectionToMainServerClosed = function() {
		    var self = returnMainP2P(this);
		    // self.close();
		    self.outcomingDataEmitter.emit("connectionCSState", "Connection the central server has been closed");
		};


		/**
		 * on error from the connection to the cs
		 * @method onConnectionToMainServerError
		 * @param {} e
		 * @return 
		 */
		MainP2PProto.onConnectionToMainServerError = function(e) {
		    var self = returnMainP2P(this);
		    logger(e);
		    self.outcomingDataEmitter.emit("connectionCSState", "Connection error " + e.message);
		};
		
		/**
		 * update the timestamp when disconnected from the cs
		 * @method updateTimestampDisconnected
		 * @return 
		 */
		MainP2PProto.updateTimestampDisconnected = function(){
			var ils = this;
			var currentTimestamp = getTimestamp();
		    ils.timestampDisconnection =  ( ils.timestampDisconnection == null || ils.timestampDisconnection > currentTimestamp ) ? currentTimestamp : ils.timestampDisconnection;
		};

		/**
		 * when connection to the main server has closed because of error, or when closed manually
		 * @method onConnectionToMainServerDisconnected
		 * @return 
		 */
		MainP2PProto.onConnectionToMainServerDisconnected = function() {
		    var _self = returnMainP2P(this);
		    if (_self.mainServer == null
		    	|| _self.mainServer.disconnected === true) { //if not disconnected from the central server
			        _self.emit("mainServerClosed");
	
			        if (_self.g_flClosedManually === true) { //if closed manually
			            if (_self.mainServer != null
			            	&& _self.mainServer.destroyed === false) { //destroy all the data received and sent threw the main server connection
			                	_self.mainServer.destroy();
			            }
			            _self.closeELS();
		            	_self.closeInnerLocalServer();
		            	
		            	setTimeout(function() {
		            		_self.mainServer = null;
				            _self.removeAllListeners(); //remove all event listeners
				            _self.removeEventListeners(); //remove all the listeners from the connection to the cs
			            	
				            _self.clearIntervals(); //clear all the existing intervals
				            _self.closeConnections(true); //close all connections with another users. if connection to the central server was closed manually, than also delete a descriptions of a connections
				            //connections to all the peers will have been automatically restored by the procedure, called outstanding, when it will detect a messages history or queue of not sent messages to a peer
						}, 1000);
		            } else {
			        	_self.mainServer.removeListener("open", _self.onConnectionToMainServerOpenAgain); //remove listeners .on and set .once for the onConnectionToMainServerOpenAgain function
			        	_self.mainServer.once("open", _self.onConnectionToMainServerOpenAgain);	//listen for a once time
			        }
					
					_self.updateTimestampDisconnected(); //update the timestamp when disconnected
			        logger("Main server disconnected");
			        _self.outcomingDataEmitter.emit("connectionCSState", "Disconnected from the central server");
		    }
		};


		/**
		 * clear all intervals on MainP2P
		 * @method clearIntervals
		 * @return 
		 */
		MainP2PProto.clearIntervals = function() {
		    var self = returnMainP2P(this);
		    if (self.intOutstanding != null) { //stop outstanding procedure
		        clearInterval(self.intOutstanding);
		        self.intOutstanding = null;
		    }
		    if (self.intCheckConnection != null) { //stop checking connection to the main server
		        clearInterval(self.intCheckConnection);
		        self.intCheckConnection = null;
		    }
		    if (self.intTrySendingUpdateUTCMillisecondsDiffirence != null) {
		        clearInterval(self.intTrySendingUpdateUTCMillisecondsDiffirence);
		        self.intTrySendingUpdateUTCMillisecondsDiffirence = null;
		    }
		    if (self.intReconnectToCS != null) {
		        self.intReconnectToCS = null;
		        clearTimeout(self.intReconnectToCS);
		    }
		};


		/**
		 * close connections to all users
		 * deleteConnectionsDescriptions - delete all messages from the history list and queue list
		 * @method closeConnections
		 * @return 
		 */
		MainP2PProto.closeConnections = function() {
		    var self = returnMainP2P(this); //MainP2P instance
		    var usersIDs = Object.keys(self.peerConnections);
		    for (var i = 0, len = usersIDs.length; i < len; i++) {
		        var usrID = usersIDs[i];
		        var usrConnDesc = self.peerConnections[usrID];
		        if (commonlib.hasProperty(usrConnDesc, "connection") === true) { //need to close the connection with the user
		            var dataConnection = usrConnDesc.connection;
		            self.closeConnectionManually(dataConnection); //close the connection and delete the user description from the list
		        }
		        delete self.peerConnections[usrID]; //connection to user is absent
		    }
		};

		//DATA CONNECTION


		/**
		 * close dataConnection by User
		 * @method closeConnectionManually
		 * @param {} dataConnection
		 * @return 
		 */
		MainP2PProto.closeConnectionManually = function(dataConnection) {
		    var self = returnMainP2P(this, dataConnection);
		    dataConnection.g_flClosedManually = true;
		    self.closeDataConnection(dataConnection);
		    self.deleteDataConnectionFromList(dataConnection); //remove it from the list
		};


		/**
		 * close DataConnection instance
		 * @method closeDataConnection
		 * @param {} dataConnection
		 * @return 
		 */
		MainP2PProto.closeDataConnection = function(dataConnection) {
		    if (isDataConnection(dataConnection) === true) {
		        var self = returnMainP2P(this, dataConnection);
		        dataConnection.close();
		        if (dataConnection.listeners("close").length === 0) { //no listeners for the closee event
		            self.onDataConnectionClosed.apply(dataConnection); //apply the function for closing the connection
		        } else {
		            dataConnection.removeAllListeners();
		        }
		    }
		};


		/**
		 * return a reference to the connection description into a corresponding typed connections list
		 * dataConnection instance of DataConnection or dataConnection === peer ID
		 * return false
		 * @method returnConnectionDescFromList
		 * @param {} dataConnection
		 * @return LogicalExpression
		 */
		MainP2PProto.returnConnectionDescFromList = function(dataConnection) {
		    var self = returnMainP2P(this, dataConnection);
		    var userID = (isDataConnection(dataConnection) === true) ? dataConnection.peer : dataConnection;
		    return commonlib.hasProperty(self, "peerConnections") && commonlib.hasProperty(self.peerConnections, userID) && self.peerConnections[userID];
		};


		/**
		 * return valid connection type or null if no exists or not equal to any valid type
		 * or false
		 * @method returnConnectionType
		 * @param {} dataConnection
		 * @return LogicalExpression
		 */
		MainP2PProto.returnConnectionType = function(dataConnection) {
		    var connMetadata = dataConnection.metadata; //connection metadata
		    return connMetadata && commonlib.hasProperty(connMetadata, "g_connType") && (connMetadata.g_connType === "ELS" || connMetadata.g_connType === "p2p" || connMetadata.g_connType === "LSToLS") && connMetadata.g_connType;
		};


		/**
		 * set the connection type
		 * @method setConnectionType
		 * @param {} dataConnection
		 * @param {} connectionType
		 * @return 
		 */
		MainP2PProto.setConnectionType = function(dataConnection, connectionType) {
		    if (commonlib.hasProperty(dataConnection, "metadata") === false) {
		        dataConnection.metadata = {};
		    }
		    dataConnection.metadata.g_connType = connectionType;
		};


		/**
		 * check is new incoming data connection valid
		 * return true or false
		 * @method checkNewIncomingDataConnection
		 * @param {} dataConnection
		 * @return LogicalExpression
		 */
		MainP2PProto.checkNewIncomingDataConnection = function(dataConnection) {
		    var self = returnMainP2P(this, dataConnection),
		        connType = self.returnConnectionType(dataConnection),
		        connTimestamp = getConnectionTimestamp(dataConnection),
		        connDesc = self.returnConnectionDescFromList(dataConnection), //description (message history, data connection) of the user
		        userID = dataConnection.peer;
		        
		    return typeof(userID) === "number" //peer ID is not empty
		        && connType !== false //connection type is not empty
		        && connTimestamp !== false && (connDesc !== false || self.externalLocalServer.isUserOnLocation(userID) === true) //check if the data connection is already into the list of a data connections or the user is located on the same location with the peer
		        && (connDesc !== false //the description of the user for dataConnection is not absent
		            && ((commonlib.hasProperty(connDesc, "connection") === true && connDesc.connection.open !== true) //connection with the user is already exists, but not opened
		                || commonlib.hasProperty(connDesc, "connection") === false //connection with the user is absent
		            )
		        ) && isValidTimestamp(connTimestamp) === true; //the connection was not expired

		};


		/**
		 * when a new data connection to another peer has come
		 * connection to inner local server and peer-to-peer
		 * @method onDataConnection
		 * @param {} dataConnection
		 * @return 
		 */
		MainP2PProto.onDataConnection = function(dataConnection) {
		    var self = returnMainP2P(this, dataConnection); //return MainP2P instance
		    dataConnection.g_MainP2P = self; //reference to the instance of MainP2P
		    if (dataConnection.open === true) { //if opened
		        self.onDataConnectionActionByType(dataConnection);
		    } else { //wait for opening of the connection
		        dataConnection.on("open", self.onDataConnectionActionByType);
		    }
		};


		/**
		 * when  a new connection has come and further action depending on the connection type
		 * @method onDataConnectionActionByType
		 * @param {} dataConnection
		 * @return 
		 */
		MainP2PProto.onDataConnectionActionByType = function(dataConnection) {
		    var self = returnMainP2P(this, dataConnection);
		    if (isDataConnection(this) === true) {
		        dataConnection = this;
		    }
		    var connType = self.returnConnectionType(dataConnection);
		    if (connType != false) {
		        logger("New incoming connection with the type = " + connType);
		    }
		    switch (connType) {
		        case "LSToLS": //if it is other local server connection to the inner local server
		        case "ELS": //if it is peer connection to the inner local server(ILS)
		            if (commonlib.hasProperty(self, "innerLocalServer") === true && self.innerLocalServer.isOpen() === true) {
		                //add new connection to the innerLocalServer list
		                self.innerLocalServer.onDataConnection(dataConnection);
		            } else { //it is connection to the inner local server, but inner local server is not opened
		                dataConnection.close(); //no needed to do anything
		                return;
		            }
		            break;
		        case "p2p": //if it has one of the types: "p2p"
		            //add new connection to the list of peer-to-peer connections
		            self.addDataConnectionToList(dataConnection);
		            return;
		        default: //unknown connection type
		            dataConnection.close(); //no needed to do anything
		            return;
		    }
		};


		/**
		 * set default event listeners for DataConnection
		 * @method setDataConnectionEventListeners
		 * @param {} dataConnection
		 * @return 
		 */
		MainP2PProto.setDataConnectionEventListeners = function(dataConnection) {
		    var self = returnMainP2P(this, dataConnection);
		    dataConnection.removeAllListeners(); //remove all previous event listeners
		    //set an event listeners
		    if (dataConnection.open) { //the data connection already has been opened
		        self.onDataConnectionOpened.apply(dataConnection);
		    } else { //is not open
		        dataConnection.once("open", self.onDataConnectionOpened);
		    }
		    dataConnection.on("error", self.onDataConnectionError);
		    dataConnection.once("close", self.onDataConnectionClosed); //data connection between peers has  closed
		    dataConnection.on("data", self.onIncomingData); //message from another peer has come
		};


		/**
		 * check is connection valid and has a type = "p2p"
		 * return true or false
		 * @method isValidP2PConnection
		 * @param {} dataConnection
		 * @return LogicalExpression
		 */
		MainP2PProto.isValidP2PConnection = function(dataConnection) {
		    var self = returnMainP2P(this, dataConnection);
		    if (!self) {
		        return false;
		    }
		    return self.isValidDataConnection(dataConnection) && (self.returnConnectionType(dataConnection).trim() == "p2p");
		};


		/**
		 * peer-to-peer data connection validation
		 * connection must be typed and in the list of typed MainP2P instance, opened, ID of the user on the other side is exists
		 * @method isValidDataConnection
		 * @param {} dataConnection
		 * @return LogicalExpression
		 */
		MainP2PProto.isValidDataConnection = function(dataConnection) {
		    if (dataConnection.open) {
		        return false;
		    }
		    var self = returnMainP2P(this, dataConnection); //return MainP2P instance
		    if (self == null) {
		        return false;
		    }
		    var connType = self.returnConnectionType(dataConnection),
		        connectionDesc = self.returnConnectionDescFromList(dataConnection);
		    if (commonlib.hasProperty(dataConnection, "g_MainP2P") === false) {
		        dataConnection.g_MainP2P = self;
		    }
		    return dataConnection._closed !== true && typeof(dataConnection.peer) === "number" && connType !== false && connectionDesc != null && connectionDesc.connection === dataConnection;
		};


		/**
		 * add connection to the list of all connections
		 * return false if connection not valid and not been added to the list
		 * @method addDataConnectionToList
		 * @param {} dataConnection
		 * @return 
		 */
		MainP2PProto.addDataConnectionToList = function(dataConnection) {
		    var usrID = dataConnection.peer,
		        self = returnMainP2P(this, dataConnection); //return MainP2P instance
		    if (self.checkNewIncomingDataConnection(dataConnection) === false) {
		        self.closeDataConnection(dataConnection);
		        return false;
		    }
		    var connectionDesc = self.returnConnectionDescFromList(dataConnection);
		    if (connectionDesc === false) { //if the connection description is not exists, create it
		        connectionDesc = self.peerConnections[usrID] = {};
		        connectionDesc.connection = dataConnection;
		    } else if (connectionDesc !== false && commonlib.hasPropperty(connectionDesc, "connection") === true //if there is an open connection of this type already exists
		        && connectionDesc.connection.open === true //if the current connection to peer is opened
		        && getConnectionTimestamp(connectionDesc.connection) > getConnectionTimestamp(dataConnection)) { //and newer, than the new connection
		        self.closeDataConnection(dataConnection); //close received connection
		        return;
		    } else { //connection from list is closed or older, than the new incoming connection
		        connectionDesc.connection = dataConnection; //add received connection to the list of connections
		        self.closeDataConnection(connectionDesc.connection); //close the current connection with the peer
		    }

		    dataConnection.g_flClosedManually = false;

		    //add messages queue and messages history for the data connection
		    if (commonlib.hasPropperty(connectionDesc, "messageList" === false)) {
		        connectionDesc.messageList = [];
		    }
		    if (commonlib.hasPropperty(connectionDesc, "messagesQueue" === false)) {
		        connectionDesc.messagesQueue = [];
		    }
		    self.setDataConnectionEventListeners(dataConnection);
		    setDataConnectionMetadataTimestamp(dataConnection); //this is for determining if the data connection is expired and can be closed
		};


		/**
		 * when peer-to-peer data connection has opened
		 * @method onDataConnectionOpened
		 * @return 
		 */
		MainP2PProto.onDataConnectionOpened = function() {
		    var dataConnection = this,
		        self = returnMainP2P(this);
		    if (self == null || self.isValidP2PConnection(dataConnection) === false) {
		        dataConnection.close();
		        return;
		    }
			
		    var connDesc = self.returnConnectionDescFromList(dataConnection);
		    connDesc.attemptsToReconnect = 0; //set the number of attempts to connect to 0, if it is successful attempt, and connection has been established
		    //send a queued messages if they are exists
		    var messagesQueue = connDesc.messagesQueue;
		    if (Array.isArray(messagesQueue) === true && messagesQueue.length > 0) { //if the messages queue is exists, and not empty
		        for (var ind = 0; ind < messagesQueue.length; ind++) {
		            var message = messagesQueue[ind];
		            dataConnection.sendP2PMessage(message); //send a message from the queue
		            self.addMessageToHistoryList(dataConnection, message); //put a message to the list of a messages exchange history
		        }
		    }
		    //delete a messages queue, because messages has been sent
		    connDesc.messagesQueue = null;
		    setDataConnectionMetadataTimestamp(dataConnection); //update connection timestamp
		};


		/**
		 * remove connection description dy dataConnection instance, from the list of a connections MainP2P instasnce
		 * dataConnection - instance of DataConnection or userID
		 * @method deleteDataConnectionFromList
		 * @param {} dataConnection
		 * @return 
		 */
		MainP2PProto.deleteDataConnectionFromList = function(dataConnection) {
		    var self = returnMainP2P(this, dataConnection); //return MainP2P instance
		    var connDesc = self.returnConnectionDescFromList(dataConnection);
		    var flUsrID = isDataConnection(dataConnection) !== true; //the argument "dataConnection" is the id of the user
		    var usrID = (flUsrID === true) ? dataConnection : dataConnection.peer;
		    if (connDesc !== false && ((flUsrID === false && connDesc.connection === dataConnection) || flUsrID === true)) { //if connection into description is not the same to the dataConnection
		        if (flUsrID === false && dataConnection.open === true) {
		            dataConnection.close(); //close the connection if it is open
		        }
		        connDesc.connection = null; //remove reference to the data connection
		        connDesc.messagesQueue = null; //delete messags queue
		        connDesc.messageList = null; //delete messages exchange history
		        delete self.peerConnections[usrID]; //remove connection description
		    }
		};


		/**
		 * when connection peer-to=peer or peer-to-local server has closed with an error
		 * @method onDataConnectionError
		 * @param {} e
		 * @return 
		 */
		MainP2PProto.onDataConnectionError = function(e) {
		    logger("DataConnection error: " + e);
		};


		/**
		 * if messages queue is not empty, try to establish a new connection with this peer and send a messages from the queue
		 * @method reconnectToPeerOrDeleteFormList
		 * @param {} userID
		 * @return 
		 */
		MainP2PProto.reconnectToPeerOrDeleteFormList = function(userID) {
		    var self = returnMainP2P(this);
		    var usrConnDesc = self.returnConnectionDescFromList(userID);
		    if (usrConnDesc !== false && commonlib.hasProperty(usrConnDesc, "messagesQueue") === true //if there is a messages into queue, that are not sended before this time
		        && usrConnDesc.messagesQueue.length !== 0) {
		        if (typeof(usrConnDesc.attemptsToReconnect) !== "number") {
		            usrConnDesc.attemptsToReconnect = 0;
		        }
		        if (++usrConnDesc.attemptsToReconnect < 8) {
		            self.connectToPeer(userID); //establish new connection with the peer for sending the messages from the queue, that are not sended
		        } else if (commonlib.hasProperty(usrConnDesc, "connection") === true && usrConnDesc.connection.open === false) {
		            //because of too many attempts to connect was done or other reason
		            self.deleteDataConnectionFromList(userID);
		        }
		    } else if ((commonlib.hasProperty(usrConnDesc, "messagesList") === true && usrConnDesc.messagesList.length === 0) //if the message history list is empty
		        || (commonlib.hasProperty(usrConnDesc, "connection") === true && self.checkConnectionTimeout(usrConnDesc.connection) === false)) { //if the connection to the user has reached timeout
		        self.deleteDataConnectionFromList(userID);
		    }
		};


		/**
		 * return an opened dataConnection from the connections list by the user ID
		 * or false if there is no an active connection to user
		 * @method returnDataConnectionByID
		 * @param {} userID
		 * @return Literal
		 */
		MainP2PProto.returnDataConnectionByID = function(userID) {
		    var self = returnMainP2P(this);
		    var usrConnDesc = self.returnConnectionDescFromList(userID);
		    if (usrConnDesc !== false && commonlib.hasProperty(usrConnDesc, "connection") === true) {
		        var usrConnection = usrConnDesc.connection;
		        if (usrConnection.open) {
		            return usrConnection; //if the connection is opened
		        }
		        self.closeDataConnection(usrConnection); //if the connection is closed               
		    }
		    return false;
		};


		/**
		 * return an object with a connection's metadata
		 * @method getOptionsForNewP2PConnection
		 * @return ObjectExpression
		 */
		MainP2PProto.getOptionsForNewP2PConnection = function() {
		    return {
		        serialization: "json",
		        metadata: {
		            g_timestamp: getTimestamp(),
		            g_connType: "p2p"
		        }
		    };
		};


		/**
		 * establish a Data Connection with a peer, that has a given ID and set it's type connectionType
		 * return an instance of DataConnection
		 * @method connectToPeer
		 * @param {} peerID
		 * @param {} callback
		 * @return dataConnection
		 */
		MainP2PProto.connectToPeer = function(peerID, callback) {
		    var self = returnMainP2P(this),
		        dataConnection = self.returnDataConnectionByID(peerID); //get a connection with the user with the peerID
		    if (dataConnection === false) { //there is no connection with the peer, create a new one
		        dataConnection = self.mainServer.connect(commonlib.strToInt(peerID), self.getOptionsForNewP2PConnection()); //creacte new data connection
		        self.onDataConnection.call(self, dataConnection); //apply the function for setting a new data connections
		        if (typeof(callback) === "function") { //call the callback if it is defined
		            callback(dataConnection);
		        }
		        callback = null;
		    }
		    return dataConnection;
		};


		/**
		 * when connection peer-to-peer has closed
		 * @method onDataConnectionClosed
		 * @return 
		 */
		MainP2PProto.onDataConnectionClosed = function() {
		    var dataConnection = this,
		        self = returnMainP2P(this, dataConnection);
		    if (self != null && dataConnection.open === false) { //connection not opened
		        var connDesc = self.returnConnectionDescFromList(dataConnection);
		        if (connDesc != null && connDesc.connection === dataConnection) { //if it is not connection from the list of all data connections
		            self.reconnectToPeerOrDeleteFormList(dataConnection.peer);
		        }
		    }
		    dataConnection.removeAllListeners();
		};


		/**
		 * message from another peer validation. Return true if a message is valid or false if an errosr
		 * @method validateMessage
		 * @param {} message
		 * @return 
		 */
		MainP2PProto.validateMessage = function(message) {
		    if (validators.validatorIncomingMessageFromCS_textMessage(message) === false) { //the message timestamp is not valid
		        logger(validators.validatorIncomingMessageFromCS_textMessage.errors); //show an errors
		        return false;
		    } else {
		        return true;
		    }
		};


		/**
		 * when message from the user peer or external local server has come
		 * if connection has no typed, set it's type by the message property 'type'
		 * @method onIncomingData
		 * @param {} data
		 * @return 
		 */
		MainP2PProto.onIncomingData = function(data) {
		    var dataConnection = this,
		        self = returnMainP2P(this, dataConnection); //return MainP2P instance
		    if (self == null || self.isValidP2PConnection(dataConnection) === false) { //not valid connection with the type of "p2p"
		        self.closeDataConnection(dataConnection);
		    } else {
		        self.onMessageP2P(data, dataConnection);
		    }
		};


		/**
		 * add a message into the history list of messages
		 * @method addMessageToHistoryList
		 * @param {} dataConnection
		 * @param {} message
		 * @return 
		 */
		MainP2PProto.addMessageToHistoryList = function(dataConnection, message) {
		    var self = returnMainP2P(this, dataConnection),
		        connDesc = self.returnConnectionDescFromList(dataConnection);
		    if (connDesc === false) {
		        return;
		    }
		    if (commonlib.hasProperty(connDesc, "messageList") === false) { //create it, if it is not exists
		        connDesc.messageList = [];
		    }
		    connDesc.messageList.push(message);
		};


		/**
		 * add a message into the queue list of messages, that can not be sent
		 * @method addMessageToQueueList
		 * @param {} dataConnection
		 * @param {} message
		 * @return 
		 */
		MainP2PProto.addMessageToQueueList = function(dataConnection, message) {
		    var self = returnMainP2P(this, dataConnection),
		        connDesc = self.returnConnectionDescFromList(dataConnection);
		    if (connDesc === false) {
		        return;
		    }
		    if (commonlib.hasProperty(connDesc, "messagesQueue") === false) {
		        connDesc.messagesQueue = [];
		    }
		    connDesc.messagesQueue.push(message);
		};


		/**
		 * message from another peer has come
		 * @method onMessageP2P
		 * @param {} messageObj
		 * @param {} dataConnection
		 * @return 
		 */
		MainP2PProto.onMessageP2P = function(messageObj, dataConnection) {
		    var self = returnMainP2P(this, dataConnection);
		    if (self.validateMessage(messageObj) === true) {
		        self.addMessageToHistoryList(dataConnection, messageObj.text);
		        setDataConnectionMetadataTimestamp(dataConnection); //update data connection timestamp that the data connection will not expire
		        self.emit("messageP2P", messageObj.text, messageObj);
		    }
		};


		/**
		 * connection has reached timeout
		 * return false if timeout
		 * @method checkConnectionTimeout
		 * @param {} dataConnection
		 * @return LogicalExpression
		 */
		MainP2PProto.checkConnectionTimeout = function(dataConnection) {
		    return commonlib.hasProperty(dataConnection, "metadata") === true || typeof(dataConnection.metadata.g_timestamp) === "number" || (getTimestamp() - (dataConnection.metadata.g_timestamp)) < timeIntervals.timeoutSecondsMainP2PPeerDataConnection; //more than the predefined number of seconds
		};


		/**
		 * check connections timestamp to reaching timeout for an each connection or reconnect to the user if it is necessary
		 * @method outstanding
		 * @return 
		 */
		MainP2PProto.outstanding = function() {
		    var self = returnMainP2P(this); //MainP2P instance
		    var connectionsDesc = self.peerConnections;
		    var users = Object.keys(connectionsDesc);
		    for (var i = 0, len = users.length; i < len; i++) {
		        var usrID = users[i];
		        var usrConnDesc = connectionsDesc[usrID]; //description of a connection with another user
		        if (commonlib.hasProperty(usrConnDesc, "connection") === true && (usrConnDesc.connection.open === false //the connection is not open
		        	|| self.checkConnectionTimeout(usrConnDesc.connection) === false)) { //data connection has reahced time out
		            	self.reconnectToPeerOrDeleteFormList(usrID); //if it is necessary to reconnect to the peer
		        }
		    }
		};


		/**
		 * create object message, that is sending to other peer, by a text message
		 * @method createObjectP2PMessage
		 * @param {} txtMessage
		 * @return ObjectExpression
		 */
		MainP2PProto.createObjectP2PMessage = function(txtMessage) {
		    return {
		        type: "toPeer",
		        text: txtMessage,
		        timestamp: getTimestamp()
		    };
		};


		/**
		 * send a message to an other user (peer) with ID, txtMessage - text message
		 * @method sendP2PMessage
		 * @param {} userID
		 * @param {} txtMessage
		 * @return 
		 */
		MainP2PProto.sendP2PMessage = function(userID, txtMessage) {
		    //find connection
		    var self = returnMainP2P(this), //MainP2P instance
		        message = self.createObjectP2PMessage(txtMessage),
		        dataConnection = self.connectToPeer(userID); //create a new connection to the peer or get an existsing connection with the peer
		    if (dataConnection == null || dataConnection.open === false) { //if there is no open connection with this peer
		        self.addMessageToQueueList(dataConnection, message);
		    } else { //if the connection is open
		        dataConnection.send(message); //send the message for now
		        self.addMessageToHistoryList(dataConnection, txtMessage); //add a text of the message to the history list
		    }
		};

		//<<EXTERNAL LOCAL SERVER


		/**
		 * is ELS opened and works
		 * @method isConnectedToELS
		 * @return LogicalExpression
		 */
		MainP2PProto.isConnectedToELS = function() {
		    var self = returnMainP2P(this);
		    return commonlib.hasProperty(self, "externalLocalServer") === true 
		    		&& self.externalLocalServer.isConnected() === true;
		};


		/**
		 * check is ELS outdated
		 * @method checkELSTimeout
		 * @return CallExpression
		 */
		MainP2PProto.checkELSTimeout = function() {
		    var self = returnMainP2P(this),
		        els = self.externalLocalServer;
		    return els.isOutdated();
		};


		/**
		 * return the current user location or null if it is absent
		 * @method getUserLocation
		 * @return 
		 */
		MainP2PProto.getUserLocation = function() {
		    var self = returnMainP2P(this);
		    var els = self.externalLocalServer;
		    if ( (isELS(els) === false || typeof(els.locationHash) !== "string")
		    	 && typeof(self.myLocationHash) !== "string" ) { //if there is no els or there is no location , defined by the els, but the previous location hash has been saved in the myLocationHash 
		        	return self.myLocationHash;
		    } else if ( isELS(els) === true ) {
		        return els.locationHash;
		    } else {
		        return null;
		    }
		};


		/**
		 * create new ExternalLocalServer instance and connect to the local server peer
		 * @method connectToELS
		 * @return 
		 */
		MainP2PProto.connectToELS = function() {
		    var self = returnMainP2P(this);
		    logger("ELS opening");
		    self.flELSMustBeOpened = true; //set the flag that the els must be opened
		    
		    if ( isELS(globalObj.els) === false
		    	|| globalObj.els.isClosed() === true ) { //if the global ils been closed or absent
			    	globalObj.els = self.externalLocalServer = new ExternalLocalServer(self); //create an instance of the ExternalLocalServer
			    	self.emit("elsOpen"); //emit an event, that els is open
		    } else {
		    	self.externalLocalServer = globalObj.els;
		    }
		    
		    self.setELSEventListeners();
		};

		/**
		 * Description
		 * @method onNewUserLocation
		 * @param {} newLocationHash
		 * @param {} lsID
		 * @return 
		 */
		MainP2PProto.onNewUserLocation = function(newLocationHash, lsID) {
		    var self = returnMainP2P(this);
		    self.myLocationHash = newLocationHash;
		    self.outcomingDataEmitter.emit("locationChange", [newLocationHash, lsID]);
		};


		/**
		 * on els was closed
		 * @method onELSClosed
		 * @return 
		 */
		MainP2PProto.onELSClosed = function() {
		    var self = returnMainP2P(this);
		    self.closeELS(); //close the previous ELS
		    if (self.g_flClosedManually === false) { //if the main connection was not closed
		        self.connectToELS(); //start the ELS again    
		    }
		};


		/**
		 * on incoming description of the user location
		 * locationDescription = { userID : { lat, lng, coordsTimestamp } }
		 * the current location description is available thru self.externalLocalServer.getLocationDescription();
		 * emit the event called "locationDescription"
		 * @method onLocationDescription
		 * @param {} locationDescription
		 * @return 
		 */
		MainP2PProto.onLocationDescription = function(locationDescription) {
		    var self = returnMainP2P(this);
		    // var usersIDs = Object.keys(locationDescription);
		    // for( var i=0, len = usersIDs; i < len; i++ ) {
		    //     //var usrID = usersIDs[i];
		    //     //var usrLocation = locationDescription[usrID]; //{ lat, lng, coordTimestamp }
		    // }
		    self.outcomingDataEmitter.emit("locationDescription", locationDescription);
		};


		/**
		 * set the listeners for the event from the els
		 * @method setELSEventListeners
		 * @return 
		 */
		MainP2PProto.setELSEventListeners = function() {
		    var self = this;
		    var els = this.externalLocalServer;
		    if (isELS(els) === true) { //ELS works already
		        els.on("locationDescription", this.onLocationDescription, self);
		        els.once("externalLocalServerClosed", this.onELSClosed);
		        els.on("locationChange", this.onNewUserLocation);
		        els.on("externalLocalServerOpened", function(lsID) {
		            self.outcomingDataEmitter.emit("onConnectedToLS", lsID);
		        });
		        els.on("externalLocalServerConnectionClosed", function() {
		            self.outcomingDataEmitter.emit("onDisconnectedFromLS");
		        });
		        els.on("externalLocalServerConnectionClosedForcibly", function() {
		            self.outcomingDataEmitter.emit("onDisconnectedFromLS");
		        });
		        els.on("offerSDP", function(userID, offer) {
		            self.outcomingDataEmitter.emit("offerSDP",userID, offer);
		        });
		        els.on("answerSDP", function(userID, answer) {
		            self.outcomingDataEmitter.emit("answerSDP",userID, answer);
		        });
		    }
		};


		/**
		 * fully close External Local Server
		 * @method closeELS
		 * @return 
		 */
		MainP2PProto.closeELS = function() {
		    var self = returnMainP2P(this);
		    if (isELS(self.externalLocalServer) === true) { //close local server instance
		        self.emit("externalLocalServerClosed");
		        self.externalLocalServer.close(); //close els
		        self.externalLocalServer = null; //and clear the reference on it
		        self.flELSMustBeOpened = false; //set the flag that the ILS must not been opened
		    }
		};

		//INNER LOCAL SERVER>>
		
		/**
		 * return the number of the locations that are handled by the local server
		 * @method getNumberOfMaintainedLocations
		 * @return 
		 */
		MainP2PProto.getNumberOfMaintainedLocations = function() {
			var self = returnMainP2P(this);
			var ils = self.innerLocalServer;
			if ( ils instanceof InnerLocalServer ) { //if the ils was started
				return ils.getNumberOfMaintainedLocations(); //get the list of a handled locations
			} else {
				return 0;	
			}
		};
		
		/**
		 * the current user is need to be a local server
		 * cb - callback function
		 * @method startInnerLocalServer
		 * @param {} cb
		 * @return 
		 */
		MainP2PProto.startInnerLocalServer = function(cb) {
		    var self = returnMainP2P(this);
		    self.emit("innerLocalServerOpen");
		    logger("ILS started");
		    self.flILSMustBeOpened = true;
		    
		    if ( isILS(globalObj.ils) === false
		    	|| globalObj.ils.isClosed() === true ) { //if the global ils been closed or absent
			    	globalObj.ils = self.innerLocalServer = new InnerLocalServer(self, cb); //local server object
		    } else {
		    	self.innerLocalServer = globalObj.ils;
		    	if ( typeof(cb) === "function" ) {
		    		cb();	
		    	}
		    }
		    
		    self.innerLocalServer.once("innerLocalServerClosed", self.onInnerLocalServerClose.bind(self));

		};

		/**
		 * Description
		 * @method onInnerLocalServerClose
		 * @return 
		 */
		MainP2PProto.onInnerLocalServerClose = function() {
		    var self = returnMainP2P(this);
		    self.closeInnerLocalServer(); //close the previous
		    logger("ILS been closed");
		    if (self.g_flClosedManually !== true) { //if not closed forcibly
		        self.startInnerLocalServer();
		    }
		};


		/**
		 * fully close Inner Local Server
		 * @method closeInnerLocalServer
		 * @return 
		 */
		MainP2PProto.closeInnerLocalServer = function() {
		    var self = returnMainP2P(this);
		    var ils = self.innerLocalServer;
		    logger("ILS closing");
		    if (isILS(ils) === true) { //close local server instance
		        ils.removeListener("innerLocalServerClosed", self.onInnerLocalServerClose);
		        ils.close();
		        self.emit("innerLocalServerClosed"); //emit for another listeners
		        self.innerLocalServer = null;
		        self.flILSMustBeOpened = false; //set the flag that the ILS must not been opened
		    }
		};
		
		/*
			Browser closing handling
		*/
		
		/**
		 * handle event on browser close
		 * @method browserClose
		 * @return 
		 */
		MainP2PProto.browserClose = function(){
			var self = returnMainP2P(this);
			self.close();
		};
		
		/*		
			Messaging with another users
		*/
		
		/**
		 * send offer to the callee user
		 * @method sendOffer
		 * @return 
		 */
		MainP2PProto.sendOffer = function() {
			var self = returnMainP2P(this);
			var els = self.externalLocalServer;
			els.sendOffer.apply(els, arguments);
		};
		
		/**
		 * send the answer for offer to the caller user
		 * @method sendAnswer
		 * @return 
		 */
		MainP2PProto.sendAnswer = function() {
			var self = returnMainP2P(this);
			var els = self.externalLocalServer;
			els.sendAnswer.apply(els, arguments);
		};
		
		MainP2P.prototype = MainP2PProto;

		module.exports = {
		    mainpeer: MainP2P
		};
},{"CommandsListener":undefined,"DataConnector":undefined,"ExternalLocalServer":undefined,"InnerLocalServer":undefined,"commonlib":undefined,"eventemitter":undefined,"globalSettings":undefined,"libMainP2P":undefined,"logger":undefined,"timeIntervals":undefined,"timestamps":undefined,"validatorsMainPeer":undefined}]},{},[]);
