/*global localforage*/
/*global user*/
/*global $*/
/*global FB*/

var interfacePlugins = require("interfacePlugins");
var commonlib = require("commonlib");

var logger = require("logger").logger;
logger.namespace = "gpages";

/*
    functions for execution from the user interface pages of the project
*/

/*
    load JSON file with available tags for the user
*/
function loadAvailTags(callbackOnLoad) {

    var _key = _gPages.settings.uiStorage.keyNameListAvailableTagsForUser; //name of the key in the storage

    if (localforage === undefined) {
        logger(new Error("The local forage is unavailable"));
    }
    else {
        localforage.getItem(_key, //try to read the list from the storage 
            function (err, res) {
                if (err != null
                    || res == null) { //if the list is empty
                        $.ajax({ //load it dynamically
                            url: "./src/availTags.json",
                            dataType: "text",
                            error: function (jqXHR, textStatus, err) { //if an error
                                logger("!!!Can't load the tags list");
                                logger(err);
                            }
                        })
                        .done(function (data) {
                            if (typeof (data) === "string" && data.trim().length > 0) {

                                var successCallback;

                                if (typeof (callbackOnLoad) === "function") { //if callback is defined
                                    successCallback =
                                        function (err) {
                                            if ( !(err instanceof Error) ) {
                                                JSON.parseAsync(data, callbackOnLoad);    
                                            } else {
                                                logger("!!!Can't load the tags list");
                                                logger(err);
                                                callbackOnLoad(err);    
                                            }
                                        };
                                }
                                else { //if not defined
                                    successCallback = undefined;
                                }

                                localforage.setItem(_key, data,
                                    successCallback
                                );
                            }
                            else {
                                logger("!!!Can't load the tags list");
                                if (typeof (callbackOnLoad) === "function") {
                                    callbackOnLoad();
                                }
                            }
                        });
                }
                else {
                    if (typeof (callbackOnLoad) === "function") { //if callback is defined
                        if (typeof (res) === "string") { //if necessary to parse
                            JSON.parseAsync(res, callbackOnLoad);
                        } else { // if already an object
                            callbackOnLoad(res);
                        }
                    }
                }

            }
        );
    }
}

/*
    befor the panel myTags will be opened
*/
function panels_myTagsLookingTags_panelbeforeopen(uiPanel) {
    
    var listsMethods = interfacePlugins.lists;
    var flPanelLookingTags = $(uiPanel).prop("id") === "panel_lookingtags"; //true if it is the lookingTags
    var listviewTarget = ( flPanelLookingTags === true ? "#listview_lookingtagslist" : "#listview_mytagslist" );
    var listviewAvailableTags = ( flPanelLookingTags === true ? "#panel_lookingtags-listview_availtagslist" : "#listview_availtagslist" );
    
    if ( typeof(user) === "object" ) {
        user.getTags( flPanelLookingTags === true, //load tags
            function (tagsUser) { //tags, chosen by the user
                loadAvailTags(function (tags) { //get tags, available for users
                    if ( typeof(tags) === "object"
                         && tags != null
                         && !(tags instanceof Error) ) {
                            
                            var i, len;
                             
                            if ( Array.isArray(tagsUser) === true
                                && tagsUser.length > 0 ) {
                                    
                                    var tagsUserDesc = {}; //{tagName : image}
                                    
                                    //filter the available tags by tags, choosed by the user
                                    for( i =0, len = tagsUser.length; i < len; i++ ) {
                                        var tagName = tagsUser[i]; //name of the chosen tag
                                        var imageForTag = tags[tagName]; //image for the chosen tag
                                    
                                        if ( typeof(imageForTag) === "string" ) { //if this tag is already into the list of the chosen tags
                                            tagsUserDesc[tagName] = imageForTag; //set the image for the chosen tag
                                            delete tags[tagsUser[i]]; 
                                        }   
                                    }
                                    
                                    listsMethods.clearListview(listviewTarget, false, true); //clean the listview without updating it
                                    listsMethods.appendListToListview(listviewTarget, tagsUserDesc);
                            } else { //if the chosen tags are absent
                                listsMethods.clearListview(listviewTarget, true, true); //clean the listview with updating it 
                            }
                            
                            if ( commonlib.isEmptyObject(tags) !== true ) { //if have an elements to add them into the list
                                listsMethods.clearListview(listviewAvailableTags, false, true); //clean and do not update
                                listsMethods.appendListToListview(listviewAvailableTags, tags);            
                            } else { //the list  must be empty
                                listsMethods.clearListview(listviewAvailableTags, true, true); //update the listview   
                            }
                    }
                });
            }
        );    
    } else {
        logger("!!!Can't read the chosen tags because the global variable User is not defined");    
    }
            
}

/*
    on panel with the chosen or the loooking tags closed
*/
function panel_myTagsLookingTags_panelclose(uiPanel) {
    var listsMethods = interfacePlugins.lists;
    var flPanelLookingTags = $(uiPanel).prop("id") === "panel_lookingTags"; //true if it is the lookingTags
    var listviewTarget = flPanelLookingTags === true ? "#listview_lookingTagsList" : "#listview_myTagsList";
    
    if ( typeof(user) === "object" ) { //save the list with chosen tags
        user.saveTags( 
            flPanelLookingTags === true, 
            listsMethods.getListviewItems(listviewTarget, true) //get the chosen items and expect the disabled elements
        );
    } else {
        logger("!!!Can't save the chosen tags because the global variable User is not defined");  
    }
}

/*
    the structure of the variable:
    {
        pages : {
            pageID : { 
                "jQuery eventType name (such as onload)" : handler function
            }
        },
        panels : {
            panelID : {
                "jQuery eventType name (such as onload)" : handler function
            }
        }
    }
*/

/*
    when the user logged to facebook
*/
function checkFacebookLoginStatus() {
    if ( FB ) {
        FB.getLoginStatus(
            function(response) {
                var loginPanel = $("div[data-ui-photo-loader='true']");
                if ( response instanceof Error ) {
                    logger(response);
                } else
                    if ( typeof(response) === "object" ) {
                        if ( response.status === 'connected' ) {
                            loginPanel.html("");    
                        }   
                    }
                
                var settings = _gPages.integration.facebook;    
                if ( settings.code == null
                    || typeof(settings.code.loginButton) !== "string" ) { //if the code for the facebook login button is not defined
                        $.ajax(
                            "../libjS/integration/facebook/elements/login.button", //request the html code for the login button
                            {
                                dataType: 'text',
                                async : true,
                                success : function(data) { //when the html code for the login button will be retrieved
                                    if ( typeof(data) === "string" ) {
                                        _gPages.integration.facebook.code.loginButton = data; //save it into the settings
                                        checkFacebookLoginStatus(); //update the form
                                    }
                                }
                            }
                        )    
                } else {
                    loginPanel.html(_gPages.integration.facebook.code.loginButton);
                }
                    
            },
            true
        ); 
    } else {
        logger(new Error("Facebook SDK does not loaded"));    
    }
}

//set a global variable _gPages
if (self === window) {
    
    var _gPages = { //module
        handlers : {
            ondrop : { 
            }    
        },
        pages: {
            page_aboutUser: {
            }
        },
        panels: {
            panel_myTags: {
                panelbeforeopen: panels_myTagsLookingTags_panelbeforeopen,
                panelclose: panel_myTagsLookingTags_panelclose
            },
            panel_lookingTags : {
                panelbeforeopen: panels_myTagsLookingTags_panelbeforeopen,
                panelclose: panel_myTagsLookingTags_panelclose
            }
        },
        integration : {
            facebook : {
                methods : {
                    checkFacebookLoginStatus : checkFacebookLoginStatus    
                },
                code : {}
            }    
        },
        settings : {
            uiStorage: { //settings for the storage
                keyNameListAvailableTagsForUser : "_listAvailableTagsForUser",
                keyNameListChosenTagsUser   : "_listAvailableTagsForUser",
            },
            flags : {
                flAvailableTagsLoaded : false //if an available tas were loaded to the listview    
            }
        }
    };
    
    window["_gPages"] = _gPages;
}