require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"MainMap":[function(require,module,exports){
/*global L*/
/*global $*/

//!!!!Leaflet.TileLayer.PouchDBCached - save all tiles to the database

//work with main map - show user and the nearest users on the map
var logger = require("logger");
logger.namespace = "maplib";
var commonlib = require("commonlib");
var globalSettings = require("globalSettings");
var EventEmitter = require("eventemitter");

//options
var moduleSettings = globalSettings.settingsMap;
		
//create the object to control the view of the main map
//mainMapID - id of a DOM element, where the map will be placed
//Leaflet - instance of Leaflet.js (by default it is the global variable called 'L')
/**
 * Description
 * @method MainMap
 * @param {} Leaflet
 * @return 
 */
function MainMap(Leaflet) {
    
    if ( moduleSettings == null ) {
        throw new Error("The settings for the module are not defined");
    }
    if ( Leaflet == null ) {
       throw new Error("Leflet.js library is not defined"); 
    }
    
    this.settings = moduleSettings;
    
    var mainMapID  = moduleSettings.mainMapID;
    this.mainMapID = mainMapID;
    
    this.Leaflet  = Leaflet;

    this.map = null; //instance of Leafletjs L.map
    this.DOMMap = $("#" + mainMapID); //get a DOM element, that contains the main map
    if ( this.DOMMap.length === 0 ) {
        throw new Error("Not found the DOM object with the id = " + mainMapID);    
    }
    
    this.usersMarkers = {}; //{ userID : marker } - markers for the users on the map
    
    //set the listeners to control a drawing of the main map
    this.sizing();
    
    //bind the context to the methods
    this.addUserMarker.bind(this);
    this.moveUserMarkerTo = this.moveUserMarkerTo.bind(this); 
    this.removeUserMarker.bind(this);
    this.redraw = this.redraw.bind(this);
}

var MainMapProto = Object.create(new EventEmitter());
/*
    EVENTS:
    centerOnUserMarker - necessary to center the map on the user marker
*/


/**
 * set listeners for an events of the map or related objects to control the map options
 * set the size of an element, on which the main map is contained
 * @method sizing
 * @return 
 */
MainMapProto.sizing = function() {
    const self = this;
    const _window = $(window); //main window object
    //set the size for DOM object, that contains the main map
    _window.resize(function(){ 
        self.redraw(); //redrow the map on window resize
    }); 
};

MainMapProto.redraw = function() {
    if ( this.map != null ) {
        this.map.invalidateSize(true);    
    }
};

/*
    set the main user
*/
MainMapProto.setMainUser = function(userID) {
 this.mainUserID = userID;   
};

/**
 * each time when the user click on the markerp of the user with id = userID
 * @method onClickMarkerUser
 * @param {} userID
 * @return 
 */
MainMapProto.onClickMarkerUser = function(userID){
    this.emit("clickOnMarker", userID);
};

/**
 * show the main map into the DOM element with all the layers and the current user
 * coords = { latitude, longitude } - coordinates of the user 
 * @method showMap
 * @param {} coords
 * @return 
 */
MainMapProto.showMap = function(coords) {
   
    if ( coords instanceof Error ) {
        logger("!!!An error while getting the user coordinates" + coords);
        return;   
    }
    var L  = this.Leaflet; //instance of Leaflet.js
    var settings = this.settings;
    
    /*check if can get the coordinates*/
    if ( coords == null
        || typeof(coords) !== "object"
        || coords.longitude === 0
        || coords.longitude == null 
        || coords.latitude === 0
        || coords.latitude == null ) {
            window.interface.showError("Unable to get your coordinates! May be it is necessary to set the permissions for the browser or for this app"); 
    }
    
    var ltlg = {
        lat: coords.latitude,
        lng: coords.longitude
    };
    
    var mainMapSettings = { //settings for the map
        center : ltlg //the user current position will be in the center of the main map
    };
    commonlib.extend(mainMapSettings, settings.settingsLeafletMap); //extend options from the global settings
    var map = this.map = L.map(this.mainMapID, mainMapSettings); //create the main map into the DOM object with the id = this.mainMapID
    map.attributionControl.setPosition("topright");
    
    //add control, that allows to 
    
    /*this is workinh example
    //var urlTileService = "https://cartodb-basemaps-{s}.global.ssl.fastly.net/light_all/{z}/{x}/{y}.png";
    // var layer = L.tileLayer(urlTileService, {
    //     attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, &copy; <a href="http://cartodb.com/attributions">CartoDB</a>',
    //     unloadInvisibleTiles : true,
    //     updateWhenIdle : false
    // });
    // layer.addTo(map);*/
    
    var tileLayer = this.tileLayer = L.tileLayer.provider('OpenStreetMap.Mapnik', this.settings.tileOptionsDefault);
    tileLayer.addTo(map);
    
    //add the mini map for better navigation
    //L.Control.MiniMap(tileLayer, { autoToggleDisplay : true, minimized : true, position: "bottomright", width : this.DOMMap.width() / 5, height : this.DOMMap.height() / 5 }).addTo(map);
    
    this.redraw();
    this.addLayersControl();
    this.addFollowUserMarkerControl();
    this.addGeocoderControl();
    
 };

/*
    enable or disable the user marker dragging
*/
MainMapProto.enableDisableDraggingForMarker = function(flEnable) {
    const mainUserID = this.mainUserID;
    if ( typeof(mainUserID) === "number" ) {
        const usersMarkers = this.usersMarkers;
        if ( usersMarkers != null ) {
            const usrMarker = this.usersMarkers[mainUserID];
            var draggable = new L.Draggable(usrMarker);
            if ( flEnable === true ) {
                draggable.enable();
                usrMarker.dragging.enable();
            } else {
                draggable.disable();  
                usrMarker.dragging.disable();
            }
        }
    }
};

/*
    add control, onclick set marker centered on the user's marker
*/
MainMapProto.addFollowUserMarkerControl = function() {
    debugger;
    const res = L.easyButton('<span class="leaflet-control-show-me">me</span>', this.onClickControlFollowUserMarker.bind(this)).setPosition("topright").addTo(this.map);
    const uiDOM = res._container;
    if ( uiDOM != null ) {
        $(uiDOM).attr("id", "mainMap_showMe");
    }
};

/*
    add control for geocoding on the map
*/
MainMapProto.addGeocoderControl = function() {
    

    /*
        setting in the format:
        {
            leaflet_name : api_key
        }
    */
    var geocoderProvider;
    const geocodersSettings = this.settings.geocoders;
    const geocodersNames = Object.keys(geocodersSettings);
    for( var i =0, len = geocodersNames.length; i < len; i++ ) {
        var geocoderName = geocodersNames[i].trim().toLowerCase();
        var geocoderApiKey = geocodersSettings[geocoderName];
        try{
            geocoderProvider = L.Control.Geocoder.mapbox( typeof(geocoderApiKey) === "string" ? geocoderApiKey.trim().toLowerCase() : undefined);
            if ( geocoderProvider != null ) {
                break;    
            }
        } catch(e){
            logger(e);    
        }
    }
    
    const geocoder = this.geocoder = L.Control.geocoder({
        position : "topright",    
        geocoder : geocoderProvider
    });
    
    geocoder.addTo(this.map);
};

/*
    on click on the control to center view on the user marker
*/
MainMapProto.onClickControlFollowUserMarker = function() {
    this.emit("centerOnUserMarker");
    const mainUserID = this.mainUserID;
    if ( typeof(mainUserID) === "number" ) { //if the ID of the user was set
        this.centerMapOnUserMarker(mainUserID);
    }
};

/*
    center the marker on the marker of the user with ID
*/
MainMapProto.centerMapOnUserMarker = function(userID){
    const usersMarkers = this.usersMarkers;
    if ( usersMarkers != null ) {
        const usrMarker = this.usersMarkers[userID];
        if ( usrMarker != null ) { //if the user marker is exists
            this.map.setView(usrMarker.getLatLng());
            usrMarker.bindPopup("You are here!").openPopup();
        }
    }
};

/*
    add control switch for various available layers provided by tiles providers
*/
MainMapProto.addLayersControl = function() {
    
    var map = this.map;
    var providers = L.TileLayer.Provider.providers;
    var listTileProviders = Object.keys(providers);
    var availableTileLayers = {};
    var tileOptionsDefault = this.settings.tileOptionsDefault;
    
    for ( var i =0, len = listTileProviders.length; i < len; i++ ) {
        var tileProviderName = listTileProviders[i];
        if ( providers[tileProviderName].variants != null ) {
            var variants = providers[tileProviderName].variants;
            var variantsNames = Object.keys(variants);
            for ( var ii =0, _len = variantsNames.length; ii < _len; ii++ ) {
                var variantName = variantsNames[ii];
                var tileFullName = tileProviderName + " - " + variantName;
                var tilePath = tileProviderName + "." + variantName;
                availableTileLayers[tileFullName] = L.tileLayer.provider(tilePath, tileOptionsDefault);    
            }
        } else {
            availableTileLayers[tileProviderName] = L.tileLayer.provider(tileProviderName, tileOptionsDefault);    
        }

    }
    
    var grouplayercontrol = L.control.layers(availableTileLayers).addTo(map); //add the control for chosing available tiles
    
    /*this is allows scrolling between the available tiles if there are too much*/
     if (!L.Browser.touch) {
       L.DomEvent
        .disableClickPropagation(grouplayercontrol._container)
        .disableScrollPropagation(grouplayercontrol._container);
    } else {
        L.DomEvent.disableClickPropagation(grouplayercontrol._container);
    }
    
};

/**
 * create the marker and place it on the map
 * coords = LatLng
 * return Marker
 * @method addUserMarker
 * @param {} userID
 * @param {} userName
 * @param {} lat
 * @param {} lng
 * @param {} title
 * @return res
 */
MainMapProto.addUserMarker = function(userID, userName, lat, lng, title) {
    var mainMap = this;
    
    var coords; //{lat, lng}
    if ( typeof(lat) === "object" ) {
        coords = lat;    
    } else {
        coords = {lat, lng};   
    }
    
    if ( this.usersMarkers[userID] != null ) { //if the user is already on the map
        this.moveUserMarkerTo(userID, userName, coords, title);    
    } else { //if necessary to add it to the map
    
        var settingsMarkerUser = this.settings.settingsMarkerUser;
        var prevTitle = settingsMarkerUser.title;
        
        if ( title !== undefined ) {
            settingsMarkerUser.title = title;
        } else 
            if ( typeof(userID) === "number"
                || typeof(userID) === "string" ) {
                    settingsMarkerUser.title = userID + "";
            }
        
        var res = this.Leaflet
                    .Marker.movingMarker([coords, coords], [1], settingsMarkerUser) //create the user marker with the settings, defined by the settingsMarkerUser option into the global settings
                    .addTo(this.map)  //put the user marker on the map
                    .on("click", mainMap.onClickMarkerUser.bind(mainMap, userID) );
        
        settingsMarkerUser.title = prevTitle;
        
        if ( userID === this.mainUserID ) { //if it is the main user marker
            const uiDOM = res._icon;
            if ( uiDOM != null ) {
                $(uiDOM).attr("id", "mainMap_userMarker");    
            }
        }
        
        this.usersMarkers[userID] = res;
        
        return res;
        
    }
};

/**
 * remove the nearest user from the list and the map
 * @method removeUserMarker
 * @param {} userID
 * @return 
 */
MainMapProto.removeUserMarker = function(userID) {
    var marker = this.usersMarkers[userID];
    if ( marker != null ) { //if a marker for the user is exists
        this.map.removeLayer(marker); //remove the user marker from the map    
    }
    delete this.usersMarkers[userID]; //delete the nearest user from the list
};

/**
 * move the user marker to position, defined by a coords = latlng
 * @method moveUserMarkerTo
 * @param {} userID
 * @param {} name
 * @param {} coords
 * @return 
 */
MainMapProto.moveUserMarkerTo = function( userID, name, coords ) {
    var marker = this.usersMarkers[userID];
    if ( marker != null ) {
        marker.moveTo(coords, this.settings.defaultDuration);
        marker.start();
    }
};

/**
 * retrun the user coordinates from the map
 * return { lat, lng }
 * @method getUserCoordsOnMap
 * @param {} userID
 * @return 
 */
MainMapProto.getUserCoordsOnMap = function(userID) {
    var marker = this.usersMarkers[userID];
    if ( marker != null ) {
        return marker.getLatLng();
    } else {
        return {lat:null, lng:null};    
    }
};

MainMap.prototype = MainMapProto;

module.exports = MainMap;
},{"commonlib":undefined,"eventemitter":undefined,"globalSettings":undefined,"logger":undefined}]},{},[]);
