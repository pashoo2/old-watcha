require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"User":[function(require,module,exports){
/*global localforage*/
/*global chance*/
/*global $*/
/*global hello*/

var geo = require("glib");
var PositionWatcher = require("positionWatcher");
var EventEmitter = require("eventemitter");
var timeIntervals = require("timeIntervals");
var commonlib     = require("commonlib");
var getCurrentTimestamp = require("timestamps").getCurrentTimestamp;
var globalSettings = require("globalSettings");
var ConnectorWithAppWorker = require("ConnectorWithAppWorker").ConnectorAppWorker;
var NeighborUser = require("NeighborUser");

var validators = require("validatorsUser");
var validatorUserDescription = validators.validatorUserDescription;

var logger = require("logger").logger;
logger.namespace = "User";

var cMethod = globalSettings.settingsDebug 
              && globalSettings.settingsDebug.spottingMethod; //method to get the current coordinates of the user
var randomLocationChangingMeters = globalSettings.settingsDebug 
                                    && typeof(globalSettings.settingsDebug.randomLocationChangingMeters) === "number"
                                    && globalSettings.settingsDebug.randomLocationChangingMeters > 0 //if > 0, then the user location will be changed from 0 to this value each time when the user's coordinates will be requested
                                    && globalSettings.settingsDebug.randomLocationChangingMeters;
                                    
var directionAngle = globalSettings.settingsDebug  //an angle of the user direction changing
                      && globalSettings.settingsDebug.directionAngle;

/**
 * the object for managing by the general functions for implementing interactions with the client
 * mainMap instance of MainMap - object to display the map on the main window
 * @method User
 * @param {} mainMap
 * @return 
 */
function User(){
    
    this.connected = false; //not connected yet
    this.connectorWithAppWorker = new ConnectorWithAppWorker(this, this.commandHandlersAppWorker); //start the connection with the appWorker
    
    if (globalSettings.debug === true  ) { //set the connector as the global variable to allow send commands for the worker
      window.debugCommand = this.connectorWithAppWorker.sendCommand.bind(this.connectorWithAppWorker);
    }
    
    this.interface = window.interface;
    
    this.getCoordinatesForOthers_callbacks = []; //callback queue for the this.getCoordinatesForOthers
    
    this.timestamps = { //a various timestamps
      getCoordinatesForOthers : 0 //timestamp when the last user coordinates has been received
    };
    
    //bind the context
    this.getCoordinatesForOthers_onCoordinates  = this.getCoordinatesForOthers_onCoordinates.bind(this);
    this.onDropNeighborUser = this.onDropNeighborUser.bind(this);
    this.onShowNeighborUser = this.onShowNeighborUser.bind(this);
    this.onClickOnMarker    = this.onClickOnMarker.bind(this);
    this.moveUserMarker     = this.moveUserMarker.bind(this);
    this.getKeyName         = this.getKeyName.bind(this);
    this.getDataNames       = this.getDataNames.bind(this);
    this.filterPrivateProperties = this.filterPrivateProperties.bind(this);
    this.onMessageFromNeighborUser = this.onMessageFromNeighborUser.bind(this);
    this.onNewNeighborUser = this.onNewNeighborUser.bind(this);
    this.onShowNeighborUserCard = this.onShowNeighborUserCard.bind(this);
    this.getUserCoordinates = this.getUserCoordinates.bind(this);
    this.onNeighborUserConnectionStateChanged = this.onNeighborUserConnectionStateChanged.bind(this);
    this.onCoordsMethod = this.onCoordsMethod.bind(this);
    
    this.listNeighborUsers = {}; //{ userID : NeighborUser }
    this.setEventHandlers(); //set user methods as a handlers
    
    this.on("propertychanged_locationmethod", this.onCoordsMethod); //on changing of the location definition method
    
}

/*
  events:
  neighborusergone(userID) - remove the user from the interface
  neighboruser(nUser) - new neighbor user? where nUser instanceof NeighborUser
  propertychanged_propertyName(propertyValue) - on property value changed 
*/
var userProto = Object.create(new EventEmitter());

/*
  from the global settings
*/
userProto.cMethod = cMethod; //the method to define the current coordinates of the user
userProto.randomLocationChangingMeters = randomLocationChangingMeters;
userProto.directionAngle = directionAngle;
userProto.positionWatcher = new PositionWatcher();
userProto.validatorUserDescription = validatorUserDescription;

/*
  main settings for the users
*/
userProto.settings = {
  storage : {
    text : { //text fields
      name      : "user_username",
      photo     : "user_urlphoto",
      gender    : "user_gender",
      email     : "user_email",
      status    : "user_status",
      age       : "user_age",
      phone     : "user_phone",
      locationmethod  : "user_locationmethod"
    },
    list : { //list fields
      chosentags    : "user_mytags",
      lookingtags   : "user_lookingtags", 
      sociallinks   : "user_sociallinks"
    },
    local : {
      flnotfirststart : "user_flnotfirststart"  
    }
  }
};

/*
  list with the private properties, not for other users
*/
userProto.privateProps = ["lookingtags"];

//handlers of a commands from the appWorker and the mainP2P
userProto.commandHandlersAppWorker = { //commands for User
    "getCoordinates" : "getCoordinatesForOthers", //get the current User coordinates
    "getDescription" : "getDescriptionForOthers", //get the current User descrtiption with coordinates
    "setUserID" : "setUserID",
    "onConnectedToCS" : "onConnectedToCS",
    "locationChange" : "onLocationChanged",
    "onConnectedToLS" : "onConnectedToLS",
    "onDisconnectedFromLS" : "onDisconnetedFromLS",
    "locationDescription" : "onLocationDescription",
    "offerSDP"  : "onOfferSDP",
    "answerSDP" : "onAnswerSDP",
    "connectionCSState" : "updateCSConnectionState"
};

/*
  return true if the property is not private 
*/
userProto.filterPrivateProperties = function(propName) {
  return ( this.privateProps.includes(propName) === false );  
};

/*
  add prefix to define the current user from other
*/
userProto.addPrefixKeyNameForCurrentUser = function(keyName) {
  return this.myID + "_" + keyName;  
};

/**
 * return the storage keyname by the user data field name
 * @method getKeyName
 * @param {} propName
 * @return 
 */
userProto.getKeyName = function(propName) {
  var storageSettings = this.settings.storage;
  var fieldname = propName.trim().toLowerCase();
  var keyName = storageSettings.text[fieldname];
  
  if ( keyName == null ) { //if not in the textfields
    keyName = storageSettings.list[fieldname];
  }
  
  if ( keyName == null ) { //may be it's local setting
    keyName = storageSettings.local[fieldname];
  }
  
  if ( keyName == null ) {
    return null;
  } else {
    return this.addPrefixKeyNameForCurrentUser(keyName);
  }
  
};

/**
 * listKeys - list from which the data properies names must be given
 * if the listKeys is empty, it return all fields names
 * flFiltered = true, return without the private properties
 * @method getDataNames
 * @param {} listKeys
 * @return _names
 */
userProto.getDataNames = function(listKeys, flFiltered) {
  
  var _names, i, len, res;
  var storageSettings = this.settings.storage;
  if ( listKeys == null ) { //return all fields names
    var storageNames = Object.keys(storageSettings);
    for( i = 0, len = storageNames.length; i <len; i++ ) {
      Object.keys(storageSettings[storageNames[i]]);
    }
  } else {
    if ( typeof(listKeys) === "string" ) {
      _names = Object.keys(storageSettings[listKeys]);
    } else {
      _names = Object.keys(listKeys);
    }
  }
  
  if ( flFiltered === true ) { //without the private properties
    res = _names.filter(this.filterPrivateProperties);  
  } else {
    res = _names;  
  }
  
  return res;
  
};

/**
 * return the names of the user data properties for a text user data
 * flFiltered = true, return without the private properties
 * @method getTextDataNames
 * @return CallExpression
 */
userProto.getTextDataNames = function(flFiltered) {
  return this.getDataNames(this.settings.storage.text, flFiltered);
};

/**
 * return names for a all user data
 * flFiltered = true, return without the private properties
 * @method getListDataNames
 * @return CallExpression
 */
userProto.getListDataNames = function(flFiltered) {
  return this.getDataNames(this.settings.storage.list, flFiltered); 
};


/*
  load the name of the user from the storage
*/
userProto.loadName = function(userID) {
  var _user = this;
  _user.getDataValue("name",
    function(res){
      if ( typeof(res) === "string"
        && res.length > 0)
          _user.name = res.trim();  
    }
  );
};

/**
 * return NeighborUser instance by it's id or false
 * @method getNeighborUser
 * @param {} userID
 * @return 
 */
userProto.getNeighborUser = function(userID) {
  var nUser = this.listNeighborUsers[userID];
  if ( nUser instanceof NeighborUser ) {
    return nUser;  
  } else {
    return false;  
  }
};

/*
  return array with NeighborUser instances depending on flag flFiltered
  flUnfiltered = false - return infiltrated users
  flUnfiltered = true - return unfiltered users
  flUnfiltered = null/undefined - return all
*/
userProto.getNeighborUsers = function(flUnfiltered) {
  var nUsers = this.listNeighborUsers;
  var nUsersNames = Object.keys(nUsers); //array with the neighbor users names
  var res = [], ind = 0;
  for ( var i = 0, len = nUsersNames.length; i < len; i++ ) {
    var nUserID = nUsersNames[i];
    var nUser = nUsers[nUserID];
    if ( nUser instanceof NeighborUser ) {
        if ( flUnfiltered != null ) {
          if ( this.filterNeighborUser(nUser) !== flUnfiltered ) { //if equals to ther given flag
            res[ind++] = nUser;  
          }
        } else { //return all users
          res[ind++] = nUser;
        }
                  
    }  
  } 
  return res;
};

/*
  return a Promise, that will be fulfilled when Data Connection will be established with the neighbor user
  or rejeted if can't to connect with the user
*/
userProto.connectWith = function(userID) {
  var nUser = this.getNeighborUser(userID);
  if ( nUser !== false ) {
    return nUser.startChat(); //trying to connect with the neighbor user  
  } else {
    return Promise.reject(new Error("The user was not found"));  
  }
};

/*
  send the message to the neighbor user with the given id
*/
userProto.sendTo = function(userID, message){
  var nUser = this.getNeighborUser(userID);
  if ( nUser !== false ) {
    nUser
        .sendMessage(message)
        .then(function(res){
          window.interface.showChatMessage(userID, res); //show this message in the chatbox 
        }); //send
  } else { //the neighbor user was not found
    logger("The neighbor user with id = " + userID + "  was not found");  
  }
};

/*
  return Promise fulfiled with the Array, that consists of the messages descriptions objects
*/
userProto.loadMessagesHistoryWithNeighborUser = function(userID) {
  var nUser = this.getNeighborUser(userID);
  if ( nUser !== false ) {
    return nUser.loadMessagesHistory();
  } else {
    return null;  
  }   
};

/*
  on various stages of the connection to the cs
  state is a string
*/
userProto.updateCSConnectionState = function(state){
  this.interface.showConnectionState(state); //show the connection state for the user 
};

/**
 * on incoming offer to create the messaging channel between the two users
 * @method onOfferSDP
 * @param {} args
 * @return 
 */
userProto.onOfferSDP = function( args ) {
  this.emit("offerSDP", args);
};

/**
 * on incoming answer to the offer
 * @method onAnswerSDP
 * @param {} args
 * @return 
 */
userProto.onAnswerSDP = function( args ) {
  this.emit("answerSDP", args);
};

/**
 * on location of the user was changed
 * @method onLocationChanged
 * @param {} newL
 * @return 
 */
userProto.onLocationChanged = function(newL) {
  
  if ( this.currentLocationHash !== newL[0] //if the location hash
      || this.currentLocalServerID !== newL[1] ) { //or the local server id is changed
        
        this.currentLocationHash  = newL[0];
        this.currentLocalServerID = newL[1];
        
        window.interface.showValue("locationHash"  , newL[0]);
        window.interface.showValue("localserverID" , newL[1]);
  }
  
};

/**
 * save users social links
 * socialLinks : {
 * socialName : url or null
 * }
 * @method setSocialLinks
 * @param {} socialLinks
 * @return 
 */
userProto.setSocialLinks = function(socialLinks) {
  var _key = this.getKeyName("sociallinks"); //name of the key in the storage
  var _socialLinks = commonlib.cleanObjectBannedWords(socialLinks, true);
  if ( _socialLinks != null ) {
    commonlib.saveObjLocalForage(this.handleSocialLinks(socialLinks), _key);
  }
};

/**
 * save users social links
 * @method getSocialLinks
 * @param {} cb
 * @return 
 */
userProto.getSocialLinks = function(cb) {
  var _key = this.getKeyName("sociallinks"); //name of the key in the storage
  commonlib.getObjLocalForage(_key, cb);
};

/**
 * return a social links which have a not empty url in format
 * { 
 * "social network name" : "profile url"
 * }
 * @method handleSocialLinks
 * @param {} socials
 * @return resSocialLinks
 */
userProto.handleSocialLinks = function(socials) {
  var resSocialLinks; 
  if ( socials != null ) { //if not empty
    var socialNames = Object.keys(socials);   
    for( var i = 0, len = socialNames.length; i < len; i++ ) { //for each social link
      
      if ( resSocialLinks === undefined ) {
        resSocialLinks = {};  
      }
      
      var socialNetName = socialNames[i];
      var socialLink = socials[socialNetName];
      if ( typeof(socialLink) === "string" ) {
          socialLink = socialLink.trim();
          if ( socialLink != ""
            && socialLink != " " ) {
              resSocialLinks[socialNetName.trim()] = socialLink; //add to the resulted list    
          }
      }
    }
  }
  
  return resSocialLinks;
};

/**
 * delete all the neighbor users
 * @method dropAllNeighborUsers
 * @return 
 */
userProto.dropAllNeighborUsers = function() {
  var listNeighborUsers = this.getNeighborUsers(); //list with all the NeighborUsers
  for( var i = 0, len = listNeighborUsers.length; i < len; i++ ) {
    var nUser = listNeighborUsers[i];
    this.removeListenersFromNeighborUser(nUser); //remove listeners from neighbor users
    nUser.drop(); //drop the user from map and all p2p connections with him
  }
};

/**
 * return a compressed JSON string, that describes the user
 * locationDescription = JSON string : { coords : { lat, lng, coordsTimestamp }, desc : description }
 * description : { phone, email, tags, status, name, gender, age, sociallinks, tags }
 * socialLinks : { socialName : link }, socialName - name of the social network, link - link to the profile
 * tags : [] - array with a text tags, that describes the user
 * status : string - text information about the user
 * @method getDescriptionForOthers
 * @param {} callback
 * @return 
 */
userProto.getDescriptionForOthers = function(callback) {
  var _user = this;
  var _callback = typeof(callback) === 'function' ? callback : this.sendToMainP2PCallback("getDescription");
  _user.getCoordinatesForOthers(
    function(coords) {
      _user
      .getAllUserData(true, true, true) //get only non empty values of the user properties
      .then(
        function(desc){
          JSON.stringifyAsync( //compress the description
            desc,
            function(compressedDesc) { 
              _callback({
                coords : coords,
                desc   : compressedDesc
              }); 
            },
            true //with compression
          );
        }
      );
    }
  );  
};

/**
 * on location description was came from the ls
 * locationDescription = JSON string : { userID : { lat, lng, coordsTimestamp, description } }
 * description : { contacts, tags, about }
 * contacts : { email, phone, socialLinks : { socialName : link } }, socialName - name of the social network, link - link to the profile
 * tags : [] - array with a text tags, that describes the user
 * about : string - text information about the user
 * @method onLocationDescription
 * @param {} locationDescription
 * @return 
 */
userProto.onLocationDescription = function(locationDescription) {
  
  var i, len, userID;
  
  var incomingUsersID = Object.keys(locationDescription); //id of the users from the incoming description
  
  var currentListNeighborUsers = this.listNeighborUsers; //list with all the current neighbor users
  var currentUsersID    = Object.keys(currentListNeighborUsers); //id of the users from the incoming description
  var thisUserID = this.myID + "";
  
  var listNeighborUsersToDrop = this.listNeighborUsersToDrop;
  if ( Array.isArray(listNeighborUsersToDrop) !== true ) { //if the list is not exists
    listNeighborUsersToDrop = this.listNeighborUsersToDrop = []; 
  } else { //if exists
    //drop all the neighbor users, that are 2 times not into the incoming location description
    for( i = 0, len = listNeighborUsersToDrop.length; i < len; i++ ) {
      var neighborUserToDrop    = listNeighborUsersToDrop[i]; //id of the neighbor user, which is into the current list of the neighbor users
      
      if ( neighborUserToDrop != null
        && neighborUserToDrop.closed !== true ) { //if the neighbor user is exists
          var neighborUserIDToDrop = neighborUserToDrop.id.toString();
          
          if ( neighborUserIDToDrop !== thisUserID ) { //if it is not the current user
            if ( incomingUsersID.indexOf(neighborUserIDToDrop) === -1 ) { //if the user is absent into the new list of the neighbor users
             neighborUserToDrop.drop();
            }
          }
      }
      
    }
  }
  
  listNeighborUsersToDrop = this.listNeighborUsersToDrop = []; //clear the list
  var indDrop = 0; //the current index into the new list of the neighbor users to drop
  
  //put all the neighbor users , that are not in the new location description, into the drop list
  for( i = 0, len = currentUsersID.length; i < len; i++ ) {
    userID = currentUsersID[i]; //id of the neighbor user, which is into the current list of the neighbor users
    
    if ( userID !== thisUserID ) { //if it is not the current user
      if ( incomingUsersID.indexOf(userID) === -1 ) { //if the user is absent into the new list of the neighbor users
        listNeighborUsersToDrop[indDrop++] = currentListNeighborUsers[userID];
      }
    }
    
  }
  
  //update the description for the current neighbor users and add a new users
  for( i = 0, len = incomingUsersID.length; i < len; i++ ) {
    userID = incomingUsersID[i];
    
    if ( userID !== thisUserID ) { //if it is not the current user
      if ( currentUsersID.indexOf(userID) !== -1 ) { //if the user is already into the list of the neighbor users
        currentListNeighborUsers[userID].updateDescription(locationDescription[userID]);  
      } else { //if the new neighbor user
        this.onNewNeighborUser(userID, locationDescription[userID]); //add new user
      }
    }
    
  }
  
};

/**
 * create new instance of NeighborUser and set listeners for it's events
 * @method onNewNeighborUser
 * @param {} userID
 * @param {} description
 * @return 
 */
userProto.onNewNeighborUser = function(userID, description) {
  var nUser = this.listNeighborUsers[userID] //add the new user into the list
                      = new NeighborUser(userID, description); //create the new instance of NeighborUser 
  
  this.setListenersForNeighborUser(nUser);

};

/*
  show live video stream provided by the neighbor user
*/
userProto.showNeighborUserVideoStream = function(userID) {
  var nUser = this.getNeighborUser(userID);
  if ( nUser !== false ) { //if a neighbor user was found
    nUser.watchVideoStream();  
  }
};

/*
  return true if the neighbor user must be filtered(unsuitable) by his hash tags
*/
userProto.filterNeighborUser = function(neighborUser) {
  var neighborUserTags;
  if ( typeof(neighborUser) === "string") { //if id is given
    var nUser = this.getNeighborUser(neighborUser);
    if ( nUser !== false ) { //if found
      neighborUserTags = nUser.chosentags; 
    }
  } else {
    neighborUserTags = neighborUser.chosentags;
  }
  var userLookingTags  = this.lookingtags;
  if ( Array.isArray(neighborUserTags) === true
      && Array.isArray(userLookingTags) ) {
        for( var i = 0, len = neighborUserTags.length; i < len; i++ ) {
          if ( userLookingTags.includes(neighborUserTags[i]) === true ) { //if a one of the neighbor user tags is chosen as the looking tag by this user
            return false; //do not filter the neighbor user 
          }
        }
  }
  return true; //by default do not show the neighbor user
};

/*
  on messaging connection state changed
*/
userProto.onNeighborUserConnectionStateChanged = function(nUserID, newState, flDisconnected) {
  this.emit("neighboruserconnectionstatechanged", nUserID, newState, flDisconnected);
};

/*
  a neighbor user want to show it
  flForTheFirstTime - the user is not on the map,
  neighborUser - object neighbor user
*/
userProto.onShowNeighborUser = function(neighborUser) {
  //check if the user must be filtered by it's hash tags
  if ( this.filterNeighborUser(neighborUser) !== true  ) { //if not filtered
    this.mainMap.addUserMarker(neighborUser.id, neighborUser.name, neighborUser.lat, neighborUser.lng);
  } else { //remove him from the map
    this.mainMap.removeUserMarker(neighborUser.id);
  }
  
  this.emit("neighboruser", neighborUser);
};

/*
  show the neighbor user description on the screen
  htmlRepresentation - html code
*/
userProto.onShowNeighborUserCard = function(nUser) {
  this.emit("neighborusercard", nUser);
};

/**
 * remove the user from the map and the list 
 * @method onDropNeighborUser
 * @param {} userID
 * @return 
 */
userProto.onDropNeighborUser = function(userID) {
  var nUser = this.listNeighborUsers[userID];
  this.removeListenersFromNeighborUser(nUser);
  delete this.listNeighborUsers[userID];
  this.mainMap.removeUserMarker(userID);
  this.emit("neighborusergone", userID);
};

/*
  on incoming message from the neighbor user
*/
userProto.onMessageFromNeighborUser = function(userID, message) {  
  window.interface.chatWith(userID);
};

/*
  set all listeners for neighbor user events
*/
userProto.setListenersForNeighborUser = function(nUser) {
   //set the listeners for neigbor user
  nUser.on("gone", this.onDropNeighborUser); //remove from the map and the list
  nUser.on("show", this.onShowNeighborUser); //show a marker for the user for the first time
  nUser.on("showMyCard", this.onShowNeighborUserCard); //show a neghbor user card
  nUser.on("message", this.onMessageFromNeighborUser);
  nUser.on("connectionstatechanged", this.onNeighborUserConnectionStateChanged);
};


/*
  remove all listeners for neighbor user events
*/
userProto.removeListenersFromNeighborUser = function(nUser) {
   //set the listeners for neigbor user
  nUser.removeListener("gone", this.onDropNeighborUser); //remove from the map and the list
  nUser.removeListener("show", this.onShowNeighborUser); //show a marker for the user for the first time
  nUser.removeListener("showMyCard", this.onShowNeighborUserCard); //show a neghbor user card
  nUser.removeListener("message", this.onMessageFromNeighborUser);
  nUser.removeListener("connectionstatechanged", this.onNeighborUserConnectionStateChanged);
};

/**
 * on click by the user marker
 * @method onClick
 * @return 
 */
userProto.onClick = function() {
    
};

/**
 * when click on the marker of the user with id = userID
 * @method onClickOnMarker
 * @param {} userID
 * @return 
 */
userProto.onClickOnMarker = function(userID) {
  if ( userID === this.myID ) { //if it is the current user
    this.onClick();
  } else {
    var neighborUser = this.getNeighborUser(userID);
    if ( neighborUser !== false ) {
      neighborUser.onClick();  
    }
  }  
};

/**
 * on connected to ls
 * @method onConnectedToLS
 * @param {} lsID
 * @return 
 */
userProto.onConnectedToLS = function(lsID) {
  window.interface.showValue("connectedtolocalserverid", lsID);
};

//on disconnected from the ls
/**
 * Description
 * @method onDisconnetedFromLS
 * @return 
 */
userProto.onDisconnetedFromLS = function() {
  window.interface.showValue("connectedtolocalserverid", "");  
};

/**
 * send any to the MainP2P
 * commandName - a command or an event name for the instanceof MainP2P
 * args - arguments for the command
 * @method sendToMainP2P
 * @param {} commandName
 * @param {} args
 * @return 
 */
userProto.sendToMainP2P = function(commandName, args) {
  this.connectorWithAppWorker.sendToMainP2P(commandName, args);
};

/**
 * return the function with only the one argument and send a value of this argument to the MainP2P assigned with the given command name
 * commandName - a command or an event name for the instanceof MainP2P
 * args - arguments for the command
 * @method sendToMainP2PCallback
 * @param {} commandName
 * @return FunctionExpression
 */
userProto.sendToMainP2PCallback = function(commandName) {
  var _self = this;
  return function(res){
    _self.sendToMainP2P(commandName, res);
  }; 
};

/**
 * after the current user coordinates were received, call a callbacks from the queue
 * res = {latitude, longitude}, if unknown coords, then {latitude:null, longitude:null}
 * @method getCoordinatesForOthers_onCoordinates
 * @param {} res
 * @return 
 */
userProto.getCoordinatesForOthers_onCoordinates = function(res){
  var callbacksQueue = this.getCoordinatesForOthers_callbacks;
  var randomLocationChangingMeters = this.randomLocationChangingMeters;
  var directionAngle = this.directionAngle;
  
  if ( res.message != null) { //if error
      logger(res);  
      this.flErrorOnCoords = true;
      this.cMethod = "marker"; //change the method to the "marker"
      this.interface.showConnectionState("Can't get your coordinates, your coordinates will be determined by the marker on the map");  
      res = { //return fake coordinates
        latitude  : 0,
        longitude : 0
      };
  } else {
    if ( this.flErrorOnCoords === true ) { //if no errors 
      this.flErrorOnCoords = false;
      this.setCoordsMethod(); //load the method from the storage
    } 
  }
    
  if ( randomLocationChangingMeters !== false ) { //it is necessary to change the user coordinates according to the app settings
      if ( res.latitude != null
          && res.longitude != null ) { //if coordinates are defined
            var rad = geo.convertMetersToDegrees(randomLocationChangingMeters, res.latitude); //convert a meters to a degrees
            //if directionAngle is not false, then the angle of direction is predefined and not null, then the user will moving with this angle and random distance
            res = geo.getCoordsOfDistantPointByRadiusAndAngle(chance.floating({min: 0, max: rad, fixed: 6}), directionAngle === "random" ? chance.integer({min: -180, max: 180}) : directionAngle, res); //add a random radius and an angle to the coords and get a coordinates of the resulted point
      }
    }
    
    if (res != null
        && res.latitude  != null 
        && res.longitude != null ) {
          window.interface.showValue("latitude", res.latitude);
          window.interface.showValue("longitude", res.longitude); 
    }
    
    if ( commonlib.isArray(callbacksQueue) === true
        && callbacksQueue.length !== 0 ) {
          for ( var i =0, len = callbacksQueue.length; i < len; i++ ) { //for an each callback
            var cb = callbacksQueue[i];
            if ( typeof(cb) === "function" ) {
              cb(res);  //call the callback
            }
          }  
    }
    this.getCoordinatesForOthers_callbacks = []; //clear the queue
    this.timestamps.getCoordinatesForOthers = getCurrentTimestamp();
};

/**
 * get the user coordinates by the default method
 * @method getUserCoordinates
 * @return 
 */
userProto.getUserCoordinates = function() {
  this.positionWatcher.getUserCoordinates(this.getCoordinatesForOthers_onCoordinates); //get the current coordinates of the user
};

/*
  res - coords method
*/
userProto.onCoordsMethod = function (res){
  var cMethod;
  var user = this;
  switch(res) {
    case "Automatic":
      cMethod = user.cMethod = "gps";
      break;
    case "Manual":
      cMethod = user.cMethod = "marker";
      break;
    default:
      cMethod = user.cMethod = userProto.cMethod;
  }
     
  if ( cMethod === "gps"  ) { //if the position updated by the gps
    user.positionWatcher.on("newcoordinates", user.moveUserMarker); //update the user position when new coordinates are received
    this.mainMap.enableDisableDraggingForMarker(); //disable dragging for the user marker
  } else { //remove the listener
    user.positionWatcher.removeListener("newcoordinates", user.moveUserMarker);
    this.mainMap.enableDisableDraggingForMarker(true); //enable dragging for the user marker
  }
      
};

/*
  load and set the property cMethod according to the app settings
*/
userProto.setCoordsMethod = function() {
  var user = this;
  user.getDataValue("locationmethod", user.onCoordsMethod);
};

/**
 * get the user coordinate according to the method defined by the global settings
 * @method getUserCoordinatesByMethod
 * @return 
 */
userProto.getUserCoordinatesByMethod = function() {

  switch ( this.cMethod ) { //get the user coordinates depending on the method, that is defined into the app settings
    case "gps": //get user coordinates by the navigator.Geolocation
      this.getUserCoordinates();
      break;
    case "marker": //by marker position
      if ( commonlib.hasProperty(this, "mainMap") === true ) { //if the _map option is defined for this user instance
        var _mainMap = this.mainMap;
                        
        var coords = _mainMap.getUserCoordsOnMap(this.myID); //get the coordinates of the user marker
        if ( coords.lat === null ) { //if can't get the users coordinates on map, then get it by default method
          logger(new Error("can't get the user coordinates by the marker"));
        } else {
          this.getCoordinatesForOthers_onCoordinates({latitude: commonlib.round(coords.lat, 6), longitude: commonlib.round(coords.lng, 6)});
          break;
        }
      }
    case "txtInputFields": //by text input fields from the main window
      var lat = window.interface.getValue("lattitude");
      var lng = window.interface.getValue("longitude");
      if ( typeof(lat) === "string" 
            && typeof(lng)  === "string" ) { //if the fields are exists
              this.getCoordinatesForOthers_onCoordinates(
                        { 
                          latitude: (parseFloat(lat)),
                          longitude: (parseFloat(lng))
                        }
              );  
              break;
      }
    default: //use the default method
      this.getUserCoordinates();
      break;
  }
};

/**
 * get a coordinates, which are visible for other users. return callback({latitude, longitude})
 * @method getCoordinatesForOthers
 * @param {} callback
 * @return 
 */
userProto.getCoordinatesForOthers = function(callback) {
    var callbacksQueue = this.getCoordinatesForOthers_callbacks; //the queue with the callback functions to call, after when the current user coordinates will be received
    var _cb = typeof(callback) === "function" ? callback : this.sendToMainP2PCallback("getCoordinates"); //define the callback if not exists
    if ( commonlib.isArray(callbacksQueue) === false ) { //if the queue is absent
      this.getCoordinatesForOthers_callbacks = [];
    } else if ( _cb != null ) {
      if ( callbacksQueue.indexOf(callback) === -1 ) { //if not found into the queue
        callbacksQueue[callbacksQueue.length] = _cb; //put the callback to the queue
        if ( callbacksQueue.length === 1 //if the method to define the user coordinates not called before(because of the queue had been empty, before this callback has been pushed into the queue)
            || (getCurrentTimestamp() - this.timestamps.getCoordinatesForOthers) > timeIntervals.timeIntervalSecondsUserOverdueGetCoordinatesForOthers //or the last attemp to get the coordinates has been overdue
          ) { //get the current coordinates
              this.getUserCoordinatesByMethod();
        }
      }
    }
};

/*
  check if the user is already logged in
*/
userProto.checkLoggedIn = function() {
  var _self = this;
  return new Promise(
    function(resolve, reject) {
      var loginServiceName = _self.loginServiceName;
      if ( typeof(loginServiceName) === "string" ) {
        const authResponse = hello(loginServiceName).getAuthResponse(); 
        if ( typeof(authResponse.access_token) === "string" ) {
          resolve([loginServiceName, _self.authid, authResponse.access_token]);
        } else {
          resolve(new Error("Not logged in"));  
        }
      } else {
        resolve(new Error("Not logged in"));  
      }  
    }  
  );
};

/*
  login on app
*/
userProto.logIn = function() {
  var _self = this;
  return _self
          .interface
          .chooseLogInService()
          .then(function(serviceName){
            return _self.startLogIn(serviceName);  
          });
};

/*
  start log in
  serviceName - service for auth, like 'facebook'
*/
userProto.startLogIn = function(serviceName) { 
  var _self = this;
  return hello
          .login(
              serviceName, //login through the chosen service
              {
                response_type : "token",
                display : "popup"
              }
          )
          .then(
            function(res){
              if( res.authResponse != null ) {
                var authResponse = res.authResponse;
                var loginServiceName = _self.loginServiceName = res.network;
                return hello(loginServiceName)
                        .api("/me")
                        .then(function(info){ //request the user id from the auth service
                            if ( typeof(info.id) === "string" ) {                           
                              var authid = _self.authid = info.id; //this is id in the auth service
                              return [loginServiceName, authid, authResponse.access_token];
                            } else {
                              throw new Error("Can't get the user id from the Authentification service " + loginServiceName); 
                            }
                        });
              } else {
                throw new Error("Wrong login result");  
              }
            }
          );
};

/**
 * start the connection to the cs
 * @method start
 * @return 
 */
userProto.start = function() {
  var _self = this;
  _self
    .logIn()
    .then(function(res){ //connect to the central server
        if ( Array.isArray(res) === true ) {
          var uid = res[1];
          var accessToken = res[2];
          _self.connectorWithAppWorker.start(uid, accessToken, _self.listHandlersMainP2P); //send handlers for the commands from the mainP2P
        } else {
          throw new Error("Wrong token and user ID");  
        }
    })
    .catch(function(e){ //user not authorized the app
      _self.interface.showConnectionState("Loading is stopped by the reason : " + e.message);  
    });
};

/**
 * move the marker of the current user 
 * @method moveUserMarker
 * @param {} coords
 * @return 
 */
userProto.moveUserMarker = function(coords) {
  this.mainMap.moveUserMarkerTo( this.myID, this.name, { lat : coords.latitude, lng: coords.longitude } );  
};

/**
 * the cs gave us the id
 * @method setUserID
 * @param {} myID
 * @return 
 */
userProto.setUserID = function(myID) {
  this.myID = myID;
  window.interface.showValue("userID", myID);
  this.loadName(); //load the name of the user
};

/*
  check if the user is a newcomer
*/
userProto.isNewUser = function(){
  var _self = this;
  debugger;
  return _self
        .getDataValue("flNotFirstStart") //get the value from the storage
        .then(function(res){
          // setTimeout(function(){
          //   _self.getDataValue("notFirstStart", true); //after the 5 minutes set the flag that the user is not a newer
          // }, 300000);
          
          return res !== true; 
        });
};

/**
 * we connected to the cs with the given id
 * @method onConnectedToCS
 * @param {} myID
 * @return 
 */
userProto.onConnectedToCS = function(myID) {
  var _self = this;
  _self.setUserID(myID);
  _self.connected = true;
  _self.setCoordsMethod();
  
  _self.isNewUser() //check if the new user and send it to the User interface object
  .then(function(res){
      _self.getCoordinatesForOthers(
        function(coords){ //get the user coordinates
          _self.interface.onUserConnected(res === true); //inform about the user connected to the cs //!!!!
          _self.setMainMap(coords);
          _self.getTags();
          _self.getTags(true);
        }
      );
  });
};

/*
  set the mainMap prop and events listeners for it
  show user marker and set the interval for updating the user marker position on the main map
  return MainMap instance   
*/
userProto.setMainMap = function(coords) {
  const mainMap = this.mainMap = window.interface.mainMap; //map
  
  if ( coords instanceof Error //if an error
    || coords.latitude == null) { //or wrong coordinates format
      logger(coords);
      mainMap.showMap({latitude: 0, longitude: 0}); //draw the map on the main window and show the user marker according to the given coordinates  
  } else {
    mainMap.showMap(coords); //draw the map on the main window and show the user marker according to the given coordinates  
  }
  
  const myID = this.myID;
  
  mainMap.setMainUser(myID); //set the user id for the main map
  mainMap.addUserMarker(myID, "me", coords.latitude, coords.longitude, "It's me"); //add the user marker to the map
  mainMap.on("clickOnMarker", this.onClickOnMarker);

};

/**
 * browser is closing
 * @method onBrowserClose
 * @return Literal
 */
userProto.onBrowserClose = function() {
  this.sendToMainP2P("browserClose");  //send this event for worker
  this.dropAllNeighborUsers(); //drop all connections with the neighbor users on the location
  return "Good bye!";
};

/**
 * set user methods as a handlers for a various events
 * @method setEventHandlers
 * @return 
 */
userProto.setEventHandlers = function() {
  var user = this;
  
  $(window).unload(user.onBrowserClose.bind(user)); //onbeforeunload event listener
};

/*
  set the property lookingtags for the user  
*/
userProto.setLookingTags = function(tags, _cb) {
  if ( Array.isArray(tags) === true ) {
    this.lookingtags = tags;  
  }  
};

/**
 * get tags, that were chosen by the user
 * return cb(err, result)
 * @method getTags
 * @param {} flLooking
 * @param {} _callback
 * @return 
 */
userProto.getTags = function(flLooking, _callback) {
  var user = this;
  var settingName = flLooking === true ? "lookingtags" : "chosentags";
  var _key = user.getKeyName(settingName); //name of the key in the storage
  var cb;
  if ( flLooking === true ) {
    if ( Array.isArray(user.lookingtags) === true ) { //if already stored in the property
      if ( typeof(_callback) === "function" ) {
        _callback(user.lookingtags); //do not use the storage, return it directly from the property 
      }
    } else {
      cb = function(res) {
        user.setLookingTags(res); //it is necessary to set the looking tags for this user
        if ( typeof(_callback) === "function" ) {
          _callback(res);
        }
      };
    }
  } else 
    if ( typeof(_callback) === "function" ) {
      cb = _callback;
    }
  commonlib.getObjLocalForage(_key, cb); 
};

/**
 * save the array with the user tags into the storage
 * return cb(err, result)
 * @method saveTags
 * @param {} flLooking
 * @param {} tags
 * @return 
 */
userProto.saveTags = function(flLooking, tags) {
    const user = this;
    var settingName = flLooking === true ? "lookingtags" : "chosentags";
    var _key = this.getKeyName(settingName); //name of the key in the storage
    var _tags = commonlib.cleanObjectBannedWords(tags, true); //clean from the banned words
    if ( _tags != null ) {
      commonlib
        .saveObjLocalForage(_tags ,_key)
        .then(function(){
          user.checkBlankProperties(); //ckeck for unfilled properties  
        });
      if ( flLooking === true ) {
        this.setLookingTags(tags); //set the new looking tags  
      }
    }
};

/**
 * get the user data by it's name and return it to the callback
 * @method getDataValue
 * @param {} valueName
 * @param {} _callback
 * @return 
 */
userProto.getDataValue = function(valueName, _callback) {
  const keyName = this.getKeyName(valueName);
  const flPromise = typeof(callback) !== "function";
  if ( keyName != null ) {
    if ( flPromise === true ) {
      return localforage.getItem(keyName);  
    } else {
      localforage.getItem(
        keyName, 
        function(err, res) { //load from the storage
            if ( typeof(res) === "string"
                && !( err instanceof Error ) ) {
                  if ( typeof(_callback) === "function" ) {
                    _callback(res);  
                  }
            } else {
              if ( typeof(_callback) === "function" ) {
                _callback(res);  
              }  
            }
        }
      );
    }
  } else {
    if ( flPromise === true ) {
      return Promise.resolve(null);
    } else {
      return null;
    }
  }
};

/*
  make sure all necesary fields are filled
*/
userProto.checkBlankProperties = function(){
  const user = this;
  user
  .getAllUserData(false, true, true) //without an empty and the private properties 
  .then(function(desc){
    const validatorUserDescription = user.validatorUserDescription;
    const res = validatorUserDescription(desc);
    if ( res === false ) { //if has some fields, that are necessary to be filled
      const errors = validatorUserDescription.errors;
      const _errKeys = Object.keys(errors);
      const len = _errKeys.length;
      var unfilledFields = []; //array with a names of the unfilled properties
      var ind = 0;
      for ( var i = 0; i < len; i++ ) {
        var fieldDesc = errors[_errKeys[i]];
        var propName = fieldDesc.dataPath; //unfilled property name
        if ( typeof(propName) === "string"
            && propName.length > 0 ) { //if not an empty string
              unfilledFields[ind++] = (propName.indexOf(".") === 0 ? propName.substring(1) : propName);  //whitout a dot at the begin of the property name
        } else { //may be the property is into the 'missing' list
          const params = fieldDesc.params;
          if ( params != null ) {
            const missingProperty = fieldDesc.params.missingProperty;
            if ( typeof(missingProperty) === "string"
                && missingProperty.length > 0 ) {
                unfilledFields[ind++] = fieldDesc.params.missingProperty; //property is missing
            }
          }
        }
      }
      window.interface.highlightUserProperties(unfilledFields, "empty", true);
    } else {
      window.interface.highlightUserProperties(null, "empty", true);  //stop animation for all properties
    }
  });
};

/**
 * save the user data by it's name
 * @method saveDataValue
 * @param {} valueName
 * @param {} value
 * @return 
 */
userProto.saveDataValue = function(valueName, value) {
  var user = this;
  
  if ( typeof(valueName) === "string" ) {
    var keyName = this.getKeyName(valueName);
    if ( keyName != null ) {
      var _value
      
      if ( typeof(value) === "string" ) {
        if ( value === "" ) {
          _value = null;
        } else {
          _value = commonlib.cleanObjectBannedWords(value, true); //clean from the banned words
        }
      }
      
      window.localforage
        .setItem(keyName, _value)
        .then(function(res){
          if ( ( res instanceof Error ) === false ) {
            user.emit("propertychanged_" + valueName, _value);  
          }
          
          user.checkBlankProperties(); //ckeck for unfilled properties
        
        })
        .catch(function(e){
          logger(e);
        });
        
    }
  }
};

/**
 * show in the interface user data, that has a string type
 * @method showTextUserData
 * @return 
 */
userProto.showTextUserData = function() {
  var listUserSimpleProperties = this.getTextDataNames();
  for( var i = 0, len = listUserSimpleProperties.length; i < len; i++ ) {
    let propName = listUserSimpleProperties[i]; //name of the user data
    var keyName = this.getKeyName(propName); //get key name of the property for the storage
    window.localforage
      .getItem(keyName)
      .then(function(value){
        if ( typeof(value) === "string" ) { //if the value is not empty
          window.interface.showValue(propName, value); //show the value
        }
      })
      .catch(function(e){
        logger(e);
      });
  }
};

/**
 * return promise, resulted with all data about the user from the storage
 * flInJSON = true - return the result as a string
 * flInJSON = false - return the result as an object
 * flFiltered = true - filter the private properties
 * flFilterEmpty - without an empty values of the properties
 * @method getAllUserData
 * @param {} flInJSON
 * @return CallExpression
 */
userProto.getAllUserData = function(flInJSON, flFiltered, flFilterEmpty){
  var textDataNames = this.getTextDataNames(flFiltered);
  var listDataNames = this.getListDataNames(flFiltered);
  var i, len, indPromisesToDo;
  var promisesToDo = [];
  var lf = window.localforage;
  
  for( i =0, len = textDataNames.length; i < len; i++ ) {
    promisesToDo[i] = lf.getItem(this.getKeyName(textDataNames[i]));  
  }
  
  indPromisesToDo = i;
  for( i =0, len = listDataNames.length; i < len; i++ ) {
    promisesToDo[indPromisesToDo++] = lf.getItem(this.getKeyName(listDataNames[i]));  
  }
  
  return Promise.all(promisesToDo)
          .then(function(results){
            var i, len, r;
            var indResults = 0;
            var _flInJSON = flInJSON;
            var _listDataNames = listDataNames;
            var _textDataNames = textDataNames;
            var _flFilterEmpty = flFilterEmpty === true;
            
            var resObj = {}; //resulted object
            var resStr = "{"; //the resultet string in JSON
            var dName;
            
            for( i =0, len = _textDataNames.length; i < len; i++ ) {
              r = results[indResults++];
              if ( r==null
                && _flFilterEmpty === true) { //if do not add an empty do nothing
              } else
                if ( _flFilterEmpty !== true 
                     || ( _flFilterEmpty === true
                        && commonlib.isEmptyValue(r) !== true ) ) {
                          dName = _textDataNames[i].trim();
                          if (_flInJSON !== true ) { //return as Object
                            resObj[dName] = r == null ? null : r.trim();  
                          } else { //return as a JSON string
                            resStr = resStr + '"' + dName + '": "' + r.trim() + '",'; //add the property and it's value to the resulted JSON string  
                          }
              }
            }
            
            len = _listDataNames.length;
            var _len = len - 1; //resolve the problem with the , at the end of the resulted JSON string
            for( i = 0; i < len; i++ ) {
              r = results[indResults++];
              if ( r==null
                && _flFilterEmpty === true) { //if do not add an empty do nothing
              } else
                if ( _flFilterEmpty !== true 
                     || ( _flFilterEmpty === true
                        && commonlib.isEmptyValue(r) !== true ) ) {
                          dName = _listDataNames[i].trim();
                          if (_flInJSON !== true  ) { //return as Object
                            resObj[dName] = r == null ? null : JSON.parse(r.trim()); 
                          } else { //return as a JSON string
                            resStr = resStr + '"' + dName + '": ' + r.trim() + ( _len === i ? '' : ',' ); //add the property and it's value to the resulted JSON string  
                          }
                }
            }
            
            //check for Live Video Streaming
            var videoTranslation = window.interface.videoTranslation;
            var liveVideoHash = videoTranslation.getCurrentStreamHash(); //get the hash of the current watching live video stream
            if ( typeof(liveVideoHash) === "string" ) {
                
                if (_flInJSON !== true  ) { //return as Object
                  resObj["videostream"] = liveVideoHash.trim();  
                } else { //return as a JSON string
                  resStr += '"videostream": "' + liveVideoHash +'"';  //put the videostream hash in the description
                }
                
                var broadcastDescription = commonlib.clearBannedWords(videoTranslation.getBroadcastDescription().trim());
                if ( typeof(broadcastDescription) === "string"
                    && broadcastDescription.length > 0 ) {
                      if (_flInJSON !== true  ) { //return as Object
                        resObj["videostreamdescription"] = broadcastDescription.trim();  
                      } else { //return as a JSON string
                        resStr += ', "videostreamdescription": "' + broadcastDescription +'"';  //put the videostream hash in the description    
                      }
                }
                
            }
            resStr +=  '}';
            
            if ( _flInJSON !== true ) { //if necessary to return a plain object
              return resObj;
            } else { //if necessary to return JSON
              return resStr; //return the resulted JSON string 
            }
            
          })
          .catch(function(e){
            logger(e);
          });
  
};

User.prototype = userProto;

module.exports = {
  user : User    
};
},{"ConnectorWithAppWorker":undefined,"NeighborUser":undefined,"commonlib":undefined,"eventemitter":undefined,"glib":undefined,"globalSettings":undefined,"logger":undefined,"positionWatcher":undefined,"timeIntervals":undefined,"timestamps":undefined,"validatorsUser":undefined}]},{},[]);
