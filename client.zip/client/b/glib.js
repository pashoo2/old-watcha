require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"glib":[function(require,module,exports){
/*global geolib*/
const moduleSettings = require("globalSettings").glib;
const commonlib = require("commonlib");

const logger = require("logger").logger;
logger.namespace = "glib";

const optionsCenterCalc = moduleSettings.locationHashCenterPointCalculation;
const locationRadiusFromCenter = Math.pow(optionsCenterCalc.locationRadiusFromCenter,2); //define the bound for the location as the circle around the location center coords
const template = /^[ ]*(\d{1,3})[ ]*([ |.|°|,])(?:(?:[ ]*(\d{1,2})[ ]*([ '.])[ ]*(\d{1,3})[ ]*[.,]*[ ]*(\d{0,2}))|(?:[ ]*(\d{1,6})))/gi;// the regex expression for a string representation of geo coordinate
const templateDegrees = /^[0-9]{1,3}[.,][0-9]+/; //the regexp expression for a string representation of a degrees

/**
 * converts an any representation of the longitude/latitude to the decimal form
 * strCoordRepresentation - string representation of the longitude/latitude
 * digitsAfterComma -number of a digits after the coordinate's comma
 * returns an object with options:
 * octothorpe:octothorpe of a decimal number form,
 * longitude: true if it is longitude, false if it is latitude, null if it may be longitude or latitude at the same time,
 * numberDecimalForm: decimal form of the coordinate represented by a number
 * @method convertCoordsToDecimal
 * @param {} strCoordRepresentation
 * @param {} digitsAfterComma
 * @return ObjectExpression
 */
function convertCoordsToDecimal( strCoordRepresentation, digitsAfterComma )
{
    if ( typeof(strCoordRepresentation) !== "string"
        && typeof(strCoordRepresentation) !== "number" ) {
            logger("Coordinate is an empty object: ");
            logger(strCoordRepresentation);
            return null;
    }
    var flagItIsLongitude = null; //if it is longitude flag will be true
    //converts symbols of N,E,S,W,-,+ into the octothorpe of the decimal form of the coordinates
    var octothorpe = "+";
    if ( typeof(strCoordRepresentation) !== "string" ) {
        strCoordRepresentation = strCoordRepresentation.toString();
    }
    var strCoordRepresentationWithoutOctothorpe = strCoordRepresentation.replace(
        /[NE\+SW-]/gi,
        function(match, offset, TotalString){
            switch( match )
            {
                case "E":
                    flagItIsLongitude = true; //east longitude
                    octothorpe = "+";
                    break;
                case "N": //north latitude
                    flagItIsLongitude = false; //east longitude
                    octothorpe = "+";
                    break;
                case "+":
                    flagItIsLongitude = null; //may be longitude or latitude
                    octothorpe = "+";
                    break;
                case "W":
                    flagItIsLongitude = true; //west longitude
                    octothorpe = "-";
                    break;
                case "S": //south latitude
                    flagItIsLongitude = false; //south lattitude
                    octothorpe = "-";
                    break;
                case "-":
                    flagItIsLongitude = null; //may be longitude or latitude
                    octothorpe = "-";
                    break;
            }
            return "";
        }
    );
    
    var template = this.template;
    template.lastIndex = 0;
    var result = template.exec(strCoordRepresentationWithoutOctothorpe);
    /*result is an array, which contains the following values into the indexes:
     (for example - for coordinate 157°57'12.3"):
     1 - hours (=157)
     2 - if = °, then 1 - is hours, else 1 - is degrees
     3 - minutes (=57)
     4 - if = "." or "," (='), then 5-th index - a part of a minutes (for example, for coordinate 21В°21.728 4-th index is equal to ".", then 5-th index = "728"),
     if (3!=="."  or ","), then 5-th - is a seconds (=12)
     6- part of a second (=3)
     7 - a part of an hour, when the representation is a decimal form of the record ( for coordinate 21.36214 six index is equal to 36214)
     *
     * */
    if ( result == null ) { // if a match is not found
        return null;
    }
    
    var flHourIsAHour = !( result[2] === "°" || this.templateDegrees.test(strCoordRepresentationWithoutOctothorpe) === true ); //the flag means that the expression is a geo coordinates, represented by a form of an hour
    var hour = ( typeof(result[1]) === "string" && result[1] !== "" ) ? result[1] : 0;
    hour = parseInt(hour, 10); //hour or if the representation is a decimal degree form it is a whole part of the degrees
    if ( isNaN(hour) === true
        || ( hour > 180 && flHourIsAHour === false )
        || ( hour > 24  && flHourIsAHour !== false ) //if hour is not a number or greater than 180
        ) {
            return null;
    }
    var partOfDegreese = result[7]; //if the coordinate is already represented by a decimal form, partOfHour is a part of a decimal number after a symbol of comma
    if ( typeof(partOfDegreese) !== "string"
        || partOfDegreese == "" ) {
	    //if the coordinate is not represented by a decimal form
		var degreese = hour; //hours is a degrees in this form
        var minutes = ( typeof(result[3]) === "string" && result[3] !== "" ) ? result[3] : 0;
        minutes = parseInt(minutes, 10);
        if ( minutes > 60 ) {return null;}
        if ( result[4] === "." 
            || result[4] === "," ) {
                var partOfTheMinutes = ( typeof(result[5]) === "string" && result[5] !== "" ) ? result[5] : 0;
                partOfTheMinutes = parseFloat("0." + partOfTheMinutes, 10); //part of the minutes, after the comma symbol
                minutes = minutes + partOfTheMinutes;
                seconds = 0;
        }
        else {
            var seconds = ( typeof(result[5]) === "string" && result[5] !== "" ) ? result[5] : 0;
            seconds = parseInt(seconds, 10);
            if ( seconds > 60 ) {return null;}
            var partOfSeconds = ( typeof(result[6]) === "string" && result[6] !== "" ) ? result[6] : 0; //part of the seconds, after the comma symbol
            partOfSeconds = parseFloat("0." + partOfSeconds, 10);
            seconds = seconds + partOfSeconds;
        }
		var numberDecimalFormWOOctothorpe = degreese + minutes/60 + seconds/3600;  //decimal form without ocotrophe
	} 
	else {
        //if the coordinate is already represented by a decimal degreese form
        partOfDegreese = parseFloat("0."+partOfDegreese, 10);
        if ( isNaN(partOfDegreese) === true ) { //a part after a comma symbol of a decimal form of the coordinate is not a number
            return null;
        }
        numberDecimalFormWOOctothorpe = hour + partOfDegreese;  //decimal form without ocotrophe
    }
    
	if ( numberDecimalFormWOOctothorpe > 180
		|| ( numberDecimalFormWOOctothorpe > 24 && flHourIsAHour === true ) ) {
			return null; //the coordinate is greater than 180
	}
	
	if ( numberDecimalFormWOOctothorpe > 90 ) {
		if( flagItIsLongitude === true ) { //lattitude must be less than 90 
			return null;
		}
		if ( flagItIsLongitude === null ) { //if unknown type of the coordinate, but it is greater than 90 degreese, that means it is longitude
			flagItIsLongitude = true; 
		}
	}
	if ( typeof(digitsAfterComma) === "number" ) {
	    numberDecimalFormWOOctothorpe = parseFloat(numberDecimalFormWOOctothorpe.toFixed(digitsAfterComma));
	}
	
	var numberDecimalForm = ( octothorpe === "+" ) ? numberDecimalFormWOOctothorpe : - numberDecimalFormWOOctothorpe;
	
	return {
        octothorpe : octothorpe,
        longitude  : flagItIsLongitude,
        numberDecimalForm: numberDecimalForm
    };

};

/**
 * get center as the difference between the most distant points by lat / 2 and the most distant points by long / 2
 * arrPoints = Array[point1...pointN], point = {lat, lng}
 * return {lat, lng} or falce if can't be calculted
 * @method getCenterOfLocation
 * @param {} arrPoints
 * @return Literal
*/
function getCenterOfLocation(arrPoints) {
    var optionsCenterCalc = this.optionsCenterCalc;
    var geolib = this.geolib;
    var commonlib = this.commonlib;
    
    if ( arrPoints.length > 1 ) {
        //try to find the minimal and the maximal lat and lng
        var i, len;
        var minLat = 200,
            maxLat = 0,
            minLng = 200,
            maxLng = 0;
        for( i = 0, len = arrPoints.length; i < len; i++ ) {
            var currPoint = arrPoints[i];
            var currLat = currPoint.lat;
            var currLng = currPoint.lng;
            if ( currLat > maxLat ) {
                maxLat = currLat;    
            }
            if ( currLat < minLat ) {
                minLat = currLat;    
            }
            if ( currLng > maxLng ) {
                maxLng = currLng;    
            }
            if ( currLng < minLng ) {
                minLng = currLng;    
            }
        }
        var maxDiffLatDistance = Math.abs(geolib.getDistance({latitude:maxLat,longitude:maxLng},{latitude:minLat,longitude:maxLng}), 5); //get a distance between the points with the maximum distance by lat
        var maxDiffLngDistance = Math.abs(geolib.getDistance({latitude:maxLat,longitude:maxLng},{latitude:maxLat,longitude:minLng}), 5); //get a distance between the points with the maximum distance by lng
        //check if the differences are appropriate for calculation of a center
        if ( maxDiffLatDistance > optionsCenterCalc.minApropriateCoordDiff
            && maxDiffLngDistance > optionsCenterCalc.minApropriateCoordDiff ) {
                return { lat : commonlib.round( ( (maxLat - minLat) / 2 + minLat), 6), lng : commonlib.round( ( (maxLng - minLng) / 2 + minLng ), 6) };        
        }
    }
    return false;
};
    
/**
 * calculate an intersection points, where x1,y1 and x2,y2 - coordinates, where the line moves, x,y - coordinates of the center point and r - radius of the circle
 * return false if there is no intersections
 * return [x,y] if an only one intersection
 * return [[x1,y1],[x2,y2]] - if a two intersections are exists
 * @method calculateIntersectionPoints
 * @param {} x1
 * @param {} y1
 * @param {} x2
 * @param {} y2
 * @param {} x
 * @param {} y
 * @param {} r
 * @return 
*/
function calculateIntersectionPoints (x1,y1,x2,y2,x,y,r) { //the quadratic equation diskrimenant
        
    var k,b,x3,x4,y3,y4;
    if (x1==x2)  {
        k = 0;
    } else {
        k=(y1-y2)/(x1-x2);
    }
    b=y1-k*x1;
    
    var d=(Math.pow((2*k*b-2*x-2*y*k),2)-(4+4*k*k)*(b*b-r*r+x*x+y*y-2*y*b));
     
    //if it is less than zero, then the equation has no a solvations
     if(d<0) {
         return false;
     } else {
    //otherwise find a solvations of the equation
        x3 = ((-(2*k*b-2*x-2*y*k)-Math.sqrt(d))/(2+2*k*k));
        x4 = ((-(2*k*b-2*x-2*y*k)+Math.sqrt(d))/(2+2*k*k));
        y3=k*x3+b;
        y4=k*x4+b;
    //if the abscisses are equal, then the equation has only the one solvation   
        if (x3===x4) {
            return [x3,y3];
        } else {
            return [[x3,y3],[x4,y4]];
        }
     }
}
    
    
/**
 * convert a length value from meters to degrees
 * lengthMeters - a value of the length in meters to convert it to the degrees
 * lattitude - the current value of the lattitude
 * @method convertMetersToDegrees
 * @param {} lengthMeters
 * @param {} lattitude
 * @return BinaryExpression
 */
function convertMetersToDegrees(lengthMeters, lattitude) {
    return lengthMeters / ( 111378 * Math.cos(lattitude * 0.01745329251994329577 ) );    
}
    

/**
 * return a calculated value of the coefficient, that represents ability of a user to become a local server for the location, on which he is located
 * calculate by the last distance, last speed and average speed
 * userDesc = { lat, lng, prevLat, prevLng, averageSpeedGradusPerSec }
 * lat - the current value of the lat coordinate
 * firstLat - a value of the lat coord, when the user has been placed on the location
 * lng  - the current value of the lng coordinate
 * firstLng - a value of the lng coord, when the user has been placed on the location
 * averageSpeedGradusPerSec - the value of the average speed in gradus per second
 * timeOnLocation - а time interval that the user has spent on the location
 * coordsCenter = {lat, lng} of the location center
 * if false, then the value of the coefficient will be calculated only by the last and the average speeds of a user
 * @method calculateValueCoefficientNewLSForLocation
 * @param {} userDesc
 * @param {} coordsCenter
 * @return coeffValue
*/
function calculateValueCoefficientNewLSForLocation(userDesc, coordsCenter) {
    var locationRadiusFromCenter = this.locationRadiusFromCenter;
    var geolib = this.geolib;
    var commonlib = this.commonlib;
    
    var coeffValue; //a value of the coefficient
    if ( coordsCenter === false ) { //if the center is undefined
        var averageSpeedGradusPerSec = userDesc.averageSpeedGradusPerSec;
        if ( averageSpeedGradusPerSec === 0 ) { //if the user is moving with a significant speed
            coeffValue = 0.0001 / Math.abs(averageSpeedGradusPerSec); //the coef is in inverse ratio to the speed of the user;    
        } else { //if the average speed is too small and is not significant(user is not moving)
            coeffValue = userDesc.timeOnLocation;    
        }
    } else {
        var usrCurrentLat = userDesc.lat; //the current value of the lat coordinate of the user
        var usrFirstLat = userDesc.firstLat; //a value of the lng coord, when the user has been placed on the location
        var degRadius = convertMetersToDegrees(locationRadiusFromCenter,coordsCenter.lat); //convert a location radius value from meters to degrees
        var intersectionCoords = calculateIntersectionPoints(usrCurrentLat,userDesc.lng,usrFirstLat,userDesc.firstLng, coordsCenter.lat, coordsCenter.lng, degRadius); //find the intersection betwen the vector of the average speed and the circle as bounds for the location
        var intersectionPoint; 
        var signIncrLat;
        if ( commonlib.isArray(intersectionCoords) === true ) { //if an intersections are exists
            if ( commonlib.isArray(intersectionCoords[0]) === true ) { //if a two intersections
                //define the right point
                var intersectionLat = intersectionCoords[0][0];
                signIncrLat = (usrCurrentLat - usrFirstLat) > 0; //sign of incremention of the lat user coordinate
                if (typeof(intersectionLat) === "number"
                    && (
                        (signIncrLat === true && intersectionLat > usrCurrentLat) //if the latitude of the intersection point lis larger then the user lat coord, and the user lat must increment
                        || (signIncrLat === false && intersectionLat <= usrCurrentLat) //if the latitude of the intersection point lis larger then the user lat coord, and the user lat must decrease
                    )
                ) {
                    intersectionPoint = {lat: intersectionLat, lng: intersectionCoords[0][1]}; //the intersection point   
                } else if(  commonlib.isArray(intersectionCoords[1]) === true
                            && typeof(intersectionCoords[1][0]) === "number" ) { //chose the second point if the first not approached
                                intersectionPoint = {lat: intersectionCoords[1][0], lng: intersectionCoords[1][1]}; //the intersection point        
                        }
            } else if ( typeof(intersectionCoords[0]) === "number" ) { //if an only one intersection
                intersectionPoint = {lat: intersectionCoords[0], lng: intersectionCoords[1]};
            }   
        }
        var distance;
        var flUserInsideBounds = geolib.isPointInCircle(userDesc, coordsCenter, locationRadiusFromCenter) === true; //check if the user is on the location or out of it's bounds
        if ( intersectionPoint !== undefined 
                && flUserInsideBounds === true ) { //if intersection point was found and the user is into the bounds of the location
            
            if ( userDesc.averageSpeedGradusPerSec !== 0 ) { //return the time, that the user has spent on the location
                coeffValue = userDesc.timeOnLocation;
            } else { //if the average speed is not null
                //found the distance between the current user's coordinates and the intersection point
                distance = Math.sqrt(Math.pow(intersectionPoint.lat - userDesc.lat,2) + Math.pow(intersectionPoint.lng - userDesc.lng,2));
                coeffValue = distance / Math.abs(userDesc.averageSpeedGradusPerSec); //return the time that is necessary for the user to move from the current point to intersection point and fo out from this location
            }
                
        } else { //if there is no an intersection point - the user is out of bounds
                
            //the coefficient is in inverse ratio to the average speed. But, because the coefficient have the negative sign, the ratio must be changed to direct
            if ( userDesc.averageSpeedGradusPerSec === 0 ) {
                coeffValue = - 1 / userDesc.timeOnLocation; //a time, that the user has spent on the location
            } else {//if the average speed is not null
                if ( intersectionPoint === undefined ) { //if not intersect the location
                    coeffValue =  - 1.5 * Math.abs(userDesc.averageSpeedGradusPerSec) / 0.0001;
                } else { //if intersect the location, may be the user want to return on the location, give him a biger value as compared with if he is not intersect the location
                    coeffValue =  - Math.abs(userDesc.averageSpeedGradusPerSec) / 0.0001;
                }
            }
        } 
    }
    return coeffValue;
}

//get the coordinates of the point which is distant from the current coordinates to the given radius and the given angle
//return {latitude, longitude}
/**
 * Description
 * @method getCoordsOfDistantPointByRadiusAndAngle
 * @param {} radius
 * @param {} angle
 * @param {} coords
 * @return coords
 */
function getCoordsOfDistantPointByRadiusAndAngle(radius, angle, coords){
   var commonlib = this.commonlib;
   
   coords.latitude  = commonlib.round((coords.latitude + radius  * Math.sin(angle)), 6);
   coords.longitude = commonlib.round((coords.longitude + radius * Math.cos(angle)), 6);
   return coords;
}

var bindTo = {
    commonlib : commonlib,
    template : template, 
    templateDegrees : templateDegrees,
    optionsCenterCalc : optionsCenterCalc,
    geolib : geolib,
    locationRadiusFromCenter : locationRadiusFromCenter
};

module.exports = {
    convertCoordsToDecimal : convertCoordsToDecimal.bind(bindTo),
    getCenterOfLocation : getCenterOfLocation.bind(bindTo),
    calculateValueCoefficientNewLSForLocation : calculateValueCoefficientNewLSForLocation.bind(bindTo),
    convertMetersToDegrees : convertMetersToDegrees,
    getCoordsOfDistantPointByRadiusAndAngle : getCoordsOfDistantPointByRadiusAndAngle.bind(bindTo)
};
},{"commonlib":undefined,"globalSettings":undefined,"logger":undefined}]},{},[]);
