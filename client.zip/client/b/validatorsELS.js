require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"validatorsELS":[function(require,module,exports){
"use strict";

//incoming message from the central server with a several messages
var Validator = Ajv;
var validator = (Validator()).compile;
var patterns = require("mainpatterns");

var validMessagesKinds = ["out", "locationDescription", "serverClosed", "locationChange", "locationMaintainceStopped", "offerSDP", "answerSDP"];

var schemas = {
     //message from the central server with ID of the local servers for the els locations
    vSchemaIncomingMessageFromCSLocalServersIDForILSMode : {
        type : "object",
        properties : {
            oldLocalServerID : patterns.optVS_userID, //the previous id of a local server, to which the els has been connected
        },
        patternProperties : {
            [patterns.patternPropertyLocationHash] : patterns.optVS_userID_orEmpty   
        }
    },
    //message from the central server with ID of the local server, that is handles the user location
    vSchemaIncomingMessageFromCSLocalServerID : {
        type : "object",
        required : ["locationHash", "timestamp", "localServerID"],
        properties : {
            timestamp       : patterns.optVS_timestamp,
            locationHash    : patterns.optVS_locationHash,
            localServerID   : patterns.optVS_userID,
            oldLocalServerID: patterns.optVS_userID //may absent
        }
    },
    //schema for a message from the cs, that informs the user about location changing
    vSchemaMessageBodyLocationChanged : {
        "type": "object",
        "additionalProperties" : false,
        "required" : ["newLocationHash","newLSID","oldLSID","timestamp","previousLocationHash"],
        "properties" : {
            "newLocationHash" : patterns.optVS_locationHash, 
            "previousLocationHash" : {
                "anyOf": [
                    patterns.optVS_locationHash,
                    { "enum": [0] }, //if absent
                ],
            },
            "newLSID": patterns.optVS_userID_orEmpty,
            "oldLSID": patterns.optVS_userID_orEmpty,
            "timestamp": patterns.optVS_timestamp //when the cs has formed the new location hash for the user coordinates
        }
    },
    //schema for a message from the cs, that informs the user about location changing
    vSchemaMessageBodyLocationChangedFromLS : {
            type: "object",
            additionalProperties : false,
            required : ["newLocationHash","newLSID","timestamp","previousLocationHash"],
            properties: {
                newLocationHash : patterns.optVS_locationHash_string, 
                previousLocationHash : patterns.optVS_locationHash_string,
                newLSID: patterns.optVS_userID_orEmpty,
                timestamp: patterns.optVS_timestamp //when the cs has formed the new location hash for the user coordinates
            }
    },
    //schema for an incoming message from the ls
    vSchemaMessageFromLS : {
            type: "object",
            additionalProperties : false,
            required : ["type","kind","body","timestamp"],
            properties: {
                type: {"enum": ["toILS", "fromLocalServer"]},
                kind: {"enum": validMessagesKinds},
                body: {
                    type: "object",
                    maxProperties: 50,
                    minProperties: 1
                },
                timestamp: patterns.optVS_timestamp
            }
    },
    //validation schema for messages from the local server
    vSchemaELSIncomingMessageLocationDescription : {
        type : "object",
        additionalProperties : false,
        required : ["locationDescription","timestampDescFormed"],
        properties : {
            locationDescription : { //userID : {lat,lng,coordsTimestamp}
                type : "object",    
                patternProperties : {
                    [patterns.patternPropertyLocationHash] : patterns.optVS_userCoordinatesWithCoordTimestamp //the current user's coordinates
                }
            },
            timestampDescFormed : patterns.optVS_timestamp //when the description has been formed on the ILS 
        }
    },
    //if the ls has stopped the location maintaince
    vSchemaMessageBodyLocationMaintainceStoppedFromLS : {
        type : "object",
        additionaProperties : ["idNewLS"],
        requires : ["locationHash"],
        properties : {
            locationHash : patterns.optVS_locationHash_string, //location maintaince of which was stopped
            idNewLS : patterns.optVS_userID //an id of a new ls for the location 
        }
    },
    vSchemaMessageBodyOnOfferSDP : { //on incoming offer to establish RTCDataConnection
        from  : patterns.optVS_userID, 
        offer : patterns.offerSDP
    },
    vSchemaMessageBodyOnAnswerSDP : { //on incoming answer to offer for meesaging with the user
        from  : patterns.optVS_userID, 
        answer : patterns.offerSDP
    },
    vSchemaMessageBodyOnLSOut : {
        type : "object", 
        additionalProperties : false,
        properties : {
            out : {
                enum : [1]    
            }
        }    
    }
};

var validators = {
	validatorMessageBodyLocationChanged : validator(schemas.vSchemaMessageBodyLocationChanged),
	validatorMessageFromLS : validator(schemas.vSchemaMessageFromLS),
	validatorMessageLocationDescription : validator(schemas.vSchemaELSIncomingMessageLocationDescription),
	validatorMessageBodyLocationMaintainceStopped : validator(schemas.vSchemaMessageBodyLocationMaintainceStoppedFromLS),
    validatorIncomingMessageFromCSLocalServerID : validator(schemas.vSchemaIncomingMessageFromCSLocalServerID),
    vSchemaIncomingMessageFromCSLocalServersIDForILSMode : validator(schemas.vSchemaIncomingMessageFromCSLocalServersIDForILSMode),
    validatorMessageBodyLocationChangedFromLS : validator(schemas.vSchemaMessageBodyLocationChangedFromLS),
    validatorMessageBodyLocationOfferSDP  : validator(schemas.vSchemaMessageBodyOnOfferSDP),
    validatorMessageBodyLocationAnswerSDP : validator(schemas.vSchemaMessageBodyOnAnswerSDP),
    validatorMessageBodyOnLSOut : validator(schemas.vSchemaMessageBodyOnLSOut)
};

module.exports = {
    validatorsELS : validators    
};
},{"mainpatterns":undefined}]},{},[]);
