require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"mainfunctions":[function(require,module,exports){
var getCurrentTimestamp = require("timestamps").getCurrentTimestamp;
var MP2P = null;

//return instance of MainP2P, get it from this value or dataConnection.g_MainP2P
//noinspection NestedFunctionJS
function returnMainP2P(thisValue, dataConnection) {
    return (thisValue instanceof MP2P === true && thisValue != null && thisValue) //this value is instance of MainP2P
            || (thisValue && thisValue.g_MainP2P instanceof MP2P && thisValue.g_MainP2P) //from property of thisValue 'g_MainP2P'
            || (dataConnection && dataConnection.g_MainP2P instanceof MP2P && dataConnection.g_MainP2P)
            || null; //null if instance of MainP2P not found
}
        
function setDataConnectionMetadataTimestamp(dataConnection) {
    if (dataConnection.metadata == null) {
        dataConnection.metadata = {};
    }
    dataConnection.metadata.g_timestamp = getCurrentTimestamp();
}
       
       
//return if it is instance of DataConnection or mockDataConnection
function isInstanceOfDataConnection(dataConnection) {
    var constructorName;
    if ( dataConnection != null && dataConnection.constructor != null ) {
        constructorName = dataConnection.constructor.name;    
    }
    return constructorName === "DataConnection"
			|| constructorName === "mockDataConnection";
}

function init(MainP2PConstructor){
   MP2P = MainP2PConstructor; 
}
		
module.exports = {
	returnMainP2P : returnMainP2P,
	setDataConnectionMetadataTimestamp : setDataConnectionMetadataTimestamp,
	isInstanceOfDataConnection : isInstanceOfDataConnection,
	init : init
};
},{"timestamps":"timestamps"}]},{},[]);
