require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"CommandsListener":[function(require,module,exports){
var commonlib = require("commonlib");
var logger = require("logger").logger;
logger.namespace = "CommandsListener";
var EventEmitter = require("eventemitter");

//listen and send commands from any source
//mainContext - context for a command handlers
//handlersList = { type : { kind : handler } }
//received commands must be Array[prefix,type, kind, body, arguments] if prefix not defined, then in the format: [type, kind, body, arguments]
//handler calls with the body as argument
//arguments must be an array, that contains arguments for handler
//if this.stopped, then do not handle any command
//callbackIfError - if command not found, or error, or stopped, then function callbackIfCommandNotPerformed(type, kind, body, arguments) will be called
//commandsEmitter - object which emit a commands through the onmessage, and realize postMessage method to send commands to the emitter
//commandsEmitter - used as the contexxt for sendCommand method
/**
 * Description
 * @method CommandsListener
 * @param {} mainContext
 * @param {} commandsEmitter
 * @param {} handlersList
 * @param {} prefix
 * @return 
 */
function CommandsListener(mainContext, commandsEmitter, handlersList, prefix) {
    this.stopped = false;
    this.mainContext = mainContext; //context for a handlers
    this.handlersList = handlersList; //list of a commands handlers
    this.cPrefix = prefix; //prefix for a commands
    this.indexCommandType       = (prefix == null ? 0 : 1); //index for type of the command. If the prefix is absent, then type of the command is under 0 index
    this.indexCommandKind       = this.indexCommandType + 1; //index of a command kind
    this.indexCommandBody       = this.indexCommandType + 2; //index of a command body
    this.indexCommandArguments  = this.indexCommandType + 3; //index of an arguments for a command handler
    this.commandMinLength       = (3 + this.indexCommandType); //minimal length of a command(Array) = type, kind, cody (3) + prefix(1) = 3 or 4
    
    //bind the context for the methods    
    this.listenCommands = this.listenCommands.bind(this);
    this.sendCommand = this.sendCommand.bind(this);
        
    this.commandsEmitter = commandsEmitter;
    //set listener for an incoming messages from the commandsEmitter
    if ( commandsEmitter.addEventListener != null ) { //if it has addEventListener method
        commandsEmitter.addEventListener("message", this.listenCommands);
    } else {
        commandsEmitter.onmessage = this.listenCommands;
    }

}

var CommandsListenerProto = Object.create(new EventEmitter());
//emitted events :
//"commandAfterStopped", arguments = [type, kind, body, arguments] - on message after the CommandsListener has stopped
//"commandHandlerNotFound", arguments = [type, kind, body, arguments] - on handler not found for the command

//set the new prefix for a commands
/**
 * Description
 * @method setCommandsPrefix
 * @param {} prefix
 * @return 
 */
CommandsListenerProto.setCommandsPrefix = function(prefix){
    this.cPrefix = prefix;    
};

//commands is arrays, where zero element must be string equal to parametr, stored in appSettings.prefixForCommandsListener
//need to use with the WebWorker.onmessage(DataConnector.listenCommands) - on the main thread side or self.onmessage(DataConnector.listenCommands()) - on the web worker side
//commands = Array[type, kind, body, arguments]
//looking up to the commands list, define the method for execution, depending on type and kind of the message : listCommands[type][kind]
//exec the method of the main object with the body argument MainObject[listCommands[type][kind]](body)
//arguments - array of the arguments, or the one value, if an arguments were given, then exec the method, with them : MainObject[listCommands[type][kind]](body, argument1, argument2,...,argumentN)
/**
 * Description
 * @method listenCommands
 * @param {} ev
 * @return 
 */
CommandsListenerProto.listenCommands = function listenerCommands(ev){
    
    if ( this.stopped === true ) { //handler is stopped
        this.emit("commandAfterStopped", arguments);
        return;    
    }
    
    var message = ev.data;
    var cPrefix = this.cPrefix || false; //prefix for commands
    
    if ( message.constructor === Array //if it is an Array
        && message.length >= this.commandMinLength //check the incoming command length 
        && ( ( cPrefix !== false && message[0] === cPrefix ) || cPrefix === false) ) { //check the prefix if it is specified
        
            var handlersList = this.handlersList;
            //validate the message structure
            var type, kind, body, args;
            //determine a handler for the message
            type = message[this.indexCommandType];
            kind = message[this.indexCommandKind]; //relative to index of the command type
            body = message[this.indexCommandBody];
            args = message[this.indexCommandArguments]; //arguments for handler 
            
            if ( type != null
                && handlersList[type] != null
                && kind != null
                && handlersList[type][kind] != null ) { //a handler for the command is exists
                    var context, methodName;
                    var handlerName = this.handlersList[type][kind];
                    
                    // try{
                    //     if ( args[1].kind.indexOf("ping") >= 0 ) {
                    //         console.log("ping");
                    //         console.log(args[1].body);
                    //     }
                    // } catch(e) {
                        
                    // }
                    
                    var flWithArgs = (Array.isArray(args) === true);
                    if ( typeof(handlerName) === "function" ) { //if this is a function
                        handlerName(body);
                    } else 
                        if ( handlerName.includes(".") === true ) { //check if it is a dotted separated string
                            //try to find the method into the object
                            
                            var res = commonlib.getObjectPropertyByCommaSeparatedName(this.mainContext, handlerName + ( ( flWithArgs === true && typeof(body) === "string" ) ? "." + body : "" ) ); //if arguments are given, than body is the part of the method name
                            if ( res !== false ) { //if the method was found
                                context     = res[0];
                                methodName  = res[1];
                                
                                if ( typeof(methodName) === "string"
                                    && methodName.endsWith(body) === true ) { //if the body is the part of method and not the argument
                                        body = null;
                                }
                                
                            }
                    } else {
                        context = this.mainContext;
                        methodName = handlerName;
                    }
                    //now methodName - the method of context object. Now it can be called as context[handlerName]
                    if (context != null 
                        && typeof(methodName) === "string"
                        && context[methodName] != null ) { //if handler for the message has been found
                            if ( flWithArgs === true ) { //if there are several arguments into the Array
                                if ( body != null ) {
                                    args.unshift(body);  //add the body to the beginning of the arguments array
                                }
                                commonlib.callFunctionWithArguments(context, methodName, args); //call the handler with the given arguments
                            } else if ( args != null ) { //if only the one argument
                                context[methodName](body, args);    
                            } else { //without any arguments
                                context[methodName](body);    
                            }
                    }
            } else {
                logger("A handler was not found for the message with the type = " + type + " and kind = " + kind);
                this.emit("commandHandlerNotFound", arguments);
            }
    }
};

//send the command with the given type, kind, body and arguments to the appWorker
//transferable - a transferable objects to send
/**
 * Description
 * @method sendCommand
 * @param {} type
 * @param {} kind
 * @param {} body
 * @param {} transferable
 * @param {} args
 * @return 
 */
CommandsListenerProto.sendCommand = function(type, kind, body, transferable, args) {
    if ( transferable == null ) { //withot transferable objects to send
        this.commandsEmitter.postMessage([this.cPrefix,type,kind,body,args]); //send a command with the prefix
    } else { //send with the given transferable objects
        if ( transferable.constructor === Array ) { //if already an array
            this.commandsEmitter.postMessage([this.cPrefix,type,kind,body,args], transferable); //send a command with the prefix
        } else { //transferable must be an array
            this.commandsEmitter.postMessage([this.cPrefix,type,kind,body,args], [transferable]); //send a command with the prefix 
        }
    }
};

//mainContext : context for a handler
//listEventsHandlers:
//{ "event" : "methodName" }, where handler name = name of the main object method
//or { "event" : [ "methodName", "argument1", "argument2" ] }
//listenedEventsEmitter : this object events will being listened
//if the even emitted with an argument, then a hangler for the event will be called with the predefined arguments, and the last agrgument for handler will be the given by an event
/**
 * Description
 * @method EventHandler
 * @param {} mainContext
 * @param {} listenedEventEmitter
 * @param {} listEventHandlers
 * @return 
 */
function EventHandler(mainContext, listenedEventEmitter, listEventHandlers){
    this.mainContext = mainContext;
    this.listenedEventEmitter = listenedEventEmitter; //an nstanceof EventEmitter that will being lisened for events, that will being handled by a handlers
    this.listEventsHandlers = listEventHandlers; //list of a handlers
    this.setEventsHandlers(); //set a handlers according to the given handlers list
}

var EventHandlerProto = {};

//listen an events form EventHandler.listenedEventEmitter and set an event listeners for an events according to the EventHandler.listEventsHandlers
/**
 * Description
 * @method setEventsHandlers
 * @return 
 */
EventHandlerProto.setEventsHandlers = function() {
   "use strict";
   var listenedEventEmitter = this.listenedEventEmitter; //listened event emitter
   var handlersList = this.listEventsHandlers; //list of event handlers
   var context = this.mainContext; //context for handler
   var events = Object.keys(handlersList);
    for ( var ii =0, len1 = events.length; ii < len1; ii++  ) {
        var event = events[ii];
        var eventHandlerName = handlersList[event];
        if ( eventHandlerName.constructor === Array
            && eventHandlerName[0] != null
            && context[eventHandlerName[0]] != null) { //if it is necessary to bind the context and the arguments to the function. eventHandlerName[0] = method name, eventHandlerName[1]...eventHandlerName[N] = arguments for the method 
                var methodName = eventHandlerName[0];
                if ( methodName.includes(".") === true ) { //check if it is a dotted separated string
                    //try to find the method into the object
                    var res = commonlib.getObjectPropertyByCommaSeparatedName(this.mainContext, methodName);
                    if ( res !== false ) { //if the method was found
                        context     = res[0];
                        methodName  = res[1];
                    } else {
                        context = null;    
                    }
                }
                if ( context != null && eventHandlerName[1] !== undefined ) { //if the predefined arguments are exists
                    var mName = methodName;
                    var args = []; //create the array with the predefined arguments
                    for( var i=0, len = eventHandlerName.length-1; i < len; i++ ) {
                        args[i] = eventHandlerName[i+1];     
                    }
                    listenedEventEmitter.on(event, 
                        (function(arg) { //call the method with a predefined arguments and the given argument by the event
                            if ( arg !== undefined ) {
                                this.args[args.length] = arg; //push the event argument to the list of the arguments
                            }
                            commonlib.callFunctionWithArguments(context, this.mName, this.args);
                            if ( arg !== undefined ) {
                                this.args.length--;
                            }
                        }).bind({mName : mName, args : args})
                    );
                } else if ( context != null ) { //a predefined arguments are absent
                    listenedEventEmitter.on(event, function(arg) {
                        context[methodName](arg); //call the method with the given argument by the event   
                    });
                } else {
                    logger("Not found listener for the event " + event);
                }
        } else 
            if ( typeof(eventHandlerName) === "string"
                && context[eventHandlerName] != null ) { //if mathod name is a string
                    methodName = eventHandlerName;
                    if ( methodName.includes(".") === true ) { //check if it is a dotted separated string
                        //try to find the method into the object
                        res = commonlib.getObjectPropertyByCommaSeparatedName(this.mainContext, methodName);
                        if ( res !== false ) { //if the method was found
                            context     = res[0];
                            methodName  = res[1];
                        }  else {
                            context = null;    
                        }
                    }
                    if ( context != null ) {
                        listenedEventEmitter.on(event, context[methodName] , context); //set the handler for the event from the list with the context equals to the ConnectorWithMainThread
                    } else {
                       logger("Not found listener for the event" + event); 
                    }
        } else {
            logger("Not found listener for the event" + event);    
        }
    }
};

EventHandler.prototype = EventHandlerProto;
CommandsListener.prototype = CommandsListenerProto;

module.exports = {
  CommandsListener : CommandsListener,
  EventHandler : EventHandler
};
},{"commonlib":undefined,"eventemitter":undefined,"logger":undefined}]},{},[]);
