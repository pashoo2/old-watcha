require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"NeighborUser":[function(require,module,exports){
/*global MessagingConnection*/
/*global $*/

/***
 * NeighborUser
 * The user located near to the current user
 * 
 */

var validators = require("validatorsUser");
var EventEmitter = require("eventemitter");
var commonlib = require("commonlib");
var logger = require("logger").logger;
var globalSettings = require("globalSettings");
logger.namespace = "NeighborUser";

var settings = globalSettings.neighborUser;


/**
 * create the neighbor user, show him on the map
 * the current user can chatting with him
 * userDescription = object or compressed JSON string { lat, lng, coordsTimestamp, description } }, where
 *      description : { contacts, tags, about, name }, where
 *      contacts : { email, phone, socialLinks : { socialName : link } }, socialName - name of the social network, link - link to the profile
 *      tags : [] - array with a text tags, that describes the user
 *      about : string - text information about the user
 * @method NeighborUser
 * @param {} userID
 * @param {} userDescription
 * @return 
 */
function NeighborUser(userID, userDescription) {
    
    this.id = commonlib.strToInt(userID); //to integer
    this.flEmpty = true; //flag that this user has not the description
    this.flAllowMessages = null; //flag that the user allow messaging with this user
    
    //bind the context
    this.onOfferSDP = this.onOfferSDP.bind(this);
    this.onConnectionClosed = this.onConnectionClosed.bind(this);
    this.onMessage = this.onMessage.bind(this);
    this.startChat = this.startChat.bind(this);
    this.setListenersForMessagingConnection = this.setListenersForMessagingConnection.bind(this);
    this.saveMessageToHistory = this.saveMessageToHistory.bind(this);
    this.saveOutMessageToHistory = this.saveOutMessageToHistory.bind(this);
    this.onMediaConnectionClosed = this.onMediaConnectionClosed.bind(this);
    this.onDeniedMessaging = this.onDeniedMessaging.bind(this);
    this.onAnswerSDP = this.onAnswerSDP.bind(this);
    
    var mainUser = window.user; //the main(not this neighbor) user
    this.mainUser       = mainUser; //set the reference to the User object
    this.mainUserID     = mainUser.myID; //save the main user id
    this.mainUserName   = mainUser.name; //save the name of the main user
    
    //update the description of the user
    this.updateDescription(userDescription);
    this.loadMessagesHistory();
    
}

/*
    prototype for the NeighborUser
    emitted events : {
        message(userID) - incoming message from the user
        "gone"(userID) - user has go away, remove him from the map and all lists,
        "show"(userID, name, about, lat, lng) - show the user on the map for the first time
    }
*/
var NeighborUserProto = Object.create(new EventEmitter());

/*
    clear a string from banned words or special keywords
*/
NeighborUserProto.clearString = commonlib.clearString;

/*
    check if the messages from this user are not denied by t he main user
*/
NeighborUserProto.allowMessages = function(msg) {
    var nUser =this;
    if ( nUser.closed === true ) { //if the user is closed
        return Promise.reject(true);     
    } else
        if ( nUser.flAllowMessages === true ) { //if allowed
            return Promise.resolve(true);    
    }  if ( nUser.flAllowMessages === false ) { //if allowed
            return Promise.reject(false);
    }   else { //show the dialog with the request
        return new Promise(
            function(res, rej) {
                $.prompt("Do uou want to chat with " + nUser.name +"(" + nUser.id + ")" + "?", {
                	title: typeof(msg) === "string" ? ("Incoming message: " + msg) : "",
                	buttons: { "Yes" : true, "No" : false },
                	submit: function(e,v,m,f){
                	    if ( v === true ) {
                	        nUser.flAllowMessages = true;
                	        res(true);    
                	    } else {
                	        nUser.flAllowMessages = false;
                	        rej(false);
                	    }	
                	}
                });
            }
        );    
    }
};

/*
    validation methods for various information related with the neighbor user
*/
NeighborUserProto.validators =  { //validation functions
    validatorCoordsTimestamp : validators.validatorUserCoordsTimestamp,
    validatorDescription : validators.validatorUserDescription //validation function for the user description
};

/**
 * set the user description object or JSON string
 * userDescription = object or JSON compressed string { lat, lng, coordsTimestamp, description } }, where
 *      description : { contacts, tags, about }, where
 *      contacts : { email, phone, socialProfiles : { socialName : link } }, socialName - name of the social network, link - link to the profile
 *      tags : [] - array with a text tags, that describes the user
 *      about : string - text information about the user
 * @method updateDescription
 * @param {} userDescription
 * @return 
 */
NeighborUserProto.updateDescription = function updateDescription(userDescription) {
    
    var validator = this.validators.validatorCoordsTimestamp;
    if ( validator(userDescription) === false ) { //not valid description
        logger(validator.errors); //show errors, that occurred during the validation
        if ( this.flEmpty === true ) {  //if it is a new user
            this.drop(); //drop this user from the map and all lists
        }
    } else {
        //check the description timestamp
                
        if ( typeof(this.updateTimestamp) === "number"
            && this.updateTimestamp > userDescription.coordsTimestamp ) { //if the current coords are newer then the given
                logger("Information about the neighbor user with id " + this.id + " is older then the current");       
        }
        
        this.updateLocation({ lat : userDescription.lat, lng :  userDescription.lng}); //update the user current location
        this.updateTimestamp = userDescription.coordsTimestamp; //the timestamp when the user description been updated
        
        var description = userDescription.description;
        if ( typeof(description) === "string" ) {
            JSON.parseAsync(description, this.setDescription, this, true);
        } else {
            this.setDescription(description);    
        } 
    }
    
};

/*
    set all the listeners for events, that must be handled by this NeighborUser instance
*/
NeighborUserProto.setListeners = function() {
    this.removeMainUserEventsListeners();
    
    var mainUser = this.mainUser;
    mainUser.on("offerSDP", this.onOfferSDP); //on incoming messaging connection
};

/*
    remove the listeners for the User events
*/
NeighborUserProto.removeMainUserEventsListeners = function() {
    var mainUser = this.mainUser;
    
    mainUser.removeListener("offerSDP", this.onOfferSDP); //on incoming messaging connection
};

/*
    remove all the listeners for events, that must be handled by this NeighborUser instance
*/
NeighborUserProto.removeInnerListeners = function() {
    this.removeMainUserEventsListeners();
    this.removeListenersForMediaConnection(); //remove all listeners for the active messaging and the media connections
    this.removeListenersForMessagingConnection();
};

/**
 * userDescription - object with the neib user description
 * @method setDescription
 * @param {} userDescription
 * @return 
 */
NeighborUserProto.setDescription = function(userDescription) {
    var nuser = this;
    
    if ( nuser.closed === true ) { //if the user has been closed before
        return;    
    }
    
    var validator = nuser.validators.validatorDescription;
    if ( validator(userDescription) === false ) { //not valid description
        logger(validator.errors);
        if ( nuser.flEmpty === true ) {  //if it is a new user
            nuser.drop(); //drop this user from the map and all lists
        }
    } else {
        //check the description timestamp
        var _props = Object.keys(userDescription);
        for( var i = 0, len = _props.length; i < len; i++ ) {
            var propName = commonlib.clearBannedWords(_props[i]);
            if ( propName.trim().length > 1 ) {
                var propValue = userDescription[propName];
                if ( typeof(propValue) === "object"
                    && propValue !== null ) {
                        propValue.__proto__ = {}; //set an empty prototype
                         nuser[propName] = commonlib.cleanObjectBannedWords(propValue);
                } else if ( typeof(propValue) === "string" ) {
                    nuser[propName] = commonlib.clearBannedWords(propValue);
                } else if ( typeof(propValue) === "number" ) {
                    nuser[propName] = propValue;
                }
            }
        }
        
        if ( nuser.flEmpty === true ) { //if it is the new user
            nuser.flEmpty = false; //set the flag that the user has the description
            nuser.setListeners(); //set the listeners for the events, that must handled by this neighbor user
        }
        
        if ( commonlib.isEmptyObject(nuser.sociallinks) === true ) {
            nuser.sociallinks = null;    
        }
        
        nuser.htmlRepresentation = this.getHTMLNeighborUserCard(true); //update the HTML description of the user without the chat button
        nuser.htmlRepresentationWithChatButton = this.getHTMLNeighborUserCard(); //update the HTML description of the user with the chat button
        nuser.closed = false; //flag that the user not closed and messaging allowed
        
        nuser.emit( "show", nuser ); //show on the map for the first time or update the user position on the map
    }
};

/**
 * update the current location description
 * locationDescription : { lat, lng }
 * @method updateLocation
 * @param {} locationDescription
 * @return 
 */
NeighborUserProto.updateLocation = function(locationDescription) {
    
    this.lat = locationDescription.lat; //lattitude
    this.lng = locationDescription.lng; //longitude
    this.emit("show", this); //show on the map for the first time or update the user position on the map

};

/**
 * remove this user from the list and the main map
 * @method drop
 * @return 
 */
NeighborUserProto.drop = function(){
   this.closed = true; //flag
   this.emit("gone", this.id);
   this.emitOnConnectionStateChanged(null, "Connection was closed because the user has gone", true);
   this.closeMessagingConnection(); //stop the connection
   this.closeMediaConnection(); //stop the live video connection if exists
   this.removeInnerListeners();
   this.removeAllListeners();
   this.saveMessagesHistory();
   window.interface.closeChatWith(this.id);
};

/*
    return text header representation of the user
*/
NeighborUserProto.represent = function() {
    return this.name +  " (" + this.id + ")" + ( this.locationmethod !== "Automatic" ? " !" : "" );    
};

/*
    show the list with the clickable user's social profiles
*/
NeighborUserProto.showSocialProfiles = function() {
    if ( this.sociallinks != null ) {
        window.interface.showSocialProfiles(this.sociallinks);    
    }
};

/*
    return html description of the user
*/
NeighborUserProto.showDesc = function(flWithoutChatButton) {
    if ( flWithoutChatButton === true ) {
        return this.htmlRepresentation;
    } else {
        return this.htmlRepresentationWithChatButton;    
    }
};

/*
    return html for the user card
    neighborUser - the neigbor user data
*/
NeighborUserProto.getHTMLNeighborUserCard = function(flWithoutChatButton){
    
    var neighborUser = this;
    //make buttons with the neighbor user tags
    var userTags = '<div data-role="controlgroup" data-type="horizontal" data-mini="true">';
    var nUserTags = neighborUser.chosentags;
    if ( Array.isArray(nUserTags) === true ) {
        for( var i =0, len = nUserTags.length; i < len; i++  ) {
            userTags += '<a href="javascript:void(0);" data-mini="true" class="ui-btn ui-corner-all">' + nUserTags[i].trim() + '</a>';
        }
    }
    userTags += '</div>';
    
    var socialProfilesButton;
    if ( neighborUser.sociallinks != null ) {
        socialProfilesButton = '<p><a href=# onclick="javascript:window.interface.showSocialProfiles(this, window.user.getNeighborUser(' + neighborUser.id + ').sociallinks)">Social profiles</a></p>';    
    } else {
        socialProfilesButton = "";    
    }
    
    var collapsibleSetDescription = '\
                <div data-role="collapsible-set">\
                    <div data-role="collapsible"> \
                        <h3>Status</h3> \
                        <p>' + neighborUser.status + '</p> \
                    </div> \
                    <div data-role="collapsible"> \
                        <h3>Contacts</h3> \
                        ' + ( commonlib.isEmptyValue(neighborUser.phone) === true ? '' : '<p>Phone: ' + neighborUser.phone + '</p>' ) +  '\
                        <p>Email: ' + neighborUser.email + '</p> \
                        ' + socialProfilesButton + '\
                    </div> \
                    <div data-role="collapsible"> \
                        <h3>Tags</h3> \
                        ' + userTags + ' \
                    </div>';
    
    if ( typeof(neighborUser.videostream) === "string" ) {
        
        collapsibleSetDescription += '<div data-role="collapsible"> \
                                    <h3>Live video stream</h3>';
                                    
        var videostreamdescriptionString = ( typeof(commonlib.clearBannedWords(this.videostreamdescription.trim())) === "string" ? this.videostreamdescription : '' );
        if ( videostreamdescriptionString.length > 0 ) {
            collapsibleSetDescription += '<label>' + videostreamdescriptionString + '</label>';    
        }
            
        collapsibleSetDescription += '<p><a onclick="window.user.showNeighborUserVideoStream(' + neighborUser.id + ')">Watch live video</a></p>';
        collapsibleSetDescription += '</div>';
    }                
                    
    collapsibleSetDescription += '</div>';
    
    var untrustedlocation = neighborUser.locationmethod !== "Automatic" ? '<p>Coordinates untrusted</p>' : '';
    
    var content = ' <div data-role="content"> \
                    ' + untrustedlocation + '\
                    <img src ="' + neighborUser.photo + '"></img> \
                    <h3>Age:</h3> \
                    <p>' + neighborUser.age + '</p> \
                    <h3>Gender:</h3> \
                    <p>' + neighborUser.gender + '</p> \
                    ' + collapsibleSetDescription;
    
    if ( flWithoutChatButton !== true ) { //add the chat button
        content += '<p><a onclick="window.interface.chatWith(' + neighborUser.id + ')">Chat</a></p>';        
    }
    content += '</div>';
    
    return content;
};

/**
 * on click by the user on the map
 * @method onClick
 * @return 
 */
NeighborUserProto.onClick = function(){
    this.emit("showMyCard", this); //emit the event to thow the neighbor user card   
};

/*
  start a media connection with the peer to watch the video tranlation  
*/
NeighborUserProto.watchVideoStream = function(videoStreamHash) {
    var nUser = this;
    var videoTranslation = window.interface.videoTranslation;
    var videostreamdescriptionString = ( typeof(nUser.videostreamdescription) === "string" ? nUser.videostreamdescription : '' );
    videoTranslation.showCameraPopup(null, "Create the connection...", videostreamdescriptionString); //show the connection state without a stream
    
    if ( this.closed === false ) {
        
        if ( typeof(videoStreamHash) === "string"
            || typeof(this.videostream) === "string" ) {
        
                var nUser = this;
                nUser.closeMediaConnection(); //close the current media connection
                
                var mc = new window.MessagingConnection(true); //create the media connection(set the argument to true)
                return mc.then(
                        function(mediaConnection) { 
                            videoTranslation.showVideoConnectionState("Creating request for the user...");
                            nUser.mediaConnection = mediaConnection; //set this media connection as the default
                            return  mediaConnection
                                        .connectToPeer()
                                        .then(function(){ //when the offer was created
                                            videoTranslation.showVideoConnectionState("Send the request...");
                                            var _offerSDP = mediaConnection.offerSDP;
                                            if ( _offerSDP == null
                                                || _offerSDP instanceof Error ) { //if an error
                                                    return Promise.reject(new Error("No offer"));
                                            } else { //send it to the peer
                                                var nUserStreamHash = nUser.videostream;
                                                return nUser.sendOffer(mediaConnection, _offerSDP, (typeof(nUserStreamHash) === "string") ? nUserStreamHash : videoStreamHash);  //send it to the neighbor user
                                            }
                                        })
                                        .then(function(){
                                            videoTranslation.showVideoConnectionState("Waiting for the video stream...");
                                            return mediaConnection.waitingForStream();
                                        }) //waiting for the incoming stream
                                        .then(function(stream){ //when got the video stream
                                            videoTranslation.showVideoConnectionState("Show the video stream");
                                            videoTranslation.showVideoStream(stream);  //show the popup with the received video stream
                                            videoTranslation.showVideoConnectionState("");
                                        })
                                        .catch(function(e){ //if an error
                                            
                                            logger(e);
                                            videoTranslation.showVideoConnectionState("Can't get the live video stream from the neighbor user with id = " + nUser.id);
                                            if ( nUser.mediaConnection === mediaConnection ) { //if this media connection is th default
                                                nUser.mediaConnection = null; //clear the default media connection
                                            }
                                            mediaConnection.close(); //close it
                                        });
                                });
            
        } else {
            window.interface.showError("There is no live video streaming provided by the neighbor user with id =" + this.id); //show error   
        }
    } else {
        window.interface.showError("Can't show video stream from the closed neighbor user with id =" + this.id); //show error   
    }
};

/*
    emit the event on changing messaging connection state
*/
NeighborUserProto.emitOnConnectionStateChanged = function(connection, msg, flDisconnected) {
    if ( this.messagingConnection === connection
        || this.messagingConnection == null ) {
            this.emit("connectionstatechanged", this.id, msg, flDisconnected);    
    } 
};

/*
  create p2p data connection with this neighbor user
*/
NeighborUserProto.startChat = function() { 
    if ( this.flAllowMessages === false ) {
        this.emitOnConnectionStateChanged(messagingConnection, "User denied your request", true); 
        return Promise.reject(new Error("User denied your request"));
    } else
        if ( this.closed === false ) { //if the user has not been closed and has the valid description
            
            var nUser = this;
            var messagingConnection = nUser.messagingConnection;
            if ( messagingConnection == null  //IF THE MESSAGING CONNECTION IS ABSENT
                || messagingConnection.closed === true ) { //OR CLOSED
                    nUser.flCallee = false;
                    var mc = new window.MessagingConnection();
                    nUser.emitOnConnectionStateChanged(messagingConnection, "Create the request", false);
                    return mc
                        .then(
                            function(messagingConnection) {
                                nUser.messagingConnection = messagingConnection;
                                return messagingConnection
                                        .connectToPeer()
                                        .then(function(e){ //on offer
                                            if ( e instanceof Error ) {
                                                throw e;    
                                            } else {
                                                var _offerSDP = messagingConnection.offerSDP;
                                                if ( _offerSDP == null
                                                    || _offerSDP instanceof Error ) {
                                                        nUser.emitOnConnectionStateChanged(messagingConnection, "Can't create the request", true);
                                                        return Promise.reject(new Error("No offer"));
                                                } else {
                                                    nUser.emitOnConnectionStateChanged(messagingConnection, "Send the request to the user", false);
                                                    return nUser.sendOffer(messagingConnection, _offerSDP);  //send it to the neighbor user
                                                }
                                            }
                                        })
                                        .then(messagingConnection.waitingForDCOpening)
                                        .then(nUser.setListenersForMessagingConnection.bind(nUser, messagingConnection))
                                        .then(function(e) {
                                            if ( e instanceof Error ) {
                                                nUser.emitOnConnectionStateChanged(messagingConnection, "An error has occurred", true);
                                                throw e;
                                            }  else {
                                                window.user.on("answerSDP", nUser.onAnswerSDP); //set the listener for another answers from the neighbor user
                                                nUser.emitOnConnectionStateChanged(messagingConnection, "Connection was opened", false);
                                                return true;    
                                            }
                                        })
                                        .catch(function(e){ //if an error
                                            if ( nUser.flAllowMessages !== false ) {
                                                nUser.emitOnConnectionStateChanged(messagingConnection, "An error has occurred", true);
                                            } else {
                                                nUser.emitOnConnectionStateChanged(messagingConnection, "User denied your request", true);    
                                            }
                                            logger(e); 
                                            if ( nUser.messagingConnection === messagingConnection ) {
                                                nUser.messagingConnection = null;
                                            }
                                            messagingConnection.close();
                                        });
                        });
            } else { //if the messaging connection is exists
                nUser.flCallee = messagingConnection.flCallee;
                nUser.emitOnConnectionStateChanged(messagingConnection, "Waiting...", false);
                return messagingConnection //whaiting when the data channel will be opened 
                        .waitingForDCOpening()
                        .then(function(e) {
                            if ( e instanceof Error ) {
                                nUser.emitOnConnectionStateChanged(messagingConnection, "An error has occurred", true);
                                throw e;
                            }  else {
                                nUser.emitOnConnectionStateChanged(messagingConnection, "Open");
                                return true;    
                            }
                        })
                        .catch(function(e){ //if an error
                            nUser.emitOnConnectionStateChanged(messagingConnection, "An error has occurred", true);
                            logger(e); 
                            if ( nUser.messagingConnection === messagingConnection ) {
                                nUser.messagingConnection = null;
                            }
                            messagingConnection.close();
                        });
            }
        } else {
            nUser.emitOnConnectionStateChanged(messagingConnection, "The user can't communicate", true);
            return new Promise.reject(new Error("The user can't communicate"));    
        }
};

/**
 * on incoming offer to create the messaging channel between the two users
 * @method onOfferSDP
 * @param {} args
 * @return 
 */
NeighborUserProto.onOfferSDP = function( args ) {
    if ( this.closed !== true
        && this.flAllowMessages !== false ) {
            var fromUserID = args[0];
            if ( fromUserID === this.id ) {
                var nUser = this;
                var offer = args[1];
                nUser.flCallee = true;
                var mc = new window.MessagingConnection(offer); //create the connection depending to the incoming offer
                return mc
                        .then( //when the MessagingConnection instance will be created
                            function(messagingConnection) {
                                var flMediaConnection = messagingConnection.mediaConnection;
                                
                                if ( flMediaConnection !== true ) { //if it is a media connection
                                    if ( nUser.flCallee === true
                                        || nUser.messagingConnection == null
                                        || nUser.messagingConnection.closed === true ) {
                                            nUser.closeMessagingConnection();    
                                            nUser.messagingConnection = messagingConnection;
                                    } else { //if it is not the callee side
                                       messagingConnection.close();
                                       return;
                                    }
                                } else {
                                    nUser.closeMediaConnection();    
                                    nUser.mediaConnection = messagingConnection;
                                }
                                
                                var _timeout = setTimeout(function(){
                                    messagingConnection.close();    
                                }, 15000);
                                
                                var resPromise = messagingConnection
                                                .connectToPeer()
                                                .then(function() {
                                                    
                                                    var answer = messagingConnection.offerSDP;
                                                    if ( answer == null
                                                        || answer.sdp == null ) {
                                                           messagingConnection.close();
                                                           return Promise.reject(new Error("SDP is absent")); 
                                                    } else {
                                                        return JSON.stringifyAsync(
                                                                    { sdp   : answer.sdp,
                                                                      type  : answer.type
                                                                    }
                                                                );  
                                                    }
                                                })
                                                .then(function(strAnswerSDP){
                                                    window.user.sendToMainP2P(null, ["sendAnswer", fromUserID, messagingConnection.addMediaPrefixForAnswer(strAnswerSDP)]);  //send it to the caller user
                                                });
                                        
                                if ( flMediaConnection === true ) {
                                    resPromise = resPromise
                                                    .then(nUser.setListenersForMediaConnection.bind(nUser, messagingConnection));
                                } else {
                                    resPromise = resPromise
                                                    .then(messagingConnection.waitingForDCOpening.bind(messagingConnection))
                                                    .then(nUser.setListenersForMessagingConnection.bind(nUser, messagingConnection));    
                                }
                                
                                return resPromise
                                    .then(function(){
                                        clearTimeout(_timeout);    
                                    });
                            }
                        )
                        .catch(function(e){
                            logger(e);
                        });
            }
    } else {
        logger("Request for the messaging from the blocked or closed user");
        window.user.sendToMainP2P(null, ["sendAnswer", this.id, this.settings.messageMessagingDenied]);
    }
};

/*
    on incoming answer from this neighbor user
*/
NeighborUserProto.onAnswerSDP = function( messagingConnection, args ) {
    
    var fl = args === undefined;  //true - if the answer was sent by the neighbor user later, after the connection has already been opened
    var nUser = this;
    if ( fl === true ) {
        args = messagingConnection;   
    }
    var fromUserID = args[0]; //id of the neighbor user
    var answer = args[1];
    if ( fromUserID === this.id ) {
        if ( fl === true ) {
            if ( typeof(answer) === "string" ) {
                if ( answer.trim() === nUser.settings.messageMessagingDenied ) {
                  nUser.onDeniedMessaging(); 
                }
            }
        } else 
            if ( messagingConnection instanceof MessagingConnection ) {
                var errMsg;
                var flMediaConnection = window.MessagingConnection.prototype.isMediaOffer(answer);
                if ( messagingConnection === nUser.messagingConnection ) { //if not absent
                    if ( answer.trim() !== nUser.settings.messageMessagingDenied ) {
                        return JSON
                                .parseAsync( flMediaConnection === true ? window.MessagingConnection.prototype.parseMediaAnswer(answer) : answer)
                                .then(function(objAnswer){
                                    nUser.emitOnConnectionStateChanged(messagingConnection, "The answer is valid", false);
                                    return messagingConnection.setAnswerOnCaller(objAnswer);    
                                });
                    } else {
                        nUser.onDeniedMessaging();
                        errMsg = "User denied your request"; 
                        nUser.closeMessagingConnection(messagingConnection);
                        return Promise.reject(new Error(errMsg));
                    }
                } else { //if there is no messaging connections with this user
                    
                    errMsg = "There is no active connections with the neighbor user " + nUser.id;
                    nUser.emitOnConnectionStateChanged(messagingConnection, errMsg, true);
                    return Promise.reject(new Error(errMsg));            
                } 
        }
    }
};

/*
    send offer to the neighbor user
    waiting for answer
    return Promise, resolved, when the answer will be got
*/
NeighborUserProto.sendOffer = function(messagingConnection, _offerSDP, videoStreamHash) {
    var nUser = this;
    return new Promise(function(resolve, reject) {
                function onAnswerSDP(args) {
                    clearTimeout(waitingTimeout);
                    nUser.emitOnConnectionStateChanged(messagingConnection, "The answer has come", false);
                    var user = window.user;
                    user.removeListener("answerSDP", onAnswerSDP);
                    resolve(args);
                }
                
                var waitingTimeout =
                    setTimeout(
                        function() { //if the messaging connection is timeout
                            
                            if ( typeof(videoStreamHash) === "string" ) {
                                nUser.closeMediaConnection(messagingConnection); //stop the videostream connection
                            } else {
                                nUser.closeMessagingConnection(messagingConnection); //stop the messaging connection
                            }
                            
                            window.user.removeListener("answerSDP", onAnswerSDP);
                            nUser.emitOnConnectionStateChanged(messagingConnection, "The response from the user has expired", false);
                            reject(new Error("Expired response time")); //reject with error
                        }, 
                        30000
                    );
    
                    JSON.stringifyAsync(
                        {   sdp  : _offerSDP.sdp,
                            type : _offerSDP.type
                        }, 
                        function(strOffer) { //stringify the answer
                            var user = window.user;
                            user.sendToMainP2P(null, ["sendOffer", nUser.id, messagingConnection.addMediaPrefixByVideoStreamHash(strOffer, videoStreamHash)]); //send it ot the callee user
                            nUser.emitOnConnectionStateChanged(messagingConnection, "The request was sent", false);
                            user.once("answerSDP", onAnswerSDP); //on incoming answer from the neighbor user
                        }
                    ); 
            })
            .then(function(args){
                return nUser.onAnswerSDP(messagingConnection, args); //call the method on answer from the neighbor user    
            });
};

/*
    close the existing messaging connection
*/
NeighborUserProto.closeMediaConnection = function(mc) {
    var mediaConnection = mc instanceof MessagingConnection ? mc : this.mediaConnection;
    if ( mediaConnection instanceof MessagingConnection ) {
       //remove the listeners
       this.removeListenersForMediaConnection();
       mediaConnection.close(); 
       if ( this.mediaConnection === mc ) { //if it is the main connection
        this.mediaConnection = null;
       }
    }
};

/*
    close the existing messaging connection
*/
NeighborUserProto.closeMessagingConnection = function(mc) {
    var messagingConnection = mc instanceof MessagingConnection ? mc : this.messagingConnection;
    if ( messagingConnection instanceof MessagingConnection ) {
       //remove the listeners
       this.removeListenersForMessagingConnection();
       messagingConnection.close(); 
       if ( this.messagingConnection === mc ) { //if it is the main connection
        this.messagingConnection = null;
        window.user.removeListener("answerSDP", this.onAnswerSDP);
       }
    }
    if ( (messagingConnection instanceof MessagingConnection) === false ) {
       window.user.removeListener("answerSDP", this.onAnswerSDP); 
    }
};

/*
    set the listeners for the messaging connection events
*/
NeighborUserProto.setListenersForMessagingConnection = function(messagingConnection) {
    var mc = ( messagingConnection == null ? this.mediaConnection : messagingConnection );
    if (this.closed === false //if the neighbor user can messaging with other
        && mc != null
        && mc.closed !== true ) { //if the messaging connection has not closed
            mc.once("close", this.onConnectionClosed); 
            mc.on("message", this.onMessage);
    }
};

/*
    remove the listeners for the messaging connection events
*/
NeighborUserProto.setListenersForMediaConnection = function(mediaConnection) {
    
    var mc = ( mediaConnection == null ? this.mediaConnection : mediaConnection );
    if ( mc != null ) {
        mc.once("close", this.onMediaConnectionClosed); 
    }
};

/*
    remove the listeners for the messaging connection events
*/
NeighborUserProto.removeListenersForMediaConnection = function() {
    var mc = this.mediaConnection;
    if ( mc != null ) {
        mc.removeListener("close", this.onMediaConnectionClosed); 
    }
    window.user.removeListener("answerSDP", this.onAnswerSDP);
};

/*
    remove the listeners for the messaging connection events
*/
NeighborUserProto.removeListenersForMessagingConnection = function() {
    var mc = this.messagingConnection;
    if ( mc != null ) {
        mc.removeListener("close", this.onConnectionClosed); 
        mc.removeListener("message", this.onMessage);
    }
    window.user.removeListener("answerSDP", this.onAnswerSDP);
};

/*
    send message to the neighbor user
    attempt - number of attempts to send the message
    return Promise, resolved with true if all is ok
*/
NeighborUserProto.sendMessage = function(message, attempt) {
    var nUser = this;

    /*
        if an error when starting messaging
    */
    function onError(e){
        
        return (new Promise(
            function(resolve, reject) {
                var _attempt = attempt == null ? 1 : attempt;
                logger(e);
                if ( nUser.closed === true //if the neighbor user closed
                    || _attempt > 3 ) { //too much attempts
                        
                        var err = new Error("Can't send the message to the neighbor user with id " + nUser.id);
                        if ( nUser.messagingConnection != null ) {
                            nUser.messagingConnection.close();
                            nUser.messagingConnection = null;
                            logger(new Error("Connection to the neighbor user "  + nUser.id + " was closed"));
                        }
                        reject(err);
                } else { //less than a 3 attempts to send the message
                    
                    setTimeout(
                        function(){
                            resolve(nUser.sendMessage(message, ++_attempt));
                        }, 
                        1000); //try once again after the pause
                }
            }
        ))
        .catch(function(e){
            logger(e);
            return new Error("Can't send the message");
        });
    }
    
    if ( this.closed === false ) {
        return nUser
            .startChat() //start Messaging Connection   
            .then(function(res){
                if ( res === true ) { //if connected
                    nUser.flAllowMessages = true; //allow messaging with the user
                    var messagingConnection = nUser.messagingConnection;
                    if ( messagingConnection != null ) { //send the message through the MessagingConnection
                        return messagingConnection.send( ( typeof(message) === "string" ) ? message : message.message ); //send the message text
                    } 
                } else {
                    return onError(res);  //if error  
                }
            })
            .then(nUser.saveOutMessageToHistory)
            .catch(onError);
    } else {
        return Promise.reject(new Error("The user can't communicate"));
    }
};

/*
    save outgoing message to the history
*/
NeighborUserProto.saveOutMessageToHistory = function(message) {
    return this.saveMessageToHistory(message, true);
};

/*
    save the given message to the messages history
    return Promise, resolved with true if all is ok
    flOutgoing - if true, then it is an outgoing message
*/
NeighborUserProto.saveMessageToHistory = function(message, flOutgoing) {
    var nUser = this;
    if ( typeof(message) === "string" //if it is a string message
        || ( typeof(message) === "object"
                && message !== null
                && message.message != null 
                && ( message instanceof Error ) === false ) //if it is a message description object
    ) {
        return nUser
                .loadMessagesHistory() //get the history list
                .then(function(messagesHistory) {
                    if ( Array.isArray(messagesHistory) === true ) { //if exists
                        var msg = messagesHistory[messagesHistory.length] = ( typeof(message) === "string" ) ? commonlib.getMessageDescriptionObj( ( flOutgoing === true ? "You" : nUser.id ), message, ( flOutgoing === true ? nUser.mainUserName : nUser.name )) : message; //save the message to the history    
                        nUser.saveMessagesHistory();
                        return msg;
                    } else {
                        return new Error("Can't get the messages history");    
                    }
                });
    } else {
        return new Error("Wrong message");    
    }
};

/*
  user denied messaging with this neighbor user  
*/
NeighborUserProto.onDeniedMessaging = function (e){
    var nUser = this;
    nUser.flAllowMessages = false;
    nUser.emitOnConnectionStateChanged(nUser.messagingConnection, "The messaging was denied", true);
    if ( nUser.messagingConnection.flCallee === true ) { //on the callee side send the message
        window.user.sendToMainP2P(null, ["sendAnswer", this.id, this.settings.messageMessagingDenied]); //send the message that a messaging was denied by the user
    }
    nUser.closeMessagingConnection();
    window.user.removeListener("answerSDP", nUser.onAnswerSDP); 
};

/*
    on incoming message
*/
NeighborUserProto.onMessage = function(message){
    var nUser = this;
    if ( nUser.closed === true
        || nUser.flAllowMessages === false ) {
            nUser.onDeniedMessaging(); 
    } else {
        var cleanMsg = commonlib.clearBannedWords(message); //clear the message from some banned words and make charater escaping
        if ( message.trim() === nUser.settings.messageMessagingDenied) {
            nUser.onDeniedMessaging();
        } else {
            nUser
            .allowMessages(message) //ask for user want to receive messages
            .then(function(res){
                
                if ( res === true ) { //if a messages allowed
                    nUser.saveMessageToHistory(cleanMsg) //save it to the messages history
                    .then(function(msgDesc){
                        if ( ( msgDesc instanceof Error ) === false ) {
                            nUser.emit("message", nUser.id, msgDesc);  //if all is ok emit the event  
                        }
                    });    
                } else {
                    nUser.onDeniedMessaging();    
                }    
            })
            .catch(nUser.onDeniedMessaging);
        }
    }
};

/*
    return key for messages history with this neighbor user
*/
NeighborUserProto.getKeyMessagesHistory = function() {
    return this.settings.keyMessagesHistory + "_" + this.id;
};

/*
    load the history of messaging
*/
NeighborUserProto.loadMessagesHistory = function() {
    var nUser = this;
    if ( nUser.flMessagesHistoryLoaded === true ) { //if the messages history was loaded
        return Promise.resolve(nUser.messagesHistory);
    } else { 
        return new Promise(
            function(resolve, reject) {
                commonlib.getObjLocalForage(
                    nUser.getKeyMessagesHistory(), 
                    function(res){
                        if ( res instanceof Error ) {
                            logger(res);
                            nUser.loadMessagesHistory();
                            resolve(null);
                        } else 
                            if ( Array.isArray(res) === true ) { //if the messages hstory is not empty
                                nUser.messagesHistory = res.slice(-100); //return the last 100 messages
                                resolve(nUser.messagesHistory);
                            }
                        else {
                            nUser.messagesHistory = []; //if the messages history is empty
                            resolve(nUser.messagesHistory);
                        }
                        nUser.flMessagesHistoryLoaded = true;
                    }
                );
            }
        );
    }
};

/*
    save the messaging history
*/
NeighborUserProto.saveMessagesHistory = function() {
    var nUser = this;
    if ( Array.isArray(nUser.messagesHistory) === true
        && nUser.messagesHistory.length > 0) { //if a messages are exists
            return commonlib.saveObjLocalForage( //return Promise
                        nUser.messagesHistory,
                        nUser.getKeyMessagesHistory()
                    )
                    .catch(logger);
    }
};

/*
    when the media connection closed
*/
NeighborUserProto.onMediaConnectionClosed = function() {
    var mc = this.mediaConnection;
    if ( mc != null
        && mc.flCallee === false) { //if we saw this translation from the neighbor user
                
    }
};

/*
    if the messaging connection with the neighbor user has been closed
*/
NeighborUserProto.onConnectionClosed = function(){
    
    var flThisIsCallee = this.messagingConnection.flCallee === true || this.flCallee === true; //if this is callee side
    this.emitOnConnectionStateChanged(this.messagingConnection, "Disconnected", true);
    this.closeMessagingConnection(); //remove listeners and close the previous messaging connection
    window.user.removeListener("answerSDP", this.onAnswerSDP); 
    if ( this.closed === false
        && flThisIsCallee !== true ) { //if it is callee side do nothing
            if ( this.flAllowMessages === false ) {
                this.emitOnConnectionStateChanged(this.messagingConnection, "User denied your request", true);   
            } else {
                setTimeout( //try to start the new connection if the user can messaging
                    this.startChat,
                    3000 //after 3 seconds timeout
                );
            }
    } else {
        this.emitOnConnectionStateChanged(this.messagingConnection, "User can't to communicate", true); 
    }
};

NeighborUserProto.settings = settings;
NeighborUser.prototype = NeighborUserProto;

module.exports = NeighborUser;
},{"commonlib":undefined,"eventemitter":undefined,"globalSettings":undefined,"logger":undefined,"validatorsUser":undefined}]},{},[]);
