require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"WebWorkerDataConnection":[function(require,module,exports){
var EventEmitter = require("eventemitter");
var logger = require("logger").logger;
logger.namespace = "WebWorkerDataConnection";

//create a mock of DataConnection instance
//with the following methods : send, close
//options : peer - id of the connected peer, metadata - metadata of the connection
//emitted events : open, close, data
//add options: "_type" = "created" - created by this client or "incoming" - incoming from another peer
//settings = { peer, options - as options for Peer.connect = {metadata, serialization ...} }
//add events sendData - send data to peer, closeConnection - conection must be closed
/**
 * Description
 * @method WebWorkerDataConnection
 * @param {} settings
 * @return 
 */
function WebWorkerDataConnection(settings) {
    this["_type"] = settings["_type"];
    this.peer = settings.peer || null;
    this._setProperties(settings); //set a new values of a properties
    
    //bind the context to the functions
    this._onOpen  = this._onOpen.bind(this);
    
    if (this.open !== true  ) { //if still not opened
      this.once("open",  this._onOpen);
    }
}
var WWDataConnectionProto = Object.create(new EventEmitter());

//set the new values of a properties instead of default
WWDataConnectionProto._setProperties = function(settings){
  this.metadata = {};
  this.serialization = 'json';
  if ( settings.options != null ) {
    this.metadata = settings.options.metadata || this.metadata; //metadata for connection
    this.serialization = settings.options.serialization || this.serialization; //serialization method
  }
  //default valuest for options
  this.open = settings.open || false;
  this.type = 'data';
  this.constructor = WebWorkerDataConnection;
  this._flNotInformOtherSide = false; //inform the other side about any events
};

//on connection opened
WWDataConnectionProto._onOpen = function(){
  this.open = true;  
};

//on incoming data
WWDataConnectionProto._onData = function(data){
  this.emit("data", data);  
};

//send data to the peer, to which is connected
/**
 * Description
 * @method send
 * @param {} data
 * @return 
 */
WWDataConnectionProto.send = function(data) {
  if ( this.open !== false ) { //if not prepared for closing
    this.emit("sendData", data);
  } else {
    logger(Error('Connection is not open. You should listen for the `open` event before sending messages.'));  
  }
};

//close the connection
//flCloseForcibly = true, then close without any delays and checkouts
/**
 * Description
 * @method close
 * @param {} flCloseForcibly
 * @return 
 */
WWDataConnectionProto.close = function(flCloseForcibly) {
  if ( this._closed === true ) {
    return;  
  }
  this.open = false;
  if (flCloseForcibly !== true
      && this.checkNumIncompleteAsyncOperations() === true //async ops are exists
      && this._flCloseAfterAsyncOperations !== true) { //or flag was set already
        logger("Deactivate the WWDataConnection type = " + this["_type"] + " and id = " + this["_uniqueID"]);
        this._flCloseAfterAsyncOperations = true; //set the flag to close this connection, when all async operations will have been completed
        this._timestampCloseAfterAsyncOperations = Date.now(); //set the timestamp when the data connectio was closed
        this.emit("deactivate");
  } else if ( this._flCloseAfterAsyncOperations !== true
              || this.checkNumIncompleteAsyncOperations() !== true ) { //if there are no an async operations that are waiting for complete
                  logger("Close the WWDataConnection type = " + this["_type"] + " and id = " + this["_uniqueID"]);
                  var _self = this;
                  setImmediate(
                    function(){ //close the connection
                      logger("Closed the instance of WWDataConnection type = " + _self["_type"] + " and id = " + _self["_uniqueID"]);
                      _self._closed = true;
                      _self.open = false;
                      _self.emit("close");
                      _self.removeAllListeners(); //remove all listeners
                      _self.metadata = null;
                      _self.peer = null;
                    }
                  );
  }
};

//decrease the number of incomplete async operations with the data connection
/**
 * Description
 * @method decreaseNumIncompleteAsyncOperations
 * @return 
 */
WWDataConnectionProto.decreaseNumIncompleteAsyncOperations = function(){
  if ( this._numIncompleteAsyncOps > 0 ) {
    this._numIncompleteAsyncOps--; //decrease the number of incomplete async operations
  }
  //close if all async operations completed
  if ( this._flCloseAfterAsyncOperations === true 
      && this._numIncompleteAsyncOps === 0  ) {
        this.close();
  }
};

//increase the number of incomplete async operations with the data connection
/**
 * Description
 * @method increaseNumIncompleteAsyncOperations
 * @return 
 */
WWDataConnectionProto.increaseNumIncompleteAsyncOperations = function(){
  if ( this._numIncompleteAsyncOps == null ) {
    this._numIncompleteAsyncOps = 1;
  } else {
    this._numIncompleteAsyncOps++;
  }
};

//reset the number of incomplete async operations with the data connection
/**
 * Description
 * @method resetNumIncompleteAsyncOperations
 * @return 
 */
WWDataConnectionProto.resetNumIncompleteAsyncOperations = function(){
  this._numIncompleteAsyncOps = 0;
};

//check if the number of incomplete operations more then zero
//return true if async operations are exists
/**
 * Description
 * @method checkNumIncompleteAsyncOperations
 * @return LogicalExpression
 */
WWDataConnectionProto.checkNumIncompleteAsyncOperations = function(){
  return this._numIncompleteAsyncOps != null
        && this._numIncompleteAsyncOps > 0;
};

WebWorkerDataConnection.prototype = WWDataConnectionProto;

module.exports = {
    WebWorkerDataConnection : WebWorkerDataConnection
};
},{"eventemitter":undefined,"logger":undefined}]},{},[]);
