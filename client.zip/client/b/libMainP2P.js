require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"libMainP2P":[function(require,module,exports){
//library with the common used functions to work with MainP2P, Peer.js, DataConnection, ExternalLocalServer, InnerLocalServer
var getCurrentTimestamp = require("timestamps").getCurrentTimestamp;

//return MainP2P instance by the given thisValue - this(context of the function) or dataConnection - instanceof DataConnection
/**
 * Description
 * @method returnMainP2P
 * @param {} thisValue
 * @param {} dataConnection
 * @return LogicalExpression
 */
function returnMainP2P(thisValue, dataConnection) {
    return thisValue != null &&
        (    
            (isMainP2P(thisValue) === true && thisValue) //this value is instance of MainP2P
             || (thisValue != null && isMainP2P(thisValue.g_MainP2P) === true && thisValue.g_MainP2P) //from property of thisValue 'g_MainP2P'
             || (dataConnection != null && isMainP2P(dataConnection.g_MainP2P) === true && dataConnection.g_MainP2P)
             || null //null if instance of MainP2P not found
        );
}

//set the current timestamp of the message into the DataConnection.metadata
/**
 * Description
 * @method setDataConnectionMetadataTimestamp
 * @param {} dataConnection
 * @return 
 */
function setDataConnectionMetadataTimestamp(dataConnection) {
    if (dataConnection.metadata == null) {
        dataConnection.metadata = {};
    }
    dataConnection.metadata.g_timestamp = getCurrentTimestamp();
}

/**
 * Description
 * @method getConnectionTimestamp
 * @param {} dataConnection
 * @return LogicalExpression
 */
function getConnectionTimestamp (dataConnection) {
    return dataConnection.metadata != null
            && typeof(dataConnection.metadata.g_timestamp) === "number"
            && dataConnection.metadata.g_timestamp;
}

/**
 * Description
 * @method isMainP2P
 * @param {} obj
 * @return LogicalExpression
 */
function isMainP2P(obj) {
    return obj != null
        && obj.constructor != null
        && obj.constructor.name === "MainP2P";
}

/**
 * Description
 * @method isELS
 * @param {} obj
 * @return LogicalExpression
 */
function isELS(obj) {
    return obj != null
        && obj.constructor != null
        && obj.constructor.name === "ExternalLocalServer";
}

/**
 * Description
 * @method isILS
 * @param {} obj
 * @return LogicalExpression
 */
function isILS(obj) {
    return obj != null
        && obj.constructor != null
        && obj.constructor.name === "InnerLocalServer";
}

/**
 * Description
 * @method isPeer
 * @param {} obj
 * @return LogicalExpression
 */
function isPeer(obj) {
    return obj != null
        && obj.constructor != null
        && obj.constructor.name === "Peer";
}

/**
 * Description
 * @method isSocket
 * @param {} obj
 * @return LogicalExpression
 */
function isSocket(obj) {
    return obj != null
        && obj.constructor != null
        && obj.constructor.name === "Socket";
}

//check if the dataConnection is instance of DataConnection
/**
 * Description
 * @method isDataConnection
 * @param {} dataConnection
 * @return LogicalExpression
 */
function isDataConnection(dataConnection) {
    var _constructor = dataConnection != null && dataConnection.constructor;
    return  _constructor !== false &&
        ( 
            dataConnection.constructor.name === "DataConnection"
            || dataConnection.constructor.name === "MockDataConnection"
            || dataConnection.constructor.name ===  "WebWorkerDataConnection"
        );
}


/**
 * return true if the given connection has closed or is not an instance of DataConnection
 * @method isDataConnectionClosed
 * @param {} dataConnection
 * @return LogicalExpression
 */
function isDataConnectionClosed(dataConnection) {
    return isDataConnection(dataConnection) === false
            || dataConnection.g_flClosedManually === true
            || dataConnection._closed === true;
}

module.exports = {
    returnMainP2P : returnMainP2P,
    setDataConnectionMetadataTimestamp : setDataConnectionMetadataTimestamp,
    isMainP2P : isMainP2P,
    isELS : isELS,
    isILS : isILS,
    isPeer : isPeer,
    isSocket : isSocket,
    isDataConnection : isDataConnection,
    getConnectionTimestamp : getConnectionTimestamp,
    isDataConnectionClosed : isDataConnectionClosed
};
},{"timestamps":undefined}]},{},[]);
