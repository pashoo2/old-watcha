require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"interfacePlugins":[function(require,module,exports){
/*global $*/
/*global FB*/
/*jquery.ScrollTo*/

var commonlib = require("commonlib");
var logger = require("logger").logger;
logger.namespace = "interfacePlugins";

var generalPagesContainerSelector = "body";

/*
    data-ui-disabled   - disable this element
    data-ui-onevent    - have a listeners for the events (panels, pages)
    data-dad-connectable - connectable listviews
    data-ui-load-script-dynamically - load the page content from pages directory
    data-ui-scroll-y - show element on the sceen with the height = screen height and scroolling
*/

/*
    return jQuery UI from the event or undefined if not exists
*/
function getTargetUIFromEvent(event) {
    var res;
    if ( event.length != null ) {
        for( var i = 0, len = event.length; i < len; i++ ) {
            var eTarget = event[i].target;
            if ( eTarget != null ) {
                res = $(res).add(eTarget);    
            }
        }
    } else {
        res = $(event.target);    
    }  
    return res;
}

/*
    return jQuery UI page from the event or undefined if not exists
*/
function getUIPageFromEventUI(UI) {
    var res;
    if ( UI.length != null ) {
        for( var i = 0, len = UI.length; i < len; i++ ) {
            var eTarget = UI[i].toPage;
            if ( eTarget != null ) {
                res = $(res).add(eTarget);    
            }
        }
    } else {
        res = $(UI.toPage);    
    }  
    return res;
}

/**
 * load js or css file by url and append it in the head of the document, show error if failed
 * url - string or array with string urls
 * folderURL - the base url, urls must be set relative to it
 * type = "js","css" - append to head or "ejs" - load and execute
 * if type === "ejs", then if context is not empty, then apply it to the loaded script
 * @method loadFile
 * @param {} type
 * @param {} url
 * @param {} folderURL
 * @param {} context
 * @return 
 */
function loadFile(type, url, folderURL, context) {
    
    var fileURL, fileLink;
    var resolvePath = commonlib.resolvePath; //util to resolve the path by it's parts
    
    /**
     * Description
     * @method appendFile
     * @param {} urlFile
     * @return 
     */
    function appendFile(urlFile) {
        if ( typeof(folderURL) === "string" ) {
            fileURL = resolvePath(folderURL, urlFile);
        } else {
            fileURL = urlFile;    
        }
        
        return new Promise(
                function(res, rej) {
                    switch ( type ) {
                        case "js"  : 
                            var fileref=document.createElement('script');
                            fileref.setAttribute("type","text/javascript");
                            fileref.setAttribute("src", fileURL);
                            document.getElementsByTagName("head")[0].appendChild(fileref);
                            res(true);
                            break;
                        case "css" :
                            fileLink = $("<link rel='stylesheet' type='text/css' href='"+fileURL+"'>");
                            $("head link:last").after(fileLink); //append to the head
                            res(true);
                            break;
                        case "ejs" :
                            if ( context != null ) {
                                context._dir = folderURL;
                                context._url = fileURL;
                                loadScriptsWithContext(fileURL, context, res, rej);
                            } else {
                                $.getScript( 
                                    fileURL, //url for init script
                                    function(data, txtStatus, jqxhr) {
                                        if ( jqxhr.status !== 200 ) {
                                            var e = new Error("Unable to load " + url);
                                            console.log(txtStatus);
                                            console.log(e);
                                            rej(e);
                                        } else {
                                            res(true);   
                                        }   
                                    }
                                );
                            }
                            break;
                        default: 
                            var e = new Error("Unknown file type" + type);
                            console.log(e);
                            rej(e);
                    }
            }
        );
    }
 
    if ( typeof(url) === "string" ) { //css file
        return appendFile(url);
    } else 
        if ( Array.isArray(url) === true ) { //if there is a several urls are given
            var promises = [], 
                ind = 0;
            for ( var i = 0, len = url.length; i < len; i++ ) {
                promises[ind++]=appendFile(url[i]);
            }
            return Promise.all(promises); //return Promise, fullfild when all files loaded
        }
    else {
        return Promise.reject(new Error("Unknown type of the url argument"));        
    }
 
}

/**
 * return jquery ui by it's id or ui
 * elem - jquery, DOM or string id with or w/o #
 * return NULL if the element is not exists or not found
 * @method getUIElement
 * @param {} elem
 * @return _ui
 */
function getUIElement(elem){
    var _ui;
    if ( typeof(elem) === "string" ) {
        _ui = $(elem.startsWith("#") === true ? elem : "#" + elem);    
    } else {
        _ui = $(elem);
    }
    return (_ui.length === 0 ) ? null : _ui; //chech for exists
}

/**
 * return id of the ui element
 * elem id or instance of jquery ui
 * id will returned with or without '#' depending on the secon argument - flWith
 * @method getUIID
 * @param {} elem
 * @param {} flWith
 * @return eID
 */
function getUIID(elem, flWith){
    var eID;
    if ( typeof(elem) === "string" ) {
        var strElem = elem.trim();
        var flContain = strElem.indexOf("#") === 0;
        if ( flWith === true ) { //with '#'
            eID = (flContain === true) ? elem : "#" + strElem;        
        } else { //by default - without '#'
            eID = (flContain === true) ? strElem.slice(1) : elem; //return without symbol '#'
        }
    } else { //get ui property id
        eID = ( flWith === true ? "#" : "" ) + (elem).prop("id");
    }
    return eID;
}

/**
 * show element on the sceen with the height = screen height and scroolling  
 * @method setVerticalScrolling
 * @param {} id
 * @return 
 */
function setVerticalScrolling(id) {
   /* var _uiElement;
    if ( typeof(id) === "string" ) {
        const _ui = $(id);
        _uiElement = _ui.filter("[data-ui-scroll-y]");
        if ( _uiElement.length === 0 ) {
            _uiElement = _ui.find("[data-ui-scroll-y]");    
        }
    } else {
        _uiElement = $("[data-ui-scroll-y]");
    }
    
    _uiElement.prop( "style", "overflow-y:scroll !important; height:auto; max-height: 80vh !important;" );  */
}

/**
 * show the given argument in the user interface field
 * @method showValue
 * @param {} fieldID
 * @param {} value
 * @return 
 */
function showValue(fieldID, value) {
    
    var _uiElem = getUIElement(fieldID);
    if ( _uiElem !== null ) {
        if ( _uiElem.attr('type') === "text" ) {
            _uiElem.val(value).text(value);    
        } else
            if ( _uiElem.attr('data-role') === "controlgroup" ) { //if it is radio
                var _uiTarget;
                if ( value != null ) {
                    _uiTarget =_uiElem.find('[type="radio"][value="'+ value.trim() +'"]');   
                }
                if ( _uiTarget.length !== 0 ) { //if found element with the value
                    _uiTarget.attr('checked', 'checked').checkboxradio("refresh");
                } else { //if an element was not found
                    _uiElem.find('[type="radio"]')[0].attr('checked', 'checked').checkboxradio("refresh");  //checked - the first element in the set of elements  
                }
            }
            else 
                if ( _uiElem.is("img") === true ) { //if it is an image
                    showPhoto(fieldID, value);    
                }
    }
}

/**
 * show the user photo
 * @method showPhoto
 * @param {} fieldID
 * @param {} url
 * @return 
 */
function showPhoto(fieldID, url) {
    var _uiPhoto = getUIElement(fieldID);
    if ( _uiPhoto !== null ) {
        if ( typeof(url) === "string" ) {
            //deescape ampersand in url
            _uiPhoto.attr("src", decodeURI(url)).show();  
        } else {
            _uiPhoto.hide();
        }
    }
}

/**
 * get the value from the user interface field
 * @method getValue
 * @param {} fieldID
 * @return 
 */
function getValue(fieldID) {
    
    var _uiElem = getUIElement(fieldID);
    if ( _uiElem !== null ) {
        if ( _uiElem.attr('type') === "text" ) {
            return $("#" + fieldID).val();    
        } else
            if ( _uiElem.attr('data-role') === "controlgroup" ) {
                var _uiTarget =_uiElem.children('[type="radio"][checked="checked"]');   
                _uiTarget.attr('checked', 'checked');
            }
    }
}

/**
 * change the current page on the main screen to the target page
 * targetPage - id of the target page
 * @method changeToTargetPage
 * @param {} targetPage
 * @return 
 */
function changeToTargetPage(targetPage, cb) {
   var options = module.options;
   var generalPagesContainer = $(generalPagesContainerSelector);
   
    generalPagesContainer
        .pagecontainer( //change the current page to the target page
            'change',
            getUIElement(targetPage), //to the page with id = targetPage
            {  //options for page changing
                changeHash: true,
                translition: options.translitionPageChanging
            }
        ); 
        
    if ( typeof(cb) === "function" ) {
        generalPagesContainer.one(
            "pagecontainerload", 
            function(event, ui){
                cb();  
            }
        );  
    }
}

/**
 * return relative url for page with the given id
 * @method urlForPage
 * @param {} pageID
 * @return BinaryExpression
 */
function urlForPage(pageID) {
    return '/pages/'+ pageID +'/';
}

/**
 * load a srcipt and execute it under the given context
 * @method loadScriptsWithContext
 * @param {} url
 * @param {} context
 * @return 
 */
function loadScriptsWithContext(url, context, cbOk, cbErr) {
    var opt ={
        url: url,
        /**
         * Description
         * @method success
         * @param {} functionBody
         * @return 
         */
        success: function (functionBody) { //on content was loaded
            (new Function(functionBody)).apply(context); //create 
            if ( typeof(cbOk) === "function" ) { //if all is ok
                cbOk();
            }
        },
        dataType: "text"
    }
    if ( typeof(cbErr) === "function" ) { //on error
        opt.error = cbErr;    
    }
    
    $.ajax(opt);
}

/**
 * add a dynamic script for a pages with the tag data-role-ui-load-scripts-dynamically"
 * if pages is Array with jquery pages elements or it's selectors, then load scrits only for this pages
 * @method loadDynamicScripts
 * @param {} _callback
 * @param {} pages
 * @return 
 */
function loadDynamicScripts(_callback, pages) {
    var numberWaitingFor = 0;
    var _selected = Array.isArray(pages) === true ? pages : $('[data-ui-load-script-dynamically]');
    
    var i, len;
    
    for( i =0, len = _selected.length; i < len; i++ ) {
        let pageID = $(_selected[i]).prop("id"); 
        
        var pageScripts = getPageScripts(pageID);
        if ( pageScripts == null ) {
        
                numberWaitingFor++;
                $.ajax({
                    url: urlForPage(pageID) + 'script/index.js',
                    /**
                     * Description
                     * @method success
                     * @param {} functionBody
                     * @return 
                     */
                    success: function (functionBody) { //on content was loaded
                            numberWaitingFor--;
                            
                            var pagesScripts = getPagesScripts();
                            var pageModule = pagesScripts[pageID] = {}; //create Window["_gPagesScripts"]["pageID"] = {}
                            (new Function(functionBody)).apply(pageModule); //create
                            
                            if ( numberWaitingFor === 0 ) {
                                if ( typeof(_callback) === "function" ) {
                                    _callback(false);    
                                }    
                            }
                            
                        },
                    dataType: "text"
                });
            }
    }
     
    if ( numberWaitingFor === 0 ) {       
        if ( typeof(_callback) === "function" ) {
            _callback(true); //callback with flag, that the scripts for the page has been loaded already   
        }
    }
}

/**
 * execute script for page, that has loaded    
 * @method setListenersForPage
 * @param {} pageID
 * @return 
 */
function setListenersForPage(pageID) {
    
    var _uiPage = getUIElement(pageID);
    var _pageID = getUIID(pageID); //without #
    
    var pagesScripts = getPagesScripts();
    
    if ( pagesScripts[_pageID] != null ) { //if the scripts are exists for the page
        
        var pageScripts = pagesScripts[_pageID].page;
        
        if ( pageScripts != null
            && pageScripts.onevent != null ) { //if the scripts are exists for the page
                var handlers = pageScripts.onevent; //{event name : handler}
                var events = Object.keys(handlers);
                for ( var i = 0, len = events.length; i < len; i++ ) {
                    var eventName = events[i];
                    var handler = handlers[eventName];
                    if ( typeof(handler) === "function" ) { //if the handler is exists for the event
                        if ( eventName === "pagecreate" ) {
                            _uiPage.one( eventName, handler ); //set the handler
                        } else {
                            _uiPage.on( eventName, handler ); //set the handler
                        }
                    }
                }
        }
        
        if ( pagesScripts[_pageID].elements != null ) { //if necesary to set the events for a panerl on the page
           setListenersForElementsOnPage(_pageID); 
        }
        
    }
    
}

/*
    return object with scripts for the page
    flCreateIfNotExists - if true, then create new object for scripts if not exists
*/
function getPageScripts(pageID, flCreateIfNotExists) {
    var pagesScripts = getPagesScripts();
    var pageScripts = pagesScripts[pageID];    
    if ( pageScripts == null ) {
        if ( flCreateIfNotExists === true ) {
            return pagesScripts[pageID] = {};    
        }
    } else {
        return pageScripts;
    }
}

/*
    return global object with scripts for all loaded pages
*/
function getPagesScripts(pageID) {
    var res = window["_gPagesScripts"];
    if ( res == null ) {
        return window["_gPagesScripts"] = {};  
    } else {
        return res;
    }  
}

/**
 * set a listeners for the panels on the page with the given id    
 * @method setListenersForElementsOnPage
 * @param {} pageID
 * @return 
 */
function setListenersForElementsOnPage(pageID) {
    var pagesScripts = getPagesScripts();
    
    if ( pagesScripts[pageID] != null ) { //if the scripts are exists for the page
        var uiElementsScripts = pagesScripts[pageID].elements;
        if ( uiElementsScripts != null ) { //if a scripts for a panels on the page are exists
            var elements = Object.keys(uiElementsScripts); 
            for( var i = 0, len = elements.length; i < len; i++ ) {
                var elementID = elements[i]; //id of the ui element
                if ( typeof(elementID) === "string") {
                    elementID = elementID.trim();
                    var _uiEL = $( "#" + elementID.trim() );
                    if ( _uiEL.length > 0 ) { //if the panel is exists
                        var handlers = uiElementsScripts[elementID].onevent;
                        if ( handlers != null ) { //if an event handlers are exists
                            var elEvents = Object.keys(handlers);
                            for ( var ii = 0, _len = elEvents.length; ii < _len; ii++ ) {
                                var eventName = elEvents[ii];   
                                var handler = handlers[eventName];
                                if ( typeof(handler) === "function" ) { //if the handler for the event is exists
                                    _uiEL.on(eventName, handler);  //set the handler                                  
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * when a page has shown on the user screen
 * @method onPageShow
 * @param {} event
 * @param {} ui
 * @return 
 */
function onPageShow(event, ui) {
    var _uiPage = getUIPageFromEventUI(ui);
    _uiPage.triggerHandler("pagecontainershow");

    $(".cd-auto-hide-header").addClass("hide");

}

/**
 * when a page hiding from the main screen
 * @method onPageShow
 * @param {} event
 * @param {} ui
 * @return 
 */
function onPageBeforeHide(event, ui) {
    var _uiPage = getUIPageFromEventUI(ui);
    _uiPage.triggerHandler("pagecontainerbeforehide");
    $(".cd-auto-hide-header").removeClass("hide");
}

/**
 * before a page has shown on the user screen
 * @method onPageBeforeShow
 * @param {} event
 * @param {} ui
 * @return 
 */
function onPageBeforeShow(event, ui) {
    var _uiPage = getUIPageFromEventUI(ui);
    setDisabledClass(_uiPage);
    loadDynamicPage(getNeighborPages(_uiPage), null, true); //load the neighbor page for hte opening page
    makeConnectableListviews(_uiPage.find('[data-ui-connectable]')); //make the listviews on the page to be connectable
    _uiPage.triggerHandler("pagecontainerbeforeshow");
    
    //show the page title
    var pageName = _uiPage.attr("data-ui-pagename");
    var title = "";
    if ( pageName !== undefined ) {
        title = pageName.toString().toUpperCase(); //change title of the page
    } else {
        title = ""; 
    }
    $("[data-ui-page-title]").text(title);
}

/**
 * add to the end of an array elments, that are given as the following arguments
 * @method appendIfNotEmpty
 * @return 
 */
function appendIfNotEmpty() {
    var arrayСatcher = arguments[0];
    for ( var i = 1, len = arguments.length; i < len; i++ ) {
       var item = arguments[i];
       if ( typeof(item) === "string"
            && item.trim() !== "" ) {
                arrayСatcher[arrayСatcher.length] = item; 
       }
    }
}

/**
 * return the neighbor pages (left, right, top, bottom) to the given page
 * @method getNeighborPages
 * @param {} _page
 * @return listNeighborPages
 */
function getNeighborPages(_page) {
    var rightpage, leftpage, toppage, bottompage;
    var listNeighborPages = [];
    var _uiPage = getUIElement(_page);
    var userInterface = window.interface;
    
    rightpage   = userInterface.getPageIDByName(_uiPage.attr("data-rightpage")); //on right swipe
    leftpage    = userInterface.getPageIDByName(_uiPage.attr("data-leftpage"));  //on left swipe
    toppage     = userInterface.getPageIDByName(_uiPage.attr("data-toppage"));
    bottompage  = userInterface.getPageIDByName(_uiPage.attr("data-bottompage"));
    
    appendIfNotEmpty(listNeighborPages, rightpage, leftpage, toppage, bottompage);
    return listNeighborPages;
}

/*
    set mask for ui input elements
    parentUI - parent element, find the children elements
*/
function setUIDataMask(parentUI) {
    $.applyDataMask( parentUI != null ? getUIElement(parentUI).find('[data-mask]') : '[data-mask]' );
}

/**
 * before a page will be created in the DOM
 * @method onPageBeforeCreate
 * @param {} event
 * @param {} ui
 * @return 
 */
function onPageBeforeCreate(event, ui) {
    var _uiPage = getTargetUIFromEvent(event);
    loadDynamicScripts(
        function(){
            setListenersForPage(_uiPage);
            var pageID = getUIID(_uiPage, true); //with '#'
            if ( $(pageID).length !== 0 ) { //if the page was created
                _uiPage.triggerHandler("pagecreate");  //fire the event "pagecreate"  
            }
            setUIDataMask(_uiPage);
        },
        [_uiPage]
    ); 
}

/*

*/
function fireOnPage(page, args) {
    var uiPage = $(page);
    uiPage.triggerHandler.apply(uiPage, args);    
}

/**
 * load a dynamic pages data-role-ui-load-scripts-dynamically="true"
 * toLoad = ['id of a page 1', ... 'id of a page N']
 * flDoNotLoadNearest - if true, then do not load the nearezt pages to the pages given in to the toLoad argument
 * @method loadDynamicPage
 * @param {} toLoad
 * @param {} _callback
 * @param {} flDoNotLoadNearest
 * @return 
 */
function loadDynamicPage(toLoad, _callback, flDoNotLoadNearest) {
    
    var loadingPages = []; //pages that are loading for now
    var generalPagesContainer = $(generalPagesContainerSelector);
    var listNeighborPages = []; //list with id of the nearest pages
    
    /**
     * Description
     * @method loadPageWithURL
     * @param {} pageID
     * @param {} url
     * @return 
     */
    function loadPageWithURL(pageID, url){
        
        var loadedPages = module.loadedPages; //list with id of the loaded pages
        
        if ( generalPagesContainer.find("#" + pageID).length === 0 //try to find in the DOM
            && loadedPages.includes(pageID) !== true ) { //and in the list of the loaded pages
                loadedPages[loadedPages.length] = pageID;
                generalPagesContainer.pagecontainer( 
                    "load", 
                    ( url == null ? urlForPage(pageID) + "content/index.html" : url ),
                    { role: "page", reload : false }
                );
        } else { //if already in the cache
            pageContainerOnLoad(null, null, pageID, true);
        }
    }
    
    /*
        check that all pages loaded
    */
    function checkAllPagesLoaded() {
        if ( loadingPages.length === 0 ) { //if all was done, then load scripts for the page
                
            clearInterval(intCheckLoading);
            generalPagesContainer.off( "pagecontainerload" , pageContainerOnLoad );
            generalPagesContainer.off( "pageloadfailed"    , pageContainerOnLoadFailed );
            
            if ( flDoNotLoadNearest !== true ) {
                loadDynamicPage(listNeighborPages, _callback, true);
            } else             
                if ( typeof(_callback) === "function" ) {
                    _callback();    
                }
        }    
    }
    
    /**
     * Description
     * @method pageContainerOnLoad
     * @param {} event
     * @param {} ui
     * @param {} pageID
     * @param {} flAlreadyExistsInDom
     * @return 
     */
    function pageContainerOnLoad(event, ui, pageID, flAlreadyExistsInDom) { //on one of the pages loaded
        
        var _uiPage, _pageID; 
        if ( ui != null ) {
            _uiPage = getUIPageFromEventUI(ui);
            _pageID = _uiPage.attr('id').trim();    
        } else {
            _pageID = pageID;
            _uiPage = $( "#" + pageID);
        }
        
        if ( flDoNotLoadNearest !== true ) {
            Array.prototype.push.apply(listNeighborPages, getNeighborPages(_uiPage));
        }
           
        _uiPage.off('pagehide.remove');  //do not remove the page from the DOM when hide it
           
        if ( $(_uiPage.attr("id")).length === 0
            && flAlreadyExistsInDom !== true ) { //if not exists in the DOM
                _uiPage.one("pagebeforecreate",
                    function(){ //when the page was created in the DOM
                        commonlib.deleteFromArray(loadingPages, _pageID ); //remove the page from the list of the loading pages
                        onPageBeforeCreate(arguments);
                        checkAllPagesLoaded();
                        window.interface.onPageLoadedDynamically(_uiPage);
                    });
        } else if ( flAlreadyExistsInDom !== true ) {
            commonlib.deleteFromArray(loadingPages, _pageID ); //remove the page from the list of the loading pages
            _uiPage.one("pagebeforecreate", onPageBeforeCreate);
        } else {
            commonlib.deleteFromArray(loadingPages, _pageID ); //remove the page from the list of the loading pages
            checkAllPagesLoaded();
        }
        
    }
    
    /**
     * Description
     * @method pageContainerOnLoadFailed
     * @param {} event
     * @param {} ui
     * @return 
     */
    function pageContainerOnLoadFailed(event, ui) { //on one of the pages loaded
        
        if ( ui.errorThrown !== "Not Found" ) { //if the page was not found
            event.preventDefault();
            ui.deferred.reject( ui.absUrl, ui.options );
        } else {
            logger("The page with url = " + ui.absUrl + " can't be found");
            ui.deferred.resolve( ui.absUrl, ui.options, null );
            clearInterval(intCheckLoading);
        }
        
        event.preventDefault(); //prevent the default
    }

    if ( Array.isArray(toLoad) ) {
        
        var intCheckLoading = setInterval( //each 5 seconds check for pages, that are not loaded succesfully
            function(){
                
                if ( loadingPages.length === 0 ) { //if all was done, then load scripts for the page
                    clearInterval(intCheckLoading);
                }
                
                for ( var i = 0, len = loadingPages.length; i < len; i++ ) { //try to load pages once again
                    var pageID = loadingPages[i];
                    loadPageWithURL(pageID); //try to load the page once again
                }
                
            }
            , 5000);
        
        generalPagesContainer.on("pageloadfailed"   , pageContainerOnLoadFailed);
        generalPagesContainer.on("pagecontainerload", pageContainerOnLoad);        
            
        for ( var i = 0, len = toLoad.length; i < len; i++ ) {
            var pageID;
            if ( typeof(toLoad[i]) === "string" ) {
                pageID = toLoad[i].trim(); 
                loadingPages[i] = pageID;
                loadPageWithURL(pageID); //load html content of the page
            }
        }
        
    }
        
    if ( loadingPages.length === 0 ) { //if all was done, then load scripts for the page
        if ( typeof(_callback) === "function" ) {
            _callback();    
        }    
    }
}

/**
 * change the current page, depending on swipe duration
 * @method onDocumentSwipeChandePage
 * @param {} direction
 * @param {} distance
 * @param {} duration
 * @param {} startHorizontal
 * @param {} startVertical
 * @return 
 */
function onDocumentSwipeChandePage(direction, distance, duration, startHorizontal, startVertical) {
    
    var options     = module.options,
        innerFlags  = module.flags;
        
    var windowWidth =  $(document).width(),
        windowHeight = $(document).height();
        
    var windowHorizontalEvDetectDistance = windowWidth / options.eventHappenDelimetr,
        windowVerticalEvDetectDistance = windowHeight / options.eventHappenDelimetr,
        windowHorizontalEvDetectRight = windowWidth / options.eventDetectionDelimetr,
        windowHorizontalEvDetectLeft = windowWidth - windowHorizontalEvDetectRight,
        windowVerticalEvDetectDown = windowHeight / options.eventDetectionDelimetr,
        windowVerticalEvDetectUp = windowHeight - windowVerticalEvDetectDown;
    
    var flCan = innerFlags.allowPagesSwiping === true //swiping is allowed
                && innerFlags.pagesWereLoaded === true; //and all pages were loaded

    if (flCan === true 
        && duration > options.eventDetectionDuration) {

            //if (event.currentTarget === document) {
                var currentPage = $("body").pagecontainer("getActivePage");
    
                var targetPage = null;
                var translition = null;
    
                switch (direction) {
                case "left":
                    if (distance > windowHorizontalEvDetectDistance
                        && startHorizontal > windowHorizontalEvDetectLeft) {
                            targetPage = "leftpage";
                    }
                    break;
                case "right":
                    if (distance > windowHorizontalEvDetectDistance
                        && startHorizontal < windowHorizontalEvDetectRight) {
                            targetPage = "rightpage";
                    }
                    break;
                case "up":
                    if (distance > windowVerticalEvDetectDistance
                        && startVertical > windowVerticalEvDetectUp) {
                            targetPage = "bottompage";
                    }
                    break;
                case "down":
                    if (distance > windowVerticalEvDetectDistance
                        && startVertical < windowVerticalEvDetectDown) {
                            targetPage = "toppage";
                    }
                    break;
                default:
                    break;
    
                }

                if (typeof (targetPage) === "string") {
                    window.interface.showPage(currentPage.attr("data-" + targetPage));
                }
    
            //}
    }
}

/**
 * on swipe touch on the document's page
 * e - jQuery 'swipe' event
 * @method onPageconteinerSwipe
 * @param {} e
 * @return 
 */
function onSwipe(e, callback) {
    
    if ( typeof(this) === "function" ) { //may be bound to a callback funtion
        callback = this;    
    }
    
    var direction,
        distance,
        duration;
    var swipestart = e.swipestart,
        swipestop = e.swipestop,
        startX = swipestart.coords[0],
        startY = swipestart.coords[1],
        stopX = swipestop.coords[0],
        stopY = swipestop.coords[1],
        distanceX = stopX - startX,
        distanceY = stopY - startY,
        distanceHor = Math.abs(distanceX), //horizontal distance
        distanceVert = Math.abs(distanceY), //vertical distance
        windowHeight = $( document ).height(),
        windowWidth  = $( document ).width();
    
    if ( ( distanceHor / windowWidth ) > ( distanceVert/ windowHeight ) ) { //check translation relatively to the screen size
        distance = distanceHor; //if it is horizontal swipe
        if (distanceX > 0) { //check for horizontal direction
            direction = "right";
        }
        else {
            direction = "left";
        }
    }
    else { //vertical swipe
        distance = distanceVert;
        if (distanceY > 0) { //check for vertical direction
            direction = "down";
        }
        else {
            direction = "up";
        }
    }
    duration = swipestop.time - swipestart.time;
    
    if ( typeof(callback) === "function" ) {
        callback(direction, distance, duration, startX , startY);
    }

}

/**
 * set the default settings for this module
 * @method defaultModuleOptions
 * @return 
 */
function defaultModuleOptions() {
    
    var generalPagesContainer = $(generalPagesContainerSelector);
    
    var settings = module.options, //settings of this module
        eventHappenDelimetr = settings.eventHappenDelimetr, //delimetr to define how much pixels must be touched on swipe to define that an event has been
        eventDetectionDelimetr = settings.eventDetectionDelimetr = 20,
        windowWidth  = settings.windowWidth  = generalPagesContainer.width(),
        windowHeight = settings.windowHeight = generalPagesContainer.height(),
        windowHorizontalEvDetectRight = settings.windowHorizontalEvDetectRight = windowWidth / eventDetectionDelimetr,
        windowVerticalEvDetectDown = settings.windowVerticalEvDetectDown = windowHeight / eventDetectionDelimetr;
    
    settings.windowHorizontalEvDetectDistance = windowWidth / eventHappenDelimetr;
    settings.windowVerticalEvDetectDistance = windowHeight / eventHappenDelimetr;
    settings.windowHorizontalEvDetectLeft = windowWidth - windowHorizontalEvDetectRight;
    settings.windowVerticalEvDetectUp = windowHeight - windowVerticalEvDetectDown;    
}

/**
 * do the basics on document ready
 * @method onDocumentReady
 * @return 
 */
function onDocumentReady() {
    
    var generalPagesContainer = $(generalPagesContainerSelector); 
    
    $.ajax(module.ajax.options); //set global options for ajax
    $.mobile.ignoreContentEnabled = true; //allow to use data-ajax='false' on a parent nodes
         
    defaultModuleOptions(); //set the default options for the module
    
    generalPagesContainer
        .pagecontainer({
          defaults: true
        })
        .on("swipe", onSwipe.bind(onDocumentSwipeChandePage));
    
    generalPagesContainer.on("pagecontainerbeforeshow", onPageBeforeShow);
    generalPagesContainer.on("pagecontainershow", onPageShow);
    generalPagesContainer.on("pagecontainerbeforehide", onPageBeforeHide);

    $.jMaskGlobals = {
        maskElements: 'input, div',
        dataMaskAttr: '*[data-mask]',
        dataMask: true,
        watchInterval: 1000,
        watchInputs: false,
        watchDataMask: false,
        byPassKeys: [9, 16, 17, 18, 36, 37, 38, 39, 40, 91],
        translation: {
            '0' : {pattern: /\d/, optional: false},
            '9' : {pattern: /\d/, optional: true},
            '#' : {pattern: /\d/, recursive: true},
            'P' : {pattern: /[0-9()-]/, recursive: true}, //phone number
            'A' : {pattern: /[a-zA-Z0-9]/},
            'S' : {pattern: /[a-zA-Z]/},
            'Z' : {pattern: /[a-zA-Z0-9]/, recursive: true},
            'z' : {pattern: /[a-zA-Z0-9]/, optional: true}
        }
    };
}

/**
 * set class for 
 * @method setDisabledClass
 * @return 
 */
function setDisabledClass(_uiPage) {
    if ( _uiPage != null ) { //find childrens for the given ui
        getUIElement(_uiPage).find("[data-ui-disabled]").addClass("ui-state-disabled"); //add class for disabled elements
    } else { //get all disabled elements
        $("[data-ui-disabled]").addClass("ui-state-disabled"); //add class for disabled elements    
    } 
}

/**
 * remove all items from the listview
 * flExpectDisabled = true, than expect the disabled items
 * @method clearListview
 * @param {} listview
 * @param {} flDoNotUpdate
 * @param {} flExpectDisabled
 * @return 
 */
function clearListview(listview, flDoNotUpdate, flExpectDisabled){
    var _uiListview = $(listview);
    
    if ( flExpectDisabled === true ) { //expect the disaled items
        _uiListview.children(':not([data-ui-disabled])').remove();
    } else {
        _uiListview.empty(); //clear the retrieved listview elements
    }
    
    if ( flDoNotUpdate !== true ) {
        updateListview(_uiListview);    
    }
    
}

/**
 * return array with items = values of the given listview element    
 * @method getListviewItems
 * @param {} listview
 * @param {} flExpectDisabled
 * @return result
 */
function getListviewItems(listview, flExpectDisabled) {
    var _uiListview = $(listview);
    var _uiListviewItems;
    
    if ( flExpectDisabled === true ) { //expect the disaled items
        _uiListviewItems = $(listview).children('li:not([data-ui-disabled])');
    } else {
        _uiListviewItems = _uiListview.children("li");    //get li elements, which are the child elements for the listview ul element    
    }
    
    var result = [];
    var indResult = 0;
    
    for( var i = 0, len = _uiListviewItems.length; i < len; i++ ) {
        result[indResult++] = $(_uiListviewItems[i]).text().trim(); //put the value of the element to the resulted array
    }
    
    return result;
}

/**
 * refresh the listview and call another methods for the given listview according to it's tags
 * uiLI - element of the listview
 * @method updateListview
 * @param {} listview
 * @param {} uiLI
 * @return 
 */
function updateListview(listview, uiLI) {
    var _uiListview = $(listview);
    
    _uiListview.listview('refresh');
    
    if ( _uiListview.data("ui-connectable") != null) { //if necessary to make it connectable
        if ( uiLI == null ) {
            makeConnectableListviews(listview);    
        } else {
            $(uiLI) //make the LI element draggable
            .draggable({
                appendTo: "ul",
                helper: "drag it to another list",
                iframeFix: true,
                revert: true,
                scope: "drop"
            });    
        }
    } 
    
}

/**
 * append a new element with the given vlue and icon element to the given listview
 * @method appendElementToListview
 * @param {} listview
 * @param {} name
 * @param {} icon
 * @param {} flDoNotUpdate
 * @return 
 */
function appendElementToListview(listview, name, icon, flDoNotUpdate) {
    var flWithIcon = typeof(icon) === "string";
    var htmlForElement = "<li " 
                        + ( flWithIcon === true ? "data-icon='"+ icon +"'" : "" ) 
                        + ">"
                        + name
                        + "</li>";
    var _uiLI = $(htmlForElement).appendTo(listview); //li element
    _uiLI.click(onClickToListElement); 
                       
    if ( flDoNotUpdate !== true ) {
        updateListview(listview, _uiLI);
    }
}

/**
 * add the given list of an elements into the list of the listview element
 * elements = { value : icon } or [],
 * listview - string, or ui
 * @method appendListToListview
 * @param {} listview
 * @param {} elements
 * @param {} flDoNotUpdate
 * @return 
 */
function appendListToListview(listview, elements, flDoNotUpdate) {
    
    var elementsList;
    var flArray = Array.isArray(elements);
    
    if ( flArray === true ) { //if an array is given
        elementsList = elements;
    } else { //if object
        elementsList = Object.keys(elements);
    }
    
    for ( var i = 0, len = elementsList.length; i < len; i++ ) { //for each element
        var elementName = elementsList[i];
        appendElementToListview(listview, elementName, flArray === true ? undefined : elements[elementName], true ); //appenfd one element to the listview    
    }
    
    if ( flDoNotUpdate !== true ) {
        updateListview(listview);
    }
    
}

/**
 * when drop on the connective list
 * @method connectiveListOnDrop
 * @param {} event
 * @param {} ui
 * @return 
 */
function connectiveListOnDrop( event, ui ) {
    var _uiElement  = ui.draggable[0];
    if ( _uiElement ) {
        appendElementToListview($(this), $(ui.draggable).text(), ""); //add to the new element
        var _uiListview = _uiElement.parentNode;
        $(_uiElement).remove(); //remove from the previous element
        $(_uiListview).listview('refresh');
        $(this).listview('refresh');
    }    
}

/*
    on click to a list element
*/
function onClickToListElement(){
    var uiLI = $(this);
    var parentList = uiLI.parent("ul"); //the parent listview
    var anotherList = $('ul[data-role="listview"][data-ui-connectable][data-ui-connectable-with="' + parentList.attr("data-ui-connectable-with").trim() + '"]').not(parentList).get(0); //another listview
    if ( anotherList != null ) {
        appendElementToListview(anotherList, uiLI.text()); //add to another listview
    }
    uiLI.remove(); //remove the element from the parent list
}

/**
 * make all listviews with the attribute data-dad-connectable="true" connectable
 * li elements may be dragged and dropped on that elements
 * @method makeConnectableListviews
 * @param {} listview
 * @return 
 */
function makeConnectableListviews(listview) {
    var _uiListview;
    
    if ( listview == null ) { //if called for all document
        _uiListview = $('ul[data-role="listview"][data-ui-connectable]');
    } else { //if called for a listview or a parent element
        _uiListview = $(listview);
        if ( _uiListview.data("role") !== "listview" ) { //if a parent element for the listview
            _uiListview = _uiListview.children('ul[data-role="listview"][data-ui-connectable]:not([data-ui-connectable="true"])'); //search for a childrens listviews     
        } else {
            _uiListview = _uiListview.not('[data-ui-connectable="true"]'); //exclude the elements, that are already connectable    
        }
    }
    
    const listviewElements = _uiListview.children('li:not([data-ui-disabled])');
    listviewElements
        .draggable({
            appendTo:"ul",
            helper:"drag it to another list",
            iframeFix:true,
            revert:true,
            scope:"drop"
        });
    
    listviewElements.click(onClickToListElement); //onclick to li elements of the list collection
                    
    _uiListview
        .droppable({
            accept:"li",
            scope: "drop",
            greedy: true,
            drop : connectiveListOnDrop
        })
        .sortable();
}

/*
    create popup widget
*/
function createPopUp(html) {
    var uiPopup = 
            $(  '<div></div>', 
                { html: html }
            );
          
    var moptions = module.options;
    
    var height  = moptions.windowHeight;
    var docWidth    = moptions.windowWidth * 0.8;
    var popupHeight = height * 0.8;
        
    uiPopup
        .appendTo("body") //add chatbox div container
        .attr("style",
            "overflow-y: auto; width : "  + ( docWidth * 0.7 ) + "px !important;" + "max-width : "  + ( docWidth * 0.7 ) + "px !important;" + "height : "  + popupHeight + "px !important;" + "max-height : "  + popupHeight + "px !important"
        )
        .trigger('create')
        .enhanceWithin() //make all jquery enchancments for html content inside the popup
        .popup(moptions.optionspopup);
    
    debugger;
    uiPopup.popup("open"); //set the defaul options
    
    return uiPopup;
}

/*
    openpopup with the given html content
*/
function openpopup(uipopup, html) {
    uipopup
    .empty()
    .html(html)
    .enhanceWithin()
    .slideToggle("slow");
    //.popup("open");    
}

/*
    scroll element
    up = true, then scroll on top
*/
function scroll(uiElement, up) {
    var _ui = $(uiElement);
    var _uiHeight = _ui.height() / 5;
    $(_ui).scrollTo( ( up === true ? "-" : "+" ) + "=" + _uiHeight + "px", {axis:"y", interrupt: true, duration: 30});
}

/*
    return a list with the siple DOM elements from array or jq object or DOm object
*/
function getListOfDOMElements(ui) {
    var domElements = []; //list with the DOm elemetns
    var ind = 0;
    if ( ui instanceof jQuery ) { //if it is jquery object
        domElements = ui.toArray();   
    } else if ( Array.isArray(ui) === true ) { //if it is an array
        domElements = ui;
    } else {
        domElements = [ui];    
    }
    
    var resList = [];
    const len = domElements.length;
    for( var i =0; i < len; i++ ) {
        var domUI = domElements[i];
        if ( domUI instanceof jQuery ) { //if it is instance of JQuery
            var jqDOMList = getListOfDOMElements(domUI);    
            resList = commonlib.mergeUnique(resList, jqDOMList);
        } else 
        if ( domUI instanceof HTMLElement
            && resList.includes(domUI) !== true ) {
                resList[resList.length] = domUI;
        }
    } 
    return resList; 
}

/*
    highlight the element
    flStopPrevious - stop effect for previois elements
*/
function highlightUI(uiEl, highlightName, className, flStopPrevious) {

    if ( flStopPrevious === true ) {
        stopHighlightUI($('.' + className).not(uiEl), highlightName, className); //stop highlight for elements, that are highlighted currently
    }
    
    var _ui = $(uiEl);
    _ui.each(function(){ //add effect with the class for the elements
        var ui = $(this);
        var effects = ui.data("ui-effects"); 
        if ( effects == null ) { //if there is no effects for the element for now
            ui.data("ui-effects", {
                [className] : [highlightName] 
            });  
        } else {
            var effectsWithClass = effects[className];
            if ( effectsWithClass == null ) {
                effects[className] = [highlightName];   
            } else if ( effectsWithClass.indexOf(highlightName) === -1 ) { //if the effect is not on the element
                effectsWithClass[effectsWithClass.length] = highlightName;    
            }
        }
    });
    
    animate(_ui, className, false); //start
}

/*
    highlight the element
*/
function stopHighlightUI(uiEl, highlightName, className) {
    
    var _ui = $(uiEl)
                .filter(function() {
                    var res = true;
                    var ui = $(this);
                    const effectsOnUI = ui.data("ui-effects");
                    if ( effectsOnUI != null ) {
                        const effectsWithClass = effectsOnUI[className]; //effects with the given class
                        if ( effectsWithClass != null
                            && effectsWithClass.length !== 0) {
                                const posEffect = effectsWithClass.indexOf(highlightName);
                                if ( posEffect !== -1 ) { //if the effect is operating on the element for now
                                    effectsWithClass.splice(posEffect, 1); //remove the effect from the node
                                    if ( effectsWithClass.length === 0 ) { //if this is only the only effect with the given class applied for this node
                                        effectsOnUI[className] = null;
                                        if ( Object.keys(effectsOnUI).length === 1 ) { //if became that there is no effects on the node
                                            ui.data("ui-effects", null);  
                                        }
                                    } else { //if another effects with the given class are exists for the node
                                        res = false; //do not remove the effect from the node
                                    }
                                }
                        }
                    }
                    return res;
                });
    
    animate(_ui, className, true); //stop
}

/*
    start or stop animation effect provided by the given className    
*/
function animate(ui, className, flStop) {
    
    const list = $(ui);
    if ( list.length !== 0 ) {
        const list1 = list.filter('input[type="text"]').parent("div.ui-input-text"); //add class for the parent divs releatives to input nodes
        const list2 = list.add(list1);
        if ( flStop !== true ) {
           list2.filter(flStop !== true ? ':not(.'+ className +')' : '.' + className).addClass(className); 
        } else {
           list1.removeClass(className); 
           list2.removeClass(className);
        }
    }
}

function getCurrentPageName() {
    var currentPage = $("body").pagecontainer("getActivePage");
    return currentPage.attr("data-ui-pagename");
}

var module = 
    module.exports =
    {
        main  : {
            scroll : scroll,
            onSwipe : onSwipe, //handler for the jquery mobile swipe event. may be bound to the callback function with .bind
            showValue : showValue,
            getValue  : getValue,
            getUIElement : getUIElement,
            onDocumentReady : onDocumentReady,
            getListOfDOMElements : getListOfDOMElements
        },
        interface : {
            setVerticalScrolling : setVerticalScrolling,
            highlightUI : highlightUI,
            stopHighlightUI : stopHighlightUI
        },
        pages : {
            changeToTargetPage  : changeToTargetPage,
            loadDynamicPage     : loadDynamicPage,
            getNeighborPages    : getNeighborPages,
            getPageScripts      : getPageScripts,
            fireOnPage          : fireOnPage,
            getCurrentPageName  : getCurrentPageName
        },
        listviews : {
            makeConnectableListviews : makeConnectableListviews,
            appendListToListview : appendListToListview,
            appendElementToListview : appendElementToListview,
            updateListview : updateListview,
            getListviewItems : getListviewItems,
            clearListview : clearListview
        },
        ajax : {
            options : {
                cache : false    
            },
            loadFile            : loadFile,
            loadDynamicPage     : loadDynamicPage,
            loadDynamicScripts  : loadDynamicScripts,
            loadScriptsWithContext : loadScriptsWithContext
        },
        options : { //some default values for an options can be set with the defaultModuleOptions function
            generalPagesContainerSelector : generalPagesContainerSelector, //jquery selector for the main page container
            urlIntegration  : "/integration", //url of files for integration with external services
            eventDetectionDuration  : 50,   //how much milliseconds an events must be long to define that an event has been
            eventDetectionDelimetr  : 20, //delimetr to define how much pixels must be touched on swipe to define that an event has been
            eventHappenDelimetr     : 40,
            translitionPageChanging : "fade",
            correspondenceValueNameDOMId : {}, //{ "element name" : "element DOM ID" }
            correspondencePageNameDOMId  : {}, // {"page name" : "DOM id"} - correspondance page name with it's DOM ID
            optionspopup : { //options for jQuery popup widgets
                positionTo: "window",
                shadow : true,
                theme : "a",
                overlayTheme : "b",
                transition: "pop"
            },
            highlightWiggle : {
                randomStart : false,
                degrees : ['0.5','1','0.5','0','-0.5','-1','-0.5','0']
            }
        },
        flags   : {
            allowPagesSwiping : false,  //allow change pages with swipe
            pagesWereLoaded   : false   //all pages were loaded dynamically using the ajax   
        },
        popup : {
            createPopUp : createPopUp,
            openpopup : openpopup
        },
        loadedPages : [], //list with id of a pages loaded dynamically via ajax
        integrationSettings : {}, //settings for integration with another services
        data : {} //various data
    };
},{"commonlib":undefined,"logger":undefined}]},{},[]);
