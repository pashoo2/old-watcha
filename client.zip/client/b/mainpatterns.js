require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"mainpatterns":[function(require,module,exports){
var common = require("commonlib");
var appSettings = require("globalSettings");
var empty_user_id = appSettings.empty_user_id; //the value, that is representation of an empty id of the user


//extend the schema with a new properties
/**
 * Description
 * @method extendSchemaProperties
 * @param {} schemaOrigin
 * @param {} newProperties
 * @return schema
 */
function extendSchemaProperties(schemaOrigin, newProperties){
    var schema = JSON.parse(JSON.stringify(schemaOrigin)); //clone the original schema
    if ( common.hasProperty(schema, "properties") === false ) {
        var props = schema.properties = {};
    } else {
        props = schema.properties;
    }
    var requiredProps = common.hasProperty(schema, "required")
        && (Array.isArray(schema.required) === true)
        && schema.required;
    var _keys = Object.keys(newProperties);
    for( var i = 0, len = _keys.length; i < len; i++ ) {
        var propertyName = _keys[i];
        props[propertyName] = newProperties[propertyName]; //add the property description
        if ( requiredProps !== false ) {
            requiredProps.push(propertyName); //add the property to the required property of the schema
        }
    }
    return schema;
}

var mainPatterns = {
    //locations hashes--
    patternPropertyLocationHash : "^[1-4][0-9]{12,14}$",
    optVS_emptyString : {
        "type" : "string",
        "maxLength": 0
    },
    optVS_age : {
        "type": "string",
        "minLength": 1,
        "maxLength": 2,
        "pattern"  : "^[1-9][0-9]*$"
    },
    optVS_email : {
        "type": "string",
        "format": "email"
    },
    optVS_phone : {
        "type": "string",
        "format": "^[0-9]{5,16}$"
    },
    optVS_gender : {
        "type" : "string",
        "enum" : ["Male", "Female"] 
    },
    optVS_uri : {
        "type"   : "string",
        "format" : "uri" 
    },
    optVS_videostreamhash : {
        "type"   : "string",
        "minLength": 8,
        "maxLength": 8
    },
    optVS_videostreamdescription : {
        "type"   : "string",
        "minLength": 8,
        "maxLength": 1000
    },
    optVS_locationHash : {
        "type": "integer",
        "minimum" : 1000001000010, //when lattitude = +0(larger than zero), longitude = +0
        "maximum" : 499999999999999, //when lattitude = -90, longitude = 180
    },
    optVS_locationHash_string : {
       "type": "string",
       "minLength" : 13,
       "maxLength" : 15,
       "pattern": "^[0-9]+$",
       "format" : "locationHash" 
    },
    //--locations hashes
    patternPropertyUserID : "^[1-9][0-9]{1,}$",
    optVS_milliseconds  : { //for get time difference beetween the server and a client
        "type" : "integer",
        "minimum" : 1432930986229, //29.05.2015
        "maximum" : 1580515200000 //01.12.2025
    },
    optVS_positive_integer : {
        "type"   : "integer",
        "minimum" : 0,
        "maximum" : 9999999
    },
    optVS_userID : {
        "type"   : "integer",
        "minimum" : 1,
        "maximum" : 9999999
    }, //for user ID fields
    optVS_timestamp : { //for timesamp fields
        "type" : "integer",
        "minimum" : 1432930986, //29.05.2015
        "maximum" : 1580515200 //01.12.2025
    },
    optVS_messageTimestamp : { //for a timestamps, when a message was formed
        "type": "integer",
        "minimum" : 1432930986, //29.05.2015
        "maximum" : 1580515200, //01.12.2025
    },
    optVS_latitude : {
        "type": "number",
        "minimum" : -90,
        "maximum" : 90
        //"multipleOf" : 0.000001 //the precision is a 6 digitts after a comma
    },
    optVS_longitude : {
        "type": "number",
        "minimum" : -180,
        "maximum" : 180
        //"multipleOf" : 0.000001 //the precision is a 6 digitts after a comma
    },
    optVS_textMessage : {
        "type": "string",
        "minLength": 1,
  		"maxLength": 500
    },
    optVS_textField : {
        "type": "string",
        "minLength": 1,
  		"maxLength": 50    
    },
    optVS_number : {
        "type": "string",
        "minLength": 1,
        "maxLength": 2,
        "pattern"  : "[1-9]"
    },
    optVS_stringCompressedUserDescription : {
        "type": "string",
        "minLength": 20,
  		"maxLength": 50000    
    },
    optVS_locationMethod : {
        "type": "string",
        "enum" : ["Manual", "Automatic"]    
    }
};

var globalPatterns = {
    optVS_userID_orEmpty : {
        anyOf: [
            mainPatterns.optVS_userID,
            { "enum" : [empty_user_id] } //an empty id of the user
       ]
    },
    optVS_userLocation_withoutLocationHash : { //current user's location
        "type": "object",
        "additionalProperties" : false,
        "required" : ["lat","lng", "description"],
        "properties": {
            "lat": mainPatterns.optVS_latitude, //location latitude
            "lng": mainPatterns.optVS_longitude,  //location longitude
            "description" : mainPatterns.optVS_stringCompressedUserDescription
        }
    },
    optVS_listWithLocations : { //array with locations
        "type" : "array",
        items  : mainPatterns.optVS_locationHash_string
    },
    offerSDP : {
        type : "string",
        minLength: 100,
        maxLength : 7000
    }
};

//extend the base schemas
globalPatterns.optVS_userLocation = extendSchemaProperties(globalPatterns.optVS_userLocation_withoutLocationHash, {locationHash: mainPatterns.optVS_locationHash_string}); //extend user coordinates with the lcoation hash
globalPatterns.optVS_userCoordinatesWithCoordTimestamp  = extendSchemaProperties(globalPatterns.optVS_userLocation_withoutLocationHash, {coordsTimestamp : mainPatterns.optVS_timestamp}); //when the coordinates has been formed by a client

globalPatterns.__proto__ = mainPatterns;
globalPatterns.__proto__.extendSchemaProperties = extendSchemaProperties;

module.exports = globalPatterns;
},{"commonlib":undefined,"globalSettings":undefined}]},{},[]);
