require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"timestamps":[function(require,module,exports){
        var settings = {
            timeUTCMillisecondsDifference : 0, //diffrernce between UTC time on the central server and the clisent
            delimetrCurrentTimestamp : 1000,
            lowerBoundValidTimestampSeconds : 60
        }
		
        //return timetamp by Date.now() in seconds
        //noinspection NestedFunctionJS
        /**
         * Description
         * @method getCurrentTimestamp
         * @return CallExpression
         */
        function getCurrentTimestamp() {
            return Math.ceil((Date.now() + settings.timeUTCMillisecondsDifference) / settings.delimetrCurrentTimestamp);
        }
        
        /**
         * Description
         * @method addSecondsToTimestamp
         * @param {} timestamp
         * @param {} seconds
         * @return 
         */
        function addSecondsToTimestamp(timestamp,seconds) {
            if ( settings.delimetrCurrentTimestamp === 1000 ) {
                return timestamp + seconds;    
            } else {
                return timestamp + ( seconds * 1000 / settings.delimetrCurrentTimestamp)
            }
        }
        
        //return timetamp by Date.now() in seconds
        //noinspection NestedFunctionJS
        /**
         * Description
         * @method setClientServerUTCTimeDifference
         * @param {} difference
         * @return 
         */
        function setClientServerUTCTimeDifference(difference) {
            settings.timeUTCMillisecondsDifference = difference;
        }
        
        //check whether is the timestamp valid
        //return true or false
        /**
         * Description
         * @method isValidTimestamp
         * @param {} timestamp
         * @return BinaryExpression
         */
        function isValidTimestamp(timestamp) {
            return Math.abs(getCurrentTimestamp() - timestamp) > settings.lowerBoundValidTimestampSeconds;
        }
        
        module.exports = {
        	 getCurrentTimestamp : getCurrentTimestamp,
        	 setClientServerUTCTimeDifference : setClientServerUTCTimeDifference,
        	 isValidTimestamp	 : isValidTimestamp,
        	 addSecondsToTimestamp : addSecondsToTimestamp
        }
        
        
},{}]},{},[]);
