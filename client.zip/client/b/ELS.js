require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"ExternalLocalServer":[function(require,module,exports){
var     EventEmitter = require("eventemitter");
        var timestamps = require("timestamps");
        var timeIntervals = require("timeIntervals");
        var validators = require("validatorsELS").validatorsELS;
        var commonlib = require("commonlib");
        var globalSettings = require("globalSettings");
        var libMainP2P = require("libMainP2P");
        
        var logger = require("logger").logger;
        logger.namespace = "ELS";

        //main variables--
        var getCurrentTimestamp = timestamps.getCurrentTimestamp;
        var isValidTimestamp = timestamps.isValidTimestamp;
        var isDataConnection = libMainP2P.isDataConnection;
        var returnMainP2P = libMainP2P.returnMainP2P;
        var setDataConnectionMetadataTimestamp = libMainP2P.setDataConnectionMetadataTimestamp;
        var isPeer = libMainP2P.isPeer;
        var isSocket = libMainP2P.isSocket;
        var isILS = libMainP2P.isILS;
        var isELS = libMainP2P.isELS;
        var getConnectionTimestamp = libMainP2P.getConnectionTimestamp;
        var empty_user_id = globalSettings.empty_user_id; //the value, that is representation of an empty id of the user
        var isEmptyLSID = commonlib.isEmptyLSID;
        var strToInt = commonlib.strToInt;
        var isArray = commonlib.isArray;
        var isDataConnectionClosed = libMainP2P.isDataConnectionClosed; //if not connection otr if the given connection has closed return true
        //--main variables

        //names of the metods, that must be debugged
        var listDebuggedMethodsNames = [""]; // ["close", "onIncomingMessage", "sendMessage", "reconnect", "onMessageFromCS", "onLSNewID", "removeELSLocation"];
        
        /*
            emitted events:
            1) offerSDP ( userID, offer )  - on incoming offer to establish RTCDataConnection with another user
            2) answeSDP ( userID, answer ) - on incoming answer to the outgoing offer
        */
        
        /**
         * @constructor
         * return false is an error has occurred
         * @class ExternalLocalServer
         * @classdesc Create a connection to an external local server
         * @property g_MainP2P - MainP2P instance
         * @property status - 0 - not connected, 1 - connecting, 2 - connected
         * @property timestamp - timestamp of the last data received from the local server
         * @property connection - DataConnection with ans els peer
         * @property flTrustedLS - false if the id of the local server is not confirmed by the cs
         * @method ExternalLocalServer
         * @param {} mainConnection
         * @param {} locationHash
         * @param {} mode
         * @param {} elsID
         * @param {} ilsInstance
         * @param {} flTrustedLS
         * @return 
         */
        function ExternalLocalServer(mainConnection, locationHash, mode, elsID, ilsInstance, flTrustedLS) {
            if (isPeer(mainConnection) === true) { //MainP2P is empty
                logger("externalLocalServer. MainP2P argument value is not an instance of MainP2P");
                return false;
            }
            
            this.empty_user_id = empty_user_id;
            this.uniqueID = this.getUniqueID(); //get the unique id for identifying to which of an ils instances a message from the cs is intended
            this.g_MainP2P = mainConnection; //reference to an instance of MainP2P
            this.ID = mainConnection.getUserID(); //the user ID
            this.status = 0; //status - not connected
            this.timestamp = 0; //means the timestamp when the els has done some work, for example it was received a data or has established the new main connection to the ls. It's need to determine that the connection to the current local server is outdated, and it is need to reconnect
            this.mode = mode || 1; //working mode - maintaince of the ils or the user            
            this.flConnectedForTheFirstTime = false; //flag defines has this els instance been connected to the local server for the first time
            
            this.messagesQueue = []; //messages that are have not been sent, because of a closed connection to the els
            this.connection = null;
            this.locationDescription = {}; //the current location description in format : { userID : { lat, lng, coordsTimestamp } }
            this.setDefaultTimestamps(); //set a dafault values of the timestamps

            if (globalSettings.debug === true) { //if debugging mode is on

                //set the proxies to watch for a changes to the significant properties

                //define proxy for elsPeerID
                Object.defineProperty(this, "elsPeerID", {
                    /**
                     * Description
                     * @method set
                     * @param {} newID
                     * @return 
                     */
                    set: function(newID) {
                        if (this.isEmptyIDLS() !== true 
                            && this.isEmptyIDLS(newID) == true) {
                                logger("!!!Set empty local server ID");
                        } else {
                            logger("!!!Set new ls ID = " + newID);
                        }
                        this.lsID = newID;
                    },
                    /**
                     * Description
                     * @method get
                     * @return MemberExpression
                     */
                    get: function() {
                        return this.lsID;
                    }
                });
                this.lsID = this.empty_user_id;

                //define proxy for connection to the ls
                Object.defineProperty(this, "connection", {
                    /**
                     * Description
                     * @method set
                     * @param {} newConnectionToLS
                     * @return 
                     */
                    set: function(newConnectionToLS) {
                        if (this.connectionToLS != null 
                            && newConnectionToLS == null) {
                                logger("!!!Set empty connection to ls");
                        } else {
                            logger("!!!Connection to the local server has been changed");
                        }
                        this.connectionToLS = newConnectionToLS;
                    },
                    /**
                     * Description
                     * @method get
                     * @return MemberExpression
                     */
                    get: function() {
                        return this.connectionToLS;
                    }
                });
                this.connectionToLS = null;

            } else {
                this.elsPeerID = this.empty_user_id; //id of the local server, to which els is connected. This local server doing the maintaince of the location, where the user is located
            }
            if (this.mode === 2) { //this mode is for handling a connection to the local server that is maintains the nearest location to one of the maintained locations by the ils
                
                if ( locationHash === null //the locations, that are maintained by the local server, to which the els instance is connected
                     || isILS(ilsInstance) === false ) {
                        return false;
                }
                
                this.trustedLS = flTrustedLS === false ? false : true; //means that this local server is trusted and we can messaging with it                
                this.locationHash = []; //list of handled locations
                this.addELSLocations(locationHash); //add location, that is handeled by the local server, to which the els is connected
                this.setILS(ilsInstance); //reference to InnerLocalServer instance
            } else { //mode for maintenance only the user location and getting information about the users, that are located around, from the local server, that handles the user location for now

                this.getUserCurrentLocationCallbacks = []; //callbacks queue with the functions to execute after when the current coordinates of the user will be received

                if (globalSettings.debug === true) {
                    //define proxy for connection to the ls
                    Object.defineProperty(this, "locationHash", {
                        /**
                         * Description
                         * @method set
                         * @param {} newLocationHash
                         * @return 
                         */
                        set: function(newLocationHash) {
                            if (typeof(newLocationHash) === "number") {
                                this.__locationHash = commonlib.numToStr(newLocationHash);
                            } else {
                                this.__locationHash = newLocationHash || null;
                            }
                            self.___currentLocationHash = newLocationHash; //set global variable (throw self) for debugging 
                        },
                        /**
                         * Description
                         * @method get
                         * @return MemberExpression
                         */
                        get: function() {
                            return this.__locationHash;
                        }
                    });
                    this.__locationHash = null;
                } else {

                    if (typeof(locationHash) === "number") {
                        this.locationHash = commonlib.numToStr(locationHash);
                    } else {
                        this.locationHash = locationHash || null;
                    }

                }
            }

            //set the functions, that are always will be executed under context equals to this els
            this.reconnect = this.reconnect.bind(this);
            this.requestLocationDescription = this.requestLocationDescription.bind(this);
            this.sendMessage = this.sendMessage.bind(this);
            this.onMessageFromCS = this.onMessageFromCS.bind(this);
            this.getUserCurrentLocation_onUserLocationDesc = this.getUserCurrentLocation_onUserLocationDesc.bind(this);
            this.getELSPeerID_onLocationDesc = this.getELSPeerID_onLocationDesc.bind(this);
            this.chooseAnotherLocalServer_onLocationDesc = this.chooseAnotherLocalServer_onLocationDesc.bind(this);
            this.getELSPeerID = this.getELSPeerID.bind(this);
            this.checkConnection = this.checkConnection.bind(this);
            this.connect = this.connect.bind(this);
            this.dropLocationDescription = this.dropLocationDescription.bind(this);
            this.getUserDescription_onUserDesc = this.getUserDescription_onUserDesc.bind(this);
            
            //event listeners for the main connection
            //this.g_MainP2P.on("connectedAgain", this.getELSPeerID); //when connection to the cs was opened again
            
            if ( this.debugThis() === true ) {
                debugger;
            }
            
            //start the periodic procedures
            if (commonlib.hasProperty(this, "intGetLocationDescription") === false) { //procedure for sending information about the user's location or getting information from the external local server for inner local server
                this.intGetLocationDescription = setInterval(this.requestLocationDescription, timeIntervals.timeIntervalExternalLocalServerGetLocationDescription);
            }
            if (commonlib.hasProperty(this, "intCheckConnection") === false) { //check connection to els peer
                this.intCheckConnection = setInterval(this.checkConnection, timeIntervals.timeIntervalExternalLocalServerCheckConnection);
            }

            //set the listeners for a messages that comes from the cs
            var postfixForMessagesEvents = "(" + this.uniqueID + ")"; //the id of this instance will being used as the postfix for the messages from the central server in this case
            mainConnection.on("messageFromCS" + postfixForMessagesEvents + "_CSToELS", this.onMessageFromCS);
            mainConnection.on("messageFromCS" + postfixForMessagesEvents + "_CSToILS", this.onMessageFromCS);
            mainConnection.on("connectedAgain",  this.checkConnection); //on connection to the cs will be established after disconnection, then check the connection to the ELS
            
            if (isDataConnection(elsID) === true) { //this is open data connection with the local server
                this.setDataConnection(elsID);
            } else {
                if (typeof(elsID) === "string") {
                    elsID = strToInt(elsID); //convert id to integer
                }
                if (this.isEmptyIDLS(elsID) === false) { //the ID of the local server is not empty
                    this.elsPeerID = strToInt(elsID);
                    this.connect(); //try to establish the new connection with the local server that has the ID equals to the given
                } else { //if there is no elsID, try to get it
                    this.checkConnection(); //try to connect with the local server after the one second after new Instance was created
                }
            }
        }
        
        /** 
         * connection to the local server peer has been opened
         * @event externalLocalServerOpened 
         */
         
        /** 
         * connection to the local server peer has been closed
         * @event externalLocalServerClosed 
        */
         
        /** 
         * connection to the local server peer has been closed purposely
         * @event externalLocalServerClosedForcibly 
        */
        
        /** 
         * connection to the local server peer has been closed purposely
         * @event locationDescription
         * @property locationDescription
         */
         
        /** 
         * arbitary message for the ils instance, that created this connection(els) to the ls
         * @event incomingMessageForILS 
         */
         
        /** 
         * arbitary message for the ils instance, that created this connection(els) to the ls
         * @event newLocalServer
         * @property newLocalServerID
         */
         
        /** 
         * this instance has closed
         * @event externalLocalServerInstanceClosed 
         */
        
        /** 
         * the current location hash has changed. new location hash and new id of the ls
         * @event locationChange
         * @property newLocationHash
         * @property newLSID
         */
         
        var ELSProto = Object.create(new EventEmitter());
        ELSProto.constructor = ExternalLocalServer;
        
        /*
            list with names of the debuggable methods
        */
        ELSProto.listDebuggedMethotsNames = listDebuggedMethodsNames;
        
        /*
            list with the debuggable methods of this ELS instance
        */
        ELSProto.listDebuggedMethots = [];
        
        /**
         * fill in the listDebuggedMethots by the methods of this ELS instance  with the namse, defined into the list listDebuggedMethotsNames
         * @method fillInListDebuggedMethots
         * @return 
         */
        ELSProto.fillInListDebuggedMethots = function() {
            var els = this;
            var methodNames = els.listDebuggedMethotsNames;
            var methods = els.listDebuggedMethots;
            for( var i in methodNames ) {
                var methodame = methodNames[i];
                if ( typeof(els[methodame]) === "function" ) { //if the method with the name is defined
                    methods[methods.length] = els[methodame]; //add it into the list with the debugged methods
                }
            }   
        };
        
        /**
         * return true if it is necessary to stop on the breakpoint
         * @method debugThis
         * @return LogicalExpression
         */
        ELSProto.debugThis = function() {
            var els = this;
            var listMethodNames = els.listDebuggedMethotsNames;
            if ( listMethodNames.length > 0
                && listMethodNames.length === 0 ) {
                    els.fillInListDebuggedMethots();    
            }
            var caller = arguments.callee.caller;
            var debuggedMethods = els.listDebuggedMethots;
            return ( (debuggedMethods.length !== 0 && debuggedMethods.indexOf(caller) !== -1) //if the methods are defined
                        || listMethodNames.length === 0 ) //or are not defined
                    && els.isAnotherILSLStoLSMode();
        };
        
        /**
         * check if it is connection to another local server in the mode ls to ls
         * @method isAnotherILSLStoLSMode
         * @param {} dataConnection
         * @return LogicalExpression
         */
        ELSProto.isAnotherILSLStoLSMode = function(dataConnection) {
            var lsID; 
            if ( isDataConnection(dataConnection) === true ) { 
                lsID = dataConnection.peer;
            } else 
                if ( typeof(dataConnection) === "number" ) { 
                    lsID = dataConnection;
                } 
            else { 
                    lsID = this.elsPeerID;
                }
                
            return this.mode === 2
                && lsID !== this.empty_user_id
                && lsID != null && lsID != this.ID;
        };
        
        /**
         * set the reference to the ils instance
         * @method setILS
         * @param {} ils
         * @return 
         */
        ELSProto.setILS = function(ils) {
            var els = this;
            if (els.mode === 2 && isILS(ils) === true) {
                els.ilsInstance = ils;
            }
        };
        
        //check if the connection to the ILS is the local
        /**
         * Description
         * @method checkIfLocalILS
         * @return LogicalExpression
         */
        ELSProto.checkIfLocalILS = function() {
            var els = this;
            return els.mode === 2
                && els.lsID === els.ID;
        };
        
        //set the listeners for the ils instance if the working mode === 2
        /**
         * Description
         * @method setILSListeners
         * @return 
         */
        ELSProto.setILSListeners = function() {
            var els = this;
            var ils = els.getILS();
            els.removeILSListeners();
            
            ils.on("ilsCloseLocation", ELSProto.onILSStopLocationHandling);
        };
        
        //remove the listeners from the ils instance
        /**
         * Description
         * @method removeILSListeners
         * @return 
         */
        ELSProto.removeILSListeners = function() {
            var els = this;
            var ils = els.getILS();
            
            ils.removeListener("ilsCloseLocation", ELSProto.onILSStopLocationHandling);            
        };
        
        /**
         * Description
         * @method onILSStopLocationHandling
         * @param {} locationHash
         * @return 
         */
        ELSProto.onILSStopLocationHandling = function(locationHash) {
            var els = this;
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            if ( els.checkIfLocalILS() === true
                && els.isLocationHandled(locationHash) === true ) {
                    if (els.removeELSLocation(locationHash) === true) { //remove the location from the list of the maintained locations
                        return; //if it is the last location, that is handled by the els. Els will be closed
                    } else { //reset the local server id for the location
                        els.emit("newLocalServer", { [locationHash] : empty_user_id });            
                    }
            }
        };
        
        //get the unique id for identifying a various els instances
        ELSProto.currentUniqueID = 0;
        /**
         * Description
         * @method getUniqueID
         * @return UpdateExpression
         */
        ELSProto.getUniqueID = function() {
            return ++this.__proto__.currentUniqueID;
        };

        /**
         * set the data connection as the main connection
         * retrun true if set or false if can't
         * @method setDataConnection
         * @param {} dataConnection
         * @return Literal
         */
        ELSProto.setDataConnection = function(dataConnection) {
            
            var els = this;
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            var currentELSConnection = els.connection;
            if ( currentELSConnection === dataConnection ) { //if the current connection and the given are equals
                return true;
            }
            
            var flCurrentConnectionExists = isDataConnectionClosed(currentELSConnection) !== true; //if the current data connection is exists and has not closed
            if ( ( els.getLastSucessfullConnectionTimestamp() === null || flCurrentConnectionExists === true ) //if the current data connection is exists or has been sucesfully connected to the ls
                 && dataConnection.open === true ) { //if the incoming data connection is open
                    if ( flCurrentConnectionExists === true ) { //if the current data connection is open
                    
                        var currentConnectionTimestamp  = getConnectionTimestamp(currentELSConnection); //the current els connection
                        var incomingConnectionTimestamp = getConnectionTimestamp(dataConnection); //incoming connection from the LS
                        if ( currentConnectionTimestamp < incomingConnectionTimestamp //check the timestamp of the incoming data connection
                            || ( currentConnectionTimestamp === incomingConnectionTimestamp //if the timestamps equals
                                 && strToInt(els.ID) > strToInt(dataConnection.peer) ) //check if the current ID is larger then the ID of the LS 
                        ) {
                            dataConnection.close();
                            return false;
                        }
                    }
                
                    //set the incoming connection as the main connection
                    els.resetLastSucessfullConnectionTimestamp();
                    els.connection = dataConnection; //set the data connection for the els
                    els.elsPeerID = dataConnection.peer; //set the ID of the local server to which the els is connected
                    els.closeDataConnection(currentELSConnection); //close the current data connection to set the new as the default data connection
                    els.setPropertiesAndListenersForNewConnectionToLS(dataConnection); //set the main properties and listeners for the existing data connection to the local server
                    els.onDataConnectionOpened(dataConnection);
                    return true;
            }
            
            return false;
        };
        

        /**
         * set a dafault values of the timestamps for the els instance
         * @method setDefaultTimestamps
         * @return 
         */
        ELSProto.setDefaultTimestamps = function() {
            var els = this;
            els.timestamps = {
                lastTimestampLocationDescription : 0, //the timestamp of the current location description
                lastLocationChange : 0, //when the last changing of the location has been.
                lastReceivedLSID : 0, //when the local server has became the local server for the location
                lastELSPeerIDRequest : 0, //the last request to the cs for getting the local server's ID
                lastChooseAnotherLocalServerRequest : 0, //the last request for changing the local server
                lastConnectionToLS : 0, //attempt of connecting to the local server
                lastCalculationLocationHash : 0, //When the cs has calculated the location hash
                currentLSIDNotOverdue : 0, //timestamp, when a new user has been placed on the location where the user is located
                lastRequestUserCoordinates : 0, //when the last request of the user's coordinates has been
                lastRequestUserDescription : 0, //when the last request of the user's coordinates has been
                lastReconnection : 0, //when the last reconnection has been    
                lastSuccessfullConnection : 0 //when the last succesfull connection to the ls has been
            };
        };


        /**
         * update the els and the main connection timestamp
         * @method updateTimestamp
         * @return 
         */
        ELSProto.updateTimestamp = function() {
            var els = this;
            els.timestamp = getCurrentTimestamp(); //set the timestamp of the els(means the timestamp when the els has done some work, for example it received the data or establish the connection)
            if (isDataConnection(els.connection) === true) { //if the connection is exists
                setDataConnectionMetadataTimestamp(els.connection);
            }
        };


        /**
         * set the properties of the new data connection to the local server
         * @method setPropertiesAndListenersForNewConnectionToLS
         * @param {} connectionToLS
         * @param {} flDoNotCheckForOpen - if true, then do not call onDataConnectionOpened
         * @return 
         */
        ELSProto.setPropertiesAndListenersForNewConnectionToLS = function(connectionToLS, flDoNotCheckForOpen) {
            var els = this;
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            if (isDataConnection(connectionToLS) === false) {
                return;
            }

            //set the necessary properties
            els.setPropertiesForNewConnectionToLS(connectionToLS);
            els.removeListenersConnectionToLS(connectionToLS);
            els.resetLastSucessfullConnectionTimestamp();
            
            if ( flDoNotCheckForOpen !== true ) { //if flag to do not check is set to true
                if (connectionToLS.open === true) { //if the connection already was opened
                    els.onDataConnectionOpened.apply(connectionToLS);
                } else { //connection still was not opened
                    connectionToLS.once("open", els.onDataConnectionOpened);
                }
            }
            
            connectionToLS.once("close", els.onConnectionClosed);
            connectionToLS.on("error", els.onConnectionError);
            connectionToLS.on("data", els.onIncomingMessage);

        };

        /**
         * Description
         * @method removeListenersConnectionToLS
         * @param {} connectionToLS
         * @return 
         */
        ELSProto.removeListenersConnectionToLS = function(connectionToLS) {
            var els = this;
            if (isDataConnection(connectionToLS) === true) {
                connectionToLS.removeListener("open", els.onDataConnectionOpened);
                connectionToLS.removeListener("close", els.onConnectionClosed);
                connectionToLS.removeListener("error", els.onConnectionError);
                connectionToLS.removeListener("data", els.onIncomingMessage);
            }
        };


        /**
         * set the necessary properties for a new data connections
         * @method setPropertiesForNewConnectionToLS
         * @param {} dataConnection
         * @return 
         */
        ELSProto.setPropertiesForNewConnectionToLS = function(dataConnection) {
            var els = this;
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            if (dataConnection != null) {
                dataConnection.g_els = els; //reference to the els instance
                dataConnection.g_flClosedManually = false;
                els.resetLastSucessfullConnectionTimestamp();
            }
        };


        /**
         * if the location is into the list of the els locations, that are maintained by the ls, represented by the els
         * return false or position into the list
         * @method isELSLocationIntoList
         * @param {} elsHandledLocation
         * @return LogicalExpression
         */
        ELSProto.isELSLocationIntoList = function(elsHandledLocation) {
            var els = this;
            var res = false;
            if (els.mode === 2) {
                var elsLocations = els.getELSLocations();
                if (elsLocations !== false) { //the list of the maintained locations is not empty
                    res = elsLocations.indexOf(elsHandledLocation); //try to find the given location intho list of maintained locations
                }
            }
            return res !== -1 
                    && res;
        };
        
        /**
         * return the number of the els locations
         * @method getNumELSLocations
         * @return Literal
         */
        ELSProto.getNumELSLocations = function(){
           var els = this;
           if (els.mode === 2) {
                var elsLocations = els.getELSLocations();
                if (elsLocations !== false) { //the list of the maintained locations is not empty
                    return elsLocations.length; //return the length  of the list
                }
            }
            return 0;
        };

        //check is the location handled by the els
        /**
         * Description
         * @method isLocationHandled
         * @param {} locationHash
         * @return LogicalExpression
         */
        ELSProto.isLocationHandled = function(locationHash) {
            var els = this;
            return commonlib.isArray(els.locationHash) === true
                && els.locationHash(locationHash) !== -1;
        };
        
        /**
         * add location of the ils, that is nearest to the els location
         * @method addELSLocations
         * @param {} elsHandledLocations
         * @param {} flRequestTheValidIdFromCS
         * @return 
         */
        ELSProto.addELSLocations = function(elsHandledLocations, flRequestTheValidIdFromCS) {
            var els = this;
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            if (els.mode !== 2) { //not ils mode
                return false;
            }
            if (Array.isArray(elsHandledLocations) === false) {
                elsHandledLocations = [elsHandledLocations]; //only the one location
            }
            for (var i = 0, len = elsHandledLocations.length; i < len; i++) { //for each of the given locations
                var locationHash = commonlib.numToStr(elsHandledLocations[i]); //new location for handling
                if (typeof(locationHash) === "string" && locationHash !== "" && els.isELSLocationIntoList(locationHash) === false) { //this location already is into the list
                    els.locationHash.push(commonlib.numToStr(locationHash)); //put into the list
                }
            }
            
            if ( flRequestTheValidIdFromCS === true ) { //if necessary to request the valid id for this locations from the cs
                els.sendMessageToCS(
                    els.messageELSToCS_GetELSPeerID(
                        {   
                            maintainedLocations: els.getILS().getILSLocationsNearestToTheLocation(elsHandledLocations), //get all the maintained locations
                            nearestLocations: elsHandledLocations //the given locations
                        }
                ));    
            }
            
        };


        /**
         * remove location of the els
         * return true if the list of the locations become an empty
         * @method removeELSLocation
         * @param {} elsHandledLocation
         * @return Literal
         */
        ELSProto.removeELSLocation = function(elsHandledLocation) {
            var els = this;
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            var elsLocations = els.getELSLocations();
            if (elsLocations !== false) {
                var pos = els.isELSLocationIntoList(elsHandledLocation);
                if (pos !== false) { //if found
                    elsLocations.splice(pos, 1); //remove from the list
                }
                if (elsLocations.length === 0) { //if there is no locations, maintained by the ils, then close it
                    els.close(1); //the reason of closing this instance - is because there is no locations for the maintaince by the els connection
                    return true;
                }
            }
            return false;
        };


        /**
         * return all the nearest locations, that are handled by the els
         * @method getELSLocations
         * @return 
         */
        ELSProto.getELSLocations = function() {
            var els = this;
            if (els.mode === 2) {
                return Array.isArray(els.locationHash) === true && els.locationHash.length > 0 && els.locationHash;
            } else {
                return els.locationHash;
            }
        };


        /**
         * return an InnerLocalServer instance by the ExternalLocalServer instance
         * or false, if there is no reference to ils instance
         * @method getILS
         * @return LogicalExpression
         */
        ELSProto.getILS = function() {
            var els = this;
            return els.mode === 2 //els working mode is the support for an ils instance
                    && isILS(els.ilsInstance) === true && els.ilsInstance;
        };

        /**
         * check if this local server is truted
         * @method isTrusted
         * @return LogicalExpression
         */
        ELSProto.isTrusted = function() {
            var els = this;
            return  els.mode === 1 //if mode peer to ls
                    || (els.mode === 2 //for mode ls to ls
                        && els.trustedLS === true);
        };
        
        /**
         * set the flag that connected to the untrusted ls
         * @method setUntrusted
         * @return 
         */
        ELSProto.setUntrusted = function(){
            var els = this;
            if ( els.mode === 2 ) {
                els.trustedLS = false;    
            }
        };
        
        /**
         * set the flag that connected to the trusted ls
         * @method setTrusted
         * @return 
         */
        ELSProto.setTrusted = function(){
            var els = this;
            if ( els.mode === 2 ) {
                els.trustedLS = true;    
            }
        };
        
        /**
         * is a connection to the local server peer open
         * @method isConnected
         * @return LogicalExpression
         */
        ELSProto.isConnected = function() {
            var els = this;
            var elsConnection = els.connection;
            return els.g_flClosedManually !== true && els.elsPeerID != null //server id is not null
                && elsConnection != null && elsConnection.open === true //DataConnection is opened
                && els.elsPeerID === elsConnection.peer; //the local server id has changed
        };


        /**
         * is a connection to the local server peer was closed
         * @method isClosed
         * @return LogicalExpression
         */
        ELSProto.isClosed = function() {
            var els = this;
            return els.g_flClosedManually === true 
                    || els.g_MainP2P == null;
        };


        /**
         * close the previous data connection ocal serverand establish a new one
         * @method reconnect
         * @return 
         */
        ELSProto.reconnect = function() {
            var els = this;
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            var currentTimestamp = getCurrentTimestamp();
            
            if ( (currentTimestamp - els.timestamps.lastReconnection) < timeIntervals.timeIntervalExternalLocalServerBetweenReconnections ) {
                logger("Too hurry to reconnect");
            } else {
                els.timestamps.lastReconnection = currentTimestamp;
                els.resetLastSucessfullConnectionTimestamp();
                logger.namespace = "ELS (" + this.mode + "|" + this.uniqueID + ")";
                logger("!!!Reconnecting to the ls");
                logger.namespace = "ELS";
                els.status = 0;
                els.closeDataConnection(els.connection); //close the current connection to the current local server
                //change properties of the els
                els.resetLastConnectionTimestamp();
                els.connect(); //connect to another ls
            }
        };


        /**
         * send a message to the central server
         * @method sendMessageToCS
         * @param {} message
         * @return 
         */
        ELSProto.sendMessageToCS = function(message) {
            var els = this;
            if (els.checkIfLocalILS() !== true //for the local connection we can not send a messages
                && commonlib.isEmptyObject(message) === false 
                && typeof(message.kind) === "string") {
                var mainConnection = returnMainP2P(els); //get the instance of a Peer.js
                if (mainConnection != false) {
                    if (els.mode === 2) { //add the header, that is differ for various working modes
                        message.type = "fromILS";
                    } else {
                        message.type = "fromELS";
                    }
                    message.uniqueID = els.uniqueID; //put the unique id of this instance
                    logger("Message to the cs by the ELS in the mode = " + els.mode + " with the kind = " + message.kind);
                    logger("List of the locations, that are handled by the els:", els.locationHash);
                    mainConnection.sendMessageToCS(message);
                }
            }
        };

        //array with the messages kinds, position into the array is the priority for the message with the kind. . Higher priority is better
        ELSProto.messagesFromCSPriority = ["locationChange", "newLocalServerID"];
        
        /**
         * listener for a messages from the cs
         * @method onMessageFromCS
         * @param {} kind
         * @param {} message
         * @return 
         */
        ELSProto.onMessageFromCS = function(kind, message) {
            var els = this;
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            logger("ELS(mode = " + els.mode + ")>onMessageFromCS. Incoming message from the cs with the kind = " + kind);
            
            //chek if the message is outdated
            switch (kind) {
                case "newLocalServerID": //new local server ID
                    els.onLSNewID(message);
                    break;
                case "locationChange": //user location chnged
                    els.onLocationChanged(message, false);
                    break;
            }
        };
        
        //reset the timestamp when the last sucessfull connection has been
        /**
         * Description
         * @method resetLastSucessfullConnectionTimestamp
         * @return 
         */
        ELSProto.resetLastSucessfullConnectionTimestamp = function() {
            this.timestamps.lastSuccessfullConnection = 0;        
        };
        
        /**
         * if the user location was changed or the local server id for the current user location was changed
         * @method onLocalServerOrLocationChange
         * @param {} newLSID
         * @param {} newLocationHash
         * @param {} messageTimestamp
         * @param {} fDoNotCheckTimestamp - do not check the timestamp of the current ls id
         * @return 
         */
        ELSProto.onLocalServerOrLocationChange = function(newLSID, newLocationHash, messageTimestamp, fDoNotCheckTimestamp) {
            var els = this;
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            if (els.mode !== 1) { //working mode is not the user to the local server
                return;
            }
            var flLSIDChange = false; //flag that the local server was changed
            var flLocationChange = false; //flag that the current user location was changed

            //check if the ls was changed
            if (els.isEmptyIDLS(newLSID) === true) {
                newLSID = empty_user_id;
            } else if (typeof(newLSID) === "string") {
                newLSID = commonlib.strToInt(newLSID);
            }
            if ( els.elsPeerID !== newLSID //local server id was changed
                && (fDoNotCheckTimestamp === true 
                    || els.timestamps.lastReceivedLSID < messageTimestamp) ) { //the incoming id is newer than the currently used
                        flLSIDChange = true;
                        els.status = 0;
                        els.emit("newLocalServer", newLSID);
                        els.elsPeerID = newLSID;
                        if ( fDoNotCheckTimestamp !== true ) { //do not set the new timestamp, it may be unvalid
                            els.timestamps.lastReceivedLSID = messageTimestamp; //when the local server has became the local server for the location
                        }
                        logger("!!!New ls id = " + newLSID);
            }

            //check if the location changed
            if (typeof(newLocationHash) === "number") {
                newLocationHash = commonlib.numToStr(newLocationHash);
            }
            if (typeof(newLocationHash) === "string"
                && newLocationHash !== "" 
                && (els.locationHash !== newLocationHash || els.locationHash === null) //user location was changed
                && (fDoNotCheckTimestamp === true 
                    || els.timestamps.lastCalculationLocationHash < messageTimestamp) //the incoming location hash is newer than the current
            ) {
                flLocationChange = true;
                els.emit("locationChange", newLocationHash, ( newLSID || els.elsPeerID ) );
                els.locationHash = newLocationHash; //change the current location
                els.timestamps.lastLocationChange = getCurrentTimestamp(); //when the last location changing was been
                if ( fDoNotCheckTimestamp !== true ) {
                    els.timestamps.lastCalculationLocationHash = messageTimestamp; //the last calculation of the location hash on the cs
                }
                logger("!!!New location hash = " + newLocationHash);
            }

            if (flLSIDChange === true) { //wait for a some time, before connect to the new local server
                commonlib.deleteFromArray(els, els.getELSPeerID_onLocationDesc); //not necessary to request the local server id, because of the new ls id has came
                els.attemptsToConnect = 0; //reset a number of attemptions to connectiong with the local server
                els.timestamps.currentLSIDNotOverdue = getCurrentTimestamp(); //when connected to the new ls update the timestamp when the last new user is on the location
                els.resetLastSucessfullConnectionTimestamp();
                els.reconnect(); //reconnect to the right local server
            } else 
                if (flLocationChange === true) { //wait for a some time, before get the description of the new location
                    setTimeout(els.requestLocationDescription, timeIntervals.timeoutBeforeConnectingToLocalServerWhenLocationOrServerIDChanged);
                }
            
            if ( flLocationChange === true
                || flLSIDChange === true) {
                    els.flDoNotConnect = false;
                    els.flShortPhaseOfConnectionToLS = false;
                    els.resetLastSucessfullConnectionTimestamp();
                    els.dropLocationDescription();
            }
            
        };


        /**
         * the user location has changed
         * flSkipTimeoutCheck - no need to delay before connecting to the ils
         * @method onLocationChanged
         * @param {} message
         * @param {} flMessageFromLS
         * @return 
         */
        ELSProto.onLocationChanged = function(message, flMessageFromLS) {
            var els = this;
            var validatorName = "validatorMessageBodyLocationChanged" + (flMessageFromLS === true ? "FromLS" : ""); //form the validator name depending on the sender of the message - cs or ils
            if ( els.mode === 1 
                 && validators[validatorName](message) !== false ) { //if the message is valid
                    if ( flMessageFromLS !== true //if from the cs, then check is the oldLSID is equals to the current
                        && els.isEmptyIDLS(els.peer) === false //if the current ls id is not empty
                        && els.lsID !== strToInt(message.oldLSID) )  { //and not equals
                            logger("LS ID from the message not equals to the id of the current ls. The id from the message is " + message.oldLSID + " and the current is " + els.lsID);
                            return false;  //if not equals      
                    }   
                    els.onLocalServerOrLocationChange(message.newLSID, message.newLocationHash, message.timestamp); //msgTimestamp - when the last calculation of the location hash
            } else {
                logger(new Error("Not valid message"));
                if ( validators[validatorName].errors != null
                    && validators[validatorName].errors.length > 0) {
                        logger(validators[validatorName].errors);
                }
            }
        };
         
        /**
         * return true if the given timestamp is newer than the timestamp when the new ls was received form the cs
         * @method checkTimestampLSID
         * @param {} timestamp
         * @return LogicalExpression
         */
        ELSProto.checkTimestampLSID = function( timestamp ){
            var els = this;    
            return ( els.isTrusted() !== true
                        || els.elsPeerID === empty_user_id ) //if the current ls id is not trusted or empty
                    || els.timestamps.lastReceivedLSID < timestamp //or timestamp of the last received is older
        };

        /**
         * new local server ID from the central server
         * message format
         * { locationHash,localServerID, timestamp }
         * locationHash - hash of the location where the user is located
         * timestamp - when the cs has formed message with the localServerID for the location
         * @method onLSNewID
         * @param {} message
         * @return 
         */
        ELSProto.onLSNewID = function(message) {
            var els = this;
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            //if the id of the local server, to which the els had been connected, while was sending the message to the cs, not equals to the current. This means that the server id already has been changed
            if ( ( els.isEmptyIDLS() === true //the current local server is absent
                    && (els.isEmptyIDLS(message.oldLocalServerID) === true ) ) //and the local server from the message is empty too
                 || (commonlib.strToInt(message.oldLocalServerID) === els.elsPeerID) //or equals to the previous local server
                ) {
                    if (els.mode === 2) { //may be a several locations, that are the nearest to the locations, that are maintained by the ils
                        if (validators.vSchemaIncomingMessageFromCSLocalServersIDForILSMode(message) === false) {
                            logger(validators.vSchemaIncomingMessageFromCSLocalServersIDForILSMode.errors);
                            return;
                        }
                        var listOfNewLS = {}; //list of the new local servers for the locations
                        var locationsHashes = Object.keys(message);
                        
                        var prevLSID, flSameLSID;
                        
                        
                        for (var i = 0, len = locationsHashes.length; i < len; i++) {
                            var locationHash = locationsHashes[i]; //location from the message
                            if (locationHash === "oldLocalServerID") { //if reserved keyword for the property (not location hash)
                                continue;
                            }
                            if (els.isELSLocationIntoList(locationHash) !== false) { //if the location is into the list of the els locations
                                var newLSID = message[locationHash];
                                if (els.isEmptyIDLS(newLSID) === true) {
                                    newLSID = els.empty_user_id;
                                } else {
                                    newLSID = commonlib.strToInt(newLSID);
                                }
                                
                                if ( prevLSID === undefined ) {
                                    prevLSID = newLSID;    
                                }
                                
                                if (els.elsPeerID != newLSID) { //local server for the location has changed
                                    
                                    if ( prevLSID !== newLSID //if the ls for this location is not equal to the local server for the previous location
                                        || newLSID === empty_user_id ) {
                                            flSameLSID = false;  //set the flag that the various local servers are maintained the locations  
                                    }
                                
                                    listOfNewLS[locationHash] = newLSID; //put into the result list
                                } else { //the cs confirmed the correctness of the
                                    els.setTrusted();    
                                }
                            }
                        }
                        
                        var flEmitEvent = false; //flag means that it is necessary to emit the event "newLocalServer" with the list of the new local servers
                        if ( flSameLSID !== false //if the one local server maintains all the locations of the ELS
                            && Object.keys(listOfNewLS).length === els.getNumELSLocations() ) { //check if all the ELS locations are handled by the another one local server for now
                                els.elsPeerID = newLSID; //set the new ls id
                                els.flDoNotConnect = false;
                                els.flShortPhaseOfConnectionToLS = false;
                                els.resetLastSucessfullConnectionTimestamp();
                                els.reconnect(); //reconnect to the new ls
                                
                                els.emit("newLocalServer", listOfNewLS); //emit the event with the list of the new local servers before closing the local server
                        } else { //if not all ELS locations are maintained by the new ls for now
                            els.emit("newLocalServer", listOfNewLS); //emit the event with the list of the new local servers before closing the local server
                            
                            if ( els.isClosed() !== true ) { //if not already closed by the ILS
                                var locationsWithNewLS = Object.keys(listOfNewLS); //get the list with the locations
                                for ( i = 0, len = locationsWithNewLS.length; i < len; i++ ) { //remove this location from the list of the ELS locations
                                    locationHash = locationsWithNewLS[i];
                                    if (els.removeELSLocation(locationHash) === true) { //remve the location from the list of the maintained locations
                                        return; //if it is the last location, that is handled by the els. Els will be closed
                                    }    
                                } 
                            }
                        }
                        
                    } else { //for the working mode peer to the local server may be the only obe locations where the user is located
                        if (validators.validatorIncomingMessageFromCSLocalServerID(message) === false) { //validator for the peer to ls working mode
                            logger(validators.validatorIncomingMessageFromCSLocalServerID.errors);
                            return;
                        }
                                                
                        if (commonlib.hasProperty(message, "timestamp") === true) { //message must contains timestamp when a location hash was calculated on the cs
                            els.onLocalServerOrLocationChange(message.localServerID, message.locationHash, message.timestamp); //connect to the new ls or get the description of the new user location
                        }
                    }
            }
        };



        /**
         * message from the peer to the central server
         * for mode = 1 userLocation : { lat, lng, locationHash, localServerID }
         * lat = lattitude coordinate
         * lng = longitude coordinate
         * mode = 2 userLocation : { maintainedLocations, locations }
         * @method messageELSToCS_GetELSPeerID
         * @param {} userLocation
         * @return msg
         */
        ELSProto.messageELSToCS_GetELSPeerID = function(userLocation) {
            var els = this;
            var msg = {
                kind: "getLSID"
            };
            if (els.mode === 2) {
                msg.body = { //required
                    locations: {
                        nearestLocations    : els.convertLocationsHashesForCS(userLocation.nearestLocations),
                        maintainedLocations : els.convertLocationsHashesForCS(userLocation.maintainedLocations)
                    }
                };
                if (els.isEmptyIDLS() === false) { //if id of the local server is exists, put it to the message
                    msg.body.lsID = els.elsPeerID; //not required if it is absent       
                }
            } else {
                msg.body = els.convertLocationsHashesForCS(userLocation);
                if (els.isEmptyIDLS() === false) { //add an id of the current ls if it is not empty
                    msg.body.localServerID = els.elsPeerID;
                }
            }
            return msg;
        };


        /**
         * add the given number of seconds to the values of els.timestamps.lastELSPeerIDRequest and els.timestamps.lastConnectionToLS and reset the value of els.attemptsToConnect
         * it allows to wait a few more time to send the request to the central server to get the local server ID
         * @method prolongAwaitingNewID
         * @param {} seconds
         * @return 
         */
        ELSProto.prolongAwaitingNewID = function(seconds) {
            var els = this;
            els.timestamps.lastELSPeerIDRequest = timestamps.addSecondsToTimestamp(getCurrentTimestamp(), seconds);
            els.timestamps.lastConnectionToLS = timestamps.addSecondsToTimestamp(getCurrentTimestamp(), seconds);
        };

        //on user description received
        /**
         * Description
         * @method getELSPeerID_onLocationDesc
         * @param {} locationDesc
         * @return 
         */
        ELSProto.getELSPeerID_onLocationDesc = function(locationDesc) {
            var els = this;
            if (locationDesc !== false) {
                //form the message for the cs
                els.sendMessageToCS(els.messageELSToCS_GetELSPeerID(locationDesc), true); //send the message with the request to the central server to get a ls ID for the user location
                els.timestamps.lastELSPeerIDRequest = getCurrentTimestamp(); //set the variable with a timestamp when a last request of the els ID
                els.prolongAwaitingNewID(timeIntervals.timeSecondsProlongAwaitingNewID); //reset the number of a attempts to connect to the ls
                
                if ( els.flDoNotConnect !== true ) { //if the flag is not set
                    els.flDoNotConnect = true;
                    var timeoutDoNotConnect = 
                            setTimeout(function() { //after 2 second els can try to connect once again
                                els.flDoNotConnect = false;
                                clearTimeout(timeoutDoNotConnect); //reset the timeout
                            }, 2000);
                }
                
            }
        };


        /**
         * get an els peer ID from the central server
         * @method getELSPeerID
         * @return 
         */
        ELSProto.getELSPeerID = function() {
            var els = this;
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            if ( ( (els.mode !== 2 && els.flConnectedForTheFirstTime === true) || els.mode === 2 ) //if has been connected to the local server(for the mode peer to ls) or the working mode equals to the ls to ls, then check for the timeout
                && typeof(els.timestamps.lastELSPeerIDRequest) === "number" //if the time has passed is less than timeout after the last request
                && ( getCurrentTimestamp() - els.timestamps.lastELSPeerIDRequest ) < timeIntervals.timeoutSecondsExternalLocalServerIDRequestTimeout ) {
                    return;
            } else { //if can to make the new request for the ls id
                els.timestamps.lastELSPeerIDRequest  = getCurrentTimestamp();   
                els.timestamps.currentLSIDNotOverdue = getCurrentTimestamp();
            }
            els.getUserCurrentLocation(els.getELSPeerID_onLocationDesc);
        };

        //message from the peer to the central server
        //for mode = 1: userLocation : { lat, lng, locationHash }
        //lat = lattitude coordinate
        //lng = longitude coordinate
        //mode = 2 userLocation : { locationHash }
        /**
         * Description
         * @method messageELSToCS_ChooseAnotherLS
         * @param {} userLocation
         * @return ObjectExpression
         */
        ELSProto.messageELSToCS_ChooseAnotherLS = function(userLocation) {
            var els = this;
            if (els.mode === 2) { //for ils mode the message must have another form
                var msgBody = {
                    locations   : els.convertLocationsHashesForCS(userLocation), //locations, that are handled by the els
                    lsID        : els.elsPeerID
                };
            } else {
                msgBody = els.convertLocationsHashesForCS(userLocation);
                msgBody.localServerID = els.elsPeerID; //add ID of the current ls
            }
            return {
                kind: "chooseAnotherLS",
                body: msgBody
            };
        };

        /**
         * Description
         * @method chooseAnotherLocalServer_onLocationDesc
         * @param {} locationDesc
         * @return 
         */
        ELSProto.chooseAnotherLocalServer_onLocationDesc = function(locationDesc) { //get the description of the user location
            var els = this;
            if (locationDesc !== false) {
                //form the message for the cs
                els.sendMessageToCS(els.messageELSToCS_ChooseAnotherLS(locationDesc), true); //send the message with the request of the ls ID for the user location		
                els.timestamps.lastChooseAnotherLocalServerRequest = getCurrentTimestamp();
                els.flShortPhaseOfConnectionToLS = true; //go to the short phase of ctrying to connect to the ls
                
                // setTimeout(function() {
                //     els.getELSPeerID(); //after some seconds request an id of the ls from the cs
                // }, timeIntervals.timeIntervalAfterChooseNewLSBeforeGetLSID);
                
                els.flDoNotConnect = true;
                var prevLSID = els.elsPeerID;
                var timeoutDoNotConnect = 
                        setTimeout(function() { //after 2 second els can try to connect once again
                            clearTimeout(timeoutDoNotConnect); //reset the timeout
                            if ( prevLSID === els.elsPeerID
                                && els.flDoNotConnect === true ) { //if still connected to the same ls
                                    els.flShortPhaseOfConnectionToLS = true; //go to the short phase of ctrying to connect to the ls
                                    els.attemptsToConnect = 1;
                                    els.status = 0;
                                    els.connect();
                            }
                            els.flDoNotConnect = false;
                        }, timeIntervals.timeIntervalAfterChooseNewLSBeforeTryToConnect);

            }
        };


        /**
         * need to choose an another local server peer
         * @method chooseAnotherLocalServer
         * @return 
         */
        ELSProto.chooseAnotherLocalServer = function() {
            var els = this;
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            if (typeof(els.elsPeerID) !== "number" //if the ID of a local server is empty
                || (els.timestamps.lastChooseAnotherLocalServerRequest //if the time has passed is less than timeout after the last request
                    && (getCurrentTimestamp() - els.timestamps.lastChooseAnotherLocalServerRequest) < timeIntervals.timeoutSecondsExternalLocalServerChooseAnotherLocalServerRequest)) {
                return;
            }

            //close the current connection and reset the number of the attemptions to connect to the current local server
            els.resetLastConnectionTimestamp();
            els.resetLastSucessfullConnectionTimestamp();
            els.getUserCurrentLocation(els.chooseAnotherLocalServer_onLocationDesc);
        };


        /**
         * set the timestamp of the last connection attempt with the ls to zero
         * @method resetLastConnectionTimestamp
         * @return 
         */
        ELSProto.resetLastConnectionTimestamp = function() {
            var els = this;
            els.timestamps.lastConnectionToLS = 0;
        };


        /**
         * check if local server have any locations for maintenance
         * @method haveMaintainedLocations
         * @return 
         */
        ELSProto.haveMaintainedLocations = function() {
            var els = this;
            var elsLocations = els.locationHash;
            if (els.mode === 1) { //for user mode the location hash can be got only by the request to the central or local server
                return true;
            } else {
                return elsLocations != null && elsLocations.constructor === Array && elsLocations.length !== 0;
            }
        };
        
        //check if the given LSID is empty or the current id of the ELS is empty if _LSID is undefined
        /**
         * Description
         * @method isEmptyIDLS
         * @param {} _LSID
         * @return CallExpression
         */
        ELSProto.isEmptyIDLS = function(_LSID){
            return isEmptyLSID(arguments.length > 0 ? arguments[0] : this.elsPeerID);
        };
        
        //reset the last sucesfull connection timestamp
        /**
         * Description
         * @method resetLastSucessfullConnectionTimestamp
         * @return 
         */
        ELSProto.resetLastSucessfullConnectionTimestamp = function() {
            this.timestamps.lastSuccessfullConnection = null;    
        };
        
        /**
         * return the timestamp of the last succesfull connection to the ls or null is not exists
         * @method getLastSucessfullConnectionTimestamp
         * @return 
         */
        ELSProto.getLastSucessfullConnectionTimestamp = function() {
            var els = this;
            if ( typeof(els.timestamps.lastSuccessfullConnection) === "number"
                && els.timestamps.lastSuccessfullConnection !== 0) {
                    return els.timestamps.lastSuccessfullConnection;
            } else { //if this timestamp is not defined
                return null;
            }    
        };
        
        /**
         * establish new connection to the external local server
         * return false if a connection was not opened
         * @method connect
         * @return 
         */
        ELSProto.connect = function() {
            
            var els = this;
            
            if ( els.flDoNotConnect === true ) { //this flag means do not trying to connect to the ls
                return;    
            }
            
            if ( els.checkIfLocalILS() === true ) { //not necessary to connect to the local ILS instance
                return true;
            }
            
            if ( els.isConnected() === true //already connected
                 || (els.mode !== 1 && els.haveMaintainedLocations() === false) //if the els is maintains the local server and there is no nearest locations for handling
                ) { //it is not necessaary to reconnect
                    return false;
            }
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            logger.namespace = "ELS (" + ( this.mode === 2 ? "E2LS" : "P2LS" ) + "|" + this.uniqueID + ")";
            logger("!!!Connecting to the ls");
            logger.namespace = "ELS";
            
            if ( els.attemptsToConnect == null ) { //attemptsToConnect property is absent
                var attemptsToConnect = els.attemptsToConnect = 0;
            } else {
                attemptsToConnect = els.attemptsToConnect;
            }
            
            var lastConnectionTimestamp = typeof(els.timestamps.lastConnectionToLS) === "number" ? els.timestamps.lastConnectionToLS : 0; //last connection tryout
            var lastSuccessfullConnectionTimestamp = els.getLastSucessfullConnectionTimestamp(); //the timestamp when the last succesfull connection to the cs has been
            
            var flEmptyID = els.isEmptyIDLS(); //empty id of the local server
            
            var attemptsToChooseNewLS = 2; //if the number of attempts is equals to this number, then trying to request the valid ls id from the cs
            
            if ( lastConnectionTimestamp !== 0 
                && (getCurrentTimestamp() - lastConnectionTimestamp) < timeIntervals.timeoutSecondsExternalLocalServerLastConnectionAttempt ) {
                    return false;
            } else 
                if ( flEmptyID === true //ID of the user, that is the local server for the els location
                     || els.isTrusted() !== true ) { //if the current id is not confirmed by the cs
                        if ( flEmptyID === true ) {
                            els.status = 0; //if id is unknown, then change status of the els to 'disconnected'
                        }
                        els.getELSPeerID(); //get the ID of the local server
                        return false;
            } else 
                if ( els.connection != null 
                     && els.connection.peer !== els.elsPeerID ) { //if the id of the local server, to which the els is connected, is not equals to the right ls id
                        els.reconnect();
            } else 
                if ( els.flShortPhaseOfConnectionToLS === true ) { //if in the short phase of connection attemt
                    attemptsToChooseNewLS = 1;    
                }
                
            if ( attemptsToConnect > attemptsToChooseNewLS //more than attemptsToGetLSID attempts to connect to the ls
                && ( 
                    els.flShortPhaseOfConnectionToLS === true  //if in the short phase of connection
                    || ( typeof(lastSuccessfullConnectionTimestamp) !== "number" //if the els have never been successful connections to the ils
                        || ( getCurrentTimestamp() - lastSuccessfullConnectionTimestamp ) > ( timeIntervals.timeoutLocationHandlingAfterClientDisconnectedFromCS + 20 ) ) 
                    )
            ) { //if too musch time was passed since the last successful connection to the local server
                els.chooseAnotherLocalServer(); //send a message to the main server, that the local server peer not respond and needed to choose another peer
            } else {
                els.openDataConnection(); //establish a new connection with an els peer    
            }
        };


        /**
         * convert all the locations hashes, that are included to the location description, returned by the getUserCurrentLocation function
         * @method convertLocationsHashesForCS
         * @param {} locationDesc
         * @return locationDesc
         */
        ELSProto.convertLocationsHashesForCS = function(locationDesc) {
            var els = this;
            if (els.mode === 1) {
                if (commonlib.hasProperty(locationDesc, "locationHash") === true) {
                    locationDesc.locationHash = commonlib.strToInt(locationDesc.locationHash);
                }
            } else {
                if (commonlib.hasProperty(locationDesc, "locations") === true) {
                    locationDesc.locations = commonlib.convertArrayStringValuesToIntegers(locationDesc.locations);
                }
                if (commonlib.hasProperty(locationDesc, "maintainedLocations") === true) {
                    locationDesc.maintainedLocations = commonlib.convertArrayStringValuesToIntegers(locationDesc.maintainedLocations);
                }
            }
            return locationDesc;
        };
        
        /**
         * Description
         * @method getUserDescription_onUserDesc
         * @param {} userDesc
         * @return 
         */
        ELSProto.getUserDescription_onUserDesc = function(userDesc) {
            var els = this;
            var mainP2P = returnMainP2P(els);
            var callbacks = els.getUserDescriptionCallbacks; //callbacks that are waiting current user coordinates
            var usrCoords = userDesc.coords; //coordinates
            if (commonlib.isArray(callbacks) === true) {
                if (usrCoords !== false //the description of the user location
                    && commonlib.hasProperty(usrCoords, "latitude") === true && commonlib.hasProperty(usrCoords, "longitude") === true) {

                        var coordinatesDesc = {
                            locationHash: els.locationHash || "0", //if the locationHash was not calculated before, then the current location hash = 0
                            lat: usrCoords.latitude, //user coordinates
                            lng: usrCoords.longitude,
                            coordsTimestamp: getCurrentTimestamp()
                        };
                        if (els.timestamps.lastCalculationLocationHash !== 0) { //add the timestap when the location hash was formed by cs
                            coordinatesDesc.timestamp = els.timestamps.lastCalculationLocationHash;
                        }
                        
                        coordinatesDesc.description = userDesc.desc; //insert the user description
                        
                        //execute each callback, that is waiting for coordinates
                        for (var i = 0, len = callbacks.length; i < len; i++) {
                            var _callback = callbacks[i];
                            if (typeof(_callback) === "function") {
                                _callback(coordinatesDesc);
                            }
                        }
                        els.getUserDescriptionCallbacks = [];
                }
            } else { //if wrong coordinates, then request it once again
                mainP2P.getUserDescription(els.getUserCurrentLocation_onUserLocationDesc);
            }
            timestamps.lastRequestUserDescription = getCurrentTimestamp(); //update the timestamp when the last request has been
        };
        
        /**
         * get the description of the current user to show it for other users
         * @method getUserDescription
         * @param {} _callback
         * @return 
         */
        ELSProto.getUserDescription  = function(_callback) {
            if (_callback == null) {
                logger(new Error("callback is not defined"));
                return false;
            }

            var els = this;
            if (els.isClosed() === true) {
                _callback(false);
                return false;
            }
            var mainP2P = returnMainP2P(els);
            var currTimestamp = getCurrentTimestamp();
            //get user's main description to get the user's current location
            if (els.mode === 1) { //mode els
                var callbacks = els.getUserDescriptionCallbacks;
                if (callbacks == null) {
                    callbacks = els.getUserDescriptionCallbacks = [_callback];
                    mainP2P.getUserDescription(els.getUserDescription_onUserDesc);
                } else 
                    if (callbacks.indexOf(_callback) === -1) {
                        callbacks[callbacks.length] = _callback;
                        timestamps.lastRequestUserDescription = currTimestamp;
                        mainP2P.getUserDescription(els.getUserDescription_onUserDesc);
                }
                
                if ( (currTimestamp - timestamps.lastRequestUserDescription) > timeIntervals.timeMillisecondsSinceLastRequestUserCoordinatesOutdated ) { //if too much time since the last request
                    mainP2P.getUserDescription(els.getUserDescription_onUserDesc, true);  //do it anyway  
                }
            }       
        };
        
        /**
         * Description
         * @method getUserCurrentLocation_onUserLocationDesc
         * @param {} usrDesc
         * @return 
         */
        ELSProto.getUserCurrentLocation_onUserLocationDesc = function(usrDesc) {
            var els = this;
            var mainP2P = returnMainP2P(els);
            var callbacks = els.getUserCurrentLocationCallbacks; //callbacks that are waiting current user coordinates
            if (commonlib.isArray(callbacks) === true) {
                if (usrDesc !== false //the description of the user location
                    && commonlib.hasProperty(usrDesc, "latitude") === true && commonlib.hasProperty(usrDesc, "longitude") === true) {

                        var coordinatesDesc = {
                            locationHash: els.locationHash || "0", //if the locationHash was not calculated before, then the current location hash = 0
                            lat: usrDesc.latitude, //user coordinates
                            lng: usrDesc.longitude,
                            coordsTimestamp: getCurrentTimestamp()
                        };
                        if (els.timestamps.lastCalculationLocationHash !== 0) { //add the timestap when the location hash was formed by cs
                            coordinatesDesc.timestamp = els.timestamps.lastCalculationLocationHash;
                        }
    
                        //execute each callback, that is waiting for coordinates
                        for (var i = 0, len = callbacks.length; i < len; i++) {
                            var _callback = callbacks[i];
                            if (typeof(_callback) === "function") {
                                _callback(coordinatesDesc);
                            }
                        }
                        els.getUserCurrentLocationCallbacks = [];
                }
            } else { //if wrong coordinates, then request it once again
                mainP2P.getUserCoordinates(els.getUserCurrentLocation_onUserLocationDesc);
            }
            timestamps.lastRequestUserCoordinates = getCurrentTimestamp(); //update the timestamp when the last request has been
        };


        /**
         * return an object with the current user location description
         * locationHash - hash of the current location
         * lat - latitude coordinate
         * lng - longitude coordinate
         * @method getUserCurrentLocation
         * @param {} _callback
         * @return 
         */
        ELSProto.getUserCurrentLocation = function(_callback) {
            if (_callback == null) {
                logger(new Error("callback is not defined"));
                return false;
            }

            var els = this;
            if (els.isClosed() === true) {
                _callback(false);
                return false;
            }
            var mainP2P = returnMainP2P(els);
            var currTimestamp = getCurrentTimestamp();
            //get user's main description to get the user's current location
            if (els.mode === 1) { //mode els
                var callbacks = els.getUserCurrentLocationCallbacks;
                if (callbacks == null) {
                    callbacks = els.getUserCurrentLocationCallbacks = [_callback];
                    mainP2P.getUserCoordinates(els.getUserCurrentLocation_onUserLocationDesc);
                } else if (callbacks.indexOf(_callback) === -1) {
                    callbacks[callbacks.length] = _callback;
                    timestamps.lastRequestUserCoordinates = currTimestamp;
                    mainP2P.getUserCoordinates(els.getUserCurrentLocation_onUserLocationDesc);
                } 
                
                if ( (currTimestamp - timestamps.lastRequestUserCoordinates) > timeIntervals.timeMillisecondsSinceLastRequestUserCoordinatesOutdated ) { //if too much time since the last request
                    mainP2P.getUserCoordinates(els.getUserCurrentLocation_onUserLocationDesc, true);  //do it anyway  
                }
            } else { //mode ils - send the list of all the locations, that are handled by the els
                var elsLocations = els.getELSLocations();
                if (elsLocations !== false) { //handled locations are exists
                    var ils = els.getILS();
                    if (ils !== false) {
                        var locationsDescForCS = {
                            nearestLocations: commonlib.convertArrayStringValuesToIntegers(elsLocations), //list of the locations that are handled by the els,
                            maintainedLocations: commonlib.convertArrayStringValuesToIntegers(ils.getILSLocationsNearestToTheLocation(elsLocations)) //list of the locations that are maintained by the ils and the nearest locations to the locations that are handled by the els
                        };
                        //convert strings from strings to integers
                        _callback(locationsDescForCS);
                        return;
                    }
                }
                _callback(false);
            }
        };
        
        /**
         * retrun list with a locations, that are maintained by the ils instance that has creted this els
         * return [locationHash] or false
         * @method getILSLocations
         * @return Literal
         */
        ELSProto.getILSLocations = function() {
            var els = this;
            if ( els.mode === 2 ) { //mode LS to LS
                var ils = els.getILS();
                if ( isILS(ils) === true ) { //valid ils instance
                    return ils.getListOfMaintainedLocations();    
                }
            }
            return false;
        };
        
        /**
         * return properties for a new Data Connection or null if there is no valid values for the properties
         * @method propertiesDataConnection
         * @param {} _callback
         * @return 
         */
        ELSProto.propertiesDataConnection = function(_callback) { //!!! add _callback
            if (!_callback) {
                logger(new Error("callback is not defined"));
                return;
            }
            var els = this;
            
            if (els.mode === 2) { //if the mode - is the connection from the ils to the nearest local server
                var opts = null;
                var ilsLocationsList = els.getILSLocations(); //get the ils instance, that has created this els instance
                if ( isArray(ilsLocationsList) === true ) { //must be instance of Array
                    opts = {
                        serialization: "json",
                        metadata: {
                            g_connType : "LSToLS", //connection type = local server to local server
                            g_locationHash : ilsLocationsList, //list of the locations hashes, that are maintained by the ils
                            g_timestamp : getCurrentTimestamp()
                        }
                    };
                }
                
                if (typeof(_callback) === "function") {
                    _callback(opts);
                    _callback = null;
                } else {
                    return opts;    
                }
                
            } else { //if the mode is peer to ls
            
                els.getUserDescription(
                    function(usrDescription) {

                        if (usrDescription !== false) {
                            var opt = null;
                            var mainP2P = returnMainP2P(els);
                            if (els.mode === 1) { //if the user to the ls mode
                                
                                if ( usrDescription.locationHash == null
                                    || usrDescription.locationHash === empty_user_id) { //if the location hash is undefined we can't connect with the local server
                                        opt = false;    
                                } else {
                                    opt = {
                                        serialization: "json",
                                        metadata: {
                                            g_timestamp: getCurrentTimestamp(),
                                            g_lat: usrDescription.lat,
                                            g_lng: usrDescription.lng,
                                            g_timestampHashCalculation: usrDescription.timestamp, //when the location hash has been calculated by the cs
                                            g_timestampCoords: usrDescription.coordsTimestamp, //when the coordinates has been formed
                                            g_connType: "ELS",
                                            g_description : usrDescription.description,
                                            g_numOfMaintainedLocations: mainP2P.getNumberOfMaintainedLocations(), //number of the maintained locations by the current user
                                            g_locationHash: usrDescription.locationHash //location which is maintained by the els
                                        }
                                    };
                                }
                            }
                            if (typeof(_callback) === "function") {
                                _callback(opt);
                                _callback = null;
                            }
                        }
                    });
            }
        };


        /**
         * establish new connection with an els peer
         * @method openDataConnection
         * @return 
         */
        ELSProto.openDataConnection = function() {
            var els = this;
            if (els.elsPeerID != null 
                && els.isConnected() === false) {
                    var mainConnection = returnMainP2P(els);
                    //if the peer ID is equal to the data connection with els peer, and data connection is open
                    //close the current connection with the local server peer and clear timestamp
                    els.closeDataConnection(els.connection);
                    els.status = 0; //change status to disconnected
                    var lsIDForConnection = els.elsPeerID; //save the id of the ls, connection to which is need to be established
                    //establish a new connection to the local server peer with the given ID, serialization method must be JSON
                    els.propertiesDataConnection( //get the properties for the dataConnection to the ils server. Properties are based on the current location of the user
                        function(dataConnectionProps) {
                            if (dataConnectionProps == null) {
                                logger("An empty properties were given for the new data connection");
                            } else if (els.elsPeerID !== lsIDForConnection) { //if the ls id for connection was changed, while we were getting the properties for the new connection
                                logger("The ID of the local server to which the els tries to connect has been changed");
                            } else if ( (getCurrentTimestamp() - els.timestamps.lastConnectionToLS) < timeIntervals.timeoutSecondsExternalLocalServerLastConnectionAttempt) {
                                logger("Too late to create the new connection with the ls");
                            } else if (els.connection != null && els.connection.open === true && els.connection.peer === lsIDForConnection) {
                                logger("Already connected");
                            } else {
                                
                                if ( els.debugThis() === true ) {
                                	debugger;
                                }
                                
                                var connectionToLocalServer = mainConnection.mainServer.connect(commonlib.strToInt(els.elsPeerID), dataConnectionProps); //open the data connection with the local server by the instance of peer.js
                                els.attemptsToConnect++; //number of connection attempts to the local server peer
                                if (connectionToLocalServer != null) { //if it was created
                                    logger("!!Create a new connection to the ls " + els.elsPeerID + " maintains location hash " + els.locationHash);
                                    els.connection = connectionToLocalServer; //set the new connection as a main connection to the local server peer
                                    els.resetLastConnectionTimestamp();
                                    els.setPropertiesAndListenersForNewConnectionToLS(els.connection);
                                    els.timestamps.lastConnectionToLS = getCurrentTimestamp(); //timestamp when the connection to the ls was established
                                    els.status = 1; //change status to "connecting"
                                    els.updateTimestamp(); //update timestamp because of an attempt to establish a new connection with the local server    
                                }
                            }
                        }
                    );
            }
        };


        /**
         * send queued messages if els in mode == "ILS to ELS"
         * @method sendQueuedMessages
         * @return 
         */
        ELSProto.sendQueuedMessages = function() {
            var els = this;
            var queue = els.messagesQueue;
            //send queued messages
            if (Array.isArray(queue) === true && queue.length > 0) {
                for (var i = 0; i < queue.length; i++) {
                    els.sendMessage(queue[i]);
                }
            }
            els.messagesQueue = [];
        };


        /**
         * check if the data connection is valid main connection of the els
         * @method isValidConnection
         * @param {} dataConnection
         * @return LogicalExpression
         */
        ELSProto.isValidConnection = function(dataConnection) {
            var els = this;
            
            return isDataConnection(dataConnection) === true
                    && dataConnection.g_flClosedManually !== true //data connection not closed
                    && dataConnection._closed !== true //data connection is open
                    && commonlib.hasProperty(dataConnection, "g_els") === true 
                    && dataConnection.g_els === els //reference to the els is from the data connection is not equals to this instance of ELS
                    && els.connection === dataConnection //main connection of the els is equals to the given data connection
                    && els.elsPeerID == dataConnection.peer; //id of the local server is equals to the id of the peer to which the connection is established
        };


        /**
         * on DataConnection is opened
         * dataConnection - can be an instance of the DataConnection
         * @method onDataConnectionOpened
         * @param {} dataConnection
         * @return 
         */
        ELSProto.onDataConnectionOpened = function(dataConnection) {
            var elsDataConnection = isDataConnection(dataConnection) === true ? dataConnection : this,
                els = elsDataConnection.g_els;
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            if ( isELS(els) === false //if a reference to the ExternalLocalServer is not defined
                 || els.isValidConnection(elsDataConnection) === false ) { //this is not the valid main data connection of the els
                    elsDataConnection.close(); //close the data connection if it is not valid
                    return;
            }
            
            this.flConnectedForTheFirstTime = true; //set the flag that been connected to the ls
            els.status = 2; //status of the els = connected
            els.updateTimestamp();
            els.timestamps.currentLSIDNotOverdue = getCurrentTimestamp(); //when connected to the new ls update the timestamp when the last new user is on the location
            els.emit("externalLocalServerOpened", els.lsID);

            els.sendQueuedMessages(); //send the messages, that are created by the ils
        };


        /**
         * close current data connection to local server peer
         * and it's no need to reconnect this connection
         * @method closeDataConnection
         * @param {} elsDataConnection
         * @return 
         */
        ELSProto.closeDataConnection = function(elsDataConnection) {
            var els = this;
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            if (isDataConnection(elsDataConnection)) { //if the current connection is opened
                
                var flItIsMainConnection = (els.connection === elsDataConnection); //flag that the closing connection is the main ELS connection
                
                //check if it is the current main data connection to the ls
                if ( flItIsMainConnection === true ) {
                    els.connection  = null;
                    els.status = 0; //change the current els status to disconnected
                }  
                
                elsDataConnection.g_flClosedManually = true;
                els.removeListenersConnectionToLS(elsDataConnection); //remove listeners, because of the data connection closed especially, ,ay be to reconnect with this peer, or connect to the another peer
                elsDataConnection.close(); //close this data connection
                
                if ( elsDataConnection.open === true
                    && flItIsMainConnection === true ) { //if it is the man data connection, then call onClosed procedure
                        els.onConnectionClosed.apply(elsDataConnection);
                }
                
            }
        };

        /**
         * after disconnected from the current local server and some time after that
         * @method dropLocationDescription
         * @return 
         */
        ELSProto.dropLocationDescription = function() {
            var els = this;
            els.emit("locationDescription", {}); //emit the event with the empty location description    
        };
        
        /**
         * data connection to the local server been closed
         * @method onConnectionClosed
         * @return 
         */
        ELSProto.onConnectionClosed = function() {
            var elsDataConnection = this;
            if (commonlib.hasProperty(elsDataConnection, "g_els") === false) {
                return;
            }
            var els = this.g_els; //the reference to the els
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            var flMainConnection = (els.connection === elsDataConnection); //this connection is the main ELS connection
            
            els.removeListenersConnectionToLS(elsDataConnection);
            elsDataConnection.g_els = null;
            
            if (flMainConnection !== true) { //it is not the main connection to els
                elsDataConnection.g_flClosedManually = true;
            } else { //if the closed connection is the main connection for the els
                logger("Connection to the local server was closed");
                //emit an event 'close', depending by closing method
                if (elsDataConnection.g_flClosedManually === true) { //if closed forcibly
                    els.emit("externalLocalServerConnectionClosedForcibly");
                } else {
                    els.emit("externalLocalServerConnectionClosed");
                }
                els.sendQueuedMessages();
                els.status = 0;
                els.connection = null;
                els.resetLastSucessfullConnectionTimestamp();
                
                els.intOnDisconnectedFromLS = setTimeout(els.dropLocationDescription, timeIntervals.timeoutSecondsLocationDescriptionBecomeUnvalid); //after the some time after the disconnection a current location description becomes invalid
                
                if (elsDataConnection.g_flClosedManually !== true) {
                    setImmediate(els.connect); //establish a new connection to the local server
                }
            }
        };
        
        /**
         * disconnect from the current local server
         * @method disconnect
         * @return 
         */
        ELSProto.disconnect = function() {
            var els = this;
            if ( isDataConnection(els.connection) === true ) { //if the main connection is an instance of DataConnection
                els.connection.close();  //close the connection to the ls  
            }
        };

        /**
         * an error has occured into the data connection to the local server
         * @method onConnectionError
         * @param {} err
         * @return 
         */
        ELSProto.onConnectionError = function(err) {
            logger("Connection to the external local server has been closed because of an error " + logger(err.type + " message " + err.message));
        };


        /**
         * is connection to els peer outdated
         * return true if outdated
         * @method isOutdated
         * @return LogicalExpression
         */
        ELSProto.isOutdated = function() {
            var els = this;
            return (typeof(els.timestamp) === "number") &&
                ((getCurrentTimestamp() - els.timestamp) > timeIntervals.timeoutSecondsIntervalExternalLocalServerMainConnection); //last data was received too much time ago
        };


        /**
         * check if the last new user was found on the location too much time ago
         * return true if overdue
         * @method isTimestampLastNewUserOutdated
         * @return BinaryExpression
         */
        ELSProto.isTimestampLastNewUserOutdated = function() {
            var els = this;
            return ((getCurrentTimestamp() - els.timestamps.currentLSIDNotOverdue) > timeIntervals.timeSecondsSinceLastNewUserWasFoundOnLocationOutdated); //last data was received too much time ago
        };
        
        /**
         * if trying to connect to the new ls, but the it is too long
         * @method isCurrentConnectionAttempOutdated
         * @return LogicalExpression
         */
        ELSProto.isCurrentConnectionAttempOutdated = function() {
            var els = this;
            return els.status !== 2 //if not connected sucesfully to the current ls
                    && (getCurrentTimestamp() - els.timestamps.lastConnectionToLS) > timeIntervals.timeoutSecondsExternalLocalServerBetweenConnectionAndMessageFromLS; //and the connection is outdated
        };
        
        /**
         * is needed to recconnect the connection to the local server peer
         * @method checkConnection
         * @return 
         */
        ELSProto.checkConnection = function() {
            var els = this;
            
            if ( els.checkIfLocalILS() !== true ) { //check if the ILS instance is the local, if not local
                if ( ( els.status !== 1 
                        && els.isConnected() === false ) //not connected, and not trying to connect
                    || els.isOutdated() === true  //connected, but the current connection is outdated (there is no information exchange with the ls too much time ) or tries to connect to the ls, but all attempts are outdated
                    || els.isCurrentConnectionAttempOutdated() === true //the current connection attempt has failed 
                ) {
                    els.closeDataConnection(els.connection); //close the main data connection of the els
                    els.connect(); //establish the new connection to the local server
                } else
                    if ( els.isTimestampLastNewUserOutdated() === true //if too much time since has passed since a last new user was found on the location
                        || els.isTrusted() !== true ) { //if the current id is not confirmed by the cs
                            els.getELSPeerID(); //update an id of a local server for the location    
                    }
            }
        };


        /**
         * close current external local server instance
         * @method close
         * @param {} reason
         * @return 
         */
        ELSProto.close = function(reason) {
            var els = this;
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            els.g_flClosedManually = true; //if the connection to local server closed mannualy by this peer

            els.emit("externalLocalServerClosed", reason); //list of the closing resons: 1 - no locations for the maintaince
            els.removeAllListeners(); //remove all event listeners

            if (els.intGetLocationDescription) { //clear interval, that sending information about a current user location
                clearInterval(els.intGetLocationDescription);
                els.intGetLocationDescription = false;
            }
            if (els.intCheckConnection) { //clear interval, that is for checking neccessity of recconection to the local server peer
                clearInterval(els.intCheckConnection);
                els.intCheckConnection = false;
            }
            els.g_MainP2P = null; //reference to the main connection
            els.g_ils = null; //reference to the ils
            els.elsPeerID = els.empty_user_id; //clear a local server peer ID
            els.getUserCurrentLocationCallbacks = [];
            els.getUserDescriptionCallbacks = [];
            
            els.status = 0;
            els.closeDataConnection(els.connection); //close connection to local server peer
        };

        //--MESSAGING between the current user and the local server peer--  

        /**
         * message template for a local server, to which the els instance is connected, if the els is working in the mode of "peer-to-ls"
         * @method messageGetLocationDescriptionForModePeerToELS
         * @param {} callback
         * @return 
         */
        ELSProto.messageGetLocationDescriptionForModePeerToELS = function(callback) {
            var els = this;
            els.getUserDescription(function(locationDescription) {
                if (typeof(callback) === "function") {
                    if (locationDescription === false) { //cant get the location description
                        callback(false);
                    } else {
                        if ( commonlib.hasProperty(locationDescription, "locationHash") === true ) {
                            delete locationDescription["locationHash"];  //this property is not necessary for a ls
                        }
                        locationDescription.numOfMaintainedLocations = returnMainP2P(els).getNumberOfMaintainedLocations(); //insert the bumber of the locations, that are handled by this local server
                        callback({
                            kind: "userDescription",
                            body: locationDescription // user's description
                        });
                    }
                    callback = null;
                }
            });
        };


        /**
         * blank message for the local server, with which the els instance is connected, if the els is working in the mode of "ils-to-els"
         * @method messageGetLocationDescriptionForModeILSToELS
         * @param {} callback
         * @return 
         */
        ELSProto.messageGetLocationDescriptionForModeILSToELS = function(callback) {
            var els = this;
            var elsLocations = els.getELSLocations();
            var res;
            if (elsLocations !== false) {
                res = { //the resulted message
                    kind: "ilsGetLocationsDescription",
                    body: elsLocations
                };
            }
            callback(res);
        };


        /**
         * get description of the current location
         * and send current user's location if els into the "peer to els" mode
         * @method requestLocationDescription
         * @return 
         */
        ELSProto.requestLocationDescription = function() {
            var els = this,
                mainConnection = returnMainP2P(this);
            if (els.isConnected() === false || mainConnection == null) { //connection is not active
                return;
            }
            if (els.mode === 2) { //mode = "ils to els"
                //get location description and form the message to the nearest local server
                els.messageGetLocationDescriptionForModeILSToELS(els.sendMessage); //the formed message will be gone to the function els.sendMessage
            } else { //mode = "peer to els"
                els.messageGetLocationDescriptionForModePeerToELS(els.sendMessage); //the formed message will be gone to the function els.sendMessage
            }
        };
        
        /**
         * when the user, which has been the local server logged out
         * @method onLSClosed
         * @return 
         */
        ELSProto.onLSClosed = function() {
            var els = this;
            els.status = 0;
            els.getELSPeerID(); //request the ID of the valid LS from the cs
        };

        /**
         * maintaince of the location was stopped by the ils
         * @method onLocationMaintainceStopped
         * @param {} message
         * @param {} messageTimestamp
         * @return 
         */
        ELSProto.onLocationMaintainceStopped = function(message, messageTimestamp) {
            if (validators.validatorMessageBodyLocationMaintainceStopped(message) === false) {
                logger(validators.validatorMessageBodyLocationMaintainceStopped.errors);
            } else { //if the message is valid
                var els = this;
                var idNewLS = ( els.isEmptyIDLS(message.idNewLS) === false ) ? message.idNewLS : els.empty_user_id; //id of the new ls
                var locationHash = message.locationHash; //maintaince of this location was stopped
                if (els.mode === 1 //els to ils mode
                    && els.locationHash === locationHash ) { //if the location hash is equls to the current 
                        els.onLocalServerOrLocationChange(idNewLS, locationHash, messageTimestamp);
                } else { //ils to ils mode
                    if (els.isELSLocationIntoList(locationHash) === true //location is hanled by the els
                        && els.removeELSLocation(locationHash) === false) { //remove the location from the list of handled locations
                            //if it is not the last handled lcoation
                            var listNewLSID = [];
                            listNewLSID[locationHash] = idNewLS;
                            els.emit("newLocalServer", listNewLSID); //emit an event with the list of the new local servers for ils
                    }
                }
            }
        };


        /**
         * incoming description of the user location
         * @method onLocationDescription
         * @param {} incomingLocationDescription
         * @return 
         */
        ELSProto.onLocationDescription = function(incomingLocationDescription) {
            if (validators.validatorMessageLocationDescription(incomingLocationDescription) === false) {
                logger(validators.validatorMessageLocationDescription.errors);
            } else {
                var els = this;
                var idThisUser = commonlib.numToStr(els.g_MainP2P.myID);
                var timestamp = incomingLocationDescription.timestampDescFormed;
                var incomingLocationDesc = incomingLocationDescription.locationDescription;
                if (els.timestamps.lastTimestampLocationDescription < timestamp) { //if the incoming description is newer than the current

                    var formedLocationDesc = {}; //location description, after filtering the incoming users
                    var currentLocationDesc = els.locationDescription;
                    if (commonlib.isEmptyObject(currentLocationDesc) === false) {
                        //for each user get coords timestamp and update only the newer
                        var usersIDs = Object.keys(incomingLocationDesc);
                        for (var i = 0, len = usersIDs.length; i < len; i++) {
                            var userID = usersIDs[i];
                            if (userID !== idThisUser) { //if it is not a coordinates of the current user
                                var incomingUserDesc = incomingLocationDesc[userID];
                                if (commonlib.hasProperty(currentLocationDesc, userID) === true) {
                                    var currUserDesc = currentLocationDesc[userID];
                                    if (typeof(currUserDesc.coordsTimestamp) !== "number" //if the timestamp of the current coordinates is absent   
                                        || currUserDesc.coordsTimestamp < incomingUserDesc.coordsTimestamp //or the incoming user coordinates is newer, then the current
                                    ) { //put the user description into the list of the new descriptions
                                        formedLocationDesc[userID] = incomingUserDesc;
                                    }
                                } else { //if the description of this user is absent into the current description of the location
                                    formedLocationDesc[userID] = incomingUserDesc;
                                    els.timestamps.currentLSIDNotOverdue = incomingUserDesc.coordsTimestamp; //update the timestamp when a new user was found on the location
                                }
                            }
                        }
                    } else { //if the current location description is absent
                        if (commonlib.hasProperty(incomingLocationDesc, idThisUser) === true) {
                            delete incomingLocationDesc[idThisUser]; //delete the coordinates of the current user from the incoming description
                        }
                        formedLocationDesc = incomingLocationDesc;
                    }

                    if (Object.keys(formedLocationDesc).length > 0) { //if the formed description is not empty
                        els.locationDescription = formedLocationDesc; //set the incoming location description as the default
                        logger("!!!Incoming description of the location " + els.locationHash);
                        logger("!!!", formedLocationDesc);
                        els.emit("locationDescription", formedLocationDesc); //emit the event
                    } else {
                        els.dropLocationDescription(); //emit the event    
                    }

                    els.timestamps.lastTimestampLocationDescription = timestamp;

                }
            }
        };


        /**
         * return the default location description
         * or false
         * @method getLocationDescription
         * @return LogicalExpression
         */
        ELSProto.getLocationDescription = function() {
            var els = this;
            return commonlib.hasProperty(els, "locationDescription") === true 
                    && commonlib.isEmptyObject(els.locationDescription) === false 
                    && els.locationDescription;
        };
        
        /**
         * send offer to another user to establish RTCDataConnection for messaging
         * offer - stringified offer object description for user with id = userID
         * @method sendOffer
         * @param {} userID
         * @param {} offer
         * @return 
         */
        ELSProto.sendOffer = function( userID, offer ) {
            
            var els = this;
            els.sendMessage({ //the resulted message
                kind: "sendOffer",
                body: {
                    to : userID,
                    offer : offer 
                }
            });
        };
        
        /**
         * incoming offer to establish Web RTC DataConnection for messaging
         * @method onOfferSDP
         * @param {} message
         * @return 
         */
        ELSProto.onOfferSDP = function( message ) {
            
            var els = this;
            if (validators.validatorMessageBodyLocationOfferSDP(message) === false) {
                logger(validators.validatorMessageBodyLocationOfferSDP.errors);
            } else {
                /*if ( commonlib.hasProperty(els.locationDescription, message.from) === true ) { //if the user is on the same or from one of the nearest location
                    */
                    els.emit("offerSDP", [message.from, message.offer]); //emit the event    
                /*} else {
                    logger("There is no user with the ID = " + message.from + " on the location!");    
                }*/
            }
        };
        
        /**
         * send answer to the user offer for messaging with him
         * answer - stringified answer object description for user with id = userID
         * @method sendAnswer
         * @param {} userID
         * @param {} answer
         * @return 
         */
        ELSProto.sendAnswer = function( userID, answer ) {
            
            var els = this;
            els.sendMessage({ //the resulted message
                kind: "sendAnswer",
                body: {
                    to : userID,
                    answer : answer    
                }
            });
        };
        
        /**
         * incoming answer to establish Web RTC DataConnection for the outgoing offer from this user
         * @method onAnswerSDP
         * @param {} message
         * @return 
         */
        ELSProto.onAnswerSDP = function( message ) {
            
            var els = this;
            if (validators.validatorMessageBodyLocationAnswerSDP(message) === false) {
                logger(validators.validatorMessageBodyLocationAnswerSDP.errors);
            } else {
                //if ( commonlib.hasProperty(els.locationDescription, message.from) === true ) { //if the user is on the same or from one of the nearest location
                    els.emit("answerSDP", [message.from, message.answer]); //emit the event    
                // } else {
                //     logger("There is no user with the ID = " + message.from + " on the location!");    
                // }
            }
        };

        /**
         * return true or false, true if the user with the id = userID is on the location
         * @method isUserOnLocation
         * @param {} userID
         * @return LogicalExpression
         */
        ELSProto.isUserOnLocation = function(userID) {
            var els = this;
            var usersOnLocation = els.getLocationDescription();
            return usersOnLocation !== false && (commonlib.hasProperty(usersOnLocation, userID) === true);
        };
        
        /**
         * on connected sucesfully to the ls
         * @method onSucessfullConnectionToLS
         * @return 
         */
        ELSProto.onSucessfullConnectionToLS = function() {
            var els = this;
            if ( els.elsPeerID !== els.empty_user_id ) {
                els.status = 2; //change the current status to the connected
                els.flShortPhaseOfConnectionToLS = false; //go to the normal connection procedure
                els.attemptsToConnect = 0; //reset the number of connection attempts
                els.timestamps.lastSuccessfullConnection = getCurrentTimestamp(); //set the timestamp when the connection to the ls was succesfull
                els.resetLastConnectionTimestamp(); //set the timestamp of the last connection attempt with the ls to zero
                els.updateTimestamp(); //update a timestamp of the current connection to the ls
                if ( els.intOnDisconnectedFromLS != null ) {
                    clearTimeout(els.intOnDisconnectedFromLS);    
                    els.intOnDisconnectedFromLS = null;
                }
            }
        };

        /**
         * an incoming message has come from the ls
         * @method onIncomingMessage
         * @param {} incomingMessage
         * @return 
         */
        ELSProto.onIncomingMessage = function(incomingMessage) {
            var elsDataConnection = this;
            var els = elsDataConnection.g_els;
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            if (isELS(els) === false //this is not connection to the external local server
                || els.isValidConnection(elsDataConnection) === false) { //this is not the main connection of the els
                    logger("!!!Not valid data connection with the ls");
                    return;
            }
            
            if (els.mode === 2 ) { //if ELS instance is working in the mode of ILS - to - ELS
                if ( els.isTrusted() === true ) {
                    els.onSucessfullConnectionToLS();
                    //do not update the els timestamp automatically
                    els.emit("incomingMessageForILS", incomingMessage); //emit an event for ils instance
                    logger("Incoming message for ILS for locations, handled by the ELS: ");
                    logger(els.locationHash);
                }
            } else { //working mode = ELS
                
                //incoming data to a message object
                var res = validators.validatorMessageFromLS(incomingMessage);
                if (res === false) {
                    logger("!!!Not valid message: ");
                    logger(validators.validatorMessageFromLS.errors);
                    return;
                }
                
                var msgKind = incomingMessage.kind;
                logger("ELS>onIncomingMessage. Incoming message with the kind = " + msgKind + " from the local server for ELS( handled location = " + els.locationHash + ")");
                els.onSucessfullConnectionToLS();
                switch (msgKind) { //behaviour depending on the behaviour depending on a message's kind
                    case "locationDescription": //a message with the description of the user location was received
                        els.onLocationDescription(incomingMessage.body);
                        break;
                    case "locationChange": //user location has been changed
                        els.onLocationChanged(incomingMessage.body, true);
                        break;
                    case "locationMaintainceStopped":
                        els.onLocationMaintainceStopped(incomingMessage.body, incomingMessage.timestamp);
                        break;
                    case "offerSDP" : 
                        els.onOfferSDP(incomingMessage.body);
                        break;
                    case "answerSDP" : 
                        els.onAnswerSDP(incomingMessage.body);
                        break;
                    case "out" :
                        els.onLSClosed(incomingMessage.body);
                        break;
                    default:
                        break;
                }
            }

        };


        /**
         * create wrapper for the message body to send the message with body to els peer
         * messageBody must contain field kind to determine message type
         * @method addMessageHeaderLSToLS
         * @param {} message
         * @return message
         */
        ELSProto.addMessageHeaderLSToLS = function(message) {
            message.timestamp = getCurrentTimestamp(); //add the message timestamp
            message.type = "toILS";
            return message;
        };

        /**
         * Description
         * @method addMessageHeaderPeerToLS
         * @param {} message
         * @return message
         */
        ELSProto.addMessageHeaderPeerToLS = function(message) {
            message.timestamp = getCurrentTimestamp(); //add the message timestamp
            message.type = "toLocalServer";
            return message;
        };


        /**
         * send a message to the els peer if els working mode = "ILS to ELS"
         * return false if message can not be sent
         * @method sendMessage
         * @param {} message
         * @return 
         */
        ELSProto.sendMessage = function(message) {
            if (message === false || message == null) { //if the mesage is absent
                return false;
            }
            var els = this;
            
            if ( els.debugThis() === true ) {
            	debugger;
            }
            
            if ( els.checkIfLocalILS() === true ) { //do not send a messages, if the ILS is local
                return;    
            }
            if (els.isClosed() === true) { //els was closed
                return false;
            }
            if (els.isConnected() === false
                || els.isTrusted() === false ) { //if not connected or connection status is "not connected"
                    if (commonlib.hasProperty(els, "messagesQueue")) {
                        els.messagesQueue = [];
                    }
                    //put the message to the queue, it will be sent, when a connection to the els peer will have been established
                    els.messagesQueue.push(message);
                    return true;
            }
            //add header to the message
            if (els.mode === 2) { //add headers for ils mode
                var objMessage = els.addMessageHeaderLSToLS(message);
            } else { //add header for peer to ls mode
                objMessage = els.addMessageHeaderPeerToLS(message);
            }
            logger("Send message to the ils with the 'kind' = " + objMessage.kind);
            els.connection.send(objMessage, null, true);
        };

        ExternalLocalServer.prototype = ELSProto;

        module.exports = {
            ELS: ExternalLocalServer
        };
},{"commonlib":undefined,"eventemitter":undefined,"globalSettings":undefined,"libMainP2P":undefined,"logger":undefined,"timeIntervals":undefined,"timestamps":undefined,"validatorsELS":undefined}]},{},[]);
