require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"hidden":[function(require,module,exports){
//get string with the length as fillNum and zero filled prefix
function getFStr(int, fillNum) {
    return ("00000000000000000000000000" + int).substr(-fillNum);
}

function _toInt(str) {
    return (str.toFixed !== undefined) ? str : ( (str+0) / 10 );    
}

//return shape hash depending on longitude and latitude
function locationHash( longitude, latitude )
{
    var latLon = quarterNumbers( longitude, latitude );
    return hashOfTheSquare(latLon[0], latLon[1]);
}

function quarterNumbers( longitude, latitude ) {
    return [Math.ceil( longitude * 556.6) , (Math.ceil( latitude * 556.6))];
}

/*return hash representation of the longitude and latitude:
 prefix + longitude + latitude
 prefix - depends on octothorpes of the longitude and latitude. Prefix is a one symbol
 longitude - amplified to 6 symbols length longitudeShapeNum
 latitude - amplified to 5 symbols length latitudeShapeNum
 */
function hashOfTheSquare(_longitudeShapeNum, _latitudeShapeNum)
{
    var prefix = "1"; //by default
    var octothorpeLon = _longitudeShapeNum < 0;
    var octothorpeLat = _latitudeShapeNum  < 0;
    if ( octothorpeLon === true && octothorpeLat === true ) { //get abs and prefix
        prefix = "2";
        _longitudeShapeNum = - _longitudeShapeNum;
        _latitudeShapeNum  = - _latitudeShapeNum;
    } else if ( octothorpeLon === true && octothorpeLat === false ) {
        _longitudeShapeNum = - _longitudeShapeNum;
        prefix = "3";
    } else if ( octothorpeLon === false && octothorpeLat === true ) {
        prefix = "4";
        _latitudeShapeNum = - _latitudeShapeNum;
    }
    return _toInt(prefix + getFStr(_longitudeShapeNum,6) + getFStr(_latitudeShapeNum,5));
}

module.exports = locationHash;
},{}]},{},[]);
