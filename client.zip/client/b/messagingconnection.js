require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"MessagingConnection":[function(require,module,exports){
/*global RTCPeerConnection*/
/*global RTCSessionDescription*/
/*global navigator*/

var commonlib = require("commonlib");
var EventEmitter = require('eventemitter');

var configConnectionRTC = {
    iceServers: [
        {url: "stun:23.21.150.121"},
        {url: 'stun:stun.l.google.com:19302'}
    ]
};

var optionsConnectionRTC = { 
    optional: [
        {'DtlsSrtpKeyAgreement':true}
    ]
};

var configOfferMedia = {
    optional: [],
    mandatory: {
        OfferToReceiveAudio: true,
        OfferToReceiveVideo: true
    }
};

var configOfferText = {
    optional: [],
    mandatory: {
        OfferToReceiveAudio: true,
        OfferToReceiveVideo: true
    }
};

var optionsDataChannel = {
    reliable : false
};

var optionsMedia = {
    videoPrefix : "#video#",
    videoStreamHashEnd : "#hash#"
};

/**
 * inherits form the Event Emitter
 * if the argument 'answer' is not empty, then create MessagingConnection for the callee side
 * if the answer is boolean true, then it will be as a media connection
 * answer format for video connection #video#unique video hash string#offer string, where video - is a flag means that it is the offer for video, unique video hash string - it is unique hash of the video stream wants to receive
 * emitted events:
 * 'offer'   - emit when the local offer has created
 * 'open'    - when the connection has opened
 * 'message' - when a new message has come with the string message
 * 'close'   - when the default data channel has closed
 * @method MessagingConnection
 * @param {} answer
 * @return 
 */
function MessagingConnection(answer) {
    
    var promiseToReturn;
    
    var _self = this;
    
    this.offerSDP  = null;
    this.answerSDP = null;
    this.state = 0; //set the current state as NOT CONNECTED
    
    var flMediaConnection = false;
    var flAnswerString = typeof(answer) === "string";
    if (answer !== undefined 
        && answer !== null
        && ( flAnswerString === true
             || typeof(answer) === "object" )
    ) { //if an incoming offer is given
        var _answer = answer.trim();
        if ( flAnswerString === true 
            && this.isMediaOffer(_answer) === true ) { //if offer to see the video translation
                _answer = this.parseMediaOffer(_answer); //return only the answer string, without prefix and video stream hash       
                flMediaConnection = true;
        }
        
        if ( _answer !== false ) {
            try {
                if ( flAnswerString === true ) { //waiting for JSON
                    promiseToReturn = JSON
                                        .parseAsync(_answer)
                                        .then(function(_answerSDP){
                                            if ( _answerSDP instanceof Error === false ) {
                                                _self.answerSDP = new RTCSessionDescription(_answerSDP);
                                                return _self;
                                            } else {
                                                throw _answerSDP;     
                                            }
                                        });
                } else {
                    this.answerSDP = new RTCSessionDescription(_answer); //parse if a string or set if an object
                }
            } catch(e) {
                return Promise.reject(e);    
            }

            this.flCallee = true; //set the flag that it is the callee side
        } else {
            return Promise.reject(new Error("Wrong offer"));    
        }
    } else {
        this.flCallee = false;  //it is caller side  
    }

    if ( flAnswerString !== true  ) { //if answer is the flag that it is a media connection
        if ( answer instanceof MediaStream ) {
            flMediaConnection = true;
            this.videoStream = answer; //set the video stream
        } else if ( typeof(answer) === "boolean" ) { //if requested for a video stream
            flMediaConnection = true;    
        }
    }
    
    this.mediaConnection = flMediaConnection; // true - this is media connection
    this.closed = false; //not closed
    this.candidatesCollected = false; //if all ICE candidates were collected
     
    //bind the context
    this.waitingForDCOpening = this.waitingForDCOpening.bind(this);
    this.onSuccessRemoteDescription = this.onSuccessRemoteDescription.bind(this);
    this.waitingCandidatesCollected = this.waitingCandidatesCollected.bind(this);
    this.end = this.close = this.close.bind(this);
        
    if ( promiseToReturn == null ) { //if not necessary to wait for MessagingConnection
        return Promise.resolve(this);
    } else {
        return promiseToReturn;    
    }
}

MessagingConnection.prototype = Object.create(EventEmitter.prototype); //make the MessagingConnection inheritable from the EventEmitter

/*
    options for video connection
*/
MessagingConnection.prototype.optionsMedia = optionsMedia;

//options for various RTC elements
MessagingConnection.prototype.configConnectionRTC  = configConnectionRTC;
MessagingConnection.prototype.optionsConnectionRTC = optionsConnectionRTC;
MessagingConnection.prototype.configOfferMedia     = configOfferMedia;
MessagingConnection.prototype.configOfferText     = configOfferText;
MessagingConnection.prototype.optionsDataChannel   = optionsDataChannel;

/*
    add media connection prefix to the string offer
*/
MessagingConnection.prototype.addMediaPrefixByVideoStreamHash = function(offer, videoStreamHash) {
    if ( this instanceof MessagingConnection ) { //if called as a method of MessagingConnection object
        if ( this.mediaConnection === true ) { //if it is a media connection
            return this.optionsMedia.videoPrefix + videoStreamHash.trim() + this.optionsMedia.videoStreamHashEnd + offer;       
        } else {
           return offer; 
        }
    } else {  //if called as global object
        return optionsMedia.videoPrefix + videoStreamHash.trim() + optionsMedia.videoStreamHashEnd + offer;    
    }
};

/*
    add media connection prefix to the string offer
*/
MessagingConnection.prototype.addMediaPrefixForAnswer = function(answer) {
    if ( this instanceof MessagingConnection ) { //if called as a method of MessagingConnection object
        if ( this.mediaConnection === true ) { //if it is a media connection
            return (this.optionsMedia.videoPrefix) + answer;        
        } else {
           return answer; 
        }
    } else { //if called as global object
        return optionsMedia.videoPrefix + answer;    
    }
};

/*
    parse answer and return clean answer SDP JSON string
*/
MessagingConnection.prototype.parseMediaAnswer = function(answer) {
    
    
    var optionsMedia = this.optionsMedia;
    var videoPrefix = optionsMedia.videoPrefix;
    var videoPrefixLength = videoPrefix.length;
    
    //get the string without the prefix
    return answer.substr(videoPrefixLength);
};

/*
    check if it is the media offer 
*/
MessagingConnection.prototype.isMediaOffer = function(offerString) {
    return offerString.startsWith(optionsMedia.videoPrefix) === true;
};

/*
    parse offer and return clean offer SDP JSON string
*/
MessagingConnection.prototype.parseMediaOffer = function(offer) {
    
    
    var messagingConnection = this;
    
    var optionsMedia = this.optionsMedia;
    var videoPrefix = optionsMedia.videoPrefix;
    var videoPrefixLength = videoPrefix.length;
    
    //get the string without the prefix
    var woPrefix = offer.substr(videoPrefixLength);
    
    //get the video stream hash from the offer
    var videoStreamHashEnd = optionsMedia.videoStreamHashEnd;
    var videoStreamHashEndLength = optionsMedia.videoStreamHashEnd.length;
    
    var hashIndex = woPrefix.indexOf(videoStreamHashEnd);
    
    var videoTranslation = window.interface.videoTranslation;

    if ( hashIndex > 0 ) { //if found
        var videoStreamHash = woPrefix.substr(0, hashIndex).trim();
        if ( videoStreamHash.length > 0 //if the stream hash is exists
            //&& videoTranslation.isActiveTranslation(videoStreamHash) == true //request if the videostream is exists
        ) { 
            
            messagingConnection.videoTranslationHash = videoStreamHash;
            messagingConnection.videoStream = videoTranslation.getActiveVideoStream();
            
            window.interface.once("stopVideoTranslation", // videotranslation stopped
                function(closedVideoStreamHash) {
                    messagingConnection.videoStream = null; //clear the current video stream for the connection
                    messagingConnection.close(); //close this connection
                }
            );
            return woPrefix.substr(hashIndex + videoStreamHashEndLength).trim(); //return the offer JSON string
        }
    }
    
    return false;
};

/**
 * set the listeners for the new data channel
 * @method onDataChannel
 * @param {} ev
 * @return 
 */
MessagingConnection.prototype.onDataChannel = function(ev) {
    var dc;
    
    if ( ev != null ) {
        var _currentDC = this.dc;
        if ( this.isDataChannel(_currentDC) === true ) { //if the current data channel is exists
            this.removeDCEventListeners(_currentDC); //close the current data channel
            _currentDC.close();    
        }
        if ( this.flCallee === true ) { //receve the new channel on the caller side
            if ( ev != null 
                && ev.channel != null ) { //if it is event
                    this.dc = dc = ev.channel;  //save the incoming data channel as the default 
            } else { //if it is a data channel
                dc = this.dc; //get the default data channel   
            }
                
            if ( this.closed === true ) { //if the messaging connector closed
                dc.close();
            } else {    
                this.setDCEventListeners(dc); //set the isteners for the dc events
                if ( this.dcTimeout != null ) { //if a timeout to close the messaging connection still exists
                    clearTimeout(this.dcTimeout); //clear the timeout
                    this.dcTimeout = null;
                }
            }
        }
    } else {
        this.setDCEventListeners(this.dc); //set the isteners for the dc events
    }
};

//set the handlers for the Data Channel events
/**
 * Description
 * @method setDCEventListeners
 * @param {} dc
 * @return 
 */
MessagingConnection.prototype.setDCEventListeners = function(dc){
    var handlerDCStateChange = this.onDataChannelStateChange.bind(this); //check the current state of the data channel
    dc.onerror = handlerDCStateChange;
    dc.onclose = handlerDCStateChange;
    dc.onopen  = handlerDCStateChange;
    dc.onmessage = this.onDataChannelMessage.bind(this); //when a new message has come         
};

//remove all listeners for the events fired by the given Data Channel
/**
 * Description
 * @method removeDCEventListeners
 * @param {} dc
 * @return 
 */
MessagingConnection.prototype.removeDCEventListeners = function(dc) {
   dc.onerror    = null;
   dc.onclose    = null; 
   dc.onopen     = null; 
   dc.onmessage  = null; 
};

//when change the state of the ICE connection
/**
 * Description
 * @method onICEConnectionStateChange
 * @param {} ev
 * @return 
 */
MessagingConnection.prototype.onICEConnectionStateChange = function (ev) {
    var connectionRTC = this.connectionRTC;
    if ( connectionRTC.iceConnectionState === "connected"
        || connectionRTC.iceConnectionState === "completed"
        || connectionRTC.iceConnectionState === "checking") { //check for the ICE connection state
            var sdp = this.offerSDP = connectionRTC.localDescription; 
            this.candidatesCollected  = true;
            this.emit('offer', sdp);
            return true;
    }
};

//when the state of the ICE gathering has changed
/**
 * Description
 * @method onICEGatheringStateChange
 * @param {} ev
 * @return 
 */
MessagingConnection.prototype.onICEGatheringStateChange = function (ev){
    var connectionRTC = this.connectionRTC;
    if ( connectionRTC.iceGatheringState === "complete" ) { //if gathering was completed
        var handler = connectionRTC.onICEConnectionStateChange.bind(this);
        if ( handler() !== true ) { //if the ICE has not the necessary state
            connectionRTC.oniceconnectionstatechange = handler; //set the handler for when the ICE connection state changing
        }
    }
};

//when a new ICE candidate was gathered
/**
 * Description
 * @method onICECandidate
 * @param {} ev
 * @return 
 */
MessagingConnection.prototype.onICECandidate =  function (ev) {
    var connectionRTC = this.connectionRTC;
    if ( ev.candidate == null ) { //if the ICE gathering was ended
        //var sdp = this.offerSDP = connectionRTC.localDescription; //set as the default
        var sdp = connectionRTC.localDescription;
        this.candidatesCollected  = true;
        this.emit('offer', sdp);
    }    
};

/**
 * Description
 * @method onFailedOffer
 * @param {} ev
 * @return 
 */
MessagingConnection.prototype.onFailedOffer =  function (ev) {
    console.log("Creatin of the offer was faileds");   
};

/*
    on data channel closed
*/
MessagingConnection.prototype.onDCClosed = function() {
    var dc = this.dc;
    var mc = this;
    console.log("Data connection has closed");
    this.state = 0; //change the current state to NOT CONNECTED
    this.removeDCEventListeners(dc); //remove all listeners from the event of the data channel
    this.dc = null;
    if ( this.closed !== true
        && this.connectionRTC != null
        && this.flCallee !== true ) { //caller must create a new connection
            // setTimeout(
            //     function() {
            //         if ( mc.closed !== true ) {
            //             mc.dc = mc.connectionRTC.createDataChannel("caller", commonlib.extend(mc.optionsDataChannel, { negotiated : false })); //create the new data channel
            //             mc.onDataChannel(); //process it    
            //         }    
            //     }
            // , 2000);
    } else 
        if ( this.closed === true
            || this.connectionRTC == null ) {
                this.close();    
    } else {
        mc.dcTimeout = setTimeout(function(){
            mc.close(); 
        }, 10000);  // set the timeout waiting for the new data channel 
    }
};

//process the current state of the data channel
/**
 * Description
 * @method onDataChannelStateChange
 * @param {} e
 * @return 
 */
MessagingConnection.prototype.onDataChannelStateChange =  function(e) {
    debugger
    var dc = this.dc;
    if ( this.closed !== true ) {
        
        if ( e instanceof Error ) { //if some error has occurred
            console.log(e);    
        } else    
        if ( dc.readyState === "open" ) { //if the data channel is open
            console.log("Data connection has open");
            this.emit('open');
            this.state = 1; //change the curent state to the OPEN
        } else
        if ( dc.readyState === "closed" ) { //if the default data channel is closed
            this.onDCClosed();
        }
    }
};

MessagingConnection.prototype.isDataChannel = function(dc) {
    return dc != null && dc.toString() === "[object RTCDataChannel]";    
}

/*
    return the promise, resolved when the data channel has the open state or reject by time out or if closed
*/
MessagingConnection.prototype.waitingForDCOpening = function() {
    var messagingConnection = this;
    var dc = this.dc;
    //set listener to handle disconnection
    this.connectionRTC.oniceconnectionstatechange = this.oniceconnectionstatechange.bind(this);
    
    if ( this.closed === true ) { //if closed already
        return Promise.reject(new Error("Messaging connection closed"));
    }
    if (messagingConnection.isDataChannel(dc)
        && dc.readyState === "open" ) { //if opened already
            return Promise.resolve(messagingConnection.waitingRTCConnectionEstablished());    
    } else 
        if ( dc == null ) {
            this.close();
            return Promise.reject("The data channel can't be created");
    } else {
        return new Promise(
                    function(resolve, reject){
                        function onOpen(){
                            clearTimeout(timeout);
                            resolve(messagingConnection.waitingRTCConnectionEstablished());
                            //resolve(true);
                        }
                        var timeout = setTimeout(function(){ //if tiem out
                            reject(new Error("Time out"));
                            messagingConnection.removeListener("open", onOpen);
                        }, 15000);
                        messagingConnection.once("open",  onOpen); //waiting for opening
                        messagingConnection.once("close", reject); //reject if the MessagingConnection has been closed
                    }
                ); 
    }
};

/*
    set the listeners for video stream
*/
MessagingConnection.prototype.setListenersForVideoStream = function() {
    var messagingConnection = this;
    var videoStream = messagingConnection.videoStream;
    if ( ( videoStream instanceof MediaStream ) === true ) {
        
        function onMediaStreamClose() {
            var timeoutToClose = setTimeout(
                function(){
                    videoStream.removeEventListener("active", onStreamRestore);
                    videoStream.removeEventListener("inactive", onMediaStreamClose);
                    videoStream.removeEventListener("removetrack", onMediaStreamClose);
                    messagingConnection.close(); //close the messaging connection
                }
                ,5000); //waiting for 5 seconds and close the connection
            
            function onStreamRestore(){ //if the stream restore
                clearInterval(timeoutToClose); //do not close the connection   
            }
            
            videoStream.addEventListener("active", onStreamRestore); //listener for the case if the video will be restored
        }
        
        //set listeners for close events
        videoStream.addEventListener("inactive", onMediaStreamClose);
        videoStream.addEventListener("removetrack", onMediaStreamClose);
    }
};

/*
    return the promise, resolved when the data channel has the open state or reject by time out or if closed
*/
MessagingConnection.prototype.waitingForStream = function() {
    var messagingConnection = this;
    if ( messagingConnection.closed === true ) { //if closed already
        return Promise.reject(new Error("Messaging connection closed"));
    } if ( messagingConnection.videoStream != null ) { //if already received
        return Promise.resolve(messagingConnection.videoStream);
    } else {
        return new Promise(
                    function(resolve, reject){
                        function onOpen(evt){
                            
                            clearTimeout(timeout);
                            var videoStream = evt.stream;
                            messagingConnection.videoStream = videoStream;
                            resolve(videoStream);
                        }
                        var timeout = setTimeout(function(){ //if tiem out
                            reject(new Error("Time out"));
                            messagingConnection.removeListener("open", onOpen);
                        }, 25000);
                        
                        messagingConnection.connectionRTC.onaddstream = onOpen;
                    }
                ); 
    }
};

/*
    send message through the opened data channel
*/
MessagingConnection.prototype.send = function(message) {
    var dc = this.dc; //data channel
    var mc = this;
    if ( this.closed !== true ) {
        if ( this.isDataChannel(dc) === true
            && dc.readyState === "open" ) { //if connected
                if ( typeof(message) !== "string"
                    && message != null ) { //if not a string
                        return JSON.stringifyAsync(message, null, dc) //stringify the message before send it
                            .then(function(res){
                                if ( typeof(res) === "string" ) {
                                    dc.send(message);
                                    return message; //return the message
                                } else {
                                    return Promise.reject("Can't stringify the message");    
                                }
                            });
                } else {
                    try {
                        dc.send(message); //send if the string   
                        return Promise.resolve(message); //return the message
                    } catch(e){
                        return Promise.reject(e);    
                    }
                }
        } else {
            return new Promise(
                function(resolve, reject) {
                    setTimeout(function(){
                        resolve(mc.send(message));  //try to send once again after waiting for 2 seconds 
                    }, 1000);    
                }    
            );   
        }
    } else {
        return Promise.reject(new Error("The connection was closed, can't send the message"));    
    }
};

/*
    when all ICE Candidates are collected
*/
MessagingConnection.prototype.waitingCandidatesCollected = function() {
    var messagingConnection = this;
    
    if ( messagingConnection.candidatesCollected === true ) { //if candidates were collected already
        return Promise.resolve(messagingConnection.offerSDP);
    } else {
        return new Promise(
            function(resolve, reject) {
                var timeout = setTimeout(
                                function(){
                                    reject(new Error("Timeout")); 
                                    messagingConnection.removeListener("offer", onOfferSDP);
                                },
                                10000
                            );
               
                function onOfferSDP(sdp){
                    
                    messagingConnection.offerSDP = sdp;
                    resolve(sdp);  
                    clearTimeout(timeout);
                }
                
                messagingConnection.once("close", reject); //reject if the MessagingConnection has been closed
                messagingConnection.once("offer", onOfferSDP);
            }    
        );
    }
};

//on new incoming message from the default data channel
/**
 * Description
 * @method onDataChannelMessage
 * @param {} ev
 * @return 
 */
MessagingConnection.prototype.onDataChannelMessage = function(ev) {
    if ( this.closed === true
        || ev instanceof Error ) { //if an Error
            console.log(ev);    
    } else { //if data has come
        if ( this.listeners("message" , true) === false  ) { //if there is no listeners for messages
            var mc = this;
            setTimeout( //wait for 2 seconds
                function(){
                    if ( mc.listeners("message" , true) === false ) {
                        mc.close();    //if still no listeners, close the messaging connection
                    } 
                }, 2000);       
        } else {
            this.emit('message', ev.data);    
        }
    }
    
};

//when the remot description was sucessfuly set
/**
 * Description
 * @method onSuccessRemoteDescription
 * @return 
 */
MessagingConnection.prototype.onSuccessRemoteDescription =  function () {
    var mc = this;
    var connectionRTC = this.connectionRTC;
    
    return new Promise( 
            function(resolve, reject) {
                var _timeout = setTimeout(
                    function(){
                        mc.close(); 
                        reject(new Error("Candidates cannot be collected"));
                    }, 
                    2000
                );
                
                connectionRTC
                        .createAnswer()
                        .then(connectionRTC.setLocalDescription.bind(connectionRTC))
                        .then(mc.waitingCandidatesCollected)
                        .then(function(){
                            clearTimeout(_timeout);
                            resolve(true);    
                        });
            }
        );
    
};

/*
return user camera stream   
*/
MessagingConnection.prototype.getUserMedia = function() {
    return new Promise(
        function(res, rej) {
            navigator.getUserMedia(
                { "audio": true, "video": true }, 
                function (stream) {
                    clearTimeout(timeout);
                    res(stream);            
                }
            );
            var timeout = 
                setTimeout(
                    function(){
                        rej(new Error("Timeout!"));    
                    },
                    2000
                );
            
        }
    );
};

/*
    create the offer on the caller side and return the result SDP, when all the candidates will be collected
*/
MessagingConnection.prototype.createOffer = function (peerConnection) {
    var messagingConnection = this;
    try{
        return peerConnection
                .createOffer( messagingConnection.mediaConnection === true ? messagingConnection.configOfferMedia : messagingConnection.configOfferText )
                .then(peerConnection.setLocalDescription.bind(peerConnection))
                .then(messagingConnection.waitingCandidatesCollected);
    } catch(e) {
        console.log(e);
        return Promise.reject(e); //resolve with error
    }
};

/**
 * create new RTCPeerConnection and make offer or answer, depending
 * return Promise, resolved with offerSDP or answerSDP
 * @method connectToPeer
 * @return 
 */
MessagingConnection.prototype.connectToPeer = function connectToPeer() {
    
    var messagingConnection = this;
    
    if ( this.closed !== true ) {
        var flItIsCallee = (this.flCallee === true); //check
        var peerConnection = this.connectionRTC = new RTCPeerConnection(this.configConnectionRTC, this.optionsConnectionRTC); //create RTC connection
        
        peerConnection.onicegatheringstatechange = this.onICEGatheringStateChange.bind(this); //waiting when the gathering state will be end
        peerConnection.onicecandidate = this.onICECandidate.bind(this); //when an ICE candidate is chosen
        peerConnection.onconnectionstatechange = this.onconnectionstatechange.bind(this); //on connection state changed
        
        if ( flItIsCallee === true ) { //on the callee side
            if ( this.mediaConnection !== true ) {
                this.dc = false; //the data channel is absent but will be opened later
                peerConnection.ondatachannel = this.onDataChannel.bind(this); //waiting when a new data channel will come
            } else { //if it is MediaConnection
                var videoStream = this.videoStream;
                if ( videoStream != null ) {
                    peerConnection.addStream(this.videoStream);  //add the videostream  
                }
                messagingConnection.waitingForStream();
            }
            
            return peerConnection
                    .setRemoteDescription(this.answerSDP)
                    .then(this.onSuccessRemoteDescription);
                    
        } else { //on the caller side
            if ( this.mediaConnection !== true ) {
                this.dc = peerConnection.createDataChannel("caller", this.optionsDataChannel); //create the new data channel
                this.onDataChannel(); //process it
                this.offerSDP = null;
                
                return messagingConnection.createOffer(peerConnection); //create the offer
                
            } else { //if it is MediaConnection
                videoStream = this.videoStream;
                if ( videoStream != null ) {
                    peerConnection.addStream(this.videoStream);  //add the videostream  
                } else {
                    try{
                        return messagingConnection
                                .getUserMedia()
                                .then(function(videoStream){
                                    var _peerConnection = peerConnection;
                                    _peerConnection.addStream(videoStream);  //add the videostream 
                                    return messagingConnection.createOffer(_peerConnection); //create the offer 
                                });
                    } catch(e) {
                        console.log(e);
                        return Promise.reject(e); //resolve with error
                    }
                } 
                
                messagingConnection.waitingForStream();
            }
    
        }
    } else {
        return Promise.reject(new Error("This messaging connection was closed")); //resolve with error    
    }
};

/*
    waiting for RTCPeerConnection will be opened
*/
MessagingConnection.prototype.waitingRTCConnectionEstablished = function() {
    if ( this.closed !== true ) {
        var messagingConnection = this;
        var pc = messagingConnection.connectionRTC;
        if ( pc.connectionState == null //if not defined (not supported by the browser)
            || pc.connectionState === "connected" ) { //or connected
                return Promise.resolve(true);      
        } else {
            return new Promise(
                function( resolve, reject ) {
                    messagingConnection.once("connectionRTC_connected", resolve); //resolve when connected
                    messagingConnection.once("close", reject); //reject if the MessagingConnection has been closed    
                }    
            );
        }
    } else {
        return Promise.reject(new Error("This connection has been closed"));    
    }
};

/*
    check if the connection was disconnected
*/
MessagingConnection.prototype.oniceconnectionstatechange = function(ev) {
    
    if ( this.closed !== true ) {
        var pc = this.connectionRTC;
        switch(pc.iceConnectionState) {
            case "closed":
            case "failed": //if the connection has closed by any reason
                this.close(); //close the connection
                break;
        }
    }
};

/*
    on RTCPeerConnection state changed
*/
MessagingConnection.prototype.onconnectionstatechange = function(event) {
    if ( this.closed !== true ) { 
      var pc = this.connectionRTC;
      switch(pc.connectionState) {
        case "connected": //connected
          this.emit("connectionRTC_connected", true);
          break;
        case "disconnected":
            this.emit("connectionRTC_disconnected");
            break;
        case "failed": // One or more transports has terminated unexpectedly or in an error
          break;
        case "closed": // The connection has been closed
          this.close(); //close the connection
          break;
      }
    }
};

/**
 * set the answer incoming from the callee on the caller side
 * @method setAnswerOnCaller
 * @param {} strAnswer
 * @return 
 */
MessagingConnection.prototype.setAnswerOnCaller = function(strAnswer) {
    var answerSDP = this.answerSDP = new RTCSessionDescription( typeof(strAnswer) === "string" ? JSON.parse(strAnswer) : strAnswer ); //set the parsed answer SDP   
    return this.connectionRTC.setRemoteDescription(answerSDP);
};

/*
    close the data channel
*/
MessagingConnection.prototype.closeDC = function() {
    var dc = this.dc;
    if ( this.isDataChannel(dc) === true ) { //RTCDataChannel
        dc.close();
        this.removeDCEventListeners(dc); //remove all listeners from the event of the data channel
    }
    
    this.dc = null;
};

/*
    remove all tracks from the stream
*/
MessagingConnection.prototype.closeVideoStream = function() {
    if ( this.videoStream != null ) {
        var stream = this.videoStream;
        var activeTracks, i, len, track; 
    
        activeTracks = stream.getVideoTracks(); //get all video tracks from the stream
        for ( i =0, len = activeTracks.length; i < len; i++ ) {
            track = activeTracks[i]; //video track
        	stream.removeTrack(track); //stop it
        }
        activeTracks = stream.getAudioTracks(); //get all video tracks from the stream
        for ( i =0, len = activeTracks.length; i < len; i++ ) {
            track = activeTracks[i]; //video track
        	stream.removeTrack(track); //stop it
        } 
        
        this.videoStream = null;
        
    }
};

/*
    close this connection
*/
MessagingConnection.prototype.close =
    MessagingConnection.prototype.end =
        function () {
            if ( this.closed !== true ) { //if has not closed before
                
                this.closed = true;
                this.state = 0;
                if ( this.flCallee !== true ) { //if it is caller side of the connection(video stream has been reuested from the other user)
                    this.closeVideoStream();
                }
                this.closeDC();            
                this.connectionRTC.close();
                this.emit("close", new Error("The connection has been closed"));
                this.removeAllListeners();
            }
        };

module.exports = MessagingConnection;

},{"commonlib":undefined,"eventemitter":undefined}]},{},[]);
