/*global $*/

const tilesprovider = "http://{s}.tiles.wmflabs.org/bw-mapnik/{z}/{x}/{y}.png";
var flOnNews = false;
var prevSection = 1;

$(document).ready(function () {
    var movingInt;
    var markersInt;
    const mymap = L.map('map', {
        zoomControl: false,
        scrollWheelZoom: false,
        touchZoom: false,
        tap: false,
        dragging: false,
        doubleClickZoom: true
    });
    var markerslist = [];
    const defaultLatLng = {
        lat: 51.505,
        lng: -0.09
    };

    $('#fullpage').fullpage({
        controlArrows: false,
        afterLoad: function (anchorLink, index) {

            mymap.invalidateSize(true); //redrow the map on window resize

            for (var indToRemove = 0, len = markerslist.length; indToRemove < len; indToRemove++) {
                var _marker = markerslist[indToRemove];
                if (_marker != null) {
                    markerslist[indToRemove] = null;
                    mymap.removeLayer(_marker);
                }
            }

            clearInterval(movingInt);
            movingInt = null;
            clearInterval(markersInt);
            markersInt = null;
            if (mymap != null) {
                mymap.setView(defaultLatLng);
            }

            if (index === 2) {
                movingInt = setInterval(function () {
                    const latlng = mymap.getCenter();
                    latlng.lat += Math.random() * (0.001 + 0.0001) - 0.0001;
                    latlng.lng += Math.random() * (0.001 + 0.0001) - 0.0001;
                    mymap.setView(latlng);
                }, 50);

            }

            if (index === 4) {
                markersInt = setInterval(function () {
                    const latlng = mymap.getCenter();
                    latlng.lat += Math.random() * (0.1 + 0.1) - 0.1;
                    latlng.lng += Math.random() * (0.1 + 0.1) - 0.1;
                    const marker = L.marker(latlng).addTo(mymap);
                    const len = markerslist.length;
                    markerslist[len] = marker;

                    const indToRemove = Math.floor(Math.random() * len) - 1;
                    if (indToRemove > 0) { //remove a random marker
                        const _marker = markerslist[indToRemove];
                        if (_marker != null) {
                            markerslist[indToRemove] = null;
                            mymap.removeLayer(_marker);
                        }
                    }

                }, 300);

            }

            $('[data-section="' + index + '"]')
                .find("[data-animation]")
                .each(
                    function () {
                        const ui = $(this);
                        const ad = Number(ui.attr("data-animation-delay"));
                        ui.addClass("typewriter" + (isNaN(ad) === true ? "" : ad));
                    }
                );

        }
    });

    $(window).resize(function () {
        mymap.invalidateSize(true); //redrow the map on window resize
    });

    mymap.setView(defaultLatLng, 13);

    L.tileLayer(
        tilesprovider, {
            attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a> Tile layer by <a href="tiles.wmflabs.org">wmflabs</a>',
            maxZoom: 18
        }
    ).addTo(mymap);

    $.getJSON(
        "https://freegeoip.net/json?callback=?", {
            crossDomain: true
        },
        function (data) {
            if (data != null &&
                typeof (data) === "object") {
                const latitudestr = data["latitude"];
                const longitudestr = data["longitude"];
                if (latitudestr != null &&
                    longitudestr != null) {
                    const latitude = Number(latitudestr);
                    const longitude = Number(longitudestr);
                    if (isNaN(latitude) === false &&
                        isNaN(longitude) === false) {
                        const defcoords = defaultLatLng;
                        defcoords.lat = latitude;
                        defcoords.lng = longitude;
                        mymap.setView(defcoords);
                    }
                }
            }
        }
    );

});

function clicktwitternews() {
    if (flOnNews === false) {
        $.fn.fullpage.moveTo(1, 1);
        flOnNews = true;
        prevSection = $("div.fp-section.active").attr("data-section");
    }
    else {
        $.fn.fullpage.moveTo(prevSection, 0);
        flOnNews = false;

    }
}

function openAPP() {
    window.location.replace("/");
}