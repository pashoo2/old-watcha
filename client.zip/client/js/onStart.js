/*global L*/
/*global $*/
/*global hello*/
/*global localforage*/

//set global variables window.user, window.interface, window.logger, window.interfacePlugins, window["_integrationPlugins"];

/*
    when the main page was loaded    
*/
function onMainPageLoaded() {
    
    var iplugins = window.interfacePlugins;
    var _flags = window.interfacePlugins.flags;
    _flags.pagesWereLoaded = true;

    var logger = window.logger = require("logger").logger;
    logger.namespace = "window";
    
    window.MessagingConnection = require("MessagingConnection"); //p2p connection between the users
    
    var User = require("User").user;
    var user = window.user = new User(); //main object for the user representation
    
    window._interface.showConnectionState("Load settings");
    user.start();
    
}

//exuecute script to initialize the integration modules 
function loadIntegrationPlugins(interfacePlugins) {
    return interfacePlugins 
            .ajax
            .loadFile(
                "ejs",
                "initialize.js",
                interfacePlugins.options.urlIntegration
            );   
}

/*
    on document ready    
*/
function onDocumentReady() {
    
    $.ajax({
        cache : true 
    });

    var interfacePlugins = window.interfacePlugins = require("interfacePlugins"); 
    interfacePlugins.main.onDocumentReady();
    
    var UI = require("UI").UserInterface;
    var _interface = window._interface = window.interface = new UI();
    _interface.showConnectionState("Load plugins");
    loadIntegrationPlugins(interfacePlugins) //load all integration plugins
        .then(function(res){
            _interface.showConnectionState("Initialise plugins");
            var _integrationPlugins = window["_integrationPlugins"];
            if ( _integrationPlugins != null ) {
                return _integrationPlugins
                            .ready
                            .then(function(){ //auth
                                hello.init({
	                                facebook: '911820115617926',
	                                google : '548241182143-37k394o78t9khcihipp67jeadkru7a8t.apps.googleusercontent.com',
	                                windows: 'bcae21ae-49e4-4142-b5aa-f688b3a7cebe'
                                });
                            })
                            .then(function(){
                                _interface.showConnectionState("Load pages");
                                interfacePlugins //load the main page
                                    .ajax
                                    .loadDynamicPage(
                                        ["page_main"],
                                        onMainPageLoaded,
                                        true
                                    );
                            });

            } else {
                throw new Error("_integrationPlugins not loaded");    
            }
        })
        .catch(function(e){
            window.interface.showConnectionState("Error: " + e.message);
            loadIntegrationPlugins();    
        }); 
}

window.LocalStart = false;
$(window.document).ready(onDocumentReady);