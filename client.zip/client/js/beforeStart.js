/*global $*/
(function() {
    const ls = window.localStorage;
    
    function redirecttointro(){
        ls.setItem("lastAccessTime", (new Date()).toUTCString());    
        window.location.replace("/intro/");
    }
    
    //check for https in url
    const _loation = window.location;
    var _href = _loation.href.trim();
    if ( _href.indexOf("https") !== 0 ) { //redirect to https url
        _href = _href.replace("http", "https").trim();
        if ( _href.indexOf("https") !== 0 ) {
            _href = "https://" + _href;   
        }
        window.location.replace(_href);    
    } else {
        //test for valid url
        const validURL = /^(https:\/\/)[0-9a-z.\-_]+[\/]*[\?]*(((\#access_token)|(\#state)).+){0,1}/i;
        const res = validURL.exec(_href);
        const validAddr = res[0].trim(); //get the valid url

        const flReirectToValid = (validAddr != _href); 
        
        // if ( ls != null ) {
        //     var last_access_time = ls.getItem("lastAccessTime");
        //     debugger;
        //     if ( typeof(last_access_time) !== "string" ) { //if there is a first time access
        //         redirecttointro();
        //     } else {
        //         last_access_time = Date.parse(last_access_time);
        //         if ( Date.now() - last_access_time > 86400 ) { //more then 24 hours passed since the last access
        //             redirecttointro();
        //         }
        //     }
        // }
        
        if ( validAddr.length === 0 ) { //if the addres is not valid stop the page loading
            window.alert("Invalid url!");
        } else if ( flReirectToValid === true ) { //if it is necessary to redirect on the base url addresss
            alert(_href);
            console.log(_href);
            alert(validAddr);
            window.stop();
            //window.location.replace(validAddr);   
        } else {
            //this is to avoid jumping to the previos page on pages changing
            $(document).bind("mobileinit", function(){
                $.mobile.pushStateEnabled = false;   
            });
        }
        
    }
})();