//thread of gClient
/*global localforage*/

//bower
importScripts("./bower_components/pako/dist/pako.min.js"); //<!-- pako  -->

//libjs
importScripts("./libJS/eventemitter.js");           //<!-- eventemitter	-->
importScripts("./libJS/setImmediate.js");           // <!-- setimmediate2	-->
importScripts("./libJS/lz-string.min.js");          // <!-- LZString -->
importScripts("./libJS/JSONWebWorker/json.async.js");
importScripts("./libJS/ajv.bundle.js");                    //<!-- setimmediate2	-->
importScripts("./libJS/jsonTry.js");                //JSON parse with try catch
importScripts("./libJS/geolib.min.js");             //<!-- geolib        -->
importScripts("./libJS/chance.js");                 //<!-- geolib        -->
importScripts("./libJS/localforage.min.js");                 //<!-- localforage  -->

//browserified
importScripts("./b/glib.js");                       //<!-- glib -->
importScripts("./b/commonlib.js");                  //<!--commonlib		-->
importScripts("./b/mainpatterns.js");               //<!--mainpatterns    -->
importScripts("./b/timestamps.js");                 //<!--timestamps      -->
importScripts("./b/mainpeer.js");                   //<!--mainpeer        -->
importScripts("./b/ELS.js");                        //<!--ELS        -->
importScripts("./b/mainfunctions.js");              //<!--mainfunctions        -->
importScripts("./b/timeIntervals.js");              //<!--timeIntervals        -->
importScripts("./b/ILS.js");                        //<!--ILS        -->
importScripts("./b/validatorsMainPeer.js");         //<!--validatorsMainPeer        -->
importScripts("./b/validatorsELS.js");              //<!--validatorsELS        -->
importScripts("./b/validatorsILS.js");              //<!--validatorsELS        -->
importScripts("./b/user.js");                       //<!--//User        -->
importScripts("./b/globalSettings.js");             //<!--globalSettings        -->
importScripts("./b/logger.js");                     //<!--logger        -->
importScripts("./b/dataConnector.js");              //<!--DataConnector        -->
importScripts("./b/commandsListener.js");           //<!-- CommandsListener        -->
importScripts("./b/connectorWithMainThread.js");    //<!-- ConnectorWithMainThread -->
importScripts("./b/libMainP2P.js");                 //<!-- libMainP2P        -->
importScripts("./b/webWorkerDataConnection.js");    //<!-- WebWorkerDataConnection        -->

if ( console.clear ) {
    console.clear();
} else {
    console.log("_______________________________________________");
    console.log("_______________________________________________");    
    console.log("_______________________________________________");    
    console.log("_______________________________________________");    
    console.log("_______________________________________________");    
    console.log("_______________________________________________");    
}

//config the local forage library
var globalSettings = require("globalSettings");
localforage.config(globalSettings.localforage);
self.localStorage = localforage; //use local forage withing the web workers

var MainP2P = require("mainpeer").mainpeer;
var logger = require("logger").logger;
var ConnectorWithMainThread = require("ConnectorWithMainThread").ConnectorWithMainThread;

var mainP2P = new MainP2P();
var connectorWithMainThread = self.connectorWithMainThread = new ConnectorWithMainThread(self, mainP2P); //create the connector to the main threa of the app