this.page = {
    onevent : { //events handlers for this page
        pagecontainershow : function() {
                                window.interface.mainMap.redraw();
                            }
    } 
};