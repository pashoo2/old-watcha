/*global window*/
/*global $*/
/*global FB*/
/*global CSPhotoSelector*/

/*
    befor the panel myTags will be opened
*/
function loadMyTagsLookingTags(flLookingTags) {
    
    var _interface = window.interface;
    var listviewTarget        = ( flLookingTags === true ? "#listview_lookingtagslist" : "#listview_mytagslist" );
    var listviewAvailableTags = ( flLookingTags === true ? "#panel_lookingtags-listview_availtagslist" : "#listview_availtagslist" );
    _interface.loadMyTagsLookingTags(flLookingTags, listviewTarget, listviewAvailableTags);
            
}

/*
    on panel with the chosen or the loooking tags closed
*/
function myTagsLookingTags_onclose() {
    var flPanelLookingTags = ( $(this).prop("id").toLowerCase().indexOf("lookingtags") !== -1 ); //true if it is the lookingTags
    var listviewTarget = ( flPanelLookingTags === true ) ? "#listview_lookingtagslist" : "#listview_mytagslist";
    window.interface.saveLookingTags(flPanelLookingTags, listviewTarget);
}

/*
    show login dialog
*/
function loginOnFacebook() {
    FB.login(
        function (response) {
    		if (response.authResponse) {
    			showChoosePhotoButton();
    			showLogOutFacebookButton();
    		}
	    },
	    {scope:'user_photos'}
	);
}

/*
    show choose photo instead of log in on facebook
*/
function showChoosePhotoButton() {
    var _uiButton = $("#buttonFacebookPhoto");
    _uiButton.html('Choose your photo');
    _uiButton.click(choosePhotos);  
}

/*
    show the dialog for chosing the user photo
*/
function fbphotoSelect(id) {
		// if no user/friend id is sent, default to current user
		if (!id) id = 'me';

		var callbackAlbumSelected = function(albumId) {
			var album, name;
			album = CSPhotoSelector.getAlbumById(albumId);
			// show album photos
			selector.showPhotoSelector(null, album.id);
		};

		var callbackAlbumUnselected = function(albumId) {
			var album, name;
			album = CSPhotoSelector.getAlbumById(albumId);
		};

		var callbackPhotoSelected = function(photoId) {
			var photo;
			
			photo = CSPhotoSelector.getPhotoById(photoId);
			
			if ( typeof(photo.picture) === "string" ) {
			    var photoUrl = photo.picture;
			    window.interface.showValue("photo", photoUrl);
			    window.user.saveDataValue("photo", photoUrl);
			}
			
			//logActivity('Selected ID: ' + photo.id);
		};

// 		var callbackPhotoUnselected = function(photoId) {
// 			var photo;
// 			album = CSPhotoSelector.getPhotoById(photoId);
// 			//buttonOK.hide();
// 		};

// 		var callbackSubmit = function(photoId) {
// 			var photo;
// 			photo = CSPhotoSelector.getPhotoById(photoId);
// 			//logActivity('<br><strong>Submitted</strong><br> Photo ID: ' + photo.id + '<br>Photo URL: ' + photo.source + '<br>');
// 		};


		// Initialise the Photo Selector with options that will apply to all instances
		CSPhotoSelector.init({debug: true});

		// Create Photo Selector instances
		var selector = CSPhotoSelector.newInstance({
			callbackPhotoSelected	: callbackPhotoSelected,
 			callbackAlbumSelected	: callbackAlbumSelected,
 			callbackAlbumUnselected	: callbackAlbumUnselected,
// 			callbackPhotoUnselected	: callbackPhotoUnselected,
// 			callbackSubmit			: callbackSubmit,
			maxSelection			: 1,
			albumsPerPage			: 6,
			photosPerPage			: 200,
			autoDeselection			: true
		});

		// reset and show album selector
		selector.reset();
		selector.showAlbumSelector(id);
	}

/*
    choose a photos from facebook
*/
function choosePhotos() {
    fbphotoSelect();
}

/*
    logout from faceboo
*/
function logoutFacebook() {
    if ( FB ) {
        FB.logout(
            function(response) {
                if ( response ) {
                    showLogInFacebookButton();
                    
                }
            }
        );    
    }
}

/*
    show LogIn button for facebook and hide log out button
*/
function showLogInFacebookButton() {
  var _uiButton = $("#buttonFacebookPhoto");
  _uiButton.html('Log in');
  _uiButton.click(loginOnFacebook);
  $("#buttonFacebookLogout").hide();  
}

/*
    show LogIn button for facebook and hide log out button
*/
function showLogOutFacebookButton() {
  var _uiButton = $("#buttonFacebookLogout");
  _uiButton.show();
  _uiButton.click(logoutFacebook);  
}

/*
    set height for content div
*/
function setContentHeight() {
    var uiPage = $("#page_about"); 
    var uiHeader = uiPage.children("div.ui-header");
    var uiContent = uiPage.children("div.ui-content");
    var uiFooter = uiPage.children("div.ui-footer");
    
    var bodyHeight      = $.mobile.getScreenHeight();
    var uiHeaderHeight  = uiHeader.outerHeight(true);
    var uiFooterHeight  = uiFooter.outerHeight(true);
    
    var contentHeight = bodyHeight - uiHeaderHeight - uiFooterHeight - 10;
    uiContent.outerHeight(contentHeight);
    
}

/*
    on editing of a profile link is completed
    socialNetworkName - name of a social network
    profile - profile name in this social network
*/
function onSaveProfile( socialNetworkName, profile ){
    console.log(arguments);
}

/*
    on editing of all profiles links is completed
*/
function onSaveAllProfiles( profiles ){
    console.log(profiles);
    window.user.setSocialLinks(profiles);
}

/*
    show social profiles
*/
function showSocialProfiles() {
    window.user.getSocialLinks(
        function(links) {
            var _plugin = window["_integrationPlugins"].getPlugin("social-master");
            _plugin.showProfiles( $("[data-ui-sociallinks]"), links); //show the profiles on the tab tab_myTagsAndSocial when click on the button with attr = data-ui-sociallinks    
            _plugin.on("saveprofile",  onSaveProfile);
            _plugin.on("saveprofiles", onSaveAllProfiles);
        }
    );
}

/*
    before the page show
*/
function beforeShow() {
    if (FB != null
        && typeof(FB.getLoginStatus) === "function") {
            FB.getLoginStatus(
                function(response) { //check login status on facebook
                    if ( response.status === 'connected') { //if the user is logged
                        showChoosePhotoButton();
                        showLogOutFacebookButton();
                    } else {
                        showLogInFacebookButton();
                    }
                }
            );
    } else {
        showLogInFacebookButton();    
    }
    
    showSocialProfiles(); //show a links to the user socail profiles
    window.user.showTextUserData(); //show user data, that is a simple text information
    loadMyTagsLookingTags();     //user tags
    loadMyTagsLookingTags(true); //looking tags
}

/*
    when shown a page
*/
function onShow() {
    setContentHeight();
    window.interfacePlugins.interface.setVerticalScrolling();
    window.user.checkBlankProperties(); //ckeck for unfilled properties
}

this.scripts = {
    myTagsLookingTags_onclose : myTagsLookingTags_onclose,
    loadMyTagsLookingTags : loadMyTagsLookingTags,
    loginOnFacebook : loginOnFacebook,
    choosePhotos : choosePhotos
};

this.page = {
    onevent : { //events handlers for this page
        pagecontainerbeforeshow : beforeShow,
        pagecontainershow : onShow
    } 
};

this.elements = {
    panel_lookingtags : {
        onevent : { //events handlers for this page
            panelclose : myTagsLookingTags_onclose,
        }
    },
    panel_mytags : {
        onevent : { //events handlers for this page
            panelclose : myTagsLookingTags_onclose,
        }
    }
};