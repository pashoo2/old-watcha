/*global window*/
/*global $*/
/*global IScroll*/

/*
    befor the panel myTags will be opened
*/
function loadLookingTags() {
    window.interface.loadMyTagsLookingTags(true, "#page_lookingtags_listview_lookingtagslist", "#page_lookingtags_listview_availtagslist");
}

function saveLookingTags() {
    window.interface.saveLookingTags(true, "#page_lookingtags_listview_lookingtagslist");   
}

this.page = {
    onevent : { //events handlers for this page
        pagecontainerbeforeshow : loadLookingTags,
        pagecontainerbeforehide : saveLookingTags
    } 
};