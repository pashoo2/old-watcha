/*global $*/

/*
    show neighbor users lists (infiltrated and unfiltrated)
*/
function showNeighborUsers() {
    
    var user = window.user;
    var listVisible   = user.getNeighborUsers(true);
    var listInvisible = user.getNeighborUsers(false);
    
    debugger;
    var _uiVisibleList = $("#page_users-visible_users");
    _uiVisibleList.find("div").remove(); //clean the list firstly
    
    var _uiInvisibleList = $("#page_users-invisible_users");
    _uiInvisibleList.find("div").remove(); //clean the list firstly
    
    var i, ii, len, nUser, currentList, currentUIList;
    for( ii = 0; ii < 2; ii++ ) {
        
        if ( ii === 0 ) {
            currentList = listVisible; //show visible users
            currentUIList = _uiVisibleList;
        } else {
            currentList = listInvisible; //show invisible users
            currentUIList = _uiInvisibleList;
        }
        
        for( i = 0, len = currentList.length; i < len; i++ ) { //add users to the list
            nUser = currentList[i];
            addUserToUIList(currentUIList, nUser, true);
        }
        
        addUserToUIList(currentUIList); //refresh the list widget
        
    }
    
    setListenersForUsersEvents();
    
}

/*
    add the user into the list and add it
*/
function addUserToUIList(_uiList, nUser, flDoNotRefreshList) {
    if ( nUser != null ) {
        _uiList.append( "<div data-role='collapsible' data-ui-page_users-userlist-user-id='" + nUser.id + "'><h3>" +  nUser.represent() + "</h3>" + nUser.showDesc() + "</div>" );    
    }
    if ( flDoNotRefreshList !== true ) {
        _uiList.collapsibleset('refresh');
        _uiList.enhanceWithin();
    }
}

/*
    set the listeners for events, emiterd by the user
*/
function setListenersForUsersEvents() {
    var _interface = window.interface;
    _interface.on("removeUser", onNeighborUserGone);
    _interface.on("showUser"  , onNeighborUserShow);
}

/*
    show the neighbor user in the list
    nUser - instanceof NeighborUser
*/
function onNeighborUserShow(nUser) {
    var userID = nUser.id;
    var nUserUI = $('[data-ui-page_users-userlist-user-id="'+userID+'"]'); //try to find this user in the list
    if ( nUserUI.length === 0 ) { //if the user is absent in the current set
        var user = window.user;
        var uiList;
        if ( user.filterNeighborUser(nUser) === true ) { //if the user is invisible
            uiList = $("#page_users-invisible_users");
        } else {
            uiList = $("#page_users-visible_users");
        }
        
        addUserToUIList(uiList, nUser); //show in the ui list
    }
}

/*
    remove the neighbor user from the ui list
*/
function onNeighborUserGone(userID) {
    $('[data-ui-page_users-userlist-user-id="'+userID+'"]') //try to find the neighbor user into the list and remove it from the interface
    .hide("slow",
        function(){ 
            $(this).remove();
            $("#page_users-visible_users").collapsibleset( "refresh" );
            $("#page_users-invisible_users").collapsibleset( "refresh" );
        });
}

this.page = {
    onevent : { //events handlers for this page
        pagecontainerbeforeshow : showNeighborUsers
    } 
};